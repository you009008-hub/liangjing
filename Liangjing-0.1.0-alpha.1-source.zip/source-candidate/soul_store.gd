# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：全部覆盖写改为原子写；会话按文件缓存；坏行容忍；新增归档与彻底删除。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 本地灵魂仓库与知识库数据层。
# 管理资料导入、Office 转换、文本切片、轻量检索、会话历史、长期记忆和界面设置。
# 新用户的数据默认位于“文档/梁鲸灵魂仓库”；已有“蓝鲸灵魂仓库”会继续沿用，避免改名导致历史数据丢失。
class_name BlueWhaleSoulStore
extends RefCounted

const OfficeConverter = preload("res://office_to_markdown.gd")
const AtomicFile = preload("res://atomic_file.gd")
const STORE_VERSION := 1
const TEXT_EXTENSIONS := ["txt", "md", "markdown", "csv", "json", "log", "ini", "yaml", "yml"]
const CHUNK_SIZE := 900
const CHUNK_OVERLAP := 140
# [DSH] 仓库说明的版本标记：内容变化时改这里，老用户下次启动会自动刷新这份说明。
const GUIDE_REVISION := "2"

var root_path := ""
var inbox_path := ""
var originals_path := ""
var extracted_path := ""
var index_path := ""
var memory_path := ""
var conversations_path := ""
var backup_path := ""
var session_id := ""

func initialize(override_root := "") -> Dictionary:
	root_path = override_root.strip_edges()
	if root_path.is_empty():
		root_path = OS.get_environment("BLUE_WHALE_SOUL_ROOT").strip_edges()
	if root_path.is_empty():
		var executable_directory := OS.get_executable_path().get_base_dir()
		if FileAccess.file_exists(executable_directory.path_join("portable.mode")):
			root_path = executable_directory.path_join("梁鲸数据")
	if root_path.is_empty():
		var documents_path := OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
		var current_store := documents_path.path_join("梁鲸灵魂仓库")
		var legacy_store := documents_path.path_join("蓝鲸灵魂仓库")
		# 品牌改名后优先使用新目录；仅在旧目录已经存在且新目录尚未建立时兼容旧数据。
		root_path = legacy_store if DirAccess.dir_exists_absolute(legacy_store) and not DirAccess.dir_exists_absolute(current_store) else current_store
	root_path = root_path.replace("\\", "/")
	inbox_path = root_path.path_join("投喂箱")
	originals_path = root_path.path_join("知识库/原始文件")
	extracted_path = root_path.path_join("知识库/提取文本")
	index_path = root_path.path_join("知识库/索引")
	memory_path = root_path.path_join("记忆")
	conversations_path = root_path.path_join("会话")
	backup_path = root_path.path_join("备份")
	session_id = make_session_id()

	var paths := [
		root_path, inbox_path, originals_path, extracted_path,
		index_path, memory_path, conversations_path, backup_path
	]
	for path in paths:
		var error := DirAccess.make_dir_recursive_absolute(path)
		if error != OK and error != ERR_ALREADY_EXISTS:
			return {"ok": false, "error": "无法创建目录：%s" % path}

	ensure_json_file(profile_file(), {
		"version": STORE_VERSION,
		"display_name": "",
		"pet_name": "梁鲸",
		"created_at": now_string(),
		"preferences": {}
	})
	ensure_json_file(memory_file(), {"version": STORE_VERSION, "items": []})
	ensure_json_file(documents_file(), {"version": STORE_VERSION, "documents": []})
	ensure_json_file(import_settings_file(), default_import_settings())
	ensure_json_file(ui_settings_file(), default_ui_settings())
	ensure_store_guide()
	# 清掉上一次正好在写入时被杀而留下的 .tmp（原子写的临时文件与目标同目录）。
	for directory in [root_path, memory_path, conversations_path, index_path, root_path.path_join("配置")]:
		AtomicFile.sweep_stale_temps(directory)
	return {"ok": true, "root": root_path, "stats": get_stats()}

func append_message(role: String, content: String, metadata := {}) -> bool:
	var clean_content := content.strip_edges()
	if clean_content.is_empty() or session_id.is_empty() or is_conversation_deleted(session_id):
		return false
	var record := {
		"timestamp": now_string(),
		"session_id": session_id,
		"role": role,
		"content": clean_content,
		"metadata": metadata
	}
	# 会话是逐行追加的 jsonl，不能整文件重写（那会在中途被杀时丢掉整段历史）。
	# 追加本身也不保证原子：被强杀可能留下半行，读取端因此必须能跳过坏行，
	# 见 for_each_conversation_record()。
	var path := conversations_path.path_join("%s.jsonl" % Time.get_date_string_from_system())
	var file := FileAccess.open(path, FileAccess.READ_WRITE)
	if file == null:
		file = FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return false
	file.seek_end()
	file.store_line(JSON.stringify(record))
	file.flush()
	file.close()
	return true

# 会话记录与知识库索引的按文件缓存。
#
# 为什么需要：搜索框每敲一个字符都会调用 list_conversations，而它原先要把所有
# jsonl 逐行重新 JSON 解析一遍；每次提问也要把所有索引 JSON 重新读盘解析一遍。
# 历史或资料一多，输入和发送都会出现可感知的卡顿。
# 这里按文件修改时间做失效判断：没变过的文件只解析一次。会话文件是追加写的，
# 唯独“今天的文件”会被追加——它的 mtime 会变，于是自然失效重读，不会读到旧内容。
var _record_cache := {}
var _index_chunk_cache := {}

func _file_signature(path: String) -> String:
	# 修改时间 + 文件大小。只用 mtime 会漏掉“同一秒内的追加”（mtime 是秒级粒度，
	# 实测确实漏过，见 ATOMIC_WRITE_SELFTEST 的缓存断言）；加长度能覆盖追加这类
	# 最常见的改动，代价只是一次文件打开。
	# 仍然无法察觉“同一秒内、长度不变”的外部改写：那种情况请调用 clear_caches()
	# 强制重读。程序自身写入时会走 append_message / learn_inbox，不存在该风险。
	return "%s:%d" % [str(FileAccess.get_modified_time(path)), _file_size(path)]

func _file_size(path: String) -> int:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return -1
	var size := file.get_length()
	file.close()
	return size

# 知识库索引文件的缓存。索引文件写入后不再变动，按 mtime 缓存即可。
func _cached_index_documents() -> Array:
	var documents: Array = []
	var seen := {}
	for path in list_files_recursive(index_path, ["json"]):
		seen[path] = true
		var signature := _file_signature(path)
		var entry = _index_chunk_cache.get(path)
		if entry is Dictionary and str(entry.get("signature", "")) == signature:
			documents.append(entry.get("document", {}))
			continue
		var data := read_json(path, {})
		var document := {
			"source": str(data.get("source", path.get_file())),
			"chunks": data.get("chunks", [])
		}
		_index_chunk_cache[path] = {"signature": signature, "document": document}
		documents.append(document)
	# 删掉已经不存在的索引，避免缓存长期膨胀。
	for cached_path in _index_chunk_cache.keys():
		if not seen.has(cached_path):
			_index_chunk_cache.erase(cached_path)
	return documents

# 缓存自检与运维接口。
# 缓存的危险在于“读到旧数据”。这里暴露统计与清空，既方便自检断言失效逻辑，
# 也留一个在外部改动过数据目录后强制重读的入口。
func cache_stats() -> Dictionary:
	return {
		"conversation_files": _record_cache.size(),
		"index_files": _index_chunk_cache.size()
	}

func clear_caches() -> void:
	_record_cache.clear()
	_index_chunk_cache.clear()

# 遍历所有会话记录，返回其中的文件路径与记录，跳过损坏行。
# 桌面进程随时可能被强杀，jsonl 的最后一行可能是半截 JSON；这里静默跳过而不是
# 让整个会话列表或整段历史因为一行坏数据而消失。
func for_each_conversation_record(visitor: Callable) -> int:
	var parsed_count := 0
	var deleted := _deleted_conversation_ids()
	var files := list_files_recursive(conversations_path, ["jsonl"])
	files.sort()
	for path in files:
		var signature := _file_signature(path)
		var entry = _record_cache.get(path)
		var records: Array
		if entry is Dictionary and str(entry.get("signature", "")) == signature:
			records = entry.get("records", [])
		else:
			records = []
			var file := FileAccess.open(path, FileAccess.READ)
			if file == null:
				continue
			while not file.eof_reached():
				var line := file.get_line().strip_edges()
				if line.is_empty():
					continue
				var parsed = JSON.parse_string(line)
				if parsed is Dictionary:
					records.append(parsed)
			file.close()
			_record_cache[path] = {"signature": signature, "records": records}
		for record in records:
			if deleted.has(_record_conversation_id(record, path)):
				continue
			parsed_count += 1
			visitor.call(record, path)
	return parsed_count

func begin_conversation(title := "新对话", workspace := "", harness_session_id := "") -> String:
	session_id = make_session_id()
	append_message("system", "会话已建立", {
		"hidden": true,
		"title": title.strip_edges() if not title.strip_edges().is_empty() else "新对话",
		"workspace": workspace.replace("\\", "/"),
		"harness_session_id": harness_session_id
	})
	return session_id

func select_conversation(conversation_id: String) -> bool:
	var clean_id := conversation_id.strip_edges()
	if clean_id.is_empty() or is_conversation_deleted(clean_id):
		return false
	session_id = clean_id
	return true

# 一天的 JSONL 可能混有多个会话，删除一段历史不能改写或移动整个文件。
# 用独立的回收标记屏蔽该 ID，原始记录保留；写入失败时历史仍然可见。
# 不调用 Harness 删除接口，也不改知识库或长期记忆。
func conversation_recycle_path() -> String:
	return root_path.path_join("回收站/会话")

func _conversation_delete_file(conversation_id: String) -> String:
	return conversation_recycle_path().path_join(conversation_id.sha256_text() + ".json")

func _record_conversation_id(record: Dictionary, path: String) -> String:
	var record_id := str(record.get("session_id", "")).strip_edges()
	return record_id if not record_id.is_empty() else "legacy-%s" % path.get_file().get_basename()

func _deleted_conversation_ids() -> Dictionary:
	var deleted := {}
	if root_path.is_empty() or not DirAccess.dir_exists_absolute(conversation_recycle_path()):
		return deleted
	for file_name in DirAccess.get_files_at(conversation_recycle_path()):
		if not file_name.ends_with(".json"):
			continue
		var entry := read_json(conversation_recycle_path().path_join(file_name), {})
		var deleted_id := str(entry.get("conversation_id", ""))
		if not deleted_id.is_empty() and file_name == deleted_id.sha256_text() + ".json":
			deleted[deleted_id] = true
	return deleted

func is_conversation_deleted(conversation_id: String) -> bool:
	if root_path.is_empty() or conversation_id.is_empty():
		return false
	var entry := read_json(_conversation_delete_file(conversation_id), {})
	return str(entry.get("conversation_id", "")) == conversation_id

func delete_conversation(conversation_id: String) -> Dictionary:
	var clean_id := conversation_id.strip_edges()
	if root_path.is_empty() or clean_id.is_empty():
		return {"ok": false, "error": "没有可删除的本机会话。"}
	if is_conversation_deleted(clean_id):
		return {"ok": true, "already_deleted": true, "conversation_id": clean_id}
	var matching: Array = []
	for_each_conversation_record(func(record: Dictionary, path: String) -> void:
		if _record_conversation_id(record, path) == clean_id:
			matching.append(true)
	)
	if matching.is_empty():
		return {"ok": false, "error": "该本机会话已不存在。"}
	var directory_error := DirAccess.make_dir_recursive_absolute(conversation_recycle_path())
	if directory_error != OK and directory_error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法保存回收标记，会话没有删除。"}
	var marker_path := _conversation_delete_file(clean_id)
	var marker := {
		"version": 1,
		"conversation_id": clean_id,
		"deleted_at": now_string(),
		"record_count": matching.size(),
		"storage": "original-jsonl-retained"
	}
	if not write_json(marker_path, marker):
		return {"ok": false, "error": "无法保存回收标记，会话没有删除。"}
	return {
		"ok": true,
		"conversation_id": clean_id,
		"was_active": session_id == clean_id,
		"recycle_marker": marker_path,
		"message": "已从本机历史删除，可撤销。"
	}

func restore_conversation(conversation_id: String) -> Dictionary:
	var clean_id := conversation_id.strip_edges()
	if not is_conversation_deleted(clean_id):
		return {"ok": false, "error": "没有找到该会话的回收标记。"}
	# 彻底删除留下的标记不能被"撤销"移除：jsonl 里的记录已经不在了，
	# 把标记删掉只会让列表恢复出一个没有任何内容的空会话（而且看起来像数据回来了）。
	var entry := read_json(_conversation_delete_file(clean_id), {})
	if str(entry.get("storage", "")) == "erased-from-jsonl":
		return {"ok": false, "error": "该会话已被彻底删除，无法恢复。"}
	# 路径只使用 ID 的 SHA256，不能由会话标题或 ID 拼成任意文件路径。
	if DirAccess.remove_absolute(_conversation_delete_file(clean_id)) != OK:
		return {"ok": false, "error": "暂时无法恢复该会话。"}
	return {"ok": true, "conversation_id": clean_id}

# ── 彻底删除 ─────────────────────────────────────────────────────────
# 与上面的"删除"（软删除，原始记录保留、可撤销）不同，这里会把该会话的记录
# 从本机 jsonl 里真正移除，并留下回收站标记防止旧备份把已删记录带回列表。
#
# 之所以要标记：会话按天写进同一个 jsonl，一次删除只影响其中若干行；
# 而删除之后用户仍可能新建同名会话或用旧文件覆盖，标记能让"已删"这个状态稳定。
func erase_conversation(conversation_id: String) -> Dictionary:
	var clean_id := conversation_id.strip_edges()
	if root_path.is_empty() or clean_id.is_empty():
		return {"ok": false, "error": "没有可彻底删除的本机会话。"}
	var removed_records := 0
	var touched_files := 0
	var failed_files: Array[String] = []
	var files := list_files_recursive(conversations_path, ["jsonl"])
	files.sort()
	for path in files:
		var file := FileAccess.open(path, FileAccess.READ)
		if file == null:
			continue
		var kept_lines: Array[String] = []
		var removed_here := 0
		while not file.eof_reached():
			var line := file.get_line()
			var trimmed := line.strip_edges()
			if trimmed.is_empty():
				continue
			var parsed = JSON.parse_string(trimmed)
			if parsed is Dictionary and _record_conversation_id(parsed, path) == clean_id:
				removed_here += 1
				continue
			# 逐字保留未被删除的行（包括损坏行），只剔除目标会话。
			kept_lines.append(line)
		file.close()
		if removed_here == 0:
			continue
		touched_files += 1
		removed_records += removed_here
		if kept_lines.is_empty():
			# 文件里只剩这个会话：整体删掉，避免留下一堆空 jsonl。
			if DirAccess.remove_absolute(path) != OK and FileAccess.file_exists(path):
				failed_files.append(path)
			continue
		# 重写必须是原子的：这一步在删除用户数据，中途被杀不能留下半截文件。
		if not AtomicFile.write_text(path, "\n".join(kept_lines) + "\n"):
			failed_files.append(path)
	if removed_records == 0 and not is_conversation_deleted(clean_id):
		return {"ok": false, "error": "该本机会话已不存在。"}
	if not failed_files.is_empty():
		# 有文件没能重写：不要写标记，保持可重试，并如实报告。
		return {
			"ok": false,
			"error": "部分文件无法重写，会话没有完全删除：%s" % ", ".join(failed_files),
			"removed_records": removed_records
		}
	# 磁盘上的记录已经变了，缓存必须立刻失效，否则列表还会显示已删会话。
	clear_caches()
	var marker_path := _conversation_delete_file(clean_id)
	DirAccess.make_dir_recursive_absolute(conversation_recycle_path())
	var marker := {
		"version": 1,
		"conversation_id": clean_id,
		"deleted_at": now_string(),
		"record_count": removed_records,
		"storage": "erased-from-jsonl",
		"erased_files": touched_files
	}
	if not write_json(marker_path, marker):
		# 记录已经删掉了，标记写不上只是防不了旧备份，不算失败，但要如实说明。
		return {
			"ok": true,
			"conversation_id": clean_id,
			"erased": true,
			"removed_records": removed_records,
			"warning": "记录已删除，但回收标记写入失败；若恢复旧备份，该会话可能重新出现。"
		}
	return {
		"ok": true,
		"conversation_id": clean_id,
		"erased": true,
		"removed_records": removed_records,
		"erased_files": touched_files,
		"message": "已从本机彻底删除，不可撤销。"
	}

# ── 归档 ─────────────────────────────────────────────────────────────
# 归档只改变列表归属，不动 jsonl 内容，因此完全可逆，也不会影响会话内容本身。
func conversation_archive_path() -> String:
	return root_path.path_join("归档/会话")

func _conversation_archive_file(conversation_id: String) -> String:
	return conversation_archive_path().path_join(conversation_id.sha256_text() + ".json")

func is_conversation_archived(conversation_id: String) -> bool:
	if root_path.is_empty() or conversation_id.is_empty():
		return false
	var entry := read_json(_conversation_archive_file(conversation_id), {})
	return str(entry.get("conversation_id", "")) == conversation_id

func _archived_conversation_ids() -> Dictionary:
	var archived := {}
	if root_path.is_empty() or not DirAccess.dir_exists_absolute(conversation_archive_path()):
		return archived
	for file_name in DirAccess.get_files_at(conversation_archive_path()):
		if not file_name.ends_with(".json"):
			continue
		var entry := read_json(conversation_archive_path().path_join(file_name), {})
		var archived_id := str(entry.get("conversation_id", ""))
		if not archived_id.is_empty() and file_name == archived_id.sha256_text() + ".json":
			archived[archived_id] = true
	return archived

func archive_conversation(conversation_id: String) -> Dictionary:
	var clean_id := conversation_id.strip_edges()
	if root_path.is_empty() or clean_id.is_empty():
		return {"ok": false, "error": "没有可归档的本机会话。"}
	if is_conversation_deleted(clean_id):
		return {"ok": false, "error": "该会话已被删除，无法归档。"}
	if is_conversation_archived(clean_id):
		return {"ok": true, "already_archived": true, "conversation_id": clean_id}
	var directory_error := DirAccess.make_dir_recursive_absolute(conversation_archive_path())
	if directory_error != OK and directory_error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法创建归档目录。"}
	# 用回收站同一套 sha256 命名规则：ID 不能拼成任意路径。
	if not write_json(_conversation_archive_file(clean_id), {
		"version": 1,
		"conversation_id": clean_id,
		"archived_at": now_string(),
		"storage": "original-jsonl-retained"
	}):
		return {"ok": false, "error": "无法写入归档标记。"}
	return {"ok": true, "conversation_id": clean_id, "message": "已归档，可在“已归档”里找到。"}

func unarchive_conversation(conversation_id: String) -> Dictionary:
	var clean_id := conversation_id.strip_edges()
	if not is_conversation_archived(clean_id):
		return {"ok": false, "error": "该会话不在归档中。"}
	if DirAccess.remove_absolute(_conversation_archive_file(clean_id)) != OK:
		return {"ok": false, "error": "暂时无法取消归档。"}
	return {"ok": true, "conversation_id": clean_id, "message": "已移出归档。"}

# ── [DSH] 回收站清理 ─────────────────────────────────────────────────
# "隐藏"与"彻底删除"都会在回收站里留下一个标记文件。它们很小，但会永久累积，
# 而用户没有任何清空的入口——这里提供查询与清理。
func recycle_usage() -> Dictionary:
	var markers := 0
	var bytes := 0
	for directory in [conversation_recycle_path(), conversation_archive_path()]:
		if not DirAccess.dir_exists_absolute(directory):
			continue
		for file_name in DirAccess.get_files_at(directory):
			if not file_name.ends_with(".json"):
				continue
			markers += 1
			bytes += get_file_size(directory.path_join(file_name))
	return {
		"markers": markers, "bytes": bytes,
		"archive": conversation_archive_path(), "recycle": conversation_recycle_path()
	}

# 清理回收站标记。erased_only=true（默认）时只清"记录已经被真删掉"的标记；
# 隐藏标记必须留着，否则用户会以为刚隐藏的会话又自己回来了。
# 本操作只删除标记文件，不触碰任何会话内容，因此不会造成数据丢失。
func purge_recycle_markers(erased_only := true) -> Dictionary:
	if root_path.is_empty():
		return {"ok": false, "error": "灵魂仓库尚未就绪。"}
	var directory := conversation_recycle_path()
	if not DirAccess.dir_exists_absolute(directory):
		return {"ok": true, "removed": 0, "message": "回收站本来就是空的。"}
	var removed := 0
	var skipped := 0
	for file_name in DirAccess.get_files_at(directory):
		if not file_name.ends_with(".json"):
			continue
		var path := directory.path_join(file_name)
		var entry := read_json(path, {})
		var erased := str(entry.get("storage", "")) == "erased-from-jsonl"
		if erased_only and not erased:
			skipped += 1
			continue
		if DirAccess.remove_absolute(path) == OK:
			removed += 1
		else:
			skipped += 1
	var suffix := "，保留 %d 个隐藏标记" % skipped if skipped > 0 else ""
	return {"ok": true, "removed": removed, "skipped": skipped, "message": "已清理 %d 个回收标记%s。" % [removed, suffix]}

func list_conversations(limit := 80, search_text := "") -> Array:
	var grouped := {}
	for_each_conversation_record(func(record: Dictionary, path: String) -> void:
		var record_session := _record_conversation_id(record, path)
		if not grouped.has(record_session):
			grouped[record_session] = {
				"id": record_session,
				"title": "新对话",
				"created_at": str(record.get("timestamp", "")),
				"updated_at": str(record.get("timestamp", "")),
				"workspace": "",
				"harness_session_id": "",
				"message_count": 0
			}
		var summary: Dictionary = grouped[record_session]
		var timestamp := str(record.get("timestamp", ""))
		if str(summary.get("created_at", "")).is_empty() or timestamp < str(summary.get("created_at", "")):
			summary["created_at"] = timestamp
		if timestamp > str(summary.get("updated_at", "")):
			summary["updated_at"] = timestamp
		var metadata: Dictionary = record.get("metadata", {}) if record.get("metadata", {}) is Dictionary else {}
		var metadata_title := str(metadata.get("title", "")).strip_edges()
		if not metadata_title.is_empty():
			summary["title"] = metadata_title
		var workspace := str(metadata.get("workspace", "")).strip_edges()
		if not workspace.is_empty():
			summary["workspace"] = workspace
		var harness_id := str(metadata.get("harness_session_id", "")).strip_edges()
		if not harness_id.is_empty():
			summary["harness_session_id"] = harness_id
		if str(record.get("role", "")) == "user":
			summary["message_count"] = int(summary.get("message_count", 0)) + 1
			if str(summary.get("title", "")) == "新对话":
				summary["title"] = conversation_title_from_text(str(record.get("content", "")))
		grouped[record_session] = summary
	)
	var conversations: Array = grouped.values()
	conversations.sort_custom(func(left: Dictionary, right: Dictionary) -> bool:
		return str(left.get("updated_at", "")) > str(right.get("updated_at", ""))
	)
	# 归档状态在这里一次性标注，避免界面为每个会话单独读一次标记文件。
	var archived_ids := _archived_conversation_ids()
	var needle := search_text.strip_edges().to_lower()
	var filtered: Array = []
	for conversation_value in conversations:
		if not conversation_value is Dictionary:
			continue
		var conversation: Dictionary = conversation_value
		conversation["archived"] = archived_ids.has(str(conversation.get("id", "")))
		if not needle.is_empty():
			var haystack := "%s %s" % [str(conversation.get("title", "")), str(conversation.get("workspace", ""))]
			if not haystack.to_lower().contains(needle):
				continue
		filtered.append(conversation)
		if filtered.size() >= limit:
			break
	return filtered

func load_conversation(conversation_id: String, limit := 500) -> Array:
	var records: Array = []
	for_each_conversation_record(func(record: Dictionary, path: String) -> void:
		if _record_conversation_id(record, path) != conversation_id:
			return
		var metadata: Dictionary = record.get("metadata", {}) if record.get("metadata", {}) is Dictionary else {}
		if bool(metadata.get("hidden", false)):
			return
		if str(record.get("role", "")) in ["user", "assistant"]:
			records.append(record)
	)
	if records.size() > limit:
		return records.slice(records.size() - limit)
	return records

func conversation_context(conversation_id: String, limit := 12) -> String:
	var records := load_conversation(conversation_id, limit)
	var lines: Array[String] = []
	for record_value in records:
		if not record_value is Dictionary:
			continue
		var record: Dictionary = record_value
		var speaker := "用户" if str(record.get("role", "")) == "user" else "助手"
		var content := str(record.get("content", "")).strip_edges()
		if content.length() > 900:
			content = content.left(900) + "……"
		if not content.is_empty():
			lines.append("%s：%s" % [speaker, content])
	return "\n".join(lines)

func recent_messages(limit := 30) -> Array:
	# 先按“最新的文件在前、文件内由后往前”收集，凑满 limit 后反转成时间正序返回。
	var by_file := {}
	var order: Array[String] = []
	for_each_conversation_record(func(record: Dictionary, path: String) -> void:
		if not by_file.has(path):
			by_file[path] = []
			order.append(path)
		by_file[path].append(record)
	)
	order.reverse()
	var records: Array = []
	for path in order:
		var current: Array = by_file[path]
		current.reverse()
		for item in current:
			records.append(item)
			if records.size() >= limit:
				records.reverse()
				return records
	records.reverse()
	return records

func remember(text: String, kind := "fact", source := "conversation") -> Dictionary:
	var clean_text := text.strip_edges()
	if clean_text.is_empty():
		return {"ok": false, "message": "没有可保存的内容。"}
	var data := read_json(memory_file(), {"version": STORE_VERSION, "items": []})
	var items: Array = data.get("items", [])
	for item in items:
		if item is Dictionary and str(item.get("text", "")).to_lower() == clean_text.to_lower():
			return {"ok": true, "duplicate": true, "message": "这件事我已经记住了。"}
	items.append({
		"id": make_id(clean_text),
		"text": clean_text,
		"kind": kind,
		"source": source,
		"created_at": now_string(),
		"updated_at": now_string(),
		"active": true
	})
	data["items"] = items
	var saved := write_json(memory_file(), data)
	return {"ok": saved, "message": "记住了：%s" % clean_text}

func forget(text: String) -> Dictionary:
	var clean_text := text.strip_edges().to_lower()
	if clean_text.is_empty():
		return {"ok": false, "message": "请告诉我要忘记什么。"}
	var data := read_json(memory_file(), {"version": STORE_VERSION, "items": []})
	var items: Array = data.get("items", [])
	var removed := 0
	for item in items:
		if not item is Dictionary:
			continue
		var memory_text := str(item.get("text", "")).to_lower()
		if memory_text.contains(clean_text):
			item["active"] = false
			item["updated_at"] = now_string()
			removed += 1
	data["items"] = items
	write_json(memory_file(), data)
	if removed == 0:
		return {"ok": true, "removed": 0, "message": "没有找到相关长期记忆。"}
	return {"ok": true, "removed": removed, "message": "已经忘记 %d 条相关记忆。" % removed}

func active_memories() -> Array:
	var data := read_json(memory_file(), {"version": STORE_VERSION, "items": []})
	var result: Array = []
	for item in data.get("items", []):
		if item is Dictionary and bool(item.get("active", true)):
			result.append(item)
	return result

func learn_inbox() -> Dictionary:
	var catalog := read_json(documents_file(), {"version": STORE_VERSION, "documents": []})
	var import_settings := get_import_settings()
	var documents: Array = catalog.get("documents", [])
	var known_hashes := {}
	for document in documents:
		if document is Dictionary:
			known_hashes[str(document.get("hash", ""))] = true

	var learned := 0
	var stored_pending := 0
	var skipped := 0
	var failed := 0
	var source_files: Array = list_files_recursive(inbox_path)
	for source_value in source_files:
		var source_path: String = str(source_value)
		var file_hash: String = FileAccess.get_md5(source_path)
		if file_hash.is_empty():
			failed += 1
			continue
		if known_hashes.has(file_hash):
			skipped += 1
			continue
		var source_name: String = source_path.get_file()
		var stored_name: String = "%s_%s" % [file_hash.left(10), source_name]
		var stored_path: String = originals_path.path_join(stored_name)
		var copy_error: Error = DirAccess.copy_absolute(source_path, stored_path)
		if copy_error != OK:
			failed += 1
			continue
		var extension: String = source_name.get_extension().to_lower()
		var status: String = "stored_pending_parser"
		var chunk_count := 0
		var converted_to_markdown := false
		var extracted_file_path := ""
		var extracted_text := ""
		if extension in TEXT_EXTENSIONS:
			extracted_text = FileAccess.get_file_as_string(stored_path)
		elif extension == "docx" and bool(import_settings.get("convert_docx", true)):
			var converted_docx: Dictionary = OfficeConverter.new().convert(stored_path)
			if bool(converted_docx.get("ok", false)):
				extracted_text = str(converted_docx.get("text", ""))
				converted_to_markdown = true
		elif extension == "xlsx" and bool(import_settings.get("convert_xlsx", true)):
			var converted_xlsx: Dictionary = OfficeConverter.new().convert(stored_path)
			if bool(converted_xlsx.get("ok", false)):
				extracted_text = str(converted_xlsx.get("text", ""))
				converted_to_markdown = true
		if not extracted_text.strip_edges().is_empty():
			var extracted_extension := "md" if converted_to_markdown else "txt"
			extracted_file_path = extracted_path.path_join("%s.%s" % [file_hash, extracted_extension])
			var text_file := FileAccess.open(extracted_file_path, FileAccess.WRITE)
			if text_file:
				text_file.store_string(extracted_text)
				text_file.close()
			var chunks: Array = chunk_text(extracted_text, import_settings)
			chunk_count = chunks.size()
			write_json(index_path.path_join("%s.json" % file_hash), {
				"document_id": file_hash,
				"source": source_name,
				"converted_to_markdown": converted_to_markdown,
				"chunks": chunks
			})
			status = "indexed"
			learned += 1
		elif extension in TEXT_EXTENSIONS:
			status = "empty"
			stored_pending += 1
		else:
			stored_pending += 1
		documents.append({
			"id": file_hash,
			"hash": file_hash,
			"name": source_name,
			"source_path": source_path,
			"stored_path": stored_path,
			"extension": extension,
			"size": get_file_size(stored_path),
			"status": status,
			"converted_to_markdown": converted_to_markdown,
			"extracted_path": extracted_file_path,
			"chunk_count": chunk_count,
			"learned_at": now_string()
		})
		known_hashes[file_hash] = true
	catalog["documents"] = documents
	write_json(documents_file(), catalog)
	return {
		"ok": failed == 0,
		"learned": learned,
		"pending": stored_pending,
		"skipped": skipped,
		"failed": failed,
		"total": documents.size()
	}

func inspect_attachment(source_path: String) -> Dictionary:
	var normalized_source := source_path.replace("\\", "/")
	if not FileAccess.file_exists(normalized_source):
		return {"ok": false, "message": "没有找到这个附件。"}
	var source_name := normalized_source.get_file()
	var extension := source_name.get_extension().to_lower()
	var extracted_text := ""
	var parser := ""
	if extension in TEXT_EXTENSIONS:
		extracted_text = FileAccess.get_file_as_string(normalized_source)
		parser = "本地文本解析"
	elif extension in ["docx", "xlsx"]:
		var converted: Dictionary = OfficeConverter.new().convert(normalized_source)
		if bool(converted.get("ok", false)):
			extracted_text = str(converted.get("text", ""))
			parser = "Word 转 Markdown" if extension == "docx" else "Excel 转 Markdown 表格"
		else:
			return {
				"ok": false,
				"name": source_name,
				"extension": extension,
				"message": str(converted.get("error", "附件解析失败。"))
			}
	elif extension in ["png", "jpg", "jpeg", "webp", "bmp"]:
		return {
			"ok": true,
			"recognized": false,
			"requires_vision": true,
			"name": source_name,
			"path": normalized_source,
			"extension": extension,
			"size": get_file_size(normalized_source),
			"parser": "视觉模型",
			"message": "图片已就绪，将交给已配置的视觉模型识别。"
		}
	else:
		return {
			"ok": true,
			"recognized": false,
			"requires_parser": true,
			"name": source_name,
			"path": normalized_source,
			"extension": extension,
			"size": get_file_size(normalized_source),
			"parser": "待扩展解析器",
			"message": "附件已就绪，但当前版本还不能提取这种格式的正文。"
		}
	var clean_text := extracted_text.strip_edges()
	return {
		"ok": not clean_text.is_empty(),
		"recognized": not clean_text.is_empty(),
		"name": source_name,
		"path": normalized_source,
		"extension": extension,
		"size": get_file_size(normalized_source),
		"parser": parser,
		"text": clean_text,
		"characters": clean_text.length(),
		"message": "已在本地识别 %d 个字符。" % clean_text.length()
	}

func attachment_excerpt(attachment: Dictionary, query: String, maximum_length := 520) -> String:
	var text := str(attachment.get("text", "")).strip_edges()
	if text.is_empty():
		return ""
	var settings := get_import_settings()
	var chunks: Array = chunk_text(text, settings)
	if chunks.is_empty():
		return text.left(maximum_length)
	var tokens := query_tokens(query.to_lower())
	var best_text := str(Dictionary(chunks[0]).get("text", ""))
	var best_score := -1.0
	for chunk_value in chunks:
		var chunk: Dictionary = chunk_value
		var candidate := str(chunk.get("text", ""))
		var lowered := candidate.to_lower()
		var score := 0.0
		for token_value in tokens:
			var token := str(token_value)
			if lowered.contains(token):
				score += 2.0 + minf(4.0, float(lowered.count(token)))
		if score > best_score:
			best_score = score
			best_text = candidate
	best_text = best_text.replace("\n", " ").strip_edges()
	return best_text.left(maximum_length) + ("……" if best_text.length() > maximum_length else "")

func import_path(source_path: String) -> Dictionary:
	var normalized_source := source_path.replace("\\", "/").trim_suffix("/")
	var is_file := FileAccess.file_exists(normalized_source)
	var is_directory := DirAccess.dir_exists_absolute(normalized_source)
	if not is_file and not is_directory:
		return {"ok": false, "copied": 0, "failed": 1, "message": "没有找到所选资料。"}
	var stamp := Time.get_datetime_string_from_system().replace(":", "").replace("-", "").replace("T", "_")
	var batch_path := inbox_path.path_join("导入_%s_%s" % [stamp, str(Time.get_ticks_msec())])
	var create_error := DirAccess.make_dir_recursive_absolute(batch_path)
	if create_error != OK and create_error != ERR_ALREADY_EXISTS:
		return {"ok": false, "copied": 0, "failed": 1, "message": "无法创建本地投喂目录。"}
	var stats := {"copied": 0, "failed": 0, "skipped_links": 0}
	var destination := batch_path.path_join(normalized_source.get_file())
	copy_import_source(normalized_source, destination, stats)
	return {
		"ok": int(stats["failed"]) == 0 and int(stats["copied"]) > 0,
		"copied": int(stats["copied"]),
		"failed": int(stats["failed"]),
		"skipped_links": int(stats["skipped_links"]),
		"batch_path": batch_path,
		"message": "已复制 %d 个文件到本地投喂箱。" % int(stats["copied"])
	}

func copy_import_source(source_path: String, destination_path: String, stats: Dictionary) -> void:
	if FileAccess.file_exists(source_path):
		var parent_error := DirAccess.make_dir_recursive_absolute(destination_path.get_base_dir())
		if parent_error != OK and parent_error != ERR_ALREADY_EXISTS:
			stats["failed"] = int(stats["failed"]) + 1
			return
		var copy_error := DirAccess.copy_absolute(source_path, destination_path)
		if copy_error == OK:
			stats["copied"] = int(stats["copied"]) + 1
		else:
			stats["failed"] = int(stats["failed"]) + 1
		return
	var source_directory := DirAccess.open(source_path)
	if source_directory == null:
		stats["failed"] = int(stats["failed"]) + 1
		return
	var directory_error := DirAccess.make_dir_recursive_absolute(destination_path)
	if directory_error != OK and directory_error != ERR_ALREADY_EXISTS:
		stats["failed"] = int(stats["failed"]) + 1
		return
	source_directory.list_dir_begin()
	var name := source_directory.get_next()
	while not name.is_empty():
		if name != "." and name != ".." and not name.begins_with("."):
			if source_directory.is_link(name):
				stats["skipped_links"] = int(stats["skipped_links"]) + 1
			else:
				copy_import_source(source_path.path_join(name), destination_path.path_join(name), stats)
		name = source_directory.get_next()
	source_directory.list_dir_end()

func search_knowledge(query: String, limit := 3) -> Array:
	var clean_query := query.strip_edges().to_lower()
	if clean_query.is_empty():
		return []
	var tokens := query_tokens(clean_query)
	var results: Array = []
	for indexed_document in _cached_index_documents():
		var source := str(indexed_document.get("source", ""))
		var chunks: Array = indexed_document.get("chunks", [])
		for chunk in chunks:
			if not chunk is Dictionary:
				continue
			var text := str(chunk.get("text", ""))
			var lowered := text.to_lower()
			var score := 0.0
			if lowered.contains(clean_query):
				score += 30.0
			for token in tokens:
				var token_text := str(token)
				if lowered.contains(token_text):
					score += 2.0 + minf(4.0, float(lowered.count(token_text)))
			if score > 0.0:
				results.append({
					"score": score,
					"source": source,
					"text": text,
					"chunk": int(chunk.get("index", 0))
				})
	results.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return float(a.get("score", 0.0)) > float(b.get("score", 0.0))
	)
	var limited: Array = []
	for item in results:
		limited.append(item)
		if limited.size() >= limit:
			break
	return limited

func get_stats() -> Dictionary:
	var catalog := read_json(documents_file(), {"documents": []})
	var documents: Array = catalog.get("documents", [])
	var indexed := 0
	var pending := 0
	for document in documents:
		if not document is Dictionary:
			continue
		if str(document.get("status", "")) == "indexed":
			indexed += 1
		else:
			pending += 1
	return {
		"memories": active_memories().size(),
		"documents": documents.size(),
		"indexed": indexed,
		"pending": pending,
		"root": root_path
	}

func chunk_text(text: String, settings: Dictionary = {}) -> Array:
	var normalized := text.replace("\r\n", "\n").replace("\r", "\n").strip_edges()
	var chunks: Array = []
	if normalized.is_empty():
		return chunks
	var chunk_size := clampi(int(settings.get("chunk_size", CHUNK_SIZE)), 300, 4000)
	var chunk_overlap := clampi(int(settings.get("chunk_overlap", CHUNK_OVERLAP)), 0, int(chunk_size / 2))
	var start := 0
	var index := 0
	while start < normalized.length():
		var end := mini(normalized.length(), start + chunk_size)
		if end < normalized.length():
			var boundary := normalized.rfind("\n", end)
			if boundary > start + int(chunk_size * 0.55):
				end = boundary
		var content := normalized.substr(start, end - start).strip_edges()
		if not content.is_empty():
			chunks.append({"index": index, "text": content})
			index += 1
		if end >= normalized.length():
			break
		start = maxi(start + 1, end - chunk_overlap)
	return chunks

func query_tokens(query: String) -> Array:
	var tokens: Array = []
	for part in query.replace("，", " ").replace("。", " ").replace("？", " ").replace("?", " ").split(" ", false):
		var token := str(part).strip_edges()
		if token.length() >= 2 and not tokens.has(token):
			tokens.append(token)
	if query.length() >= 2:
		for index in range(query.length() - 1):
			var pair := query.substr(index, 2).strip_edges()
			if pair.length() == 2 and not tokens.has(pair):
				tokens.append(pair)
	return tokens

func list_files_recursive(directory: String, extensions: Array = []) -> Array:
	var result: Array = []
	var dir := DirAccess.open(directory)
	if dir == null:
		return result
	dir.list_dir_begin()
	var name := dir.get_next()
	while not name.is_empty():
		if name != "." and name != ".." and not name.begins_with("."):
			var path := directory.path_join(name)
			if dir.current_is_dir():
				result.append_array(list_files_recursive(path, extensions))
			elif extensions.is_empty() or name.get_extension().to_lower() in extensions:
				result.append(path)
		name = dir.get_next()
	dir.list_dir_end()
	return result

func profile_file() -> String:
	return memory_path.path_join("用户档案.json")

func memory_file() -> String:
	return memory_path.path_join("长期记忆.json")

func documents_file() -> String:
	return root_path.path_join("知识库/资料目录.json")

func import_settings_file() -> String:
	return root_path.path_join("知识库/导入配置.json")

func ui_settings_file() -> String:
	return root_path.path_join("界面配置.json")

func default_ui_settings() -> Dictionary:
	return {
		"version": 1,
		"chat_workspace": {
			"position": [27, 205],
			"size": [746, 627]
		},
		"analysis_panel": {
			"position": [788, 214],
			"size": [419, 609]
		},
		"app_window": {
			"position": [],
			"size": [271, 522]
		},
		# 主动开口必须由用户显式开启，旧配置不能因为缺少新字段而自动启用。
		"proactive_enabled": false,
		"proactive_opt_in": false,
		# [DSH] 窗口置顶默认关闭：用户反馈"一直置顶体验很差"。
		"window_topmost": false
	}

func get_ui_settings() -> Dictionary:
	var defaults := default_ui_settings()
	var settings := read_json(ui_settings_file(), defaults)
	for key in ["chat_workspace", "analysis_panel", "app_window"]:
		if not settings.has(key) or not settings[key] is Dictionary:
			settings[key] = defaults[key]
	# [DSH] 布尔开关：缺失时补默认值。这类"用户开关"必须能读回来，
	# 否则用户关掉之后重启又会被打开（等于开关无效）。
	if not settings.has("proactive_enabled"):
		settings["proactive_enabled"] = bool(defaults.get("proactive_enabled", false))
	if not settings.has("proactive_opt_in"):
		settings["proactive_opt_in"] = false
	if not settings.has("window_topmost"):
		settings["window_topmost"] = bool(defaults.get("window_topmost", false))
	return settings

func save_ui_settings(settings: Dictionary) -> bool:
	# [DSH] 注意：这里是从 default_ui_settings() 重建字典，**未显式搬运的键会被丢弃**。
	# 新增设置项时必须同时改 get/save/默认值三处，否则表现为"设置保存不了"。
	var normalized := default_ui_settings()
	normalized["proactive_enabled"] = bool(settings.get("proactive_enabled", normalized.get("proactive_enabled", false)))
	normalized["proactive_opt_in"] = bool(settings.get("proactive_opt_in", normalized.get("proactive_opt_in", false)))
	normalized["window_topmost"] = bool(settings.get("window_topmost", normalized.get("window_topmost", false)))
	for key in ["chat_workspace", "analysis_panel"]:
		var value: Dictionary = settings.get(key, {})
		var fallback: Dictionary = normalized[key]
		var position: Array = value.get("position", fallback["position"])
		var size: Array = value.get("size", fallback["size"])
		if position.size() >= 2 and size.size() >= 2:
			normalized[key] = {
				"position": [int(position[0]), int(position[1])],
				"size": [int(size[0]), int(size[1])]
			}
	var app_value: Dictionary = settings.get("app_window", {})
	var app_fallback: Dictionary = normalized["app_window"]
	var app_position: Array = app_value.get("position", app_fallback["position"])
	var app_size: Array = app_value.get("size", app_fallback["size"])
	if app_size.size() >= 2:
		normalized["app_window"] = {
			"position": [int(app_position[0]), int(app_position[1])] if app_position.size() >= 2 else [],
			"size": [maxi(271, int(app_size[0])), maxi(522, int(app_size[1]))]
		}
	return write_json(ui_settings_file(), normalized)

func default_import_settings() -> Dictionary:
	return {
		"version": 1,
		"convert_docx": true,
		"convert_xlsx": true,
		"keep_original": true,
		"chunk_size": CHUNK_SIZE,
		"chunk_overlap": CHUNK_OVERLAP
	}

func get_import_settings() -> Dictionary:
	var settings := read_json(import_settings_file(), default_import_settings())
	var defaults := default_import_settings()
	for key in defaults:
		if not settings.has(key):
			settings[key] = defaults[key]
	return settings

func save_import_settings(settings: Dictionary) -> bool:
	var normalized := default_import_settings()
	normalized["convert_docx"] = bool(settings.get("convert_docx", true))
	normalized["convert_xlsx"] = bool(settings.get("convert_xlsx", true))
	normalized["keep_original"] = true
	normalized["chunk_size"] = clampi(int(settings.get("chunk_size", CHUNK_SIZE)), 300, 4000)
	normalized["chunk_overlap"] = clampi(int(settings.get("chunk_overlap", CHUNK_OVERLAP)), 0, int(normalized["chunk_size"]) / 2)
	return write_json(import_settings_file(), normalized)

func ensure_json_file(path: String, fallback: Dictionary) -> void:
	if not FileAccess.file_exists(path):
		write_json(path, fallback)

func ensure_store_guide() -> void:
	var path := root_path.path_join("使用说明.txt")
	var revision_marker := "梁鲸灵魂仓库（说明版本 %s）" % GUIDE_REVISION
	if FileAccess.file_exists(path):
		# 老用户的这份说明是最早版本写的，内容已过时（缺归档/回收站/换装等目录）。
		# 只在"没有本版本标记"时重写一次，避免每次启动都覆盖用户可能改过的文件。
		if FileAccess.get_file_as_string(path).begins_with(revision_marker):
			return
	var text := "梁鲸灵魂仓库（说明版本 %s）\n\n" % GUIDE_REVISION
	text += "1. 点击桌上的书本，可导入文件或文件夹。\n"
	text += "2. txt、md、csv、json 等文本会直接建立索引。\n"
	text += "3. docx 和 xlsx 会在本机转换为 Markdown 后建立索引。\n"
	text += "4. 老式 doc 和复杂 PDF 会安全保存，等待相应解析组件。\n"
	text += "5. 原文件、Markdown 副本、聊天记录和长期记忆都保存在本机。\n"
	text += "\n各目录作用：\n"
	text += "- 会话：按天保存的聊天记录（.jsonl，每行一条）。\n"
	text += "- 记忆：用户档案与长期记忆。\n"
	text += "- 知识库：原始文件、提取文本与检索索引。\n"
	text += "- 技能库：你自己创建或导入的技能包，导入后默认停用。\n"
	text += "- 换装：AI 生成的换装形象与收藏的衣柜。\n"
	text += "- 工作流运行：每次工作流执行的记录（只保留最近的已完成记录）。\n"
	text += "- 归档：被归档的会话在这里留一个标记，会话内容仍在“会话”目录里，可随时移出归档。\n"
	text += "- 回收站：隐藏或彻底删除会话时留下的标记。清空标记不会删除任何聊天内容，\n"
	text += "  但被“隐藏”的会话会重新出现在列表里；被“彻底删除”的会话内容已经不在了。\n"
	AtomicFile.write_text(path, text)

func get_file_size(path: String) -> int:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return 0
	var size := file.get_length()
	file.close()
	return size

func read_json(path: String, fallback: Dictionary) -> Dictionary:
	if not FileAccess.file_exists(path):
		return fallback.duplicate(true)
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if parsed is Dictionary:
		return parsed
	return fallback.duplicate(true)

func write_json(path: String, data: Dictionary) -> bool:
	# 原子写：进程被强杀时不会留下半截 JSON（半截 JSON 会被静默回落成默认值，
	# 表现成“用户配置无缘无故消失”）。
	return AtomicFile.write_text(path, JSON.stringify(data, "  ", false))

func make_id(text: String) -> String:
	return "%s-%s" % [str(Time.get_unix_time_from_system()), str(text.hash()).replace("-", "n")]

func make_session_id() -> String:
	return "%s-%s-%s" % [
		Time.get_date_string_from_system(),
		str(Time.get_unix_time_from_system()),
		str(randi_range(1000, 9999))
	]

func conversation_title_from_text(text: String) -> String:
	var clean_text := text.replace("\r", " ").replace("\n", " ").strip_edges()
	while clean_text.contains("  "):
		clean_text = clean_text.replace("  ", " ")
	if clean_text.is_empty():
		return "新对话"
	return clean_text.left(22) + ("…" if clean_text.length() > 22 else "")

func now_string() -> String:
	return Time.get_datetime_string_from_system(false, true)
