# 工作流“对话自动匹配”的安全决策层。
# 自动执行可能产生文件和外部操作，因此只接受明确的执行指令。
class_name BlueWhaleWorkflowAutoMatch
extends RefCounted

const TRIGGER_AUTO := "对话自动匹配"
const MIN_QUERY_LENGTH := 4
const SCORE_NAME_CONTAINS := 100
const SCORE_TRIGGER_WORD := 30
const MIN_SCORE := 30
const EXECUTION_WORDS: Array[String] = [
    "请运行", "请执行", "请启动", "帮我运行", "帮我执行", "帮我启动",
    "运行", "执行", "启动", "开始运行", "开始执行", "跑一下", "跑一遍"
]
const NEGATION_WORDS: Array[String] = [
    "不要", "别运行", "别执行", "别启动", "不许", "禁止", "取消运行",
    "取消执行", "停止运行", "停止执行", "暂不", "先不", "不用", "无需", "不必"
]


static func decide(query: String, workflows: Array, runner_active: bool) -> Dictionary:
    var text := query.strip_edges()
    if runner_active:
        return _no("已有工作流正在运行")
    if text.length() < MIN_QUERY_LENGTH:
        return _no("提问过短，不足以判断是否要触发工作流")
    if contains_negation(text):
        return _no("检测到否定或取消表达，不自动执行")
    if not has_execution_intent(text):
        return _no("没有明确的运行、执行或启动指令")
    var best: Dictionary = {}
    var best_score := 0
    var tied := false
    var candidates := 0
    for value in workflows:
        if not value is Dictionary:
            continue
        var workflow: Dictionary = value
        if not _is_auto_candidate(workflow):
            continue
        candidates += 1
        var score := score_workflow(text, workflow)
        if score <= 0:
            continue
        if score > best_score:
            best_score = score
            best = workflow
            tied = false
        elif score == best_score:
            tied = true
    if candidates == 0:
        return _no("没有启用“对话自动匹配”的可用工作流")
    if best.is_empty() or best_score < MIN_SCORE:
        return _no("执行意图明确，但没有工作流名称或显式关键词命中")
    if tied:
        return _no("有多个工作流同样匹配，属于歧义，不自动执行")
    return {
        "run": true,
        "reason": "命中工作流《%s》（匹配分 %d）" % [str(best.get("name", "未命名")), best_score],
        "workflow": best
    }


static func has_execution_intent(query: String) -> bool:
    for word in EXECUTION_WORDS:
        if query.contains(word):
            return true
    return false


static func contains_negation(query: String) -> bool:
    for word in NEGATION_WORDS:
        if query.contains(word):
            return true
    return false


static func _is_auto_candidate(workflow: Dictionary) -> bool:
    if str(workflow.get("trigger", "")) != TRIGGER_AUTO:
        return false
    if not bool(workflow.get("enabled", false)) or not bool(workflow.get("confirmed", false)):
        return false
    if str(workflow.get("name", "")).strip_edges().is_empty():
        return false
    var steps: Variant = workflow.get("steps", [])
    if not steps is Array or steps.is_empty():
        return false
    for step in steps:
        if not step is Dictionary:
            return false
        var kind := str(step.get("type", ""))
        if kind == "条件分支":
            return false
        if not kind in ["模型处理", "Harness执行", "技能", "验证", "输出", "输入", "用户交互"]:
            return false
    return true


static func score_workflow(query: String, workflow: Dictionary) -> int:
    var name := str(workflow.get("name", "")).strip_edges()
    if name.length() >= 2 and query.contains(name):
        return SCORE_NAME_CONTAINS
    var score := 0
    for word in trigger_words(workflow):
        if query.contains(word):
            score += SCORE_TRIGGER_WORD
    return score


# 只读取工作流显式保存的关键词。步骤名称描述的是实现细节，不能作为执行授权。
static func trigger_words(workflow: Dictionary) -> Array[String]:
    var words: Array[String] = []
    var raw: Variant = workflow.get("keywords", [])
    if raw is Array:
        for item in raw:
            var word := str(item).strip_edges()
            if word.length() >= 2 and not words.has(word):
                words.append(word)
    elif raw is String:
        var pieces := str(raw).replace("，", ",").split(",", false)
        for piece in pieces:
            var word := piece.strip_edges()
            if word.length() >= 2 and not words.has(word):
                words.append(word)
    return words


static func _no(reason: String) -> Dictionary:
    return {"run": false, "reason": reason, "workflow": {}}


static func selftest() -> Dictionary:
    var failures: Array[String] = []
    var cases := 0
    var step_a := {"type": "模型处理", "name": "整理本周会话"}
    var workflow := {
        "name": "整理本周会话", "trigger": TRIGGER_AUTO,
        "enabled": true, "confirmed": true,
        "keywords": ["整理会话", "周报"], "steps": [step_a]
    }
    var pool: Array = [workflow]

    var hit := decide("请运行整理本周会话", pool, false)
    cases += 1
    if not bool(hit.get("run", false)):
        failures.append("明确指令加工作流名称没有命中：%s" % str(hit.get("reason", "")))

    var by_word := decide("请执行周报工作流", pool, false)
    cases += 1
    if not bool(by_word.get("run", false)):
        failures.append("明确指令加显式关键词没有命中：%s" % str(by_word.get("reason", "")))

    for denied in ["不要运行整理本周会话", "先不执行整理本周会话", "取消运行整理本周会话"]:
        cases += 1
        if bool(decide(denied, pool, false).get("run", false)):
            failures.append("否定指令被自动执行：%s" % denied)

    cases += 1
    if bool(decide("整理本周会话", pool, false).get("run", false)):
        failures.append("仅提到名称、没有执行意图时仍然自动执行")

    var step_only := workflow.duplicate(true)
    step_only["name"] = "每周整理流程"
    step_only["keywords"] = []
    cases += 1
    if bool(decide("帮我看看怎么整理本周会话", [step_only], false).get("run", false)):
        failures.append("步骤名称被当作触发授权")

    var manual := workflow.duplicate(true)
    manual["trigger"] = "手动运行"
    cases += 1
    if bool(decide("请运行整理本周会话", [manual], false).get("run", false)):
        failures.append("手动工作流被自动触发")
    for field in ["enabled", "confirmed"]:
        var off := workflow.duplicate(true)
        off[field] = false
        cases += 1
        if bool(decide("请运行整理本周会话", [off], false).get("run", false)):
            failures.append("工作流 %s=false 时仍自动触发" % field)

    for bad_steps in [[], [{"type": "条件分支", "name": "判断"}], [{"type": "未知类型", "name": "处理"}]]:
        var bad := workflow.duplicate(true)
        bad["steps"] = bad_steps
        cases += 1
        if bool(decide("请运行整理本周会话", [bad], false).get("run", false)):
            failures.append("不可执行的步骤配置被自动触发：%s" % str(bad_steps))

    cases += 1
    if bool(decide("请运行整理本周会话", pool, true).get("run", false)):
        failures.append("已有工作流运行时仍重复启动")
    cases += 1
    if bool(decide("请运行一个完全无关的流程", pool, false).get("run", false)):
        failures.append("无关执行指令触发了工作流")

    var tie_a := {"name": "周报整理", "trigger": TRIGGER_AUTO, "enabled": true, "confirmed": true, "keywords": ["生成周报"], "steps": [step_a]}
    var tie_b := {"name": "周报归档", "trigger": TRIGGER_AUTO, "enabled": true, "confirmed": true, "keywords": ["生成周报"], "steps": [step_a]}
    cases += 1
    if bool(decide("请执行生成周报", [tie_a, tie_b], false).get("run", false)):
        failures.append("多个工作流并列时仍自动执行")

    cases += 1
    var words := trigger_words({"keywords": ["做", "整理会话"], "steps": [{"name": "内部步骤"}]})
    if words.has("做") or words.has("内部步骤") or not words.has("整理会话"):
        failures.append("显式关键词过滤错误：%s" % str(words))
    return {"ok": failures.is_empty(), "failures": failures, "cases": cases}
