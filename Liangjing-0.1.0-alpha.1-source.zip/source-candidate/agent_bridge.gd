# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：authorization 失效信号；turn 中途失败保留已生成内容。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# Harness 本地核心通信桥。
# 负责启动/停止本地进程、会话与工作区同步、轮询回复，以及审批和追问事件转发。
# 所有 HTTP 端点只绑定 127.0.0.1，界面层通过本脚本的信号接收状态。
class_name AgentBridge
extends Node

signal outgoing(payload: Dictionary)
signal response_received(payload: Dictionary)
signal status_changed(state: String, detail: String)
signal trace_received(title: String, detail: String)
signal reasoning_received(detail: String)
signal model_configured(ok: bool, detail: String)
signal approval_requested(request: Dictionary)
signal approval_resolved(request: Dictionary, allowed: bool)
signal question_requested(request: Dictionary)
signal question_resolved(request: Dictionary, cancelled: bool)
signal session_changed(session_id: String, workspace_path: String)
signal metrics_updated(metrics: Dictionary)
# 会话切换或内核关闭时，之前排队的审批/追问已经不可能再被 Harness 接受了
# （再提交只会得到 409）。界面必须据此清空队列，否则用户会对着一个永远送不出去的
# 授权卡反复点击。
signal interactions_invalidated(reason: String)

const DEFAULT_CORE_URL := "http://127.0.0.1:43818"
const DEFAULT_INTERACTION_URL := "http://127.0.0.1:43819"
const STARTUP_ATTEMPTS := 48
const STARTUP_INTERVAL := 0.25
const QUERY_POLL_INTERVAL := 0.35
# [DSH] 这里原本有一个 300 秒的等待上限，已删除。
# 它把"任务还在正常执行"误报成"本次任务等待超时"，并把这句写进会话记录，
# 而 Harness 那边其实还在跑、之后照常给出完整回答。中止权现在归用户（stop_query）。
const ChatResponse = preload("res://chat_response.gd")

var project_root := ""
var data_root := ""
var workspace_path := ""
var workspace_id := ""
var runtime_root := ""
var node_path := ""
var launcher_path := ""
var harness_data_path := ""
var framework_name := "DeepSeek Harness"
var framework_mode := "bundled"
var framework_adapter := "blue_whale_v1"
var framework_auto_start := true
var core_url := DEFAULT_CORE_URL
var interaction_url := DEFAULT_INTERACTION_URL
var configured_arguments: Array[String] = []
var proxy_enabled := false
var proxy_url := ""
var proxy_no_proxy := "localhost,127.0.0.1,::1"
var proxy_source := "直连"
var process_id := -1
var owns_process := false
var core_ready := false
var starting := false
var stopping := false
var session_id := ""
var last_event_seq := -1
var last_assistant_stream_ordinal := 0
var assistant_stream_supported := true
var request_serial := 0
var interaction_poll_clock := 0.0
var interaction_poll_busy := false
var announced_approvals := {}
var announced_questions := {}
# [DSH] 用户点了"停止"：等待循环据此退出。不再用等待上限来结束任务——
# 上限会把"还在正常跑"误报成"没完成"（真机已踩过）。
var query_cancelled := false
var interaction_request: HTTPRequest

func configure(project_directory: String, soul_directory: String, settings: Dictionary = {}, network_settings: Dictionary = {}) -> void:
	project_root = project_directory
	data_root = soul_directory
	workspace_path = data_root
	runtime_root = project_root.path_join("runtime").path_join("harness")
	framework_name = str(settings.get("name", "DeepSeek Harness")).strip_edges()
	if framework_name.is_empty():
		framework_name = "执行框架"
	framework_mode = str(settings.get("mode", "bundled")).strip_edges().to_lower()
	framework_adapter = str(settings.get("adapter", "blue_whale_v1")).strip_edges().to_lower()
	framework_auto_start = bool(settings.get("auto_start", true))
	core_url = str(settings.get("core_url", DEFAULT_CORE_URL)).strip_edges().trim_suffix("/")
	interaction_url = str(settings.get("interaction_url", DEFAULT_INTERACTION_URL)).strip_edges().trim_suffix("/")
	node_path = str(settings.get("executable_path", "")).strip_edges().replace("\\", "/")
	launcher_path = str(settings.get("launcher_path", "")).strip_edges().replace("\\", "/")
	if node_path.is_empty() and framework_mode == "bundled":
		node_path = runtime_root.path_join("node.exe")
	if launcher_path.is_empty() and framework_mode == "bundled":
		launcher_path = runtime_root.path_join("app").path_join("blue-whale-harness.mjs")
	configured_arguments.clear()
	var raw_arguments = settings.get("launch_arguments", [])
	if raw_arguments is Array:
		for argument_value in raw_arguments:
			var argument := str(argument_value).strip_edges()
			if not argument.is_empty():
				configured_arguments.append(argument)
	proxy_enabled = bool(network_settings.get("enabled", false))
	proxy_url = str(network_settings.get("url", "")).strip_edges()
	proxy_no_proxy = str(network_settings.get("no_proxy", "localhost,127.0.0.1,::1")).strip_edges()
	proxy_source = str(network_settings.get("source", "直连"))
	if proxy_url.is_empty():
		proxy_enabled = false
	harness_data_path = data_root.path_join("运行核心")
	if not interaction_request:
		interaction_request = HTTPRequest.new()
		interaction_request.name = "ApprovalInteractionPoll"
		interaction_request.timeout = 5.0
		interaction_request.request_completed.connect(_on_interaction_poll_completed)
		add_child(interaction_request)

func start() -> void:
	if starting or core_ready or stopping:
		return
	starting = true
	_set_status("starting", "正在启动本地核心……")
	if await _probe_core() and await _probe_interactions():
		core_ready = true
		starting = false
		_set_status("ready", "%s 已连接" % framework_name)
		return
	if framework_mode == "external" or not framework_auto_start:
		starting = false
		_set_status("configured", "%s 已配置，等待兼容服务启动" % framework_name)
		return
	if framework_adapter != "blue_whale_v1":
		starting = false
		_set_status("error", "当前版本不支持所选执行框架协议")
		return
	print("HARNESS_RUNTIME_ROOT=", runtime_root)
	print("HARNESS_RUNTIME_FILES node=", FileAccess.file_exists(node_path), " launcher=", FileAccess.file_exists(launcher_path))
	if not FileAccess.file_exists(node_path) or (framework_mode == "bundled" and not FileAccess.file_exists(launcher_path)):
		starting = false
		_set_status("missing", "%s 的运行程序或入口文件不存在" % framework_name)
		return
	var make_error := DirAccess.make_dir_recursive_absolute(harness_data_path)
	if make_error != OK and make_error != ERR_ALREADY_EXISTS:
		starting = false
		_set_status("error", "无法创建本地核心数据目录")
		return
	var arguments := build_launch_arguments()
	# OS.create_process 没有逐进程环境变量参数。只在创建 Harness 子进程的瞬间
	# 注入代理，随后立即恢复梁鲸自身环境，避免污染其他功能或用户系统设置。
	var environment_backup := apply_process_proxy_environment()
	process_id = OS.create_process(node_path, arguments, false)
	restore_process_proxy_environment(environment_backup)
	if process_id <= 0:
		starting = false
		_set_status("error", "本地核心启动失败")
		return
	owns_process = true
	for _attempt in range(STARTUP_ATTEMPTS):
		await get_tree().create_timer(STARTUP_INTERVAL).timeout
		if stopping:
			starting = false
			return
		if await _probe_core() and await _probe_interactions():
			core_ready = true
			starting = false
			_set_status("ready", "%s 已连接" % framework_name)
			return
		if process_id > 0 and not OS.is_process_running(process_id):
			break
	starting = false
	core_ready = false
	_set_status("error", "%s 没有正常响应" % framework_name)

func build_launch_arguments() -> PackedStringArray:
	var result := PackedStringArray()
	# 内置 Node 24 使用环境代理时必须显式打开该开关，并且 Node 选项必须位于
	# Harness 入口脚本之前。localhost 已通过 NO_PROXY 排除，不影响审批轮询。
	if framework_mode == "bundled" and proxy_enabled:
		result.append("--use-env-proxy")
	# Node 类运行时需要先传入口脚本；其他可执行程序也可以把入口留空。
	if not launcher_path.is_empty():
		result.append(launcher_path)
	if framework_mode == "bundled":
		result.append_array(PackedStringArray([
			"--data-dir", harness_data_path,
			"--host", service_host(core_url),
			"--port", str(service_port(core_url, 43818)),
			"--interaction-port", str(service_port(interaction_url, 43819)),
			# 让内置 Harness 只服务当前梁鲸进程。即使主程序异常退出，
			# 后台核心也会自行结束，避免下次启动连接到残留实例。
			"--parent-pid", str(OS.get_process_id())
		]))
	for argument in configured_arguments:
		result.append(expand_launch_argument(argument))
	return result

func apply_process_proxy_environment() -> Dictionary:
	var backup := {}
	for variable_name in ["HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "no_proxy"]:
		backup[variable_name] = {
			"present": OS.has_environment(variable_name),
			"value": OS.get_environment(variable_name)
		}
	if proxy_enabled:
		OS.set_environment("HTTP_PROXY", proxy_url)
		OS.set_environment("HTTPS_PROXY", proxy_url)
		OS.set_environment("http_proxy", proxy_url)
		OS.set_environment("https_proxy", proxy_url)
	else:
		for variable_name in ["HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"]:
			OS.unset_environment(variable_name)
	OS.set_environment("NO_PROXY", proxy_no_proxy)
	OS.set_environment("no_proxy", proxy_no_proxy)
	return backup

func restore_process_proxy_environment(backup: Dictionary) -> void:
	for variable_name in backup:
		var saved: Dictionary = backup[variable_name]
		if bool(saved.get("present", false)):
			OS.set_environment(variable_name, str(saved.get("value", "")))
		else:
			OS.unset_environment(variable_name)

func expand_launch_argument(argument: String) -> String:
	var expanded := argument
	expanded = expanded.replace("{data_dir}", harness_data_path)
	expanded = expanded.replace("{core_url}", core_url)
	expanded = expanded.replace("{interaction_url}", interaction_url)
	expanded = expanded.replace("{core_host}", service_host(core_url))
	expanded = expanded.replace("{core_port}", str(service_port(core_url, 43818)))
	expanded = expanded.replace("{interaction_port}", str(service_port(interaction_url, 43819)))
	return expanded

func service_host(url: String) -> String:
	var authority := url.trim_prefix("http://").trim_prefix("https://").get_slice("/", 0)
	return authority.get_slice(":", 0) if authority.contains(":") else authority

func service_port(url: String, fallback: int) -> int:
	var authority := url.trim_prefix("http://").trim_prefix("https://").get_slice("/", 0)
	if not authority.contains(":"):
		return fallback
	var parsed := int(authority.get_slice(":", 1))
	return parsed if parsed > 0 else fallback

func test_connection() -> Dictionary:
	var core_ok := await _probe_core()
	var interaction_ok := await _probe_interactions()
	if core_ok and interaction_ok:
		return {"ok": true, "message": "%s 的核心与审批通道均可用。" % framework_name}
	if core_ok:
		return {"ok": false, "message": "核心可用，但审批交互通道没有响应。"}
	return {"ok": false, "message": "没有连接到执行框架核心，请检查地址或启动设置。"}


# 模型列表优先经 Harness 自带的 Node 网络通道读取。Windows 上 Godot 的
# HTTPS 客户端在部分网络/代理环境下会长时间等待，而 Node 通道与 Harness
# 执行模型使用同一网络栈，连接更快也更稳定。API Key 只在本机回环地址传递。
func fetch_model_list(base_url: String, api_key: String) -> Dictionary:
	if not core_ready:
		return {"ok": false, "error": "Harness 尚未连接"}
	return await _interaction_call("/models", HTTPClient.METHOD_POST, {
		"baseUrl": base_url,
		"apiKey": api_key
	}, 65.0)

func shutdown() -> void:
	stopping = true
	starting = false
	core_ready = false
	# 内核被关掉后，所有排队的审批/追问都不可能再送达。
	if not announced_approvals.is_empty() or not announced_questions.is_empty():
		interactions_invalidated.emit("本地核心已关闭")
	session_id = ""
	announced_approvals.clear()
	announced_questions.clear()
	if owns_process and process_id > 0 and OS.is_process_running(process_id):
		OS.kill(process_id)
	process_id = -1
	owns_process = false
	_set_status("stopped", "本地核心已关闭")
	# shutdown 只是一次操作状态，结束后必须复位；否则“保存并重启”和一键升级都无法再次 start。
	stopping = false

func _process(delta: float) -> void:
	if not core_ready or interaction_poll_busy:
		return
	interaction_poll_clock += delta
	if interaction_poll_clock < 0.45:
		return
	interaction_poll_clock = 0.0
	_begin_interaction_poll()

func _begin_interaction_poll() -> void:
	if not interaction_request or interaction_request.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return
	interaction_poll_busy = true
	var headers := PackedStringArray([
		"Accept: application/json",
		"X-Blue-Whale-Client: godot"
	])
	var request_error := interaction_request.request(interaction_url + "/interactions", headers, HTTPClient.METHOD_GET)
	if request_error != OK:
		interaction_poll_busy = false

func _on_interaction_poll_completed(transport_result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_handle_interaction_poll_response(transport_result, response_code, body)

func _handle_interaction_poll_response(transport_result: int, response_code: int, body: PackedByteArray) -> void:
	interaction_poll_busy = false
	if transport_result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary:
		return
	var value: Dictionary = parsed
	var approvals: Array = value.get("approvals", []) if value.get("approvals", []) is Array else []
	var active_approval_ids := {}
	for request_value in approvals:
		if not request_value is Dictionary:
			continue
		var request: Dictionary = request_value
		if not bool(request.get("testOnly", false)) and str(request.get("sessionId", "")) != session_id:
			continue
		var rpc_id := str(request.get("rpcId", ""))
		if rpc_id.is_empty():
			continue
		active_approval_ids[rpc_id] = true
		if not announced_approvals.has(rpc_id):
			announced_approvals[rpc_id] = request.duplicate(true)
			approval_requested.emit(request.duplicate(true))
			_mark_approval_seen(rpc_id)
	for rpc_id in announced_approvals.keys():
		if not active_approval_ids.has(rpc_id):
			announced_approvals.erase(rpc_id)
	var questions: Array = value.get("questions", []) if value.get("questions", []) is Array else []
	var active_question_ids := {}
	for request_value in questions:
		if not request_value is Dictionary:
			continue
		var request: Dictionary = request_value
		if not bool(request.get("testOnly", false)) and str(request.get("sessionId", "")) != session_id:
			continue
		var rpc_id := str(request.get("rpcId", ""))
		if rpc_id.is_empty():
			continue
		active_question_ids[rpc_id] = true
		if not announced_questions.has(rpc_id):
			announced_questions[rpc_id] = request.duplicate(true)
			question_requested.emit(request.duplicate(true))
	for rpc_id in announced_questions.keys():
		if not active_question_ids.has(rpc_id):
			announced_questions.erase(rpc_id)

func _mark_approval_seen(rpc_id: String) -> void:
	var request := HTTPRequest.new()
	request.timeout = 5.0
	add_child(request)
	request.request_completed.connect(func(_result: int, _code: int, _headers: PackedStringArray, _body: PackedByteArray) -> void:
		request.queue_free()
	, CONNECT_ONE_SHOT)
	var headers := PackedStringArray([
		"Content-Type: application/json",
		"Accept: application/json",
		"X-Blue-Whale-Client: godot"
	])
	var request_error := request.request(
		interaction_url + "/approval-seen",
		headers,
		HTTPClient.METHOD_POST,
		JSON.stringify({"rpcId": rpc_id})
	)
	if request_error != OK:
		request.queue_free()

func respond_approval(request: Dictionary, allowed: bool) -> Dictionary:
	var payload := {
		"rpcId": str(request.get("rpcId", "")),
		"sessionId": str(request.get("sessionId", "")),
		"approvalId": str(request.get("approvalId", "")),
		"outcome": "allowed-once" if allowed else "rejected"
	}
	var result := await _interaction_call("/approval", HTTPClient.METHOD_POST, payload)
	if bool(result.get("ok", false)):
		announced_approvals.erase(str(payload["rpcId"]))
		approval_resolved.emit(request.duplicate(true), allowed)
	return result

func request_approval_test() -> Dictionary:
	if not core_ready:
		return {"ok": false, "error": "Harness 实时审批通道尚未就绪"}
	return await _interaction_call("/approval-test", HTTPClient.METHOD_POST, {
		"source": "blue-whale-settings"
	})

# 切换 Harness 当前会话的原生权限预设。workspace-write 会把写入限制在
# 当前工作区，并在扩大权限时请求用户审批；danger-full-access 则不会审批。
func set_permission_preset(preset: String) -> Dictionary:
	var clean_preset := preset.strip_edges().to_lower()
	if not clean_preset in ["workspace-write", "danger-full-access"]:
		return {"ok": false, "error": "不支持的权限模式"}
	if not core_ready:
		return {"ok": false, "error": "Harness 本地核心尚未就绪"}
	if not await _ensure_session():
		return {"ok": false, "error": "无法建立 Harness 会话"}
	var command_result := await _rpc_call("commands.execute", {
		"agentId": session_id,
		"line": "/permission %s" % clean_preset,
		"images": []
	})
	if not bool(command_result.get("ok", false)):
		return command_result
	var value: Dictionary = command_result.get("value", {}) if command_result.get("value", {}) is Dictionary else {}
	if value.is_empty():
		return {"ok": false, "error": "Harness 没有识别权限切换命令"}
	var settled: Dictionary = value.get("result", {}) if value.get("result", {}) is Dictionary else {}
	if str(settled.get("kind", "success")) == "error":
		return {"ok": false, "error": str(settled.get("text", "权限模式切换失败"))}
	return {"ok": true, "preset": clean_preset}

func respond_question(request: Dictionary, answers: Array, cancelled := false) -> Dictionary:
	var payload := {
		"rpcId": str(request.get("rpcId", "")),
		"sessionId": str(request.get("sessionId", "")),
		"answers": answers,
		"cancelled": cancelled
	}
	var result := await _interaction_call("/question", HTTPClient.METHOD_POST, payload)
	if bool(result.get("ok", false)):
		announced_questions.erase(str(payload["rpcId"]))
		question_resolved.emit(request.duplicate(true), cancelled)
	return result

func request_question_test() -> Dictionary:
	if not core_ready:
		return {"ok": false, "error": "Harness 实时交互通道尚未就绪"}
	return await _interaction_call("/question-test", HTTPClient.METHOD_POST, {
		"source": "blue-whale-settings"
	})

func sync_deepseek(api_key: String, base_url: String, model: String, reasoning_effort := "off") -> Dictionary:
	if not core_ready:
		var offline := {"ok": false, "error": "本地核心尚未连接"}
		model_configured.emit(false, str(offline["error"]))
		return offline
	var clean_key := api_key.strip_edges()
	if clean_key.is_empty():
		var missing := {"ok": false, "error": "没有可同步的 API Key"}
		model_configured.emit(false, str(missing["error"]))
		return missing
	var effort := str(reasoning_effort).strip_edges().to_lower()
	if not effort in ["off", "low", "high", "max"]:
		effort = "off"
	var credential := await _rpc_call("credentials.set", {
		"ref": "DEEPSEEK_API_KEY",
		"value": clean_key
	})
	if not bool(credential.get("ok", false)):
		var credential_error := "API Key 没有写入本地核心：%s" % _rpc_error_text(credential)
		model_configured.emit(false, credential_error)
		return {"ok": false, "error": credential_error}
	var model_settings := await _rpc_call("settings.update", {
		"ns": "llm-deepseek",
		"patch": {
			"apiKeyEnv": "DEEPSEEK_API_KEY",
			"baseURL": base_url.strip_edges().trim_suffix("/"),
			"thinking": "enabled" if effort != "off" else "disabled",
			"reasoningEffort": effort
		}
	})
	if not bool(model_settings.get("ok", false)):
		var settings_error := "模型参数没有同步：%s" % _rpc_error_text(model_settings)
		model_configured.emit(false, settings_error)
		return {"ok": false, "error": settings_error}
	var default_model := await _rpc_call("settings.update", {
		"ns": "agent-default-model",
		"patch": {
			"provider": "deepseek-official",
			"model": model.strip_edges(),
			"reasoningEffort": effort
		}
	})
	if not bool(default_model.get("ok", false)):
		var model_error := "默认模型没有同步：%s" % _rpc_error_text(default_model)
		model_configured.emit(false, model_error)
		return {"ok": false, "error": model_error}
	model_configured.emit(true, "Harness 已使用当前对话模型")
	return {"ok": true}

func send_query(text: String, extra_context := "", images: Array = []) -> Dictionary:
	if not core_ready:
		return {"ok": false, "error": "本地核心尚未连接"}
	if not await _ensure_session():
		return {"ok": false, "error": "无法建立梁鲸会话"}
	await _refresh_history(false)
	# DSH 的即时 token 走 agent/assistant-stream，不会立刻进入持久化 history。
	# 先把上一轮的流游标推进到末尾，避免新一轮重复旧分片。
	await _refresh_assistant_stream(false)
	var prompt_text := text.strip_edges()
	if not extra_context.strip_edges().is_empty():
		prompt_text += "\n\n本次本地上下文：\n" + extra_context.strip_edges()
	outgoing.emit({"type": "agent.query", "source": "pet.panel", "text": text})
	trace_received.emit("交给 Harness", "正在规划任务并选择工具")
	var prompt_content: Array = [{"type": "text", "text": prompt_text}]
	for image_value in images:
		if not image_value is Dictionary:
			continue
		var image: Dictionary = image_value
		var bytes: PackedByteArray = image.get("bytes", PackedByteArray())
		if bytes.is_empty():
			continue
		prompt_content.append({
			"type": "image",
			"mediaType": str(image.get("media_type", "image/png")),
			"data": Marshalls.raw_to_base64(bytes),
			"name": str(image.get("name", "粘贴图片.png"))
		})
	var submitted := await _rpc_call("session.prompt", {
		"sessionId": session_id,
		"mode": "queue",
		"content": prompt_content,
		"clientTimeZone": "Asia/Shanghai"
	})
	if not bool(submitted.get("ok", false)):
		return {"ok": false, "error": _rpc_error_text(submitted)}
	var started_at := Time.get_ticks_msec()
	var final_text := ""
	var streamed_text := ""
	var live_stream_active := false
	# [DSH] 不再设等待上限：任务跑多久就等多久，中止权交给用户（与 Harness 一致）。
	#
	# 原实现是 300 秒硬上限，真机上造成过严重误报：一轮"让 AI 检查代码"跑了 5 分钟以上，
	# 程序先判定「本次任务等待超时」并把这句话写进会话记录，而 Harness 其实还在正常执行、
	# 之后照常产出了完整回答。用户看到的就是"Harness 里答得好好的，程序里说没完成"。
	# 这种"没完成"是假的——它只是等不及了。
	#
	# 终态仍然只有三个：任务正常结束、用户主动停止、本地核心掉线。
	while true:
		await get_tree().create_timer(QUERY_POLL_INTERVAL).timeout
		# 本地核心掉线时必须退出，否则界面会永远停在"执行中"。
		if not core_ready:
			return {"ok": false, "error": "本地核心已断开，本次任务无法继续。可稍后重新发送。", "interrupted": true}
		if query_cancelled:
			query_cancelled = false
			return {"ok": false, "error": "已按你的要求停止本次任务。", "cancelled": true}
		# assistant-stream 是 DSH 给实时界面的瞬时通道；history 通常要到整轮提交后才包含这些 chunk。
		var live_stream := await _refresh_assistant_stream(true)
		if bool(live_stream.get("ok", false)):
			for frame_value in live_stream.get("frames", []):
				if not frame_value is Dictionary:
					continue
				var delta := assistant_stream_delta(frame_value)
				var reasoning_delta := str(delta.get("reasoning", ""))
				var answer_delta := str(delta.get("answer", ""))
				if not reasoning_delta.is_empty():
					live_stream_active = true
					reasoning_received.emit(reasoning_delta)
				if not answer_delta.is_empty():
					live_stream_active = true
					streamed_text += answer_delta
		var history := await _refresh_history(true)
		if not bool(history.get("ok", false)):
			continue
		var events: Array = history.get("events", [])
		for event_value in events:
			if not event_value is Dictionary:
				continue
			var event: Dictionary = event_value
			var event_type := str(event.get("type", ""))
			var data: Dictionary = event.get("data", {}) if event.get("data", {}) is Dictionary else {}
			if event_type == "assistant/message":
				var candidate := _message_text(data)
				if not candidate.is_empty():
					final_text = candidate
			elif event_type == "tool/call":
				trace_received.emit("调用工具", str(data.get("name", data.get("tool", "正在执行"))))
			elif event_type == "tool/result":
				trace_received.emit("检查结果", str(data.get("name", data.get("tool", "工具执行完成"))))
			elif event_type == "assistant/chunk":
				# 新运行时已经从瞬时流展示过这些分片；history 里的压缩副本只能作兼容回退。
				if not live_stream_active:
					var delta_text := _chunk_text(data)
					if not delta_text.is_empty():
						streamed_text += delta_text
					_emit_reasoning_trace(data)
			elif event_type == "turn/end":
				var reason = data.get("reason", {})
				if reason is Dictionary and str(reason.get("kind", "")) == "error":
					# 中途失败时不能丢掉已经生成的内容：模型往往已经输出了一大段有效回答，
					# 直接报“执行失败”会让用户重问一遍，还多付一次费用。
					var partial := final_text
					if partial.strip_edges().is_empty():
						partial = streamed_text.strip_edges()
					if partial.strip_edges().is_empty():
						return {"ok": false, "error": _turn_error_text(reason)}
					var partial_payload := {
						"ok": true,
						"partial": true,
						"text": "%s\n\n（任务在中途中断：%s。以上是已经生成的内容。）" % [partial.strip_edges(), _turn_error_text(reason)],
						"session_id": session_id
					}
					response_received.emit(partial_payload)
					return partial_payload
				if final_text.is_empty() and not streamed_text.strip_edges().is_empty():
					final_text = streamed_text.strip_edges()
				if final_text.is_empty():
					final_text = "任务已经完成，但模型没有返回文字答复。"
				var response_payload := {"ok": true, "text": final_text, "session_id": session_id}
				response_received.emit(response_payload)
				return response_payload
	# 循环只会在"任务结束/用户停止/核心掉线"三处返回，正常不会走到这里。
	# 但真到了这里必须说得准确——不能沿用旧的"等待超时"文案（任务可能还在跑）。
	return {"ok": false, "error": "任务循环意外退出，未能确认结果。可在会话记录里查看这一轮是否已经完成。"}

# [DSH] 用户主动停止：先请求 Harness 中止当前轮次，再通知等待循环退出。
# 语义与 Harness 自己的停止一致，中止权完全在用户手上（不再靠等待上限兜）。
func stop_query() -> Dictionary:
	query_cancelled = true
	if session_id.is_empty():
		return {"ok": false, "error": "当前没有进行中的会话"}
	var stopped := await _rpc_call("session.stop", {"sessionId": session_id}, false, 10.0)
	if not bool(stopped.get("ok", false)):
		# 即使上游没确认，也要让本地等待循环停下来，并把原因如实说出。
		return {"ok": false, "error": "停止请求未获确认：%s" % _rpc_error_text(stopped)}
	return {"ok": true}

func _ensure_session() -> bool:
	if not session_id.is_empty():
		return true
	return bool((await new_conversation()).get("ok", false))

func new_conversation(timeout := 30.0) -> Dictionary:
	# 旧会话的待审批项随会话一起作废，先让界面清空，再建立新会话。
	if not session_id.is_empty() or not announced_approvals.is_empty() or not announced_questions.is_empty():
		interactions_invalidated.emit("会话已切换")
	session_id = ""
	last_event_seq = -1
	last_assistant_stream_ordinal = 0
	assistant_stream_supported = true
	announced_approvals.clear()
	announced_questions.clear()
	var payload := {"cwd": workspace_path if not workspace_path.is_empty() else data_root}
	if not workspace_id.is_empty():
		payload = {"workspaceId": workspace_id}
	var created := await _rpc_call("session.create", payload, true, timeout)
	if not bool(created.get("ok", false)):
		return created
	var value: Dictionary = created.get("value", {}) if created.get("value", {}) is Dictionary else {}
	session_id = str(value.get("sessionId", ""))
	last_event_seq = -1
	if session_id.is_empty():
		return {"ok": false, "error": "本地核心没有返回会话编号"}
	session_changed.emit(session_id, workspace_path)
	return {"ok": true, "session_id": session_id, "workspace_path": workspace_path}

func open_project(path: String) -> Dictionary:
	var clean_path := path.replace("\\", "/").trim_suffix("/")
	if clean_path.is_empty() or not DirAccess.dir_exists_absolute(clean_path):
		return {"ok": false, "error": "所选项目文件夹不存在"}
	# 项目切换属于前台按钮操作，不能让界面在 Harness 异常时等待半分钟。
	var created := await _rpc_call("workspace.create", {"path": clean_path}, true, 12.0)
	if not bool(created.get("ok", false)):
		return created
	var value: Dictionary = created.get("value", {}) if created.get("value", {}) is Dictionary else {}
	var workspace: Dictionary = value.get("workspace", {}) if value.get("workspace", {}) is Dictionary else value
	workspace_id = str(workspace.get("workspaceId", workspace.get("id", "")))
	if workspace_id.is_empty():
		return {"ok": false, "error": "Harness 没有返回项目编号"}
	workspace_path = clean_path
	return await new_conversation(12.0)

func _refresh_assistant_stream(only_new: bool) -> Dictionary:
	if session_id.is_empty() or not assistant_stream_supported:
		return {"ok": false, "frames": []}
	var result := await _rpc_call("session.stream", {
		"sessionId": session_id,
		"afterOrdinal": last_assistant_stream_ordinal if only_new else 0
	})
	if not bool(result.get("ok", false)):
		if "Unsupported Liang Jing method" in str(result.get("error", "")):
			assistant_stream_supported = false
		return {"ok": false, "frames": []}
	var value: Dictionary = result.get("value", {}) if result.get("value", {}) is Dictionary else {}
	var frames: Array = value.get("frames", []) if value.get("frames", []) is Array else []
	last_assistant_stream_ordinal = maxi(last_assistant_stream_ordinal, int(value.get("cursor", last_assistant_stream_ordinal)))
	return {"ok": true, "frames": frames if only_new else []}

func _refresh_history(only_new: bool) -> Dictionary:
	if session_id.is_empty():
		return {"ok": false, "events": []}
	var history := await _rpc_call("session.history", {
		"sessionId": session_id,
		"maxMessages": 200
	})
	if not bool(history.get("ok", false)):
		return {"ok": false, "events": []}
	var value: Dictionary = history.get("value", {}) if history.get("value", {}) is Dictionary else {}
	var entries: Array = value.get("events", []) if value.get("events", []) is Array else []
	var fresh: Array = []
	var all_events: Array = []
	var highest_seq := last_event_seq
	for entry_value in entries:
		if not entry_value is Dictionary:
			continue
		var entry: Dictionary = entry_value
		var event: Dictionary = entry.get("event", {}) if entry.get("event", {}) is Dictionary else {}
		all_events.append(event)
		var sequence := int(event.get("seq", -1))
		if not only_new or sequence > last_event_seq:
			fresh.append(event)
		highest_seq = maxi(highest_seq, sequence)
	last_event_seq = highest_seq
	metrics_updated.emit(_derive_session_metrics(all_events))
	return {"ok": true, "events": fresh}

# Harness 浏览器底边的统计来自 sessionStats/token usage 投影。桌宠通信层
# 已经拿到了同一批持久化事件，因此在本机按相同边界折叠即可稳定展示。
func _derive_session_metrics(events: Array) -> Dictionary:
	var turns := {}
	var step_starts := {}
	var first_tokens := {}
	var tool_starts := {}
	var usage_by_step := {}
	var steps := 0
	var llm_ms := 0.0
	var tool_ms := 0.0
	var ttft_ms := 0.0
	var ttft_steps := 0
	var decode_ms := 0.0
	var decode_tokens := 0.0
	for event_value in events:
		if not event_value is Dictionary:
			continue
		var event: Dictionary = event_value
		var event_type := str(event.get("type", ""))
		var data: Dictionary = event.get("data", {}) if event.get("data", {}) is Dictionary else {}
		var event_time := float(event.get("time", 0.0))
		var step_key := "%s:%s" % [str(data.get("turn", "")), str(data.get("step", ""))]
		match event_type:
			"step/start":
				step_starts[step_key] = event_time
			"assistant/chunk":
				var chunk: Dictionary = data.get("chunk", {}) if data.get("chunk", {}) is Dictionary else {}
				if str(chunk.get("type", "")) == "text-delta" and not str(chunk.get("text", "")).is_empty() and not first_tokens.has(step_key):
					first_tokens[step_key] = event_time
			"assistant/message":
				if step_starts.has(step_key):
					llm_ms += maxf(0.0, event_time - float(step_starts[step_key]))
				if first_tokens.has(step_key) and step_starts.has(step_key):
					ttft_ms += maxf(0.0, float(first_tokens[step_key]) - float(step_starts[step_key]))
					ttft_steps += 1
					decode_ms += maxf(0.0, event_time - float(first_tokens[step_key]))
				var usage: Dictionary = data.get("usage", {}) if data.get("usage", {}) is Dictionary else {}
				if not usage.is_empty():
					usage_by_step[step_key] = usage
					decode_tokens += float(usage.get("outputTokens", 0.0))
			"tool/call":
				var call_id := str(data.get("callId", ""))
				if not call_id.is_empty():
					tool_starts[call_id] = event_time
			"tool/result":
				var message: Dictionary = data.get("message", {}) if data.get("message", {}) is Dictionary else {}
				var source: Dictionary = message.get("source", {}) if message.get("source", {}) is Dictionary else {}
				var result_call_id := str(source.get("callId", data.get("callId", "")))
				if tool_starts.has(result_call_id):
					tool_ms += maxf(0.0, event_time - float(tool_starts[result_call_id]))
					tool_starts.erase(result_call_id)
			"step/end":
				steps += 1
				turns[str(data.get("turn", steps))] = true
	var input_tokens := 0.0
	var cache_read_tokens := 0.0
	var cache_write_tokens := 0.0
	for usage_value in usage_by_step.values():
		if not usage_value is Dictionary:
			continue
		var usage: Dictionary = usage_value
		input_tokens += float(usage.get("inputTokens", 0.0))
		cache_read_tokens += float(usage.get("cacheReadTokens", 0.0))
		cache_write_tokens += float(usage.get("cacheWriteTokens", 0.0))
	var cache_total := input_tokens + cache_read_tokens + cache_write_tokens
	return {
		"turns": turns.size(),
		"steps": steps,
		"llm_ms": llm_ms,
		"tool_ms": tool_ms,
		"ttft_ms": ttft_ms / float(ttft_steps) if ttft_steps > 0 else 0.0,
		"tokens_per_second": decode_tokens * 1000.0 / decode_ms if decode_ms > 0.0 else 0.0,
		"cache_hit": cache_read_tokens / cache_total if cache_total > 0.0 else 0.0,
		"input_tokens": cache_total
	}

func _probe_core() -> bool:
	var result := await _rpc_call("session.list", {}, false, 2.0)
	return bool(result.get("ok", false))

func _probe_interactions() -> bool:
	var result := await _interaction_call("/health", HTTPClient.METHOD_GET, {}, 2.0)
	return bool(result.get("ok", false))

func _interaction_call(path: String, method: int, payload: Dictionary = {}, timeout := 10.0) -> Dictionary:
	if not is_inside_tree():
		return {"ok": false, "error": "交互桥接尚未挂载"}
	var request := HTTPRequest.new()
	request.timeout = timeout
	add_child(request)
	var headers := PackedStringArray([
		"Accept: application/json",
		"X-Blue-Whale-Client: godot"
	])
	var body := ""
	if method == HTTPClient.METHOD_POST:
		headers.append("Content-Type: application/json")
		body = JSON.stringify(payload)
	var request_error := request.request(interaction_url + path, headers, method, body)
	if request_error != OK:
		request.queue_free()
		return {"ok": false, "error": "无法连接授权交互桥"}
	var completed = await request.request_completed
	request.queue_free()
	var transport_result := int(completed[0])
	var response_code := int(completed[1])
	var response_body: PackedByteArray = completed[3]
	if transport_result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return {"ok": false, "error": "授权交互桥连接失败（%d）" % response_code}
	var parsed = JSON.parse_string(response_body.get_string_from_utf8())
	if not parsed is Dictionary:
		return {"ok": false, "error": "授权交互桥返回了无效数据"}
	var response: Dictionary = parsed
	if bool(response.get("ok", false)):
		return {"ok": true, "value": response}
	return {"ok": false, "error": str(response.get("error", "授权操作失败"))}

func _rpc_call(method: String, payload: Dictionary, require_ready := true, timeout := 30.0) -> Dictionary:
	if require_ready and not core_ready:
		return {"ok": false, "error": "本地核心未连接"}
	if not is_inside_tree():
		return {"ok": false, "error": "梁鲸桥接尚未挂载"}
	request_serial += 1
	var rpc_id := "%d-%d-%d" % [Time.get_ticks_usec(), request_serial, randi()]
	var envelope := {
		"type": "client-request",
		"rpcId": rpc_id,
		"method": method,
		"payload": payload
	}
	var request := HTTPRequest.new()
	request.timeout = timeout
	add_child(request)
	var headers := PackedStringArray(["Content-Type: application/json", "Accept: application/json"])
	var request_error := request.request(
		core_url + "/api/" + method,
		headers,
		HTTPClient.METHOD_POST,
		JSON.stringify(envelope)
	)
	if request_error != OK:
		request.queue_free()
		return {"ok": false, "error": "无法连接梁鲸本地核心"}
	var completed = await request.request_completed
	request.queue_free()
	var transport_result := int(completed[0])
	var response_code := int(completed[1])
	var body: PackedByteArray = completed[3]
	if transport_result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		return {"ok": false, "error": "本地核心连接失败（%d）" % response_code}
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary:
		return {"ok": false, "error": "本地核心返回了无效数据"}
	var response: Dictionary = parsed
	var rpc_result: Dictionary = response.get("result", {}) if response.get("result", {}) is Dictionary else {}
	if bool(rpc_result.get("ok", false)):
		return {"ok": true, "value": rpc_result.get("value", {})}
	var rpc_error: Dictionary = rpc_result.get("error", {}) if rpc_result.get("error", {}) is Dictionary else {}
	return {
		"ok": false,
		"error": str(rpc_error.get("message", "本地核心执行失败")),
		"code": str(rpc_error.get("code", ""))
	}

func _message_text(data: Dictionary) -> String:
	# DSH 的最终事件结构是 data.message.content；兼容旧版直接放在 data.content 的结构。
	var message: Dictionary = data.get("message", {}) if data.get("message", {}) is Dictionary else data
	var raw_content = message.get("content", [])
	var blocks: Array = raw_content if raw_content is Array else [raw_content]
	var parts: Array[String] = []
	for block_value in blocks:
		if block_value is Dictionary:
			var block: Dictionary = block_value
			if str(block.get("type", "")) == "text":
				var text := str(block.get("text", "")).strip_edges()
				if not text.is_empty():
					parts.append(text)
	return "\n".join(parts)

func _chunk_text(data: Dictionary) -> String:
	var chunk: Dictionary = data.get("chunk", {}) if data.get("chunk", {}) is Dictionary else {}
	if str(chunk.get("type", "")) == "text-delta":
		return str(chunk.get("text", ""))
	return ""

static func assistant_stream_delta(frame: Dictionary) -> Dictionary:
	if str(frame.get("type", "")) != "chunk":
		return {"answer": "", "reasoning": ""}
	var chunk: Dictionary = frame.get("chunk", {}) if frame.get("chunk", {}) is Dictionary else {}
	var chunk_type := str(chunk.get("type", ""))
	if chunk_type == "text-delta":
		return {"answer": str(chunk.get("text", "")), "reasoning": ""}
	if chunk_type == "reasoning-delta":
		return {"answer": "", "reasoning": str(chunk.get("text", ""))}
	return {"answer": "", "reasoning": ""}

static func assistant_stream_selftest() -> Dictionary:
	var failures: Array[String] = []
	var reasoning := assistant_stream_delta({"type": "chunk", "chunk": {"type": "reasoning-delta", "text": "先分析"}})
	if reasoning.get("reasoning") != "先分析" or reasoning.get("answer") != "":
		failures.append("reasoning-delta 没有实时分离")
	var answer := assistant_stream_delta({"type": "chunk", "chunk": {"type": "text-delta", "text": "再回答"}})
	if answer.get("answer") != "再回答" or answer.get("reasoning") != "":
		failures.append("text-delta 没有实时分离")
	if not str(assistant_stream_delta({"type": "start"}).get("reasoning", "")).is_empty():
		failures.append("start 帧被误当成思考")
	if not str(assistant_stream_delta({"type": "chunk", "chunk": {"type": "tool-call-delta", "argumentsDelta": "{}"}}).get("answer", "")).is_empty():
		failures.append("工具分片被误当成回答")
	return {"ok": failures.is_empty(), "failures": failures, "cases": 4}

func _emit_reasoning_trace(data: Dictionary) -> void:
	var detail := ChatResponse.reasoning_delta(data)
	if not detail.is_empty():
		reasoning_received.emit(detail)

func _turn_error_text(reason: Dictionary) -> String:
	var error: Dictionary = reason.get("error", {}) if reason.get("error", {}) is Dictionary else {}
	var code := str(error.get("code", ""))
	if code == "MISSING_CREDENTIAL":
		return "还没有给梁鲸配置 API Key。"
	return str(error.get("message", "梁鲸任务执行失败"))

func _rpc_error_text(result: Dictionary) -> String:
	return str(result.get("error", "本地核心执行失败"))

func _set_status(state: String, detail: String) -> void:
	status_changed.emit(state, detail)
