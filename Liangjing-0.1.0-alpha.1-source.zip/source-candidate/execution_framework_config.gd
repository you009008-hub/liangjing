# 梁鲸执行框架配置存储。
#
# 这里只保存“怎么启动/连接执行框架”，不保存模型 API Key。模型与执行框架
# 分开配置后，可以升级 DeepSeek Harness，或切换到实现了梁鲸 RPC 协议的其他框架。
class_name ExecutionFrameworkConfigStore
extends RefCounted

const CONFIG_VERSION := 1
const DEFAULT_CORE_URL := "http://127.0.0.1:43818"
const DEFAULT_INTERACTION_URL := "http://127.0.0.1:43819"
const SUPPORTED_MODES := ["bundled", "custom", "external"]
const SUPPORTED_ADAPTERS := ["blue_whale_v1"]

var config_directory := ""
var config_path := ""

func initialize(soul_root: String) -> Dictionary:
	if soul_root.strip_edges().is_empty():
		return {"ok": false, "error": "本地数据目录为空"}
	config_directory = soul_root.path_join("运行核心").replace("\\", "/")
	config_path = config_directory.path_join("执行框架.json")
	var make_error := DirAccess.make_dir_recursive_absolute(config_directory)
	if make_error != OK and make_error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法创建执行框架配置目录"}
	if not FileAccess.file_exists(config_path):
		var created := save_config(default_config())
		if not bool(created.get("ok", false)):
			return created
	return {"ok": true, "path": config_path, "config": load_config()}

func default_config() -> Dictionary:
	return {
		"version": CONFIG_VERSION,
		"name": "DeepSeek Harness",
		"mode": "bundled",
		"adapter": "blue_whale_v1",
		"auto_start": true,
		"core_url": DEFAULT_CORE_URL,
		"interaction_url": DEFAULT_INTERACTION_URL,
		# 路径留空表示跟随程序目录中的 runtime/harness，便于免安装版整体移动。
		"executable_path": "",
		"launcher_path": "",
		"launch_arguments": []
	}

func load_config() -> Dictionary:
	var defaults := default_config()
	if config_path.is_empty() or not FileAccess.file_exists(config_path):
		return defaults
	var file := FileAccess.open(config_path, FileAccess.READ)
	if file == null:
		return defaults
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return defaults
	return normalize_config(parsed)

func save_config(value: Dictionary) -> Dictionary:
	if config_path.is_empty():
		return {"ok": false, "message": "执行框架配置目录尚未准备好。"}
	var config := normalize_config(value)
	var validation := validate_config(config)
	if not bool(validation.get("ok", false)):
		return validation
	var temporary_path := config_path + ".tmp"
	var file := FileAccess.open(temporary_path, FileAccess.WRITE)
	if file == null:
		return {"ok": false, "message": "无法写入执行框架配置。"}
	file.store_string(JSON.stringify(config, "\t"))
	file.close()
	if FileAccess.file_exists(config_path):
		var remove_error := DirAccess.remove_absolute(config_path)
		if remove_error != OK:
			DirAccess.remove_absolute(temporary_path)
			return {"ok": false, "message": "旧配置正在被占用，无法覆盖。"}
	var rename_error := DirAccess.rename_absolute(temporary_path, config_path)
	if rename_error != OK:
		return {"ok": false, "message": "执行框架配置保存失败。"}
	return {"ok": true, "message": "执行框架配置已保存在本机。", "config": config}

func normalize_config(value: Dictionary) -> Dictionary:
	var defaults := default_config()
	var mode := str(value.get("mode", defaults["mode"])).strip_edges().to_lower()
	if not mode in SUPPORTED_MODES:
		mode = str(defaults["mode"])
	var adapter := str(value.get("adapter", defaults["adapter"])).strip_edges().to_lower()
	if not adapter in SUPPORTED_ADAPTERS:
		adapter = str(defaults["adapter"])
	var arguments: Array[String] = []
	var source_arguments = value.get("launch_arguments", [])
	if source_arguments is Array:
		for argument_value in source_arguments:
			var argument := str(argument_value).strip_edges()
			if not argument.is_empty() and arguments.size() < 40:
				arguments.append(argument.left(1024))
	return {
		"version": CONFIG_VERSION,
		"name": str(value.get("name", defaults["name"])).strip_edges().left(80),
		"mode": mode,
		"adapter": adapter,
		"auto_start": bool(value.get("auto_start", defaults["auto_start"])),
		"core_url": normalize_url(str(value.get("core_url", defaults["core_url"]))),
		"interaction_url": normalize_url(str(value.get("interaction_url", defaults["interaction_url"]))),
		"executable_path": str(value.get("executable_path", "")).strip_edges().replace("\\", "/"),
		"launcher_path": str(value.get("launcher_path", "")).strip_edges().replace("\\", "/"),
		"launch_arguments": arguments
	}

func validate_config(config: Dictionary) -> Dictionary:
	if str(config.get("name", "")).is_empty():
		return {"ok": false, "message": "请填写执行框架名称。"}
	if not is_safe_service_url(str(config.get("core_url", ""))):
		return {"ok": false, "message": "核心地址必须是本机 HTTP 地址，或安全的 HTTPS 地址。"}
	if not is_safe_service_url(str(config.get("interaction_url", ""))):
		return {"ok": false, "message": "交互地址必须是本机 HTTP 地址，或安全的 HTTPS 地址。"}
	var mode := str(config.get("mode", "bundled"))
	if mode == "custom" and bool(config.get("auto_start", true)):
		var executable := str(config.get("executable_path", ""))
		if executable.is_empty() or not FileAccess.file_exists(executable):
			return {"ok": false, "message": "本地兼容框架需要选择有效的运行程序。"}
	return {"ok": true}

func normalize_url(value: String) -> String:
	return value.strip_edges().trim_suffix("/")

func is_safe_service_url(value: String) -> bool:
	var url := normalize_url(value)
	if url.begins_with("https://"):
		return url.length() > 12
	if not url.begins_with("http://"):
		return false
	var host := url.trim_prefix("http://").get_slice("/", 0).get_slice(":", 0).to_lower()
	return host in ["127.0.0.1", "localhost", "::1", "[::1]"]
