extends SceneTree

# Anatomical regions of the original 1024 x 1536 illustration, not hidden-body art.
# Earlier polygons claim their pixels first; the remainder becomes the torso.
const REGIONS := {
	"head": [Vector2(0,0),Vector2(1024,0),Vector2(1024,355),Vector2(602,355),Vector2(552,364),Vector2(550,391),Vector2(485,391),Vector2(482,366),Vector2(402,355),Vector2(0,355)],
	"arm_left": [Vector2(364,554),Vector2(392,567),Vector2(335,661),Vector2(264,722),Vector2(273,766),Vector2(211,820),Vector2(105,848),Vector2(173,760),Vector2(224,740),Vector2(204,714),Vector2(259,668),Vector2(315,587)],
	"arm_right": [Vector2(644,563),Vector2(671,550),Vector2(718,622),Vector2(786,700),Vector2(820,724),Vector2(804,750),Vector2(859,778),Vector2(908,840),Vector2(827,820),Vector2(772,777),Vector2(750,737),Vector2(701,679)],
	"hair_left": [Vector2(0,355),Vector2(402,355),Vector2(438,394),Vector2(421,424),Vector2(387,434),Vector2(368,471),Vector2(336,496),Vector2(331,551),Vector2(300,610),Vector2(268,665),Vector2(230,700),Vector2(209,753),Vector2(285,790),Vector2(349,717),Vector2(395,651),Vector2(393,715),Vector2(338,780),Vector2(285,820),Vector2(0,840)],
	"hair_right": [Vector2(602,355),Vector2(1024,355),Vector2(1024,840),Vector2(746,820),Vector2(686,754),Vector2(638,708),Vector2(631,647),Vector2(683,721),Vector2(741,790),Vector2(817,753),Vector2(795,700),Vector2(755,644),Vector2(714,573),Vector2(704,525),Vector2(675,477),Vector2(638,457),Vector2(619,428),Vector2(590,411)],
	"leg_left": [Vector2(361,857),Vector2(498,867),Vector2(502,1536),Vector2(280,1536),Vector2(306,1179),Vector2(343,1015)],
	"leg_right": [Vector2(524,867),Vector2(664,858),Vector2(698,1030),Vector2(747,1536),Vector2(514,1536)],
	"skirt": [Vector2(0,648),Vector2(1024,648),Vector2(1024,1536),Vector2(0,1536)]
}
const SIZE := Vector2(1024, 1536)
var failures := 0

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var remainder: Array[PackedVector2Array] = []
	for y in range(0, 1536, 24):
		for x in range(0, 1024, 24):
			var right := mini(x + 24, 1024)
			remainder.append(PackedVector2Array([Vector2(x,y),Vector2(right,y),Vector2(right,y+24),Vector2(x,y+24)]))
	var regions := {}
	for key in REGIONS:
		var mask := PackedVector2Array(REGIONS[key])
		var pieces: Array[PackedVector2Array] = []
		var rest: Array[PackedVector2Array] = []
		for poly in remainder:
			pieces.append_array(Geometry2D.intersect_polygons(poly, mask))
			rest.append_array(Geometry2D.clip_polygons(poly, mask))
		regions[key] = pieces
		remainder = rest
	regions["torso"] = remainder
	var total_area := 0.0
	for key in regions:
		var mesh := make_mesh(regions[key])
		total_area += mesh_area(mesh)
		var error := ResourceSaver.save(mesh, OS.get_environment("LAYER_OUTPUT").path_join(key + ".res"))
		if error != OK: failures += 1
		print("LAYER ", key, " vertices=", mesh.surface_get_array_len(0))
	if absf(total_area - SIZE.x * SIZE.y) > 2.0: failures += 1
	print("LAYER_AREA=", total_area, " EXPECTED=", SIZE.x * SIZE.y, " FAILURES=", failures)
	quit(failures)

func make_mesh(polygons: Array) -> ArrayMesh:
	var vertices := PackedVector3Array()
	var uvs := PackedVector2Array()
	for piece in polygons:
		var triangles := Geometry2D.triangulate_polygon(piece)
		for index in triangles:
			var point: Vector2 = piece[index]
			vertices.append(Vector3(point.x-SIZE.x*0.5, point.y-SIZE.y*0.5, 0))
			uvs.append(point/SIZE)
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

func mesh_area(mesh: ArrayMesh) -> float:
	var v: PackedVector3Array = mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
	var area := 0.0
	for i in range(0, v.size(), 3):
		area += (v[i+1]-v[i]).cross(v[i+2]-v[i]).length()*0.5
	return area


