extends Node

const NativeWindows = preload("res://native_windows.gd")
const NativeFilePicker = preload("res://native_file_picker.gd")
# [DSH] 换装 Key 走原子写 + 设备绑定加密，与模型中心的 Key 同一套。
const AtomicFile = preload("res://atomic_file.gd")

# Independent image-edit adapter. Chat credentials are never reused or persisted here.
signal appearance_changed(texture: Texture2D)
signal motion_profile_changed(profile: Dictionary)
signal model_settings_requested

const MotionProfile = preload("res://motion_profile.gd")
const LayeredPreview = preload("res://layered_character.gd")
# [DSH] 代理设置只解析一处：换装请求也走 network_config.apply_to_request。
const NetworkConfig = preload("res://network_config.gd")
const MAX_FILE_BYTES := 20 * 1024 * 1024
const MAX_SIDE := 4096
var base_texture: Texture2D
var storage := ""
var window: Window
var picker: FileDialog
var endpoint: LineEdit
var model: LineEdit
var key: LineEdit
var instructions: TextEdit
var status: Label
var reference_preview: TextureRect
var result_preview: TextureRect
var generate_button: Button
var apply_button: Button
var select_button: Button
var cancel_button: Button
var request: HTTPRequest
# [DSH] 网络（代理）设置的来源，由 main.gd 注入；换装请求发出去之前必须套用它。
var network_settings_provider := Callable()
# [DSH] 换装 Key 的加密存储位置与设备密钥来源（由 main.gd 注入 deepseek_config）。
var secret_path := ""
var device_key_source: Object = null
# 最近一次套用结果与调用次数：给自检用，证明"发请求之前真的套过"。
var last_proxy_result: Dictionary = {}
var proxy_apply_count := 0
var reference_image: Image
var candidate: Image
var busy := false
var active := false
var provider: OptionButton
var service_hint: Label
var request_is_seedream := false
var generation_id := 0
var auto_path: CheckButton
var size_input: LineEdit
var timeout_input: SpinBox
var cleanup_strength: SpinBox
var clear_gaps: CheckButton
var cleanup_button: Button
var cleanup_source: Image
var service_panel: VBoxContainer
var service_status: Label
var model_summary: Label
var wardrobe_list: ItemList
var wardrobe_preview: TextureRect
var wardrobe_name: LineEdit
var save_name: LineEdit
var wardrobe_status: Label
var current_appearance: Image
var wardrobe_panel: VBoxContainer
var editor_panel: VBoxContainer
var heading_label: Label
var active_look_id := ""
var current_motion_profile: Dictionary = MotionProfile.defaults()
var candidate_look_id := ""
var candidate_motion_profile: Dictionary = MotionProfile.defaults()
var candidate_is_active := false
var cleanup_motion_profile: Dictionary = MotionProfile.defaults()
var cleanup_look_id := ""
var selected_motion_profile: Dictionary = MotionProfile.defaults()
var selected_look_id := ""
var motion_controls: Dictionary = {}
var motion_options: VBoxContainer
var calibration_options: VBoxContainer
var eyes_enabled: CheckButton
var blink_enabled: CheckButton
var eye_calibration_label: Label
var calibration_eye := ""
var calibrated_eyes: Dictionary = {}
var motion_updating := false
var preview_viewport: SubViewport
var preview_rig: Node2D
var preview_texture: Texture2D
var preview_clock := 0.0
var eye_markers: Array[ColorRect] = []
var calibration_lines: Dictionary = {}
var wardrobe_scroll: ScrollContainer
var calibration_prompt: HBoxContainer
var calibration_hint: Label

func setup(soul_root: String, original: Texture2D, key_source: Object = null) -> void:
	storage = soul_root.path_join("换装")
	# [DSH] 换装 Key 的落盘位置与模型中心的 chat/vision Key 放在一起，用同一套设备绑定加密。
	device_key_source = key_source
	secret_path = soul_root.path_join("配置/image_model.key")
	base_texture = original
	build_window()
	# 已经保存过的 Key 直接回填，用户不必每次重新粘贴（换装当前是可用的正式功能）。
	var stored_key := load_saved_key()
	if not stored_key.is_empty():
		key.text = stored_key
	var settings := ConfigFile.new()
	if settings.load(storage.path_join("settings.cfg")) == OK:
		endpoint.text = str(settings.get_value("service", "endpoint", ""))
		model.text = str(settings.get_value("service", "model", ""))
		provider.select(clampi(int(settings.get_value("service", "provider", 0)), 0, 2))
		auto_path.button_pressed = bool(settings.get_value("service", "auto_path", true))
		size_input.text = str(settings.get_value("service", "size", ""))
		timeout_input.value = float(settings.get_value("service", "timeout", 180))
		cleanup_strength.value = float(settings.get_value("cleanup", "strength", 60))
		clear_gaps.button_pressed = bool(settings.get_value("cleanup", "gaps", true))
		if bool(settings.get_value("appearance", "active", false)):
			var restored := Image.new()
			if restored.load(storage.path_join("active.png")) == OK and restored.get_size() == Vector2i(base_texture.get_size()):
				active = true
				current_appearance = restored.duplicate()
				cleanup_source = restored.duplicate()
				var saved_id := str(settings.get_value("appearance", "look_id", ""))
				active_look_id = saved_id if valid_look_id(saved_id) else ""
				current_motion_profile = profile_value(settings.get_value("appearance", "motion", {}))
				cleanup_motion_profile = current_motion_profile.duplicate(true)
				cleanup_look_id = active_look_id
				motion_profile_changed.emit(active_motion_profile())
				appearance_changed.emit(ImageTexture.create_from_image(restored))
	cleanup_button.disabled = cleanup_source == null
	refresh_service_hint()
	refresh_wardrobe()

func label_in(parent: Node, text: String) -> Label:
	var item := Label.new()
	item.text = text
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(item)
	return item

func button_in(parent: Node, text: String, action: Callable) -> Button:
	var item := Button.new()
	item.text = text
	item.custom_minimum_size.y = 36
	item.pressed.connect(action)
	parent.add_child(item)
	return item

func field_in(parent: Node, title: String, placeholder: String) -> LineEdit:
	label_in(parent, title)
	var item := LineEdit.new()
	item.placeholder_text = placeholder
	parent.add_child(item)
	return item

func build_window() -> void:
	window = Window.new()
	window.title = "梁鲸 · 换装与衣柜"
	window.size = Vector2i(720, 820)
	window.min_size = Vector2i(560, 500)
	window.transient = false
	window.exclusive = false
	window.visible = false
	add_child(window)
	NativeWindows.configure(window)
	window.close_requested.connect(close)
	var background := ColorRect.new()
	background.color = Color("f3faff")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	window.add_child(background)
	var scroll := ScrollContainer.new()
	wardrobe_scroll = scroll
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	window.add_child(scroll)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for edge in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + edge, 18)
	scroll.add_child(margin)
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 10)
	margin.add_child(layout)
	var heading := label_in(layout, "换装与衣柜")
	heading_label = heading
	heading.add_theme_font_size_override("font_size", 24)
	var navigation := HBoxContainer.new()
	layout.add_child(navigation)
	button_in(navigation, "制作新装", func(): show_wardrobe(false))
	button_in(navigation, "我的衣柜", func(): show_wardrobe(true))
	editor_panel = VBoxContainer.new()
	editor_panel.add_theme_constant_override("separation", 10)
	layout.add_child(editor_panel)
	wardrobe_panel = VBoxContainer.new()
	wardrobe_panel.visible = false
	wardrobe_panel.add_theme_constant_override("separation", 12)
	layout.add_child(wardrobe_panel)
	build_wardrobe()
	layout = editor_panel
	label_in(layout, "上传衣服或穿搭参考图，为当前人物生成新服装。")
	label_in(layout, "换装支持轻柔动态；收藏后可在衣柜调整动作和位置，眼部动作需要先校准。")
	model_summary = label_in(layout, "图像模型尚未配置，请到台灯模型中心设置。")
	button_in(layout, "前往台灯模型中心配置", func(): model_settings_requested.emit())
	var service := VBoxContainer.new()
	service_panel = service
	service.visible = false
	layout.add_child(service)
	label_in(service, "图像服务")
	provider = OptionButton.new()
	provider.add_item("自动识别地址和模型")
	provider.add_item("豆包 Seedream（火山方舟）")
	provider.add_item("兼容 Images Edits")
	service.add_child(provider)
	endpoint = field_in(service, "服务地址（豆包可填 /api/v3）", "https://ark.cn-beijing.volces.com/api/v3")
	model = field_in(service, "图像模型名称", "填写服务商提供的图片编辑模型")
	auto_path = CheckButton.new()
	auto_path.text = "自动补全豆包基础地址的生成路径"
	auto_path.button_pressed = true
	service.add_child(auto_path)
	size_input = field_in(service, "生成尺寸（按服务支持填写）", "例如：2K、1024x1536；兼容模式可留空")
	size_input.text = ""
	label_in(service, "等待时间（秒）")
	timeout_input = SpinBox.new()
	timeout_input.min_value = 30
	timeout_input.max_value = 600
	timeout_input.value = 180
	service.add_child(timeout_input)
	key = field_in(service, "图像服务 Key（加密保存在本机）", "不使用聊天模型的 Key")
	key.secret = true
	service_hint = label_in(service, "")
	provider.item_selected.connect(on_provider_selected)
	endpoint.text_changed.connect(func(_value: String): refresh_service_hint())
	model.text_changed.connect(func(_value: String): refresh_service_hint())
	button_in(service, "保存图像接口配置", save_service)
	service_status = label_in(service, "配置供柜子里的换装功能使用。Key 加密保存在本机，只在你的这台电脑上能解开。")
	var previews := HBoxContainer.new()
	previews.custom_minimum_size.y = 200
	layout.add_child(previews)
	for title in ["参考图", "换装预览"]:
		var column := VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		previews.add_child(column)
		label_in(column, title)
		var panel := PanelContainer.new()
		panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
		column.add_child(panel)
		var preview := TextureRect.new()
		preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		panel.add_child(preview)
		if title == "参考图":
			reference_preview = preview
		else:
			result_preview = preview
	select_button = button_in(layout, "选择参考图片", func(): NativeFilePicker.open(picker))
	var cleanup_options := VBoxContainer.new()
	button_in(layout, "边缘清理设置 ▾", func(): cleanup_options.visible = not cleanup_options.visible)
	layout.add_child(cleanup_options)
	cleanup_options.visible = false
	label_in(cleanup_options, "绿幕清理强度（0–100，越高越容易去除绿色边缘）")
	cleanup_strength = SpinBox.new()
	cleanup_strength.min_value = 0
	cleanup_strength.max_value = 100
	cleanup_strength.value = 60
	cleanup_options.add_child(cleanup_strength)
	clear_gaps = CheckButton.new()
	clear_gaps.text = "清理头发缝隙中的绿色（绿色服装请关闭）"
	clear_gaps.button_pressed = true
	cleanup_options.add_child(clear_gaps)
	cleanup_button = button_in(cleanup_options, "重新清理当前形象（不联网）", reprocess_preview)
	cleanup_button.disabled = true
	instructions = TextEdit.new()
	instructions.custom_minimum_size.y = 65
	instructions.placeholder_text = "补充要求（可选），例如：保留发型，换成蓝色外套。"
	layout.add_child(instructions)
	label_in(layout, "点击生成会把原人物、参考图和补充要求发送到上方配置的服务，可能产生接口费用。")
	var actions := HBoxContainer.new()
	layout.add_child(actions)
	generate_button = button_in(actions, "生成换装预览", generate)
	apply_button = button_in(actions, "应用换装", apply_candidate)
	apply_button.disabled = true
	cancel_button = button_in(actions, "取消生成", cancel)
	cancel_button.disabled = true
	button_in(actions, "恢复原装", restore_original)
	var save_row := HBoxContainer.new()
	layout.add_child(save_row)
	save_name = LineEdit.new()
	save_name.placeholder_text = "形象名称，例如：红色工装"
	save_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	save_row.add_child(save_name)
	button_in(save_row, "收藏这套形象", save_to_wardrobe)
	status = label_in(layout, "请先配置图像服务并选择参考图片。")
	picker = FileDialog.new()
	picker.access = FileDialog.ACCESS_FILESYSTEM
	picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	picker.use_native_dialog = true
	picker.filters = PackedStringArray(["*.png,*.jpg,*.jpeg,*.webp ; 图片"])
	window.add_child(picker)
	picker.file_selected.connect(select_reference)
	request = HTTPRequest.new()
	request.timeout = 180.0
	request.body_size_limit = 40 * 1024 * 1024
	# Do not follow redirects with an Authorization header.
	request.max_redirects = 0
	add_child(request)
	request.request_completed.connect(completed)
	refresh_service_hint()
	apply_light_theme(window)

func surface(color: Color) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.border_color = Color("b8d8ec")
	box.set_border_width_all(1)
	box.set_corner_radius_all(10)
	box.content_margin_left = 10
	box.content_margin_right = 10
	box.content_margin_top = 6
	box.content_margin_bottom = 6
	return box

func apply_light_theme(node: Node) -> void:
	if node is Control:
		# 只补齐“还没被显式设定过”的属性。
		# 这里是递归覆盖整棵控件树：原来无条件写 font_size=15，会把标题的 24
		# 一起压成正文大小，也让本函数无法重复调用（第二次会抹掉第一次之后设的值）。
		# 因此字体只在还没有 font_size 覆盖时设置，样式只在该状态槽为空时设置。
		var control := node as Control
		if not control.has_theme_font_size_override("font_size"):
			control.add_theme_font_size_override("font_size", 15)
		for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color", "font_selected_color"]:
			if not control.has_theme_color_override(color_name):
				control.add_theme_color_override(color_name, Color("173f63"))
		if not control.has_theme_color_override("font_placeholder_color"):
			control.add_theme_color_override("font_placeholder_color", Color("6f8ba2"))
		if not control.has_theme_color_override("font_disabled_color"):
			control.add_theme_color_override("font_disabled_color", Color("718b9e"))
	if node is Button:
		var button := node as Button
		# normal/hover/pressed/disabled 全部为空说明这个按钮还没有风格，才补默认外观。
		if not button.has_theme_stylebox_override("normal") and not button.has_theme_stylebox_override("hover"):
			button.add_theme_stylebox_override("normal", surface(Color.WHITE))
			button.add_theme_stylebox_override("hover", surface(Color("e5f5ff")))
			button.add_theme_stylebox_override("pressed", surface(Color("d3ecff")))
			button.add_theme_stylebox_override("disabled", surface(Color("edf3f7")))
	if node is LineEdit or node is TextEdit or node is ItemList:
		var field := node as Control
		if not field.has_theme_stylebox_override("normal"):
			field.add_theme_stylebox_override("normal", surface(Color.WHITE))
			field.add_theme_stylebox_override("focus", surface(Color("f7fcff")))
	if node is ItemList:
		var list := node as ItemList
		if not list.has_theme_stylebox_override("panel"):
			list.add_theme_stylebox_override("panel", surface(Color.WHITE))
		if not list.has_theme_stylebox_override("selected"):
			list.add_theme_stylebox_override("selected", surface(Color("d3ecff")))
			list.add_theme_stylebox_override("selected_focus", surface(Color("d3ecff")))
	if node is PanelContainer:
		var panel := node as PanelContainer
		if not panel.has_theme_stylebox_override("panel"):
			panel.add_theme_stylebox_override("panel", surface(Color("e5f1f8")))
	if node is SpinBox:
		apply_light_theme(node.get_line_edit())
	for child in node.get_children():
		apply_light_theme(child)

func build_wardrobe() -> void:
	label_in(wardrobe_panel, "保存喜欢的形象，随时换上，无需再次生成。")
	wardrobe_list = ItemList.new()
	wardrobe_list.custom_minimum_size.y = 180
	wardrobe_list.fixed_icon_size = Vector2i(72, 100)
	wardrobe_list.max_columns = 3
	wardrobe_list.fixed_column_width = 190
	wardrobe_list.icon_mode = ItemList.ICON_MODE_TOP
	wardrobe_panel.add_child(wardrobe_list)
	wardrobe_list.item_selected.connect(preview_wardrobe)
	calibration_prompt = HBoxContainer.new()
	calibration_prompt.hide()
	wardrobe_panel.add_child(calibration_prompt)
	calibration_hint = label_in(calibration_prompt, "")
	calibration_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button_in(calibration_prompt, "结束校准", finish_eye_calibration)
	wardrobe_preview = TextureRect.new()
	wardrobe_preview.custom_minimum_size.y = 280
	wardrobe_preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	wardrobe_preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	wardrobe_preview.mouse_filter = Control.MOUSE_FILTER_STOP
	wardrobe_preview.gui_input.connect(on_preview_input)
	wardrobe_panel.add_child(wardrobe_preview)
	for tint in [Color("318dcc"), Color("ed9748")]:
		var marker := ColorRect.new()
		marker.color = tint
		marker.size = Vector2(7, 7)
		marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		marker.hide()
		wardrobe_preview.add_child(marker)
		eye_markers.append(marker)
	for field in ["head_y", "shoulder_y", "feet_y"]:
		var line := ColorRect.new()
		line.color = Color(0.2, 0.55, 0.8, 0.7)
		line.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.hide()
		wardrobe_preview.add_child(line)
		var caption := Label.new()
		caption.text = {"head_y": "头部", "shoulder_y": "肩线", "feet_y": "脚底"}[field]
		caption.position = Vector2(0, -19)
		caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(caption)
		calibration_lines[field] = line
	wardrobe_name = field_in(wardrobe_panel, "形象名称", "先选择一套形象")
	var row := HBoxContainer.new()
	wardrobe_panel.add_child(row)
	button_in(row, "穿上这套", wear_from_wardrobe)
	button_in(row, "保存名称", rename_wardrobe)
	button_in(row, "恢复原装", restore_original)
	button_in(wardrobe_panel, "动作与位置设置 ▾", func(): motion_options.visible = not motion_options.visible)
	motion_options = VBoxContainer.new()
	motion_options.add_theme_constant_override("separation", 8)
	motion_options.hide()
	wardrobe_panel.add_child(motion_options)
	label_in(motion_options, "调节只影响上方预览，点击保存后才会改变这套衣服。百分比以完整图片为准。")
	var presets := HBoxContainer.new()
	motion_options.add_child(presets)
	for preset_name in ["轻柔", "正常", "静止"]:
		button_in(presets, preset_name, use_motion_preset.bind(preset_name))
	add_motion_control("breath", "呼吸强度", 0, 2, 0.05)
	add_motion_control("hair", "头发摆动", 0, 2, 0.05)
	add_motion_control("arm_swing", "手臂摆幅", 0, 2, 0.05)
	add_motion_control("leg_swing", "腿部重心", 0, 2, 0.05)
	add_motion_control("speed", "动作速度", 0, 2, 0.05)
	button_in(motion_options, "位置与眼睛校准 ▾", func(): calibration_options.visible = not calibration_options.visible)
	calibration_options = VBoxContainer.new()
	calibration_options.add_theme_constant_override("separation", 8)
	calibration_options.hide()
	motion_options.add_child(calibration_options)
	add_motion_control("head_y", "头部中心（%）", 8, 40, 0.5, calibration_options)
	add_motion_control("shoulder_y", "肩线位置（%）", 18, 60, 0.5, calibration_options)
	add_motion_control("feet_y", "脚底位置（%）", 65, 100, 0.5, calibration_options)
	var eye_row := HBoxContainer.new()
	calibration_options.add_child(eye_row)
	button_in(eye_row, "校准画面左眼", begin_eye_calibration.bind("left"))
	button_in(eye_row, "校准画面右眼", begin_eye_calibration.bind("right"))
	eye_calibration_label = label_in(calibration_options, "请依次点击上方人物的两只眼睛，校准后才能启用眼部动作。")
	add_motion_control("eye_radius_x", "眼部范围宽（%）", 1, 7, 0.1, calibration_options)
	add_motion_control("eye_radius_y", "眼部范围高（%）", 0.8, 5.5, 0.1, calibration_options)
	eyes_enabled = CheckButton.new()
	eyes_enabled.text = "校准后启用视线"
	eyes_enabled.disabled = true
	calibration_options.add_child(eyes_enabled)
	eyes_enabled.toggled.connect(on_eyes_toggled)
	blink_enabled = CheckButton.new()
	blink_enabled.text = "简易眨眼（试验）"
	blink_enabled.disabled = true
	calibration_options.add_child(blink_enabled)
	blink_enabled.toggled.connect(on_blink_toggled)
	label_in(calibration_options, "简易眨眼会压缩眼部图片，不会生成真正的闭眼画稿；效果不合适可关闭。")
	button_in(motion_options, "保存这套动作设置", save_motion_profile)
	wardrobe_status = label_in(wardrobe_panel, "衣柜还是空的，先收藏一套形象吧。")
	populate_motion_controls(MotionProfile.defaults())

func show_wardrobe(show: bool) -> void:
	wardrobe_panel.visible = show
	editor_panel.visible = not show
	if show:
		refresh_wardrobe()

func valid_look_id(id: String) -> bool:
	return id.begins_with("look_") and id.length() == 29 and id.substr(5).is_valid_hex_number(false)

func wardrobe_directory() -> String:
	return storage.path_join("衣柜")

func profile_value(value: Variant) -> Dictionary:
	return MotionProfile.sanitize(value if value is Dictionary else {})

func active_motion_profile() -> Dictionary:
	return current_motion_profile.duplicate(true)

func reset_candidate_profile() -> void:
	candidate_look_id = ""
	candidate_motion_profile = MotionProfile.defaults()
	candidate_is_active = false

func read_look_settings(id: String) -> ConfigFile:
	var settings := ConfigFile.new()
	if valid_look_id(id):
		var path := wardrobe_directory().path_join(id + ".cfg")
		if FileAccess.file_exists(path):
			settings.load(path)
	return settings

func write_look_settings(id: String, settings: ConfigFile) -> Error:
	if not valid_look_id(id):
		return ERR_INVALID_PARAMETER
	var path := wardrobe_directory().path_join(id + ".cfg")
	var error := settings.save(path + ".pending")
	if error != OK:
		return error
	return DirAccess.rename_absolute(path + ".pending", path)

func write_thumbnail(id: String, source: Image) -> Image:
	if not valid_look_id(id) or source == null or source.is_empty():
		return null
	var thumbnail := source.duplicate() as Image
	var factor := minf(72.0 / thumbnail.get_width(), 100.0 / thumbnail.get_height())
	thumbnail.resize(maxi(1, roundi(thumbnail.get_width() * factor)), maxi(1, roundi(thumbnail.get_height() * factor)), Image.INTERPOLATE_LANCZOS)
	var path := wardrobe_directory().path_join(id + ".thumb.png")
	if thumbnail.save_png(path + ".pending") == OK:
		DirAccess.rename_absolute(path + ".pending", path)
	return thumbnail

func load_thumbnail(id: String) -> Image:
	var path := wardrobe_directory().path_join(id + ".thumb.png")
	if not valid_look_id(id) or not FileAccess.file_exists(path):
		return null
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 256 * 1024:
		return null
	file = null
	var thumbnail := Image.new()
	if thumbnail.load(path) != OK or thumbnail.is_empty() or thumbnail.get_width() > 100 or thumbnail.get_height() > 100:
		return null
	return thumbnail

func save_to_wardrobe() -> void:
	if busy:
		return
	var img := candidate if candidate != null else current_appearance
	if img == null:
		status.text = "请先生成预览或应用一套形象，再收藏。"
		return
	var id := "look_" + Crypto.new().generate_random_bytes(12).hex_encode()
	var directory := wardrobe_directory()
	if DirAccess.make_dir_recursive_absolute(directory) != OK or img.save_png(directory.path_join(id + ".png")) != OK:
		status.text = "衣柜图片保存失败，请检查目录权限。"
		return
	var title := save_name.text.strip_edges().left(40)
	if title.is_empty():
		title = "新装 " + Time.get_datetime_string_from_system().replace("T", " ")
	var settings := ConfigFile.new()
	settings.set_value("look", "name", title)
	var profile := candidate_motion_profile if candidate != null else current_motion_profile
	settings.set_value("look", "motion", profile_value(profile))
	if write_look_settings(id, settings) != OK:
		status.text = "衣柜名称保存失败，当前形象没有改变。"
		return
	write_thumbnail(id, img)
	if cleanup_source != null and (candidate != null or cleanup_look_id == active_look_id):
		cleanup_look_id = id
		cleanup_motion_profile = profile_value(profile)
	if candidate != null:
		candidate_look_id = id
	if active and (candidate == null or candidate_is_active):
		active_look_id = id
		persist(true)
	status.text = "已收藏“%s”，可在我的衣柜随时换上。" % title
	refresh_wardrobe()

func write_look_name(id: String, title: String) -> Error:
	if not valid_look_id(id):
		return ERR_INVALID_PARAMETER
	var settings := read_look_settings(id)
	settings.set_value("look", "name", title.left(40))
	return write_look_settings(id, settings)

func refresh_wardrobe() -> void:
	wardrobe_list.clear()
	wardrobe_preview.texture = null
	preview_texture = null
	selected_look_id = ""
	calibration_eye = ""
	if preview_viewport:
		preview_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	wardrobe_name.text = ""
	populate_motion_controls(MotionProfile.defaults())
	var directory := DirAccess.open(wardrobe_directory())
	if directory == null:
		wardrobe_status.text = "衣柜还是空的，先收藏一套形象吧。"
		return
	for filename in directory.get_files():
		var id := filename.get_basename()
		if filename.get_extension() != "cfg" or not valid_look_id(id):
			continue
		var settings := ConfigFile.new()
		if settings.load(wardrobe_directory().path_join(filename)) != OK:
			continue
		if not FileAccess.file_exists(wardrobe_directory().path_join(id + ".png")):
			continue
		# Older outfits migrate lazily on selection; opening the wardrobe never decodes their full-size images.
		var thumbnail := load_thumbnail(id)
		var icon: Texture2D = ImageTexture.create_from_image(thumbnail) if thumbnail != null else null
		var index := wardrobe_list.add_item(str(settings.get_value("look", "name", "未命名形象")), icon)
		wardrobe_list.set_item_metadata(index, id)
	wardrobe_status.text = "已收藏 %d 套，选择后点击“穿上这套”。" % wardrobe_list.item_count

func load_look(id: String) -> Image:
	if not valid_look_id(id):
		return null
	var path := wardrobe_directory().path_join(id + ".png")
	if not FileAccess.file_exists(path):
		return null
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_FILE_BYTES:
		return null
	file = null
	var img := Image.new()
	if img.load(path) != OK or img.is_empty() or img.get_width() > MAX_SIDE or img.get_height() > MAX_SIDE:
		return null
	return img

func preview_wardrobe(index: int) -> void:
	if index < 0 or index >= wardrobe_list.item_count:
		return
	selected_look_id = str(wardrobe_list.get_item_metadata(index))
	var img := load_look(selected_look_id)
	if img == null:
		wardrobe_preview.texture = null
		preview_texture = null
		selected_look_id = ""
		wardrobe_status.text = "这套形象的图片无法读取。"
		return
	wardrobe_name.text = wardrobe_list.get_item_text(index)
	var settings := read_look_settings(selected_look_id)
	populate_motion_controls(profile_value(settings.get_value("look", "motion", {})))
	preview_texture = ImageTexture.create_from_image(img)
	setup_motion_preview()
	if load_thumbnail(selected_look_id) == null:
		var thumbnail := write_thumbnail(selected_look_id, img)
		if thumbnail:
			wardrobe_list.set_item_icon(index, ImageTexture.create_from_image(thumbnail))
	wardrobe_status.text = "正在预览“%s”；调节后请保存动作设置。" % wardrobe_name.text

func wear_from_wardrobe() -> void:
	if busy or wardrobe_list.get_selected_items().is_empty():
		wardrobe_status.text = "请先选择一套形象，并等待当前处理结束。"
		return
	var index := int(wardrobe_list.get_selected_items()[0])
	var img := load_look(str(wardrobe_list.get_item_metadata(index)))
	if img == null:
		wardrobe_status.text = "这套形象的图片无法读取。"
		return
	candidate = img
	candidate_is_active = false
	candidate_look_id = str(wardrobe_list.get_item_metadata(index))
	var settings := read_look_settings(candidate_look_id)
	candidate_motion_profile = profile_value(settings.get_value("look", "motion", {}))
	cleanup_source = img.duplicate()
	cleanup_motion_profile = candidate_motion_profile.duplicate(true)
	cleanup_look_id = candidate_look_id
	result_preview.texture = ImageTexture.create_from_image(img)
	set_busy(false)
	apply_candidate()
	wardrobe_status.text = status.text

func rename_wardrobe() -> void:
	if wardrobe_list.get_selected_items().is_empty() or wardrobe_name.text.strip_edges().is_empty():
		return
	var index := int(wardrobe_list.get_selected_items()[0])
	var title := wardrobe_name.text.strip_edges().left(40)
	if write_look_name(str(wardrobe_list.get_item_metadata(index)), title) == OK:
		wardrobe_list.set_item_text(index, title)
		wardrobe_status.text = "名称已保存。"
	else:
		wardrobe_status.text = "名称保存失败，请检查目录权限。"

func add_motion_control(field: String, title: String, minimum: float, maximum: float, step: float, parent: Control = null) -> void:
	var row := HBoxContainer.new()
	(parent if parent != null else motion_options).add_child(row)
	var label := label_in(row, title)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var input := SpinBox.new()
	input.min_value = minimum
	input.max_value = maximum
	input.step = step
	input.custom_minimum_size.x = 130
	row.add_child(input)
	motion_controls[field] = input
	input.value_changed.connect(on_motion_value_changed.bind(field))

func populate_motion_controls(profile: Dictionary) -> void:
	motion_updating = true
	selected_motion_profile = profile_value(profile)
	calibration_eye = ""
	calibration_prompt.hide()
	wardrobe_preview.custom_minimum_size.y = 280
	calibrated_eyes = {"left": bool(selected_motion_profile.get("eyes_calibrated", false)), "right": bool(selected_motion_profile.get("eyes_calibrated", false))}
	for field in motion_controls:
		var input := motion_controls[field] as SpinBox
		input.value = float(selected_motion_profile[field]) * motion_control_scale(field)
	eyes_enabled.set_pressed_no_signal(bool(selected_motion_profile.get("eyes_enabled", false)))
	blink_enabled.set_pressed_no_signal(bool(selected_motion_profile.get("blink_enabled", false)))
	refresh_eye_controls()
	motion_updating = false
	update_motion_preview()

func use_motion_preset(preset_name: String) -> void:
	if selected_look_id.is_empty():
		wardrobe_status.text = "先在衣柜选择一套形象。"
		return
	var key_name: String = {"轻柔": "gentle", "正常": "normal", "静止": "still"}[preset_name]
	populate_motion_controls(MotionProfile.preset(key_name, selected_motion_profile))
	wardrobe_status.text = "已预览%s动作，点击“保存这套动作设置”后生效。" % preset_name

func on_motion_value_changed(value: float, field: String) -> void:
	if motion_updating:
		return
	selected_motion_profile[field] = value / motion_control_scale(field)
	if field in ["breath", "hair", "speed"]:
		selected_motion_profile["enabled"] = true
	selected_motion_profile = profile_value(selected_motion_profile)
	# Coupled limits (e.g. shoulders below the head) must also be visible in the controls.
	for control_field in motion_controls:
		motion_controls[control_field].set_value_no_signal(float(selected_motion_profile[control_field]) * motion_control_scale(control_field))
	update_motion_preview()
	wardrobe_status.text = "动作预览已更新，尚未保存。"

func motion_control_scale(field: String) -> float:
	return 100.0 if field.ends_with("_y") or field.begins_with("eye_radius_") else 1.0

func on_eyes_toggled(value: bool) -> void:
	if motion_updating:
		return
	selected_motion_profile["eyes_enabled"] = value and bool(selected_motion_profile.get("eyes_calibrated", false))
	update_motion_preview()
	wardrobe_status.text = "眼部预览已更新，尚未保存。"

func on_blink_toggled(value: bool) -> void:
	if motion_updating:
		return
	selected_motion_profile["blink_enabled"] = value and bool(selected_motion_profile.get("eyes_calibrated", false))
	update_motion_preview()
	wardrobe_status.text = "眨眼预览已更新，尚未保存。"

func begin_eye_calibration(eye: String) -> void:
	if selected_look_id.is_empty() or preview_texture == null:
		wardrobe_status.text = "先在衣柜选择一套形象。"
		return
	calibration_eye = eye
	calibration_prompt.show()
	wardrobe_preview.custom_minimum_size.y = 420
	calibration_hint.text = "请点画面%s眼中心。人物已暂停；位置尚未保存。" % ("左侧" if eye == "left" else "右侧")
	eye_calibration_label.text = calibration_hint.text
	update_motion_preview()
	focus_calibration_preview.call_deferred()

func focus_calibration_preview() -> void:
	await get_tree().process_frame
	if not calibration_eye.is_empty():
		wardrobe_scroll.ensure_control_visible(wardrobe_preview)
		wardrobe_scroll.ensure_control_visible(calibration_prompt)

func finish_eye_calibration() -> void:
	calibration_eye = ""
	calibration_prompt.hide()
	wardrobe_preview.custom_minimum_size.y = 280
	refresh_eye_controls()
	update_motion_preview()
	await get_tree().process_frame
	wardrobe_scroll.ensure_control_visible(calibration_options)

func preview_image_rect() -> Rect2:
	if preview_texture == null:
		return Rect2()
	var texture_size := preview_texture.get_size()
	var factor := minf(wardrobe_preview.size.x / texture_size.x, wardrobe_preview.size.y / texture_size.y)
	var drawn := texture_size * factor
	return Rect2((wardrobe_preview.size - drawn) / 2.0, drawn)

func on_preview_input(event: InputEvent) -> void:
	if calibration_eye.is_empty() or not event is InputEventMouseButton or event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
		return
	var rect := preview_image_rect()
	if not rect.has_point(event.position):
		return
	var uv: Vector2 = (event.position - rect.position) / rect.size
	var valid_x := uv.x >= 0.15 and uv.x <= 0.60 if calibration_eye == "left" else uv.x >= 0.40 and uv.x <= 0.85
	if not valid_x or uv.y < 0.06 or uv.y > 0.50:
		calibration_hint.text = "请点击人物面部的%s眼中心。" % ("左侧" if calibration_eye == "left" else "右侧")
		return
	var next_eye := "right" if calibration_eye == "left" else "left"
	selected_motion_profile["eye_" + calibration_eye + "_x"] = uv.x
	selected_motion_profile["eye_" + calibration_eye + "_y"] = uv.y
	calibrated_eyes[calibration_eye] = true
	selected_motion_profile["eyes_calibrated"] = bool(calibrated_eyes.get("left", false)) and bool(calibrated_eyes.get("right", false))
	calibration_eye = ""
	selected_motion_profile = profile_value(selected_motion_profile)
	refresh_eye_controls()
	update_motion_preview()
	if not bool(calibrated_eyes.get(next_eye, false)):
		begin_eye_calibration(next_eye)
	else:
		calibration_hint.text = "双眼已标记。点击“结束校准”返回设置，再保存这套动作。"
	wardrobe_status.text = "眼睛位置已更新，尚未保存。"
	wardrobe_preview.accept_event()

func refresh_eye_controls() -> void:
	var calibrated := bool(selected_motion_profile.get("eyes_calibrated", false))
	eyes_enabled.disabled = not calibrated
	blink_enabled.disabled = not calibrated
	if calibrated:
		eye_calibration_label.text = "双眼已校准。蓝点为画面左眼，橙点为画面右眼；可再次点击按钮调整。"
	elif calibrated_eyes.get("left", false) or calibrated_eyes.get("right", false):
		eye_calibration_label.text = "已标记一只眼睛，请继续校准另一只。"
	else:
		eye_calibration_label.text = "请依次点击上方人物的两只眼睛，校准后才能启用眼部动作。"

func save_motion_profile() -> void:
	if busy or selected_look_id.is_empty():
		wardrobe_status.text = "请先选择一套形象，并等待当前处理结束。"
		return
	var profile := profile_value(selected_motion_profile)
	var settings := read_look_settings(selected_look_id)
	settings.set_value("look", "motion", profile)
	if write_look_settings(selected_look_id, settings) != OK:
		wardrobe_status.text = "动作设置保存失败，请检查目录权限。"
		return
	if candidate_look_id == selected_look_id:
		candidate_motion_profile = profile.duplicate(true)
	if cleanup_look_id == selected_look_id:
		cleanup_motion_profile = profile.duplicate(true)
	if active and active_look_id == selected_look_id:
		current_motion_profile = profile.duplicate(true)
		motion_profile_changed.emit(active_motion_profile())
		if persist(true) != OK:
			wardrobe_status.text = "衣柜动作已保存并应用，但启动设置写入失败；重启后请重新穿上这套。"
			return
	wardrobe_status.text = "这套动作设置已保存。" + ("当前穿着已同步更新。" if active and active_look_id == selected_look_id else "下次穿上时生效。")

func setup_motion_preview() -> void:
	if preview_texture == null:
		return
	if preview_rig == null and base_texture != null and base_texture.get_size() == Vector2(1024, 1536):
		preview_viewport = SubViewport.new()
		preview_viewport.size = Vector2i(384, 576)
		preview_viewport.transparent_bg = true
		preview_viewport.disable_3d = true
		add_child(preview_viewport)
		preview_rig = LayeredPreview.new()
		preview_viewport.add_child(preview_rig)
		preview_rig.position = Vector2(192, 288)
		preview_rig.scale = Vector2.ONE * 0.375
		preview_rig.setup(base_texture, base_texture)
	wardrobe_preview.texture = preview_texture
	if preview_rig and preview_rig.ready_for_use and preview_rig.set_appearance(preview_texture):
		preview_rig.show()
		wardrobe_preview.texture = preview_viewport.get_texture()
		preview_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		update_motion_preview()
	elif preview_viewport:
		preview_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED

func update_motion_preview() -> void:
	if preview_rig and preview_rig.ready_for_use:
		var profile := selected_motion_profile.duplicate(true)
		if not calibration_eye.is_empty():
			profile["enabled"] = false
			profile["eyes_enabled"] = false
			profile["blink_enabled"] = false
		preview_rig.set_motion_profile(profile)

func _process(delta: float) -> void:
	var showing := window != null and window.visible and wardrobe_panel.visible and preview_texture != null
	if preview_viewport:
		preview_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS if showing and wardrobe_preview.texture == preview_viewport.get_texture() else SubViewport.UPDATE_DISABLED
	for index in eye_markers.size():
		var side := "left" if index == 0 else "right"
		eye_markers[index].visible = showing and calibration_options.is_visible_in_tree() and bool(calibrated_eyes.get(side, false))
		if eye_markers[index].visible:
			var rect := preview_image_rect()
			eye_markers[index].position = rect.position + rect.size * Vector2(float(selected_motion_profile["eye_" + side + "_x"]), float(selected_motion_profile["eye_" + side + "_y"])) - Vector2(3.5, 3.5)
	for field in calibration_lines:
		var line := calibration_lines[field] as ColorRect
		line.visible = showing and calibration_options.is_visible_in_tree() and not calibration_prompt.visible
		if line.visible:
			var image_rect := preview_image_rect()
			line.position = image_rect.position + Vector2(0, image_rect.size.y * float(selected_motion_profile[field]))
			line.size = Vector2(image_rect.size.x, 1)
	if not showing or preview_rig == null or not preview_rig.ready_for_use:
		return
	preview_clock += delta
	var blink := maxf(0.0, 1.0 - absf(fmod(preview_clock, 4.0) - 3.8) / 0.12)
	var rect := preview_image_rect()
	var gaze := Vector2.ZERO
	if rect.has_point(wardrobe_preview.get_local_mouse_position()):
		gaze = ((wardrobe_preview.get_local_mouse_position() - rect.get_center()) / (rect.size * 0.5)).clamp(Vector2(-1, -1), Vector2.ONE)
	preview_rig.advance(delta, calibration_eye.is_empty(), gaze, blink)

func is_seedream() -> bool:
	if provider.selected != 0:
		return provider.selected == 1
	return endpoint.text.to_lower().contains("volces.com") or model.text.to_lower().contains("seedream")

func on_provider_selected(index: int) -> void:
	if index == 1:
		if endpoint.text.strip_edges().is_empty():
			endpoint.text = "https://ark.cn-beijing.volces.com/api/v3"
		if model.text.strip_edges().is_empty():
			model.text = "doubao-seedream-5-0-260128"
	refresh_service_hint()

func refresh_service_hint() -> void:
	if not service_hint:
		return
	service_hint.text = "豆包：自动补全生成地址，双图参考生成后移除纯绿背景；请检查头发与衣服边缘。" if is_seedream() else "兼容接口：双图 Images Edits，需返回透明 PNG。DeepSeek 聊天模型不能用于换装。"
	if model_summary:
		model_summary.text = "换装图像模型：" + model.text.strip_edges() if not model.text.strip_edges().is_empty() else "图像模型尚未配置，请到台灯模型中心设置。"

func mount_model_settings(container: Control) -> void:
	service_panel.reparent(container, false)
	service_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	service_panel.visible = true

func resolved_endpoint() -> String:
	var url := endpoint.text.strip_edges().trim_suffix("/")
	if is_seedream() and auto_path.button_pressed and url.ends_with("/api/v3"):
		return url + "/images/generations"
	return url

func open() -> void:
	var usable := DisplayServer.screen_get_usable_rect()
	if usable.size.x > 100 and usable.size.y > 100:
		window.size = Vector2i(mini(720, usable.size.x), mini(820, usable.size.y))
		window.position = usable.position + (usable.size - window.size) / 2
	NativeWindows.fit(window)
	window.show()
	window.grab_focus()

func close() -> void:
	cancel()
	window.hide()

func persist(active_value: bool) -> Error:
	var error := DirAccess.make_dir_recursive_absolute(storage)
	if error != OK:
		return error
	var settings := ConfigFile.new()
	settings.set_value("service", "endpoint", endpoint.text.strip_edges())
	settings.set_value("service", "model", model.text.strip_edges())
	settings.set_value("service", "provider", provider.selected)
	settings.set_value("service", "auto_path", auto_path.button_pressed)
	settings.set_value("service", "size", size_input.text.strip_edges())
	settings.set_value("service", "timeout", timeout_input.value)
	settings.set_value("cleanup", "strength", cleanup_strength.value)
	settings.set_value("cleanup", "gaps", clear_gaps.button_pressed)
	settings.set_value("appearance", "active", active_value)
	settings.set_value("appearance", "look_id", active_look_id if active_value else "")
	settings.set_value("appearance", "motion", active_motion_profile() if active_value else MotionProfile.defaults())
	error = settings.save(storage.path_join("settings.pending.cfg"))
	if error != OK:
		return error
	return DirAccess.rename_absolute(storage.path_join("settings.pending.cfg"), storage.path_join("settings.cfg"))

func save_service() -> void:
	var saved := persist(active) == OK
	var key_note := ""
	if saved:
		# [DSH] Key 以前只留在内存里，用户每次开程序都得重新粘贴。现在落盘，
		# 但**只走设备绑定加密**（和 chat/vision 的 Key 同一套），不写进 settings.cfg 明文。
		var typed := key.text.strip_edges()
		if typed.is_empty():
			clear_saved_key()
			key_note = "已清除保存的 Key。"
		elif save_saved_key(typed):
			key_note = "Key 已加密保存在本机。"
		else:
			key_note = "Key 保存失败（加密写入没有通过回读校验）。"
	status.text = ("接口与清理设置已保存；" + key_note) if saved else "无法保存设置，请检查换装目录的写入权限。"
	service_status.text = status.text

# ── [DSH] 换装 Key 的设备绑定加密存储 ────────────────────────────────
# 与 deepseek_config.gd 完全相同的做法：AtomicFile 先写临时文件再原子替换，
# 并回读校验；设备密钥包含电脑名与用户名，文件换台机器解不开。
func device_key() -> PackedByteArray:
	if device_key_source and device_key_source.has_method("device_key"):
		return device_key_source.device_key()
	# 没有注入来源（例如单独跑断言）时退回同一套派生规则，保证读得回自己写的文件。
	var stable_user_data_dir := OS.get_environment("APPDATA").strip_edges()
	if stable_user_data_dir.is_empty():
		stable_user_data_dir = OS.get_user_data_dir()
	else:
		stable_user_data_dir = stable_user_data_dir.path_join("Godot/app_userdata/蓝鲸智能体桌宠")
	stable_user_data_dir = stable_user_data_dir.replace("\\", "/")
	var identity := "%s|%s|%s|blue-whale-agent-v1" % [
		OS.get_environment("COMPUTERNAME"),
		OS.get_environment("USERNAME"),
		stable_user_data_dir
	]
	var hashing := HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(identity.to_utf8_buffer())
	return hashing.finish()

func has_saved_key() -> bool:
	return not secret_path.is_empty() and FileAccess.file_exists(secret_path)

func load_saved_key() -> String:
	if not has_saved_key():
		return ""
	var file := FileAccess.open_encrypted(secret_path, FileAccess.READ, device_key())
	if file == null:
		return ""
	var content := file.get_as_text().strip_edges()
	file.close()
	return content

func save_saved_key(value: String) -> bool:
	if secret_path.is_empty():
		return false
	var directory_error := DirAccess.make_dir_recursive_absolute(secret_path.get_base_dir())
	if directory_error != OK and directory_error != ERR_ALREADY_EXISTS:
		return false
	var previous := load_saved_key()
	if not AtomicFile.write_encrypted(secret_path, value, device_key()):
		if not previous.is_empty():
			AtomicFile.write_encrypted(secret_path, previous, device_key())
		return false
	# 写完必须回读校验：否则会出现"看起来保存了，重启却是空的或解不开"。
	return load_saved_key() == value

func clear_saved_key() -> void:
	if not secret_path.is_empty():
		AtomicFile.remove_quietly(secret_path)

func select_reference(path: String) -> void:
	if busy:
		return
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > MAX_FILE_BYTES:
		status.text = "图片无法读取，或超过 20 MB。"
		return
	var img := Image.new()
	if img.load(path) != OK or img.is_empty():
		status.text = "图片无法解码，请选择 PNG、JPEG 或 WebP。"
		return
	if img.get_width() > MAX_SIDE or img.get_height() > MAX_SIDE:
		status.text = "请使用长边不超过 4096 像素的参考图。"
		return
	reference_image = img
	reference_preview.texture = ImageTexture.create_from_image(img)
	candidate = null
	reset_candidate_profile()
	result_preview.texture = null
	apply_button.disabled = true
	status.text = "参考图已载入，点击生成后才会上传。"

func set_busy(value: bool) -> void:
	busy = value
	generate_button.disabled = value
	select_button.disabled = value
	apply_button.disabled = value or candidate == null
	cancel_button.disabled = not value
	endpoint.editable = not value
	model.editable = not value
	key.editable = not value
	instructions.editable = not value
	provider.disabled = value
	auto_path.disabled = value
	size_input.editable = not value
	timeout_input.editable = not value
	cleanup_strength.editable = not value
	clear_gaps.disabled = value
	cleanup_button.disabled = value or cleanup_source == null

func cancel() -> void:
	if not busy:
		return
	request.cancel_request()
	generation_id += 1
	set_busy(false)
	status.text = "已停止等待；服务端可能仍在处理本次生成。"

func valid_endpoint(url: String) -> bool:
	if "@" in url or "?" in url or "#" in url or "\n" in url or "\r" in url:
		return false
	return url.begins_with("https://") or url.begins_with("http://127.0.0.1:") or url.begins_with("http://localhost:")

func multipart(boundary: String) -> PackedByteArray:
	var data := PackedByteArray()
	var prompt := "Edit image 1 (the original character). Use only the clothing from image 2 as reference. Preserve image 1 identity, face, hair, art style, standing pose and body proportions. Show the entire character including feet. Output a single character on a genuinely transparent background, no text, shadows or extra objects. " + instructions.text.left(3000)
	var fields := {"model": model.text.strip_edges(), "prompt": prompt, "n": "1", "background": "transparent", "output_format": "png"}
	# Empty size uses the provider default.
	if not size_input.text.strip_edges().is_empty():
		fields["size"] = size_input.text.strip_edges()
	for name in fields:
		data.append_array(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % [boundary, name, fields[name]]).to_utf8_buffer())
	var images := [base_texture.get_image(), reference_image]
	for index in range(images.size()):
		data.append_array(("--%s\r\nContent-Disposition: form-data; name=\"image[]\"; filename=\"image%d.png\"\r\nContent-Type: image/png\r\n\r\n" % [boundary, index]).to_utf8_buffer())
		data.append_array(images[index].save_png_to_buffer())
		data.append_array("\r\n".to_utf8_buffer())
	data.append_array(("--%s--\r\n" % boundary).to_utf8_buffer())
	return data

func seedream_payload() -> Dictionary:
	return {
		"model": model.text.strip_edges(),
		"prompt": "图1是原人物，图2仅作为服装参考。保留图1的脸、发型、画风和身体比例，穿上图2的服装，不采用图2的人脸。保持完整正面站姿，头顶和鞋子完整留在画面中，四周留白。竖幅构图。背景必须均匀纯绿色 #00FF00，无渐变、无阴影、无文字、无其他物体，人物衣服不要使用此背景绿色。补充要求：" + instructions.text.left(2000),
		"image": ["data:image/png;base64," + Marshalls.raw_to_base64(base_texture.get_image().save_png_to_buffer()), "data:image/png;base64," + Marshalls.raw_to_base64(reference_image.save_png_to_buffer())],
		"size": size_input.text.strip_edges() if not size_input.text.strip_edges().is_empty() else "2K",
		"response_format": "b64_json",
		"sequential_image_generation": "disabled",
		"stream": false,
		"watermark": false
	}

# [DSH] 把当前网络（代理）设置套到换装自己的 HTTPRequest 上。
# provider 由 main.gd 注入（resolved_network_settings），这里不重复解析代理地址。
# 返回套用结果，便于自检直接断言"代理真的被套上了"。
func apply_network_proxy() -> Dictionary:
	if not network_settings_provider.is_valid():
		last_proxy_result = {"applied": false, "host": "", "port": -1, "reason": "没有注入网络设置来源"}
		return last_proxy_result
	last_proxy_result = NetworkConfig.apply_to_request(request, network_settings_provider.call())
	proxy_apply_count += 1
	return last_proxy_result

func generate() -> void:
	if busy:
		return
	if reference_image == null:
		status.text = "请先选择参考图片。"
		return
	var url := resolved_endpoint()
	if model.text.to_lower().begins_with("deepseek") or endpoint.text.to_lower().contains("api.deepseek.com"):
		status.text = "DeepSeek 聊天接口不能生成换装。请选择豆包 Seedream 或其他图像编辑服务。"
		return
	if not valid_endpoint(url) or model.text.strip_edges().is_empty() or key.text.strip_edges().is_empty() or "\n" in key.text or "\r" in key.text:
		status.text = "请到台灯模型中心的“图像／换装”页填写有效地址、模型和 Key。"
		return
	candidate = null
	result_preview.texture = null
	set_busy(true)
	reset_candidate_profile()
	generation_id += 1
	request_is_seedream = is_seedream()
	request.timeout = timeout_input.value
	# [DSH] 换装生成也必须走代理：这个 HTTPRequest 是自己 new 的，早期版本从没套过代理，
	# 于是用户开了代理照样连不上，而界面只显示"生成失败"，看不出是代理没生效。
	# 代理设置由 main.gd 通过 network_settings_provider 注入，避免两处各写一套解析。
	apply_network_proxy()
	status.text = "正在生成换装预览，最多等待 %d 秒……" % int(request.timeout)
	var boundary := "LiangJing" + str(Time.get_ticks_usec())
	var headers := PackedStringArray(["Authorization: Bearer " + key.text.strip_edges(), "Content-Type: multipart/form-data; boundary=" + boundary])
	var error: Error
	if request_is_seedream:
		headers[1] = "Content-Type: application/json"
		error = request.request(url, headers, HTTPClient.METHOD_POST, JSON.stringify(seedream_payload()))
	else:
		error = request.request_raw(url, headers, HTTPClient.METHOD_POST, multipart(boundary))
	if error != OK:
		set_busy(false)
		status.text = "请求未能启动，请检查服务地址或网络。"

func completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if not busy:
		return
	if result != HTTPRequest.RESULT_SUCCESS:
		set_busy(false)
		status.text = transport_error(result)
		return
	if code < 200 or code >= 300:
		set_busy(false)
		# Never display arbitrary upstream bodies: a provider could echo credentials.
		status.text = http_error(code)
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if not parsed is Dictionary or not parsed.get("data") is Array or parsed["data"].is_empty() or not parsed["data"][0] is Dictionary:
		set_busy(false)
		status.text = "返回格式不兼容：需要 data[0].b64_json 图片。"
		return
	var encoded = parsed["data"][0].get("b64_json", "")
	if not encoded is String or encoded.is_empty():
		set_busy(false)
		status.text = "接口没有返回 Base64 图片；请使用支持此格式的图像服务。"
		return
	var img := Image.new()
	var raw := Marshalls.base64_to_raw(encoded)
	var decoded: Error = img.load_jpg_from_buffer(raw) if raw.size() > 2 and raw[0] == 255 and raw[1] == 216 else img.load_png_from_buffer(raw)
	if decoded != OK:
		set_busy(false)
		status.text = "结果不是有效 PNG/JPEG 图片，无法预览。"
		return
	cleanup_source = img.duplicate()
	cleanup_look_id = ""
	cleanup_motion_profile = MotionProfile.defaults()
	if request_is_seedream and img.detect_alpha() == Image.ALPHA_NONE:
		status.text = "图片已生成，正在移除纯色背景……"
		var current_id := generation_id
		img = await remove_green_background(img, current_id)
		if current_id != generation_id:
			return
		if img == null:
			set_busy(false)
			status.text = "生成图没有可识别的纯绿背景，未应用。请要求均匀纯绿背景后重新生成。"
			return
	reset_candidate_profile()
	cleanup_motion_profile = MotionProfile.defaults()
	candidate = normalize_image(img)
	set_busy(false)
	if candidate == null:
		status.text = "结果不是可用的透明人物图，或尺寸超限。请调整要求后重新生成。"
		return
	result_preview.texture = ImageTexture.create_from_image(candidate)
	apply_button.disabled = false
	status.text = "预览已就绪。请检查脸、服装和完整站姿，满意后应用。"

func transport_error(result: int) -> String:
	match result:
		HTTPRequest.RESULT_CANT_RESOLVE:
			return "无法解析服务域名，请检查地址和 DNS。"
		HTTPRequest.RESULT_CANT_CONNECT, HTTPRequest.RESULT_CONNECTION_ERROR:
			return "无法连接图像服务，请检查网络或代理；本次没有收到服务响应。"
		HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
			return "HTTPS 证书握手失败，请检查系统时间、证书和代理设置。"
		HTTPRequest.RESULT_TIMEOUT:
			return "等待超过 %d 秒。服务端可能仍在生成，重新请求可能再次计费。" % int(request.timeout)
		HTTPRequest.RESULT_BODY_SIZE_LIMIT_EXCEEDED:
			return "返回图片超过接收上限，请降低图片尺寸。"
	return "图像请求中断（网络结果 %d），请检查连接后再试。" % result

func http_error(code: int) -> String:
	match code:
		400:
			return "请求参数不被接受（HTTP 400），请核对模型是否支持双图及 2K 输出。"
		401:
			return "图像服务 Key 无效或已过期（HTTP 401）。"
		403:
			return "没有模型调用权限（HTTP 403），请检查模型开通状态。"
		404:
			return "接口或模型未找到（HTTP 404）。豆包地址应以 /api/v3/images/generations 结尾，并使用控制台已开通的模型。"
		429:
			return "服务限流或额度不足（HTTP 429），请查看服务控制台。"
	return "图像服务返回 HTTP %d；未应用任何新形象。" % code

# Only remove green pixels connected to the outside, preserving enclosed details.
# Yield in batches so cancellation and window interaction remain responsive.
func remove_green_background(source: Image, current_id: int) -> Image:
	if source.get_width() > MAX_SIDE or source.get_height() > MAX_SIDE:
		return null
	var img := source.duplicate() as Image
	img.convert(Image.FORMAT_RGBA8)
	if maxi(img.get_width(), img.get_height()) > 2048:
		var factor := 2048.0 / maxi(img.get_width(), img.get_height())
		img.resize(maxi(1, roundi(img.get_width() * factor)), maxi(1, roundi(img.get_height() * factor)))
	var width := img.get_width()
	var height := img.get_height()
	var bytes := img.get_data()
	var visited := PackedByteArray()
	visited.resize(width * height)
	var queue := PackedInt32Array()
	for x in range(width):
		queue.append(x)
		queue.append((height - 1) * width + x)
	for y in range(1, height - 1):
		queue.append(y * width)
		queue.append(y * width + width - 1)
	var index := 0
	var removed := 0
	while index < queue.size():
		var pixel := queue[index]
		index += 1
		if index % 50000 == 0:
			await get_tree().process_frame
			if current_id != generation_id:
				return null
		if visited[pixel] != 0:
			continue
		visited[pixel] = 1
		var offset := pixel * 4
		var r := int(bytes[offset])
		var g := int(bytes[offset + 1])
		var b := int(bytes[offset + 2])
		if g < 120 or g - maxi(r, b) < 65:
			continue
		bytes[offset + 3] = 0
		removed += 1
		var x := pixel % width
		if x > 0 and visited[pixel - 1] == 0:
			queue.append(pixel - 1)
		if x < width - 1 and visited[pixel + 1] == 0:
			queue.append(pixel + 1)
		if pixel >= width and visited[pixel - width] == 0:
			queue.append(pixel - width)
		if pixel < width * (height - 1) and visited[pixel + width] == 0:
			queue.append(pixel + width)
	# The previous edge flood missed green islands enclosed by curls.
	# Optionally key those islands and suppress green spill without changing red/blue.
	var strength := float(cleanup_strength.value) / 100.0
	if clear_gaps.button_pressed and strength > 0.0:
		var cutoff := lerpf(100.0, 35.0, strength)
		for y in range(height):
			if y % 64 == 0:
				await get_tree().process_frame
				if current_id != generation_id:
					return null
			for x in range(width):
				var offset := (y * width + x) * 4
				if bytes[offset + 3] == 0:
					continue
				var r := float(bytes[offset])
				var g := float(bytes[offset + 1])
				var b := float(bytes[offset + 2])
				var excess := g - maxf(r, b)
				if excess <= 10.0 or g < 80.0:
					continue
				var removal := smoothstep(10.0, cutoff, excess)
				bytes[offset + 3] = roundi(float(bytes[offset + 3]) * (1.0 - removal))
				bytes[offset + 1] = roundi(lerpf(g, maxf(r, b), removal))
	if (removed < width * height / 100 and source.detect_alpha() == Image.ALPHA_NONE) or removed > width * height * 0.98:
		return null
	return Image.create_from_data(width, height, false, Image.FORMAT_RGBA8, bytes)

func reprocess_preview() -> void:
	if busy or cleanup_source == null:
		return
	set_busy(true)
	generation_id += 1
	var current_id := generation_id
	status.text = "正在本机清理绿色残留，不调用图像接口……"
	var cleaned := await remove_green_background(cleanup_source, current_id)
	if current_id != generation_id:
		return
	if cleaned == null:
		set_busy(false)
		status.text = "当前图片不适合绿幕清理，保留原预览。"
		return
	candidate = normalize_image(cleaned)
	candidate_motion_profile = cleanup_motion_profile.duplicate(true)
	candidate_look_id = ""
	candidate_is_active = false
	set_busy(false)
	if candidate == null:
		status.text = "清理结果不可用，未改变当前形象。"
		return
	result_preview.texture = ImageTexture.create_from_image(candidate)
	status.text = "清理预览已更新，满意后点击应用换装。"

func normalize_image(img: Image) -> Image:
	if img.is_empty() or img.get_width() > MAX_SIDE or img.get_height() > MAX_SIDE:
		return null
	img.convert(Image.FORMAT_RGBA8)
	if not img.is_invisible() and img.detect_alpha() != Image.ALPHA_NONE:
		var bounds := img.get_used_rect()
		if bounds.size.x < 8 or bounds.size.y < 8:
			return null
		var target := base_texture.get_image().get_used_rect()
		var crop := img.get_region(bounds)
		var factor := minf(float(target.size.x) / bounds.size.x, float(target.size.y) / bounds.size.y)
		crop.resize(maxi(1, roundi(bounds.size.x * factor)), maxi(1, roundi(bounds.size.y * factor)), Image.INTERPOLATE_LANCZOS)
		var canvas := Image.create(int(base_texture.get_width()), int(base_texture.get_height()), false, Image.FORMAT_RGBA8)
		canvas.fill(Color.TRANSPARENT)
		var destination := Vector2i(target.position.x + (target.size.x - crop.get_width()) / 2, target.end.y - crop.get_height())
		canvas.blit_rect(crop, Rect2i(Vector2i.ZERO, crop.get_size()), destination)
		return canvas
	return null

func apply_candidate() -> void:
	if busy or candidate == null:
		return
	if DirAccess.make_dir_recursive_absolute(storage) != OK or candidate.save_png(storage.path_join("active.pending.png")) != OK:
		status.text = "图片保存失败，未改变当前人物。"
		return
	if DirAccess.rename_absolute(storage.path_join("active.pending.png"), storage.path_join("active.png")) != OK:
		status.text = "图片替换失败，未改变当前人物。"
		return
	active = true
	current_appearance = candidate.duplicate()
	active_look_id = candidate_look_id
	current_motion_profile = profile_value(candidate_motion_profile)
	candidate_is_active = true
	motion_profile_changed.emit(active_motion_profile())
	appearance_changed.emit(ImageTexture.create_from_image(candidate))
	status.text = "换装已应用，下次启动继续使用。" if persist(true) == OK else "本次换装已应用，但设置保存失败，下次启动可能无法恢复。"

func restore_original() -> void:
	cancel()
	active = false
	active_look_id = ""
	current_motion_profile = MotionProfile.defaults()
	candidate = null
	current_appearance = null
	cleanup_source = null
	cleanup_look_id = ""
	cleanup_motion_profile = MotionProfile.defaults()
	reset_candidate_profile()
	cleanup_button.disabled = true
	apply_button.disabled = true
	result_preview.texture = null
	motion_profile_changed.emit(active_motion_profile())
	appearance_changed.emit(null)
	status.text = "已恢复原装和原有动作。" if persist(false) == OK else "本次已恢复原装，但设置保存失败，下次启动可能仍显示换装。"

# 自检：apply_light_theme 是递归覆盖整棵控件树的，必须满足两条不变量，
# 否则界面会被悄悄压平：
#   1) 已经显式设定过字号/样式的控件不能被覆盖（曾经把 24 号标题压成 15 号正文）；
#   2) 重复调用必须幂等（第二次不能抹掉第一次之后设置的属性）。
# 这条断言是被真实缺陷逼出来的，不要再简化掉。
static func selftest() -> Dictionary:
	var failures: Array[String] = []
	var root := VBoxContainer.new()
	var heading := Label.new()
	heading.text = "换装与衣柜"
	heading.add_theme_font_size_override("font_size", 24)
	root.add_child(heading)
	var body := Label.new()
	body.text = "普通说明文字"
	root.add_child(body)
	var button := Button.new()
	button.text = "按钮"
	root.add_child(button)

	var instance := new()
	instance.apply_light_theme(root)
	if heading.get_theme_font_size("font_size") != 24:
		failures.append("显式设定的标题字号被覆盖：期望 24，实际 %d" % heading.get_theme_font_size("font_size"))
	if body.get_theme_font_size("font_size") != 15:
		failures.append("未设定的正文应补成 15，实际 %d" % body.get_theme_font_size("font_size"))
	if not button.has_theme_stylebox_override("normal"):
		failures.append("按钮没有被补上默认外观")

	# 幂等性：改一次正文样式后重复调用，不应把它抹掉。
	body.add_theme_color_override("font_color", Color("ff0000"))
	instance.apply_light_theme(root)
	var body_color := body.get_theme_color("font_color")
	if not body_color.is_equal_approx(Color("ff0000")):
		failures.append("重复调用把已有颜色覆盖掉了：%s" % body_color)
	if heading.get_theme_font_size("font_size") != 24:
		failures.append("重复调用后标题字号变化：%d" % heading.get_theme_font_size("font_size"))

	root.free()
	return {"ok": failures.is_empty(), "failures": failures, "cases": 5}

