@echo off
rem Liang Jing development verification entry point.
rem Runs: encoding guard -> updater unit test -> local-endpoint guard -> full headless selftest.
rem All artifacts stay under tmp\ ; the product itself is not touched.
setlocal
set "ROOT=%~dp0"
set "NODE=%ROOT%runtime\harness\node.exe"
set "PS=powershell.exe"
set "FAILED=0"

echo === [1/4] encoding guard (UTF-8 BOM + parse check) ===
"%NODE%" "%ROOT%tmp\ensure_bom.mjs"
if errorlevel 1 set "FAILED=1"

echo.
echo === [2/4] updater + packaging unit tests ===
%PS% -NoProfile -ExecutionPolicy Bypass -File "%ROOT%tmp\test_runtime_version_merge.ps1"
if errorlevel 1 set "FAILED=1"
%PS% -NoProfile -ExecutionPolicy Bypass -File "%ROOT%tmp\test_updater_adapter_preservation.ps1"
if errorlevel 1 set "FAILED=1"
rem Packaging guard: the .ps1 helper must actually ship inside the exported pack.
%PS% -NoProfile -ExecutionPolicy Bypass -File "%ROOT%tmp\test_native_picker_packaging.ps1"
if errorlevel 1 set "FAILED=1"

echo.
echo === [3/4] local endpoint guard (43818 gateway / 43819 bridge origins) ===
"%NODE%" "%ROOT%tmp\test_interaction_guard.mjs"
if errorlevel 1 set "FAILED=1"

echo.
echo === [4/4] full headless selftest ===
%PS% -NoProfile -ExecutionPolicy Bypass -File "%ROOT%tmp\run_selftest.ps1" -TimeoutSeconds 150
if errorlevel 1 set "FAILED=1"

echo.
if "%FAILED%"=="0" (
  echo VERIFY_ALL=PASS
) else (
  echo VERIFY_ALL=FAIL
)
endlocal & exit /b %FAILED%
