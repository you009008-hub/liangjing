﻿# 开发期验证运行器（不参与产品运行）。
#
# 背景：headless Godot 跑完自检后不会自行退出，普通 shell 调用会一直挂住；
# 而桌宠本体可能正被用户运行着，绝不能按进程名批量结束。
# 因此这里等待自检正常退出；超时时也只结束本脚本直接创建的 Godot 进程。
param(
    [string[]]$GodotArgs = @('--selftest'),
    [int]$TimeoutSeconds = 240,
    # [DSH] --weknora-probe 要读**真实**的密钥：设备绑定密钥里包含 APPDATA 路径，
    # 一旦把 APPDATA 指到临时目录就解不开 weknora.key。这类探针必须用真实用户数据目录。
    [switch]$RealUserData,
    # [DSH] 有屏自检：去掉 --headless，让渲染类断言真的跑起来。
    # 会短暂占用用户桌面（约 35 秒），只在定位"只在真实显示下才失败"的缺陷时使用。
    [switch]$Windowed
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$godot = Join-Path $projectRoot 'Godot_v4.7.1-stable_win64.exe'
if (-not (Test-Path -LiteralPath $godot)) { throw "找不到运行引擎：$godot" }

# 用户数据目录必须放到工作区内：沙箱下 %APPDATA%\Godot 不可写，Godot 会直接崩。
# 例外：真机探针（-RealUserData）必须用真实目录，否则设备绑定密钥解不开。
$appData = Join-Path $projectRoot 'tmp\godot_appdata'
New-Item -ItemType Directory -Path $appData -Force | Out-Null
if (-not $RealUserData) { $env:APPDATA = $appData }

$logPath = Join-Path $projectRoot 'tmp\selftest_run.log'
$stderrPath = $logPath + '.err'
if (Test-Path -LiteralPath $logPath) { Remove-Item -LiteralPath $logPath -Force }
if (Test-Path -LiteralPath $stderrPath) { Remove-Item -LiteralPath $stderrPath -Force }

# 自检必须从干净状态开始：数据目录里只要残留上一次运行的会话或资料，
# 断言就会依赖脏状态（实测踩过：旧会话被算进“会话条数”导致连续失败）。
$selftestData = Join-Path $projectRoot 'tmp\.selftest_runtime'
if ((Test-Path -LiteralPath $selftestData) -and -not $RealUserData) {
    Remove-Item -LiteralPath $selftestData -Recurse -Force
    Write-Host "RESET $selftestData"
}

# 注意：PowerShell 5.1 不支持 if/else 三元表达式（那是 7+ 的语法）。
# 写成三元会让整个脚本在解析阶段失败，而错误只在 stderr——
# 外层若只看 stdout 就会以为"跑过了"，实际读到的是上一轮的旧日志（我自己踩过一次）。
$headlessArgs = @('--headless')
if ($Windowed) { $headlessArgs = @() }
$argList = $headlessArgs + @('--path', $projectRoot, '--') + $GodotArgs
Write-Host "RUN godot $($argList -join ' ')"
# Windows PowerShell 5.1 的 Start-Process 在父进程同时带有 Path/PATH 时会因
# 大小写不敏感的环境字典冲突而直接抛异常。ProcessStartInfo 会规范化该字典，
# 同时保留我们只按自己持有的 PID 停止进程这一安全边界。
$quotedRoot = '"' + $projectRoot.Replace('"', '\"') + '"'
$nativeArgs = $headlessArgs + @('--path', $quotedRoot, '--') + $GodotArgs
$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = $godot
$startInfo.Arguments = $nativeArgs -join ' '
$startInfo.WorkingDirectory = $projectRoot
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true
$startInfo.StandardOutputEncoding = [System.Text.Encoding]::UTF8
$startInfo.StandardErrorEncoding = [System.Text.Encoding]::UTF8
$proc = New-Object System.Diagnostics.Process
$proc.StartInfo = $startInfo
if (-not $proc.Start()) { throw '无法启动 Godot 自检进程。' }
$stdoutTask = $proc.StandardOutput.ReadToEndAsync()
$stderrTask = $proc.StandardError.ReadToEndAsync()

$deadline = (Get-Date).AddSeconds($TimeoutSeconds)
while (-not $proc.HasExited -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 500 }
# 自检现在会自己退出（见 main.gd 的 schedule_selftest_exit），正常退出才会执行
# _exit_tree 里的子进程清理。超时强杀只作为兜底，并且要如实报告——
# 因为强杀会绕过清理，正是孤儿 node 进程堆积的原因。
$forceStopped = -not $proc.HasExited
if ($forceStopped) {
    Write-Host "TIMEOUT after ${TimeoutSeconds}s - force stopping godot (子进程清理会被跳过)"
}

# selftest 模式明确不启动 Harness，因此这里只能结束本脚本直接创建的 Godot 进程。
# 绝不能按进程名或启动时间扫描 node；那会误杀用户同时启动的其他开发任务。
if (-not $proc.HasExited) {
    Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
}
$proc.WaitForExit()
$godotExitCode = $proc.ExitCode
$stdoutText = $stdoutTask.GetAwaiter().GetResult()
$stderrText = $stderrTask.GetAwaiter().GetResult()
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($logPath, $stdoutText, $utf8NoBom)
[System.IO.File]::WriteAllText($stderrPath, $stderrText, $utf8NoBom)

Write-Host "`n===== SELFTEST LINES ====="
# 显式按 UTF-8 读取，否则中文自检行会变成乱码。
$content = if (Test-Path -LiteralPath $logPath) { Get-Content -LiteralPath $logPath -Encoding UTF8 } else { @() }
$stderrContent = if (Test-Path -LiteralPath $stderrPath) { Get-Content -LiteralPath $stderrPath -Encoding UTF8 } else { @() }
$combined = @($content) + @($stderrContent)
# 失败原因必须显示在控制台：断言失败却看不到原因，只能去翻日志，等于把排查成本推给下一个人。
$selftestLines = $combined | Select-String -Pattern 'SELFTEST|_FAILURE|SOUL_STORE_READY|HARNESS_STATUS|SCRIPT ERROR|Parse Error|Error calling deferred method|Method not found|CrashHandlerException'
$selftestLines | ForEach-Object { $_.Line }

Write-Host "`n===== VERDICT ====="
$fails = @($selftestLines | Select-String -Pattern 'SELFTEST=FAIL|MISMATCH')
$runtimeErrors = @($combined | Select-String -Pattern 'SCRIPT ERROR|Parse Error|Error calling deferred method|Method not found|CrashHandlerException')
if ($forceStopped) {
    Write-Host "SELFTEST_RESULT=FAIL timeout"
    exit 1
}
if ($godotExitCode -ne 0) {
    Write-Host "SELFTEST_RESULT=FAIL godot-exit=$godotExitCode"
    exit 1
}
if ($fails.Count -gt 0) {
    Write-Host "SELFTEST_RESULT=FAIL failures=$($fails.Count)"
    exit 1
}
if ($runtimeErrors.Count -gt 0) {
    Write-Host "RUNTIME/SCRIPT ERRORS: $($runtimeErrors.Count)"
    $runtimeErrors | ForEach-Object { $_.Line }
    Write-Host "SELFTEST_RESULT=FAIL runtime-errors=$($runtimeErrors.Count)"
    exit 1
}
$passCount = @($selftestLines | Select-String -Pattern '=PASS').Count
if ($passCount -eq 0) { Write-Host "SELFTEST_RESULT=FAIL no-pass-lines"; exit 1 }
Write-Host "SELFTEST_RESULT=PASS pass-lines=$passCount forceStopped=$forceStopped"
exit 0
