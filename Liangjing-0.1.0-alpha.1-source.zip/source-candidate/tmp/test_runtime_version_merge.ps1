﻿# 开发期单元验证：升级器写回 runtime-version.json 时必须保留 upstream_port 与
# implementation_revision。这里复刻 update_harness.ps1 中同一段逻辑，喂入真实存在的
# 文件与两个边界情况（文件缺失、字段缺失），确认输出契约。
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Merge-RuntimeVersion {
    param([string]$PreviousJson, [string]$Latest)
    # ↓↓↓ 与 update_harness.ps1 中新增逻辑逐字对应 ↓↓↓
    $rvPrevious = $null
    if ($PreviousJson) { try { $rvPrevious = ($PreviousJson | ConvertFrom-Json) } catch { $rvPrevious = $null } }
    $rvUpstream = 43918
    $rvRevision = 1
    if ($rvPrevious) {
        # Set-StrictMode -Version Latest turns a missing property into a terminating
        # error, so probe through PSObject.Properties rather than dot access.
        $rvUpstreamProp = $rvPrevious.PSObject.Properties['upstream_port']
        if ($rvUpstreamProp) {
            $parsedUpstream = 0
            if ([int]::TryParse([string]$rvUpstreamProp.Value, [ref]$parsedUpstream) -and $parsedUpstream -gt 0) { $rvUpstream = $parsedUpstream }
        }
        $rvRevisionProp = $rvPrevious.PSObject.Properties['implementation_revision']
        if ($rvRevisionProp) {
            $parsedRevision = 0
            if ([int]::TryParse([string]$rvRevisionProp.Value, [ref]$parsedRevision) -and $parsedRevision -gt 0) { $rvRevision = $parsedRevision + 1 }
        }
    }
    return [ordered]@{ component = 'DeepSeek Harness'; version = $Latest; upstream_port = $rvUpstream; integration = 'blue-whale-agent-v1'; implementation_revision = $rvRevision; port = 43818; updated_at = 'TEST' }
    # ↑↑↑ 对应结束 ↑↑↑
}

$real = [IO.File]::ReadAllText((Resolve-Path 'runtime\harness\app\runtime-version.json').Path, [Text.Encoding]::UTF8)
$source = $real | ConvertFrom-Json
"输入（当前发行版）: version=$($source.version) upstream_port=$($source.upstream_port) implementation_revision=$($source.implementation_revision)"

$problems = 0

# 用例 1：正常升级，两个字段都必须保住，revision 递增。
$case1 = Merge-RuntimeVersion -PreviousJson $real -Latest '0.1.6-rc.1'
if ($case1.upstream_port -eq $source.upstream_port) { "PASS 用例1 upstream_port 保留 = $($case1.upstream_port)" } else { "FAIL 用例1 upstream_port=$($case1.upstream_port) 期望 $($source.upstream_port)"; $problems++ }
if ($case1.implementation_revision -eq ([int]$source.implementation_revision + 1)) { "PASS 用例1 implementation_revision 递增 = $($case1.implementation_revision)" } else { "FAIL 用例1 revision=$($case1.implementation_revision)"; $problems++ }
if ($case1.version -eq '0.1.6-rc.1') { "PASS 用例1 版本已更新" } else { "FAIL 用例1 版本未更新"; $problems++ }
if ($case1.Keys.Count -eq 7) { "PASS 用例1 键数 = 7（旧实现只写 5 个）" } else { "FAIL 用例1 键数=$($case1.Keys.Count)"; $problems++ }

# 用例 2：完全没有旧文件时回落到契约默认值，而不是写 null。
$case2 = Merge-RuntimeVersion -PreviousJson $null -Latest '0.1.6-rc.1'
if ($case2.upstream_port -eq 43918) { "PASS 用例2 upstream_port 回落 = $($case2.upstream_port)" } else { "FAIL 用例2 upstream_port=$($case2.upstream_port)"; $problems++ }
if ($case2.implementation_revision -eq 1) { "PASS 用例2 implementation_revision 回落 = $($case2.implementation_revision)" } else { "FAIL 用例2 revision=$($case2.implementation_revision)"; $problems++ }

# 用例 3：旧文件缺字段（正是被旧实现破坏过的形态）时不能崩，也不能写 null。
$case3 = Merge-RuntimeVersion -PreviousJson '{"component":"DeepSeek Harness","version":"0.1.4","integration":"blue-whale-agent-v1","port":43818}' -Latest '0.1.6-rc.1'
if ($case3.upstream_port -eq 43918 -and $case3.implementation_revision -eq 1) { "PASS 用例3 缺字段安全回落" } else { "FAIL 用例3 upstream=$($case3.upstream_port) revision=$($case3.implementation_revision)"; $problems++ }

# 用例 4：损坏 JSON 不能让升级流程整体失败。
$case4 = Merge-RuntimeVersion -PreviousJson '{ this is not json' -Latest '0.1.6-rc.1'
if ($case4.upstream_port -eq 43918 -and $case4.implementation_revision -eq 1) { "PASS 用例4 损坏 JSON 安全回落" } else { "FAIL 用例4"; $problems++ }

if ($problems -eq 0) { "RUNTIME_VERSION_MERGE_SELFTEST=PASS" } else { "RUNTIME_VERSION_MERGE_SELFTEST=FAIL problems=$problems" }
exit $problems
