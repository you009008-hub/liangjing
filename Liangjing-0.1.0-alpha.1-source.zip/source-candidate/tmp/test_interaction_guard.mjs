// [DSH] 43818 / 43819 本机来源守卫的验证脚本（开发期工具，不参与产品运行）。
//
// 默认模式：只跑纯函数判定表，速度快，已接入 verify.cmd 第 3 步。
// --live 模式：在旁路端口真起一份 Harness（独立 data-dir，不碰正在运行的梁鲸），
//   用裸 socket 伪造 Host / Origin / Sec-Fetch-Site，断言真实的 403/200。
//   纯函数自检只能证明"判定逻辑对"，--live 才能证明"这份 app 目录真的接上了"。
//
// 用法：
//   node tmp\test_interaction_guard.mjs          仅纯函数（verify.cmd 使用）
//   node tmp\test_interaction_guard.mjs --live   纯函数 + 端到端
import fs from "node:fs";
import net from "node:net";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const guardPath = path.join(projectRoot, "runtime", "harness", "app", "blue-whale-interaction-guard.mjs");
const { allowedNamesFor, checkLocalRequest, parseHostHeader, describeRejection } = await import(pathToFileURL(guardPath).href);

let failures = 0;
let cases = 0;

function check(name, actual, expected) {
  cases += 1;
  const ok = actual === expected;
  if (!ok) failures += 1;
  console.log(`${ok ? "PASS" : "FAIL"} ${name}${ok ? "" : `（实际 ${JSON.stringify(actual)} 期望 ${JSON.stringify(expected)}）`}`);
}

// ── 判定表 ──────────────────────────────────────────────────────────────
// expected === true 表示必须放行，否则必须是给出的原因码。
// 表里既有"梁鲸自己"的正例，也有"网页/其它程序"的反例：
// 只看正例会给出虚假的安全感，所以每个拒绝分支都至少有一条用例。
const interaction = { port: 43819, requireClientHeader: false };
const interactionWrite = { port: 43819, requireClientHeader: true };
const gateway = { port: 43818, names: ["127.0.0.1", "localhost"], requireClientHeader: false };
const godot = { "x-blue-whale-client": "godot" };

const table = [
  // —— 放行：梁鲸自己 ——
  ["梁鲸 GET 轮询（带标识头）", { host: "127.0.0.1:43819", "x-blue-whale-client": "godot" }, interaction, true],
  ["梁鲸 GET 健康检查（不带标识头也放行）", { host: "127.0.0.1:43819" }, interaction, true],
  ["梁鲸 POST（带标识头）", { host: "127.0.0.1:43819", ...godot }, interactionWrite, true],
  ["localhost 访问", { host: "localhost:43819", ...godot }, interactionWrite, true],
  ["IPv6 回环访问", { host: "[::1]:43819", ...godot }, interactionWrite, true],
  ["标识头大小写不敏感", { host: "127.0.0.1:43819", "x-blue-whale-client": "Godot" }, interactionWrite, true],
  ["同源 Origin", { host: "127.0.0.1:43819", origin: "http://127.0.0.1:43819", ...godot }, interactionWrite, true],
  ["同源 Origin(localhost)", { host: "localhost:43819", origin: "http://localhost:43819", ...godot }, interactionWrite, true],
  ["地址栏直接打开(same-origin 标记)", { host: "127.0.0.1:43819", "sec-fetch-site": "same-origin" }, interaction, true],
  ["地址栏直接打开(none 标记)", { host: "127.0.0.1:43819", "sec-fetch-site": "none" }, interaction, true],
  ["Host 不带端口（能到这个 socket 就说明端口对）", { host: "127.0.0.1", ...godot }, interactionWrite, true],

  // —— 拒绝：DNS 重绑定 ——
  ["重绑定域名", { host: "evil.example:43819", ...godot }, interactionWrite, "host-not-allowed"],
  ["重绑定域名(不带端口)", { host: "evil.example", ...godot }, interactionWrite, "host-not-allowed"],
  ["后缀伪装域名", { host: "127.0.0.1.evil.example:43819", ...godot }, interactionWrite, "host-not-allowed"],
  ["通配地址", { host: "0.0.0.0:43819", ...godot }, interactionWrite, "host-not-allowed"],
  ["外网 IPv6", { host: "[2001:db8::1]:43819", ...godot }, interactionWrite, "host-not-allowed"],
  ["裸 IPv6（无法区分端口）", { host: "::1:43819", ...godot }, interactionWrite, "host-header-invalid"],

  // —— 拒绝：格式与端口 ——
  ["Host 缺失", { ...godot }, interactionWrite, "host-header-missing"],
  ["Host 为空串", { host: "", ...godot }, interactionWrite, "host-header-missing"],
  ["Host 带空格", { host: "127.0.0.1 :43819", ...godot }, interactionWrite, "host-header-invalid"],
  ["Host 带用户信息", { host: "user@127.0.0.1:43819", ...godot }, interactionWrite, "host-header-invalid"],
  ["Host 带路径", { host: "127.0.0.1:43819/api", ...godot }, interactionWrite, "host-header-invalid"],
  ["Host 端口越界", { host: "127.0.0.1:99999", ...godot }, interactionWrite, "host-header-invalid"],
  ["Host 端口非数字", { host: "127.0.0.1:abc", ...godot }, interactionWrite, "host-header-invalid"],
  ["端口不符（43818 的 Host 打到 43819）", { host: "127.0.0.1:43818", ...godot }, interactionWrite, "host-port-mismatch"],
  ["请求头整体缺失", null, interactionWrite, "host-header-missing"],

  // —— 拒绝：跨站 ——
  ["跨站 Origin", { host: "127.0.0.1:43819", origin: "https://evil.example", ...godot }, interactionWrite, "origin-not-allowed"],
  ["Origin: null（沙箱 iframe / file://）", { host: "127.0.0.1:43819", origin: "null", ...godot }, interactionWrite, "origin-not-allowed"],
  ["同主机不同端口 Origin", { host: "127.0.0.1:43819", origin: "http://127.0.0.1:43818", ...godot }, interactionWrite, "origin-not-allowed"],
  ["浏览器标注跨站", { host: "127.0.0.1:43819", "sec-fetch-site": "cross-site", ...godot }, interactionWrite, "cross-site-browser-request"],

  // —— 拒绝：缺少标识头（挡住"网页直连 127.0.0.1"）——
  ["写请求缺标识头", { host: "127.0.0.1:43819" }, interactionWrite, "client-header-required"],
  ["写请求标识头不对", { host: "127.0.0.1:43819", "x-blue-whale-client": "curl" }, interactionWrite, "client-header-required"],
  ["写请求标识头为空", { host: "127.0.0.1:43819", "x-blue-whale-client": "" }, interactionWrite, "client-header-required"],

  // —— 43818 网关：白名单不得被无意放宽 ——
  ["网关正常请求", { host: "127.0.0.1:43818" }, gateway, true],
  ["网关 localhost", { host: "localhost:43818" }, gateway, true],
  ["网关不接受 IPv6 别名（保持原白名单）", { host: "[::1]:43818" }, gateway, "host-not-allowed"],
  ["网关拒绝跨站 Origin", { host: "127.0.0.1:43818", origin: "https://evil.example" }, gateway, "origin-not-allowed"],
  ["网关拒绝重绑定 Host", { host: "evil.example:43818" }, gateway, "host-not-allowed"],
];

console.log("── 纯函数判定表 ──");
for (const [name, headers, options, expected] of table) {
  const result = checkLocalRequest(headers, options);
  check(name, result.trusted ? true : result.reason, expected);
}

// 判定必须对"开关"敏感：同一份请求头，开关一开一关结论必须相反。
// 否则 options 没接上也能"全 PASS"，这正是接线类断言最容易骗人的地方。
const writeHeaders = { host: "127.0.0.1:43819" };
check(
  "标识头开关生效（同请求，关=放行）",
  checkLocalRequest(writeHeaders, interaction).trusted,
  true,
);
check(
  "标识头开关生效（同请求，开=拒绝）",
  checkLocalRequest(writeHeaders, interactionWrite).reason,
  "client-header-required",
);

// 解析层单测：Host 解析是判定的地基，单独钉住几种形态。
console.log("── Host 解析 ──");
check("解析 名字:端口", JSON.stringify(parseHostHeader("127.0.0.1:43819")), JSON.stringify({ ok: true, name: "127.0.0.1", port: 43819 }));
check("解析 名字（无端口）", JSON.stringify(parseHostHeader("LocalHost")), JSON.stringify({ ok: true, name: "localhost", port: null }));
check("解析 [IPv6]:端口", JSON.stringify(parseHostHeader("[::1]:43819")), JSON.stringify({ ok: true, name: "::1", port: 43819 }));
check("解析 非字符串", parseHostHeader(undefined).ok, false);
check("拒绝文案可读", describeRejection("host-not-allowed").includes("DNS"), true);
check("未知原因码有兜底文案", describeRejection("whatever").length > 0, true);

// 白名单构造：必须跟着 --host 走，否则用户把接口指到内网地址时会被自己的守卫拦死；
// 但通配绑定不能并进来，否则等于"任意 Host 都放行"。
console.log("── 白名单构造 ──");
check("回环监听：含 127.0.0.1", allowedNamesFor("127.0.0.1").includes("127.0.0.1"), true);
check("回环监听：含 localhost 与 ::1", allowedNamesFor("127.0.0.1").includes("localhost") && allowedNamesFor("127.0.0.1").includes("::1"), true);
check(
  "内网监听：监听地址本身被允许",
  checkLocalRequest({ host: "192.168.1.5:43819", ...godot }, { ...interactionWrite, names: allowedNamesFor("192.168.1.5") }).trusted,
  true,
);
check(
  "内网监听：外部域名仍被拒",
  checkLocalRequest({ host: "evil.example:43819", ...godot }, { ...interactionWrite, names: allowedNamesFor("192.168.1.5") }).reason,
  "host-not-allowed",
);
check("通配监听：0.0.0.0 不进白名单", allowedNamesFor("0.0.0.0").includes("0.0.0.0"), false);
check(
  "通配监听：Host 写成 0.0.0.0 仍被拒",
  checkLocalRequest({ host: "0.0.0.0:43819", ...godot }, { ...interactionWrite, names: allowedNamesFor("0.0.0.0") }).reason,
  "host-not-allowed",
);
check("方括号 IPv6 被归一并去重", allowedNamesFor("[::1]").filter((name) => name === "::1").length, 1);

// 接线检查：守卫必须真的被两个服务调用，且 43819 的写路由必须要求标识头。
// 这条只是补充，真正的证据是下面的 --live。
const harnessSource = fs.readFileSync(path.join(projectRoot, "runtime", "harness", "app", "blue-whale-harness.mjs"), "utf8");
console.log("── 接线 ──");
check("harness 引入了守卫模块", harnessSource.includes('from "./blue-whale-interaction-guard.mjs"'), true);
check("交互桥调用守卫", harnessSource.includes("checkLocalRequest(request.headers, {\n      port: interactionPort"), true);
check("网关调用守卫", harnessSource.includes("checkLocalRequest(request.headers, { port: Number(port)"), true);
check("写路由要求标识头", harnessSource.includes("requireClientHeader: request.method !== \"GET\" && request.method !== \"HEAD\""), true);

// ── 端到端（--live）────────────────────────────────────────────────────
function rawRequest({ port, method = "GET", target = "/", headers = {}, body = "" }) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(port, "127.0.0.1");
    let raw = "";
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error("request timeout"));
    }, 8000);
    socket.on("connect", () => {
      const lines = [`${method} ${target} HTTP/1.1`, ...Object.entries(headers).map(([key, value]) => `${key}: ${value}`)];
      if (body) lines.push(`Content-Length: ${Buffer.byteLength(body)}`);
      lines.push("Connection: close", "", body);
      socket.write(lines.join("\r\n"));
    });
    socket.on("data", (chunk) => {
      raw += chunk.toString("utf8");
    });
    socket.on("end", () => {
      clearTimeout(timer);
      resolve(raw);
    });
    socket.on("error", (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}

function statusOf(raw) {
  const matched = /^HTTP\/1\.[01] (\d{3})/.exec(raw);
  return matched ? Number(matched[1]) : 0;
}

function reasonOf(raw) {
  const matched = /"reason":"([^"]+)"/.exec(raw);
  return matched ? matched[1] : "";
}

async function live() {
  const corePort = 45200;
  const interactionPort = 45201;
  const dataDirectory = path.join(projectRoot, "tmp", ".guard_live_runtime");
  const launcher = path.join(projectRoot, "runtime", "harness", "app", "blue-whale-harness.mjs");
  const nodePath = path.join(projectRoot, "runtime", "harness", "node.exe");
  fs.rmSync(dataDirectory, { recursive: true, force: true });
  const logPath = path.join(projectRoot, "tmp", "interaction_guard_live.log");
  const logFd = fs.openSync(logPath, "w");
  console.log("── 端到端：旁路起一份 Harness（%d/%d，独立 data-dir）──", corePort, interactionPort);
  const child = spawn(nodePath, [launcher, "--data-dir", dataDirectory, "--host", "127.0.0.1", "--port", String(corePort), "--interaction-port", String(interactionPort)], {
    cwd: projectRoot,
    stdio: ["ignore", logFd, logFd],
    windowsHide: true,
  });
  let exited = false;
  child.once("exit", () => {
    exited = true;
  });
  try {
    let ready = false;
    for (let attempt = 0; attempt < 90 && !exited; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      try {
        const raw = await rawRequest({ port: interactionPort, target: "/health", headers: { Host: `127.0.0.1:${interactionPort}` } });
        if (statusOf(raw) === 200) {
          ready = true;
          break;
        }
      } catch {
        /* 还没起来 */
      }
    }
    if (!ready) {
      console.log("SKIP 端到端：旁路 Harness 未能在 45 秒内就绪（日志 tmp\\interaction_guard_live.log）");
      return "skip";
    }
    const host = `127.0.0.1:${interactionPort}`;
    const body = "{}";
    const post = { method: "POST", target: "/approval-test" };

    const health = await rawRequest({ port: interactionPort, target: "/health", headers: { Host: host } });
    check("端到端：只读健康检查放行（不带标识头）", statusOf(health), 200);

    const rebind = await rawRequest({ port: interactionPort, ...post, headers: { Host: `evil.example:${interactionPort}`, "X-Blue-Whale-Client": "godot" }, body });
    check("端到端：重绑定 Host 被拒", statusOf(rebind), 403);
    check("端到端：拒绝原因是 Host", reasonOf(rebind), "host-not-allowed");

    const noClient = await rawRequest({ port: interactionPort, ...post, headers: { Host: host }, body });
    check("端到端：缺标识头的写请求被拒", statusOf(noClient), 403);
    check("端到端：拒绝原因是标识头", reasonOf(noClient), "client-header-required");

    const crossOrigin = await rawRequest({ port: interactionPort, ...post, headers: { Host: host, "X-Blue-Whale-Client": "godot", Origin: "https://evil.example" }, body });
    check("端到端：跨站 Origin 被拒", statusOf(crossOrigin), 403);
    check("端到端：拒绝原因是来源", reasonOf(crossOrigin), "origin-not-allowed");

    const crossSite = await rawRequest({ port: interactionPort, ...post, headers: { Host: host, "X-Blue-Whale-Client": "godot", "Sec-Fetch-Site": "cross-site" }, body });
    check("端到端：浏览器跨站标记被拒", statusOf(crossSite), 403);

    const legitimate = await rawRequest({ port: interactionPort, ...post, headers: { Host: host, "X-Blue-Whale-Client": "godot" }, body });
    check("端到端：梁鲸自己的写请求放行", statusOf(legitimate), 200);
    check("端到端：放行时真的建立了审批", legitimate.includes('"rpcId"'), true);

    const pending = await rawRequest({ port: interactionPort, target: "/interactions", headers: { Host: host } });
    check("端到端：待审批列表可轮询", statusOf(pending), 200);
    // 恰好 1 条：被拒的 4 次写请求不能偷偷建出审批来（否则"拒绝"只挡了返回值，没挡副作用）。
    check("端到端：被拒的请求没有留下审批", (pending.match(/"rpcId"/g) || []).length, 1);

    const gatewayRebind = await rawRequest({ port: corePort, ...post, target: "/api/session.list", headers: { Host: `evil.example:${corePort}` }, body: JSON.stringify({ type: "client-request", rpcId: "guard-test", method: "session.list", payload: {} }) });
    check("端到端：网关拒绝重绑定 Host", statusOf(gatewayRebind), 403);

    const gatewayOrigin = await rawRequest({ port: corePort, ...post, target: "/api/session.list", headers: { Host: `127.0.0.1:${corePort}`, Origin: "https://evil.example" }, body: JSON.stringify({ type: "client-request", rpcId: "guard-test", method: "session.list", payload: {} }) });
    check("端到端：网关拒绝跨站 Origin", statusOf(gatewayOrigin), 403);

    const gatewayOk = await rawRequest({ port: corePort, ...post, target: "/api/session.list", headers: { Host: `127.0.0.1:${corePort}` }, body: JSON.stringify({ type: "client-request", rpcId: "guard-test", method: "session.list", payload: {} }) });
    check("端到端：网关正常请求放行", statusOf(gatewayOk), 200);
  } finally {
    if (!exited) child.kill();
    // Windows 上刚结束的进程可能还占着日志/数据文件，删不掉不该让整个自检变成"异常退出"。
    for (let attempt = 0; attempt < 10; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 300));
      try {
        fs.rmSync(dataDirectory, { recursive: true, force: true });
        break;
      } catch {
        /* 再等一轮 */
      }
    }
    fs.closeSync(logFd);
  }
  return "pass";
}

if (process.argv.includes("--live")) {
  // 起不来只报 SKIP（并说清原因），绝不写成 PASS——这条通道没被验证就不能算验证过。
  const outcome = await live();
  if (outcome === "skip") {
    console.log("INTERACTION_GUARD_LIVE=SKIP reason=harness-not-ready");
  } else {
    console.log(failures === 0 ? `INTERACTION_GUARD_LIVE=PASS cases=${cases} failures=0` : `INTERACTION_GUARD_LIVE=FAIL cases=${cases} failures=${failures}`);
  }
} else {
  console.log("（端到端模式：node tmp\\test_interaction_guard.mjs --live）");
}
console.log(failures === 0 ? `INTERACTION_GUARD=PASS cases=${cases} failures=0` : `INTERACTION_GUARD=FAIL cases=${cases} failures=${failures}`);
process.exit(failures === 0 ? 0 : 1);
