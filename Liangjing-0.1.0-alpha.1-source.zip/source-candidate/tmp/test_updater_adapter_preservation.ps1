﻿# [DSH] 升级器"适配层搬运"回归（开发期工具，不参与产品运行）。
#
# 背景：runtime\harness\updater\update_harness.ps1 会把 app 目录整体换成官方新版，
# 梁鲸自己的 blue-whale-*.mjs 必须被逐个搬过去。漏搬一个模块 = 新版本 Harness
# 因 import 失败整体起不来 = 桌宠彻底连不上核心，而**本地开发时完全看不出来**
# （本地 app 目录一直是全的），所以这条必须有断言。
#
# 这里不复制升级器里的代码，而是把脚本里**真实的过滤模式**抠出来，
# 对真实的 app 目录跑一遍，再用入口文件的 import 列表反过来要求它覆盖。
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$root = Split-Path -Parent $PSScriptRoot
$updater = Join-Path $root 'runtime\harness\updater\update_harness.ps1'
$appDir = Join-Path $root 'runtime\harness\app'
$harness = Join-Path $appDir 'blue-whale-harness.mjs'
$problems = 0

# 用例 1：脚本本身必须能通过解析（PS 5.1 + StrictMode 下真跑之前的最低门槛）。
$tokens = $null
$parseErrors = $null
[System.Management.Automation.Language.Parser]::ParseFile($updater, [ref]$tokens, [ref]$parseErrors) | Out-Null
if ($parseErrors.Count -eq 0) { 'PASS 升级器脚本可解析' } else { "FAIL 升级器脚本解析失败：$($parseErrors[0].Message)"; $problems++ }

# 用例 2：搬运语句必须存在，且必须是通配符而不是写死的文件名清单。
$match = [regex]::Match([IO.File]::ReadAllText($updater, [Text.Encoding]::UTF8), 'Get-ChildItem -LiteralPath \$targetApp -Filter ''([^'']+)'' -File')
if (-not $match.Success) {
    'FAIL 找不到适配层搬运语句（升级后新旧适配文件会全部丢失）'
    $problems++
} else {
    $pattern = $match.Groups[1].Value
    "PASS 搬运语句使用模式：$pattern"

    # 用例 3：用脚本里真实的模式去选真实的目录，选出来的必须等于"所有 blue-whale-*.mjs"。
    $selected = @(Get-ChildItem -LiteralPath $appDir -Filter $pattern -File | ForEach-Object { $_.Name } | Sort-Object)
    $present = @(Get-ChildItem -LiteralPath $appDir -Filter 'blue-whale-*.mjs' -File | ForEach-Object { $_.Name } | Sort-Object)
    if ($present.Count -lt 2) {
        "FAIL app 目录里只有 $($present.Count) 个适配文件，样本不足，用例形同虚设"
        $problems++
    }
    $missing = @($present | Where-Object { $selected -notcontains $_ })
    if ($missing.Count -eq 0) {
        "PASS 现有适配文件全部在搬运范围内（$($present -join '、')）"
    } else {
        "FAIL 这些适配文件不会被搬到新版本：$($missing -join '、')"
        $problems++
    }

    # 用例 4（关键）：入口文件真正引用到的模块，一个都不能漏。
    # 引用有两种写法——ES import 与 path.join(appDirectory, "…") 拼绝对路径，
    # 所以这里统一按"出现过 blue-whale-*.mjs 文件名"来收集，两种都不会漏。
    # 先确认真的抓到了东西——抓不到就等于这条断言是空的，那才是虚假的安全感。
    $referenced = @([regex]::Matches([IO.File]::ReadAllText($harness, [Text.Encoding]::UTF8), 'blue-whale-[A-Za-z0-9._-]*\.mjs') | ForEach-Object { $_.Value } | Sort-Object -Unique)
    if ($referenced.Count -lt 2) {
        "FAIL 只从入口里解析出 $($referenced.Count) 个适配层引用，检查解析规则是否失效"
        $problems++
    }
    foreach ($reference in $referenced) {
        if ($selected -contains $reference) {
            "PASS 入口引用的模块会被搬运：$reference"
        } else {
            "FAIL 入口引用了 $reference，但搬运模式 $pattern 不会带它走"
            $problems++
        }
    }

    # 用例 5：模式不能过宽，否则会把 node_modules 之类的杂物一起搬。
    if ($pattern -eq 'blue-whale-*.mjs') { 'PASS 模式范围收敛（只搬梁鲸适配层）' } else { "FAIL 模式范围异常：$pattern"; $problems++ }
}

if ($problems -eq 0) { 'UPDATER_ADAPTER_SELFTEST=PASS' } else { "UPDATER_ADAPTER_SELFTEST=FAIL problems=$problems" }
exit $problems
