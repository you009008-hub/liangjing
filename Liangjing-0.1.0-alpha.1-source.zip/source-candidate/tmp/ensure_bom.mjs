﻿// 开发期编码守卫（不参与产品运行）。
//
// 背景：本机 PowerShell 是 5.1，读取没有 BOM 的 UTF-8 .ps1 时会按 ANSI 解码，
// 脚本里的中文会变成乱码并直接导致语法错误。编辑工具写回文件时不保留 BOM，
// 因此每次用编辑工具改过 .ps1 之后都要跑这里。
// 用 Node 而不是 PowerShell 实现，避免“守卫脚本自己也需要 BOM”的自举问题。
import fs from "node:fs";
import path from "node:path";

const defaults = [
  "runtime/harness/updater/update_harness.ps1",
  "tmp/run_selftest.ps1",
  "tmp/test_runtime_version_merge.ps1",
  "tmp/test_updater_adapter_preservation.ps1",
  "tmp/test_native_picker_packaging.ps1",
  "tmp/ensure_bom.mjs",
];

// 每个文件的中文哨兵串：BOM 丢失时这些串会变成乱码，用它们判定内容是否被 ANSI 破坏。
const sentinels = {
  "runtime/harness/updater/update_harness.ps1": "升级",
  "tmp/run_selftest.ps1": "自检",
  "tmp/test_runtime_version_merge.ps1": "用例",
  "tmp/test_updater_adapter_preservation.ps1": "适配",
  "tmp/test_native_picker_packaging.ps1": "打包",
};

const targets = process.argv.length > 2 ? process.argv.slice(2) : defaults;
const BOM = Buffer.from([0xef, 0xbb, 0xbf]);
let failed = 0;

for (const relative of targets) {
  const full = path.resolve(relative);
  let raw;
  try {
    raw = fs.readFileSync(full);
  } catch (error) {
    console.log(`MISSING   ${relative} (${error.message})`);
    failed += 1;
    continue;
  }
  const hasBom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  if (hasBom) {
    console.log(`BOM OK    ${relative}`);
  } else {
    fs.writeFileSync(full, Buffer.concat([BOM, raw]));
    console.log(`BOM ADDED ${relative}`);
  }
  // 校验：文件必须是合法 UTF-8，且去掉 BOM 后能以 UTF-8 正常解码。
  const text = fs.readFileSync(full).toString("utf8");
  if (text.includes("\ufffd")) {
    console.log(`  WARNING: ${relative} 含无效 UTF-8 字节（可能已被 ANSI 破坏）`);
    failed += 1;
  }
  // 关键中文串存活检查：BOM 丢失时这些串会变成乱码，这里直接把它们当哨兵。
  const key = relative.replace(/\\/g, "/");
  const sentinel = sentinels[key];
  if (sentinel && !text.includes(sentinel)) {
    console.log(`  WARNING: ${relative} 的中文哨兵「${sentinel}」丢失，内容可能已被破坏`);
    failed += 1;
  }
}
console.log(failed === 0 ? "ENCODING_GUARD=PASS" : `ENCODING_GUARD=FAIL problems=${failed}`);
process.exit(failed === 0 ? 0 : 1);
