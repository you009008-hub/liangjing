﻿# [DSH] 打包完整性守卫：原生文件选择器的 PowerShell 脚本必须真的随包发布。
#
# 背景（一次真实缺陷）：native_file_picker.gd 原来把
# ProjectSettings.globalize_path("res://native_file_picker.ps1") 直接交给 PowerShell。
# 而 export_presets.cfg 是 export_filter="all_resources" + include_filter=""，
# **非资源文件默认不进 .pck**——我实测导出过一次，包里确实没有那个 .ps1。
# 后果是发包给别人之后所有文件对话框静默失败（只有一条 push_warning）。
# 就算把它加进 include_filter 也不够：包内文件不是磁盘文件，PowerShell 打不开，
# 所以运行时必须把脚本落地成临时文件再启动。
#
# 这里守三件事：
#   1. include_filter 必须包含该脚本（否则 FileAccess 读不到它）；
#   2. GDScript 不能再把 res:// 的 ps1 路径直接交给 PowerShell；
#   3. GDScript 必须真的把脚本写到临时文件再启动。
# 决定性的验证是**真导出一次包再查内容**（见脚本末尾打印的命令），本文件只是快速守卫。
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$root = Split-Path -Parent $PSScriptRoot
$presets = Join-Path $root 'export_presets.cfg'
$picker = Join-Path $root 'native_file_picker.gd'
$problems = 0

# 用例 1：包含过滤器必须点到名。
$presetText = [IO.File]::ReadAllText($presets, [Text.Encoding]::UTF8)
$match = [regex]::Match($presetText, 'include_filter="([^"]*)"')
if (-not $match.Success) {
    'FAIL 找不到 include_filter'
    $problems++
} elseif ($match.Groups[1].Value -notmatch 'native_file_picker\.ps1') {
    "FAIL include_filter 没有包含 native_file_picker.ps1，导出包里不会有它（当前：$($match.Groups[1].Value)）"
    $problems++
} else {
    "PASS 导出包含过滤器已列入：$($match.Groups[1].Value)"
}

# 用例 2/3：启动方式必须走"落地临时脚本"。
$pickerText = [IO.File]::ReadAllText($picker, [Text.Encoding]::UTF8)
if ($pickerText -match 'globalize_path\("res://native_file_picker\.ps1"\)') {
    'FAIL 仍然把 res:// 的 ps1 路径直接交给 PowerShell（打包后该路径上什么都没有）'
    $problems++
} else {
    'PASS 没有再把 res:// 的 ps1 路径直接交给 PowerShell'
}
if ($pickerText -match 'get_file_as_string\("res://native_file_picker\.ps1"\)' -and $pickerText -match 'script_path') {
    'PASS 运行时会把脚本落地成临时文件再启动'
} else {
    'FAIL 没有看到"读脚本 → 写临时文件 → 启动临时脚本"的写法'
    $problems++
}
# 反向自检：确认这段源码里确实存在写文件动作，否则上面的正则在测空气。
if ($pickerText -match 'FileAccess\.open\(script_path, FileAccess\.WRITE\)') {
    'PASS 临时脚本确实被写入'
} else {
    'FAIL 找不到写临时脚本的语句，断言可能失效'
    $problems++
}
# 脚本本体存在且非空（它是唯一事实来源）。
$scriptPath = Join-Path $root 'native_file_picker.ps1'
if ((Test-Path -LiteralPath $scriptPath) -and (Get-Item $scriptPath).Length -gt 500) {
    "PASS 脚本本体存在（$((Get-Item $scriptPath).Length) 字节）"
} else {
    'FAIL 脚本本体缺失或过短'
    $problems++
}

if ($problems -eq 0) {
    'NATIVE_PICKER_PACKAGING_SELFTEST=PASS'
    '提示：决定性验证是真导出一次包再查内容——'
    '  Godot_v4.7.1-stable_win64.exe --headless --path . --export-pack "Windows Desktop" tmp\probe.pck'
    '  然后在包里搜 native_file_picker.ps1'
} else {
    "NATIVE_PICKER_PACKAGING_SELFTEST=FAIL problems=$problems"
}
exit $problems
