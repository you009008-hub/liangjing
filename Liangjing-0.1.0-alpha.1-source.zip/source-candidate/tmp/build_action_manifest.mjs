// [DSH] 动作帧去重清单生成器（开发期工具，可重复运行）。
//
// 背景：assets/actions/peek_side 有 60 个 "帧"，但其中 57 个是同一张图、3 个是另一张图
// （29/30/31 是闭眼那一拍）。60 张 1024×1536 纹理在显存里各占一份，等于 377 MB，
// 而屏幕上真正变化的只有两张图。本脚本按**文件内容哈希**推导出去重清单，
// 写进 action.json 的 images / frames 两个字段，主程序据此加载两张图、
// 再展开成 60 个槽位（同一个 Texture2D 被引用多次，不额外占显存）。
//
// 用法：
//   node tmp\build_action_manifest.mjs            显示当前目录的推导结果（不写盘）
//   node tmp\build_action_manifest.mjs --write    写入 action.json
// 清单完全由哈希推导，不手工维护，避免"改了图忘了改清单"。
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const actionDirectory = process.argv.find((value) => value.startsWith("--dir="))?.slice(6)
  ?? path.join(projectRoot, "assets", "actions", "peek_side");
const shouldWrite = process.argv.includes("--write");

const frameFiles = fs.readdirSync(actionDirectory)
  .filter((name) => /^\d{2}\.png$/.test(name))
  .sort();
if (frameFiles.length === 0) {
  console.log(`MANIFEST_SKIP 目录里没有编号帧：${actionDirectory}`);
  process.exit(0);
}

const digestOf = (name) => crypto.createHash("sha256").update(fs.readFileSync(path.join(actionDirectory, name))).digest("hex");
const uniqueKeys = new Map();      // 哈希 → 清单里的键（用首次出现的帧号，机械且不含语义假设）
const frames = [];
for (const [index, name] of frameFiles.entries()) {
  const digest = digestOf(name);
  if (!uniqueKeys.has(digest)) uniqueKeys.set(digest, { key: name.slice(0, 2), file: name, first: index, digest });
  frames.push(uniqueKeys.get(digest).key);
}

const images = {};
for (const entry of uniqueKeys.values()) images[entry.key] = entry.file;

console.log(`目录：${path.relative(projectRoot, actionDirectory)}`);
console.log(`帧数：${frameFiles.length}　不同内容：${uniqueKeys.size}`);
for (const entry of uniqueKeys.values()) {
  const count = frames.filter((key) => key === entry.key).length;
  console.log(`  键 ${entry.key} → ${entry.file}　重复 ${count} 帧　首次出现于第 ${entry.first} 帧　sha256=${entry.digest.slice(0, 16)}…`);
}
const dropped = frameFiles.filter((name) => !Object.values(images).includes(name));
console.log(`可删除的重复帧：${dropped.length} 个（${dropped.slice(0, 6).join("、")}${dropped.length > 6 ? " …" : ""}）`);
console.log(`保留：${Object.values(images).join("、")}`);

// 清单的 frames 数组按 10 个一行排版，方便人眼核对"哪几帧是闭眼"。
const rows = [];
for (let index = 0; index < frames.length; index += 10) {
  rows.push("    " + frames.slice(index, index + 10).map((key) => `"${key}"`).join(", "));
}
const previous = fs.existsSync(path.join(actionDirectory, "action.json"))
  ? JSON.parse(fs.readFileSync(path.join(actionDirectory, "action.json"), "utf8"))
  : {};
const manifest = {
  name: previous.name ?? path.basename(actionDirectory),
  fps: previous.fps ?? 60,
  loop: previous.loop ?? false,
  images,
  frames,
};
const text = `{\n  "name": ${JSON.stringify(manifest.name)},\n  "fps": ${manifest.fps},\n  "loop": ${manifest.loop},\n  "images": ${JSON.stringify(images)},\n  "frames": [\n${rows.join(",\n")}\n  ]\n}\n`;

if (shouldWrite) {
  fs.writeFileSync(path.join(actionDirectory, "action.json"), text);
  console.log("MANIFEST_WRITTEN action.json");
} else {
  console.log("（未写盘；加 --write 生效）");
}
