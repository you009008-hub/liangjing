extends RefCounted

# Keep provider reasoning separate from the final answer. Only explicit upstream
# reasoning fields are accepted; ordinary answer text is never treated as thought.
static func build_payload(profile: Dictionary, messages: Array) -> Dictionary:
	var payload := {
		"model": str(profile.get("model", "")).strip_edges(),
		"stream": false,
		"messages": messages
	}
	if str(profile.get("provider", "")) == "deepseek":
		var effort := str(profile.get("reasoning_effort", "high" if bool(profile.get("thinking", false)) else "off")).strip_edges().to_lower()
		if effort not in ["off", "low", "high", "max"]:
			effort = "off"
		payload["thinking"] = {"type": "disabled" if effort == "off" else "enabled"}
		if effort != "off":
			payload["reasoning_effort"] = effort
	return payload

static func text_parts(value: Variant, reasoning_only := false) -> String:
	if value is String:
		return value
	if not value is Array:
		return ""
	var parts: Array[String] = []
	for item in value:
		if not item is Dictionary:
			continue
		var part_type := str(item.get("type", "text"))
		var is_reasoning := part_type in ["reasoning", "thinking", "reasoning_text"]
		if is_reasoning != reasoning_only:
			continue
		var part_text = item.get("text", "")
		if part_text is String and not part_text.is_empty():
			parts.append(part_text)
	return "\n".join(parts)

static func parse_completion(parsed: Variant) -> Dictionary:
	if not parsed is Dictionary:
		return {"ok": false, "error": "模型返回了无效数据", "reasoning": ""}
	# [DSH] 有些服务端用 "HTTP 200 + body 里带 error" 表达失败。若不识别，
	# 就会被误报成"模型回答为空"，把排查方向带偏（真机上已经误导过一次）。
	if parsed.get("error", null) is Dictionary:
		var api_message := str(parsed.get("error", {}).get("message", ""))
		if not api_message.is_empty():
			return {"ok": false, "error": "模型服务返回错误：%s" % api_message, "reasoning": ""}
	var choices: Array = parsed.get("choices", []) if parsed.get("choices", []) is Array else []
	if choices.is_empty() or not choices[0] is Dictionary:
		return {"ok": false, "error": "模型没有返回回答", "reasoning": ""}
	var message: Dictionary = choices[0].get("message", {}) if choices[0].get("message", {}) is Dictionary else {}
	var raw_content = message.get("content", "")
	var answer := text_parts(raw_content).strip_edges()
	var reasoning := text_parts(message.get("reasoning_content", "")).strip_edges()
	if reasoning.is_empty() and raw_content is Array:
		reasoning = text_parts(raw_content, true).strip_edges()
	if answer.is_empty():
		return {"ok": false, "error": "模型回答为空", "reasoning": reasoning}
	return {"ok": true, "text": answer, "reasoning": reasoning}

static func reasoning_delta(data: Dictionary) -> String:
	var chunk: Dictionary = data.get("chunk", {}) if data.get("chunk", {}) is Dictionary else {}
	var chunk_type := str(chunk.get("type", ""))
	if chunk_type not in ["reasoning-delta", "reasoning_delta", "reasoning", "thinking", "analysis"]:
		return ""
	# Do not strip individual chunks: spaces/newlines can be significant at joins.
	return text_parts(chunk.get("text", chunk.get("content", "")))
