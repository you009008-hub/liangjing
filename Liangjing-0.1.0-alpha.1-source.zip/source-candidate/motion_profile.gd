# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：新增 arm_swing / leg_swing 四肢摆动参数与区间约束。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
extends RefCounted

# Values use the full normalized character canvas, not the cropped thumbnail.
static func defaults() -> Dictionary:
	return {
		"enabled": true, "head_y": 0.18, "shoulder_y": 0.28, "feet_y": 0.98,
		"breath": 1.0, "hair": 1.0, "speed": 1.0, "gaze": 1.0,
		"arm_swing": 1.0, "leg_swing": 1.0,
		"eyes_calibrated": false, "eyes_enabled": false, "blink_enabled": false,
		"eye_left_x": 0.444, "eye_left_y": 0.182,
		"eye_right_x": 0.544, "eye_right_y": 0.182,
		"eye_radius_x": 0.043, "eye_radius_y": 0.030,
	}

static func finite_number(value: Variant, fallback: float, minimum: float, maximum: float) -> float:
	if typeof(value) != TYPE_FLOAT and typeof(value) != TYPE_INT:
		return fallback
	var number := float(value)
	if not is_finite(number):
		return fallback
	return clampf(number, minimum, maximum)

static func sanitize(input: Dictionary) -> Dictionary:
	var result := defaults()
	for key in ["enabled", "eyes_calibrated", "eyes_enabled", "blink_enabled"]:
		if typeof(input.get(key)) == TYPE_BOOL:
			result[key] = input[key]
	var ranges := {
		"head_y": Vector2(0.08, 0.40), "shoulder_y": Vector2(0.18, 0.60), "feet_y": Vector2(0.65, 1.0),
		"breath": Vector2(0.0, 2.0), "hair": Vector2(0.0, 2.0), "speed": Vector2(0.0, 2.0), "gaze": Vector2(0.0, 2.0),
		"arm_swing": Vector2(0.0, 2.0), "leg_swing": Vector2(0.0, 2.0),
		"eye_left_x": Vector2(0.15, 0.60), "eye_right_x": Vector2(0.40, 0.85),
		"eye_left_y": Vector2(0.06, 0.50), "eye_right_y": Vector2(0.06, 0.50),
		"eye_radius_x": Vector2(0.010, 0.070), "eye_radius_y": Vector2(0.008, 0.055),
	}
	for key in ranges:
		var bounds: Vector2 = ranges[key]
		result[key] = finite_number(input.get(key), float(result[key]), bounds.x, bounds.y)
	result["shoulder_y"] = maxf(float(result["shoulder_y"]), float(result["head_y"]) + 0.04)
	result["feet_y"] = maxf(float(result["feet_y"]), float(result["shoulder_y"]) + 0.15)
	# Prevent crossed eyes or overlapping calibration masks.
	result["eye_right_x"] = maxf(float(result["eye_right_x"]), float(result["eye_left_x"]) + 0.03)
	result["eye_radius_x"] = minf(float(result["eye_radius_x"]), (float(result["eye_right_x"]) - float(result["eye_left_x"])) * 0.48)
	if not result["eyes_calibrated"]:
		result["eyes_enabled"] = false
		result["blink_enabled"] = false
	return result

static func preset(name: String, base: Dictionary = {}) -> Dictionary:
	var result := sanitize(base)
	match name:
		"gentle", "轻柔":
			result.merge({"enabled": true, "breath": 0.55, "hair": 0.45, "speed": 0.75, "gaze": 0.65, "arm_swing": 0.5, "leg_swing": 0.4}, true)
		"still", "静止":
			result["enabled"] = false
		"normal", "正常":
			result.merge({"enabled": true, "breath": 1.0, "hair": 1.0, "speed": 1.0, "gaze": 1.0, "arm_swing": 1.0, "leg_swing": 1.0}, true)
	return result
