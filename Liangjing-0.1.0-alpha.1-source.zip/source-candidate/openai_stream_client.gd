extends Node

signal reasoning_delta_received(text: String)
signal answer_delta_received(text: String)

const ChatResponse = preload("res://chat_response.gd")
const REQUEST_TIMEOUT_SECONDS := 180.0
const CONNECT_TIMEOUT_SECONDS := 30.0
# [DSH] 流静默多久判定服务端不会再发正文。真机实测的中转服务是回完开场帧就彻底静默，
# 2.5 秒足够区分"慢"和"断了"，又不会让用户等满 180 秒超时。
const STREAM_IDLE_TIMEOUT_MS := 2500


func request(profile: Dictionary, api_key: String, messages: Array, network_settings: Dictionary = {}) -> Dictionary:
	var base_url := str(profile.get("base_url", "")).strip_edges().trim_suffix("/")
	var model := str(profile.get("model", "")).strip_edges()
	if base_url.is_empty() or model.is_empty() or api_key.is_empty():
		return {"ok": false, "error": "模型配置不完整", "reasoning": "", "reasoning_streamed": false}
	var endpoint := base_url if base_url.ends_with("/chat/completions") else base_url + "/chat/completions"
	var endpoint_info := parse_endpoint(endpoint)
	if not bool(endpoint_info.get("ok", false)):
		return {"ok": false, "error": str(endpoint_info.get("error", "接口地址无效")), "reasoning": "", "reasoning_streamed": false}

	var client := HTTPClient.new()
	apply_proxy(client, network_settings)
	var tls_options: TLSOptions = TLSOptions.client() if bool(endpoint_info.get("tls", false)) else null
	var connect_error := client.connect_to_host(str(endpoint_info["host"]), int(endpoint_info["port"]), tls_options)
	if connect_error != OK:
		return {"ok": false, "error": "模型网络连接没有启动", "reasoning": "", "reasoning_streamed": false}
	var deadline := Time.get_ticks_msec() + int(REQUEST_TIMEOUT_SECONDS * 1000.0)
	while client.get_status() in [HTTPClient.STATUS_RESOLVING, HTTPClient.STATUS_CONNECTING]:
		if Time.get_ticks_msec() >= deadline:
			client.close()
			return {"ok": false, "error": "模型网络连接超时", "reasoning": "", "reasoning_streamed": false}
		client.poll()
		await get_tree().process_frame
	if client.get_status() != HTTPClient.STATUS_CONNECTED:
		client.close()
		return {"ok": false, "error": "模型网络连接失败", "reasoning": "", "reasoning_streamed": false}

	var headers := PackedStringArray([
		"Content-Type: application/json",
		"Accept: text/event-stream",
		"Authorization: Bearer %s" % api_key
	])
	var payload := ChatResponse.build_payload(profile, messages)
	payload["stream"] = true
	var request_error := client.request(HTTPClient.METHOD_POST, str(endpoint_info["target"]), headers, JSON.stringify(payload))
	if request_error != OK:
		client.close()
		return {"ok": false, "error": "模型请求没有发出", "reasoning": "", "reasoning_streamed": false}

	var response_code := 0
	var full_body := PackedByteArray()
	var pending := PackedByteArray()
	var answer := ""
	var reasoning := ""
	var saw_sse := false
	var stream_done := false
	var stream_error := ""
	# [DSH] 流"卡住"的检测：收到字节就刷新时钟，静默超过 IDLE 就认定服务端不会再发。
	# 真机实测：某个中转服务收到 stream:true 后只回一帧开场帧（content 为空）就静默，
	# 于是客户端一路等到 180 秒超时才报错——用户看到的是"等三分钟然后失败"。
	# 有了静默判定，这种情况几秒内就能定性并转入非流式回退。
	# 时钟必须从正文开始起算，不能从发请求起算：服务端排队、长提示词导致首字节
	# 3~5 秒才到是正常现象；若拿发请求的时刻当基准，响应头一到就会被误判成静默，
	# 慢而健康的服务端反而直接失败。0 表示"正文还没开始"。
	var body_started_at := 0
	var last_data_at := 0
	var stalled := false
	while Time.get_ticks_msec() < deadline:
		var poll_error := client.poll()
		if poll_error != OK:
			stream_error = "读取模型流失败"
			break
		if response_code == 0 and client.has_response():
			response_code = client.get_response_code()
		var status := client.get_status()
		if status == HTTPClient.STATUS_BODY:
			if body_started_at == 0:
				body_started_at = Time.get_ticks_msec()
				last_data_at = body_started_at
			var chunk := client.read_response_body_chunk()
			if not chunk.is_empty():
				last_data_at = Time.get_ticks_msec()
				full_body.append_array(chunk)
				pending.append_array(chunk)
				var consumed := consume_sse_frames(pending)
				pending = consumed.get("pending", PackedByteArray())
				for event_value in consumed.get("events", []):
					var event: Dictionary = event_value
					saw_sse = true
					if not str(event.get("error", "")).is_empty():
						stream_error = str(event["error"])
						break
					var reasoning_delta := str(event.get("reasoning", ""))
					var answer_delta := str(event.get("answer", ""))
					if not reasoning_delta.is_empty():
						reasoning += reasoning_delta
						reasoning_delta_received.emit(reasoning_delta)
					if not answer_delta.is_empty():
						answer += answer_delta
						answer_delta_received.emit(answer_delta)
					if bool(event.get("done", false)):
						stream_done = true
				if not stream_error.is_empty() or stream_done:
					break
			elif Time.get_ticks_msec() - last_data_at >= STREAM_IDLE_TIMEOUT_MS:
				stalled = true
				break
		elif status in [HTTPClient.STATUS_CONNECTED, HTTPClient.STATUS_DISCONNECTED]:
			break
		elif status not in [HTTPClient.STATUS_REQUESTING, HTTPClient.STATUS_CONNECTING, HTTPClient.STATUS_RESOLVING]:
			stream_error = "模型流连接异常"
			break
		await get_tree().process_frame
	client.close()
	if Time.get_ticks_msec() >= deadline:
		return {"ok": false, "error": "模型请求超时", "reasoning": reasoning, "reasoning_streamed": not reasoning.is_empty()}
	var body_text := full_body.get_string_from_utf8()
	if response_code < 200 or response_code >= 300:
		return {"ok": false, "error": response_error(body_text, response_code), "reasoning": reasoning, "reasoning_streamed": not reasoning.is_empty()}
	if not stream_error.is_empty():
		return {"ok": false, "error": stream_error, "reasoning": reasoning, "reasoning_streamed": not reasoning.is_empty()}
	# [DSH] 流结束后的去向由这一个纯函数裁决，避免判断散落在多个分支里。
	var outcome := decide_stream_outcome(stalled, saw_sse, answer, body_text)
	if outcome == "fallback":
		# [DSH] 收到 SSE 却没有正文：**改用同一次请求的非流式通道重试**。
		#
		# 为什么必须这样做：有些中转服务对 stream:true 只回开场帧、正文要等完整结果，
		# 原来的非流式回退只在"一个 SSE 帧都没收到"时才会执行，
		# 于是这种服务永远走不到回退，用户只会看到"模型回答为空"。
		# 这里是一次用户提问内的通道降级：流式那一侧没有产出过正文 token；
		# 但若已经流出过 reasoning，那部分已被计费，回退会再算一次——不掩饰这一点。
		var fallback_result := await request_without_stream(profile, api_key, messages, network_settings)
		if bool(fallback_result.get("ok", false)):
			fallback_result["reasoning"] = reasoning.strip_edges()
			fallback_result["reasoning_streamed"] = not reasoning.is_empty()
			fallback_result["transport"] = "非流式回退"
			# 把"流式失败、已降级"这件事如实记在 trace 上，便于以后定位。
			return fallback_result
		# 回退也失败：把两边的信息都带上，而不是只说"回答为空"。
		return {
			"ok": false,
			"error": "模型回答为空（流式%s，非流式回退也失败：%s）" % ["已静默中断" if stalled else "未产生正文", str(fallback_result.get("error", "未知原因"))],
			"reasoning": reasoning.strip_edges(),
			"reasoning_streamed": not reasoning.is_empty()
		}
	if outcome == "truncated":
		# [DSH] 说到一半就静默：回退重发会作废已生成的内容、还可能重复计费，所以保留已有正文；
		# 但绝不能拿半截答案冒充完整回答，truncated 由上层显式告诉用户。
		return {
			"ok": true,
			"text": answer.strip_edges(),
			"reasoning": reasoning.strip_edges(),
			"reasoning_streamed": not reasoning.is_empty(),
			"truncated": true,
			"error": "模型流在回答中途静默中断，以上回答不完整"
		}
	if outcome == "answer":
		return {"ok": true, "text": answer.strip_edges(), "reasoning": reasoning.strip_edges(), "reasoning_streamed": not reasoning.is_empty()}
	# 少数兼容接口会忽略 stream=true 并直接返回普通 JSON；保留非流式回退。
	var fallback := ChatResponse.parse_completion(JSON.parse_string(body_text))
	fallback["reasoning_streamed"] = false
	return fallback

# [DSH] 流结束后的去向判定（纯函数，便于直接断言）。这是"静默中断"的唯一裁决点：
#   fallback  —— 一帧正文都没有（静默中断，或服务端只回开场帧）：走非流式降级
#   truncated —— 已经产出正文但中途静默：保留正文，但必须标记为不完整
#   answer    —— 正常拿到正文
#   json      —— 一帧 SSE 都没有、body 却是完整 JSON（服务端忽略了 stream=true）
static func decide_stream_outcome(stalled: bool, saw_sse: bool, answer: String, body_text: String) -> String:
	if answer.strip_edges().is_empty():
		if stalled or saw_sse or body_text.strip_edges().is_empty():
			return "fallback"
		return "json"
	return "truncated" if stalled else "answer"


# [DSH] 用非流式方式发同一个请求（同一次用户提问内的通道降级）。
# 与主请求共用 endpoint 解析、代理与鉴权逻辑，避免两套实现逐渐走偏。
func request_without_stream(profile: Dictionary, api_key: String, messages: Array, network_settings: Dictionary) -> Dictionary:
	var base_url := str(profile.get("base_url", "")).strip_edges().trim_suffix("/")
	var model := str(profile.get("model", "")).strip_edges()
	if base_url.is_empty() or model.is_empty() or api_key.is_empty():
		return {"ok": false, "error": "模型配置不完整"}
	var endpoint := base_url if base_url.ends_with("/chat/completions") else base_url + "/chat/completions"
	var info := parse_endpoint(endpoint)
	if not bool(info.get("ok", false)):
		return {"ok": false, "error": str(info.get("error", "接口地址无效"))}
	var client := HTTPClient.new()
	apply_proxy(client, network_settings)
	var tls_options: TLSOptions = TLSOptions.client() if bool(info.get("tls", false)) else null
	if client.connect_to_host(str(info["host"]), int(info["port"]), tls_options) != OK:
		return {"ok": false, "error": "模型网络连接没有启动"}
	var connect_deadline := Time.get_ticks_msec() + int(CONNECT_TIMEOUT_SECONDS * 1000.0)
	while client.get_status() in [HTTPClient.STATUS_RESOLVING, HTTPClient.STATUS_CONNECTING]:
		if Time.get_ticks_msec() >= connect_deadline:
			client.close()
			return {"ok": false, "error": "模型网络连接超时"}
		client.poll()
		await get_tree().process_frame
	if client.get_status() != HTTPClient.STATUS_CONNECTED:
		client.close()
		return {"ok": false, "error": "模型网络连接失败"}
	var headers := PackedStringArray([
		"Content-Type: application/json",
		"Accept: application/json",
		"Authorization: Bearer %s" % api_key
	])
	var payload := ChatResponse.build_payload(profile, messages)
	payload["stream"] = false
	if client.request(HTTPClient.METHOD_POST, str(info["target"]), headers, JSON.stringify(payload)) != OK:
		client.close()
		return {"ok": false, "error": "模型请求没有发出"}
	var body := PackedByteArray()
	var code := 0
	var deadline := Time.get_ticks_msec() + int(REQUEST_TIMEOUT_SECONDS * 1000.0)
	while Time.get_ticks_msec() < deadline:
		client.poll()
		if code == 0 and client.has_response():
			code = client.get_response_code()
		var status := client.get_status()
		if status == HTTPClient.STATUS_BODY:
			var chunk := client.read_response_body_chunk()
			if not chunk.is_empty():
				body.append_array(chunk)
		elif status in [HTTPClient.STATUS_CONNECTED, HTTPClient.STATUS_DISCONNECTED]:
			break
		elif status not in [HTTPClient.STATUS_REQUESTING, HTTPClient.STATUS_CONNECTING, HTTPClient.STATUS_RESOLVING]:
			break
		await get_tree().process_frame
	client.close()
	var text := body.get_string_from_utf8()
	if code < 200 or code >= 300:
		return {"ok": false, "error": response_error(text, code)}
	var parsed := ChatResponse.parse_completion(JSON.parse_string(text))
	parsed["reasoning_streamed"] = false
	return parsed


static func parse_endpoint(endpoint: String) -> Dictionary:
	var value := endpoint.strip_edges()
	var tls := value.begins_with("https://")
	if not tls and not value.begins_with("http://"):
		return {"ok": false, "error": "接口地址必须以 http:// 或 https:// 开头"}
	var remainder := value.trim_prefix("https://").trim_prefix("http://")
	var slash := remainder.find("/")
	var authority := remainder if slash < 0 else remainder.left(slash)
	var target := "/" if slash < 0 else remainder.substr(slash)
	if authority.is_empty():
		return {"ok": false, "error": "接口地址缺少主机名"}
	var host := authority
	var port := 443 if tls else 80
	var colon := authority.rfind(":")
	if colon > 0 and authority.find(":") == colon:
		var port_text := authority.substr(colon + 1)
		if port_text.is_valid_int():
			host = authority.left(colon)
			port = int(port_text)
	if host.is_empty() or port <= 0 or port > 65535:
		return {"ok": false, "error": "接口地址的主机或端口无效"}
	return {"ok": true, "host": host, "port": port, "target": target, "tls": tls}


static func apply_proxy(client: HTTPClient, network_settings: Dictionary) -> void:
	if not bool(network_settings.get("enabled", false)):
		return
	var host := str(network_settings.get("host", ""))
	var port := int(network_settings.get("port", -1))
	if host.is_empty() or port <= 0:
		return
	client.set_http_proxy(host, port)
	client.set_https_proxy(host, port)


static func find_sse_frame_end(bytes: PackedByteArray) -> Dictionary:
	for index in range(bytes.size() - 1):
		if bytes[index] == 10 and bytes[index + 1] == 10:
			return {"index": index, "skip": 2}
		if index + 3 < bytes.size() and bytes[index] == 13 and bytes[index + 1] == 10 and bytes[index + 2] == 13 and bytes[index + 3] == 10:
			return {"index": index, "skip": 4}
	return {"index": -1, "skip": 0}


static func consume_sse_frames(input: PackedByteArray) -> Dictionary:
	var pending := input.duplicate()
	var events: Array[Dictionary] = []
	while true:
		var delimiter := find_sse_frame_end(pending)
		var frame_end := int(delimiter.get("index", -1))
		if frame_end < 0:
			break
		var frame := pending.slice(0, frame_end).get_string_from_utf8()
		pending = pending.slice(frame_end + int(delimiter.get("skip", 0)))
		var decoded := decode_sse_event(frame)
		if not decoded.is_empty():
			events.append(decoded)
	return {"events": events, "pending": pending}


static func decode_sse_event(frame: String) -> Dictionary:
	var data_lines: Array[String] = []
	for raw_line in frame.replace("\r\n", "\n").split("\n"):
		var line := str(raw_line)
		if line.begins_with("data:"):
			data_lines.append(line.substr(5).trim_prefix(" "))
	if data_lines.is_empty():
		return {}
	var data := "\n".join(data_lines)
	if data.strip_edges() == "[DONE]":
		return {"done": true}
	var parsed = JSON.parse_string(data)
	if not parsed is Dictionary:
		return {"error": "模型返回了无效的流式数据"}
	if parsed.get("error", null) is Dictionary:
		return {"error": str(parsed.get("error", {}).get("message", "模型流返回错误"))}
	return parse_completion_delta(parsed)


static func parse_completion_delta(parsed: Dictionary) -> Dictionary:
	var choices: Array = parsed.get("choices", []) if parsed.get("choices", []) is Array else []
	if choices.is_empty() or not choices[0] is Dictionary:
		return {}
	var choice: Dictionary = choices[0]
	var delta: Dictionary = choice.get("delta", {}) if choice.get("delta", {}) is Dictionary else {}
	var raw_content = delta.get("content", "")
	var answer := ChatResponse.text_parts(raw_content)
	var reasoning := ChatResponse.text_parts(delta.get("reasoning_content", ""))
	if reasoning.is_empty():
		for field in ["reasoning", "thinking", "analysis"]:
			reasoning = ChatResponse.text_parts(delta.get(field, ""))
			if not reasoning.is_empty():
				break
	if raw_content is Array:
		reasoning += ChatResponse.text_parts(raw_content, true)
	return {
		"answer": answer,
		"reasoning": reasoning,
		"done": str(choice.get("finish_reason", "")) != ""
	}


static func response_error(body_text: String, response_code: int) -> String:
	var fallback := "服务返回 %d" % response_code
	var parsed = JSON.parse_string(body_text)
	if parsed is Dictionary and parsed.get("error", null) is Dictionary:
		return str(parsed.get("error", {}).get("message", fallback))
	return fallback


static func selftest() -> Dictionary:
	var failures: Array[String] = []
	var endpoint := parse_endpoint("https://api.example.com:8443/v1/chat/completions")
	if not bool(endpoint.get("ok", false)) or endpoint.get("host") != "api.example.com" or endpoint.get("port") != 8443 or endpoint.get("target") != "/v1/chat/completions":
		failures.append("HTTPS 接口地址解析错误")
	var first := decode_sse_event('data: {"choices":[{"delta":{"reasoning_content":"先想 "}}]}')
	if first.get("reasoning") != "先想 " or first.get("answer") != "":
		failures.append("reasoning_content 分片解析错误")
	var second := decode_sse_event('data: {"choices":[{"delta":{"content":"回答"}}]}')
	if second.get("answer") != "回答" or second.get("reasoning") != "":
		failures.append("回答分片解析错误")
	var typed := decode_sse_event('data: {"choices":[{"delta":{"content":[{"type":"reasoning","text":"分析"},{"type":"text","text":"正文"}]}}]}')
	if typed.get("reasoning") != "分析" or typed.get("answer") != "正文":
		failures.append("类型化分片没有分离思考与正文")
	var unicode_frame := 'data: {"choices":[{"delta":{"reasoning_content":"中文鲸鱼"}}]}\n\n'.to_utf8_buffer()
	var split_at := unicode_frame.size() - 4
	var partial := consume_sse_frames(unicode_frame.slice(0, split_at))
	if not partial.get("events", []).is_empty():
		failures.append("不完整 UTF-8/SSE 帧被提前解析")
	var joined: PackedByteArray = partial.get("pending", PackedByteArray())
	joined.append_array(unicode_frame.slice(split_at))
	var completed := consume_sse_frames(joined)
	if completed.get("events", []).size() != 1 or completed.get("events", [])[0].get("reasoning") != "中文鲸鱼":
		failures.append("跨网络块的 UTF-8/SSE 帧没有完整恢复")
	if not bool(decode_sse_event("data: [DONE]").get("done", false)):
		failures.append("[DONE] 没有结束流")
	# [DSH] 降级通道的断言（新增 2 项）。
	# 背景：真机上出现过"服务端只回一帧开场帧就不再发内容"，用户看到"模型回答为空"。
	# 修复依赖两条性质，缺一不可，因此都必须由断言守住：
	#   1) 非流式回退必须是**非流式**——否则会原样复现同一个故障；
	#   2) 回退路径要能识别"HTTP 200 但 body 里带 error"这种服务端表达方式，
	#      否则会把服务端错误说成"模型回答为空"，继续误导排查。
	var bare_payload := ChatResponse.build_payload({"model": "m", "provider": "openai_compatible"}, [])
	if bool(bare_payload.get("stream", false)):
		failures.append("非流式回退的请求体仍是 stream=true，会原样复现故障")
	# 非标准字段只应在 deepseek provider 下出现，避免发给不认它的兼容服务。
	if bare_payload.has("thinking"):
		failures.append("非 deepseek 的请求体里带了非标准 thinking 字段")
	var error_payload := ChatResponse.parse_completion({"error": {"message": "服务端拒绝了这个模型名"}})
	if str(error_payload.get("error", "")) != "模型服务返回错误：服务端拒绝了这个模型名":
		failures.append("HTTP 200 但 body 带 error 时没有被识别为服务端错误")
	# [DSH] 静默中断的去向裁决（新增 5 项）。这是本次修复的核心行为，
	# 断言裁决本身，而不是只断言它用到的两个纯函数。
	if decide_stream_outcome(true, false, "", "") != "fallback":
		failures.append("静默且没有正文时没有转入非流式回退")
	if decide_stream_outcome(true, true, "半截回答", "data: x") != "truncated":
		failures.append("静默但有正文时没有标记为不完整")
	if decide_stream_outcome(false, true, "完整回答", "data: x") != "answer":
		failures.append("正常拿到正文被误判成异常")
	if decide_stream_outcome(false, false, "完整回答", "") != "answer":
		failures.append("没有静默的正常正文被误判为不完整")
	if decide_stream_outcome(false, false, "", '{"choices":[{"message":{"content":"正文"}}]}') != "json":
		failures.append("服务端忽略 stream 直接返回 JSON 时没有走 JSON 解析")
	return {"ok": failures.is_empty(), "failures": failures, "cases": 15}
