# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：用户规则改为原子写。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
extends Node

const NativeWindows = preload("res://native_windows.gd")
const NativeFilePicker = preload("res://native_file_picker.gd")

const AtomicFile = preload("res://atomic_file.gd")

signal changed

var host: Node
var root_path := ""
var data_path := ""
var window: Window
var rule_list: ItemList
var name_input: LineEdit
var category_select: OptionButton
var scope_select: OptionButton
var decision_select: OptionButton
var description_input: TextEdit
var enabled_check: CheckButton
var status_label: Label
var rules: Array[Dictionary] = []
var selected_index := -1

const WINDOW_SIZE := Vector2i(860, 660)

func setup(owner_node: Node, soul_root: String) -> void:
	host = owner_node
	root_path = soul_root.path_join("配置")
	DirAccess.make_dir_recursive_absolute(root_path)
	data_path = root_path.path_join("用户规则.json")
	load_rules()
	build_window()

func make_style(color: Color, border := Color("b9d9ee"), radius := 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func style_button(button: Button, primary := false) -> void:
	button.add_theme_font_size_override("font_size", 14)
	button.add_theme_color_override("font_color", Color.WHITE if primary else Color("17486d"))
	button.add_theme_stylebox_override("normal", make_style(Color("3198d7") if primary else Color("f8fcff"), Color("3198d7")))
	button.add_theme_stylebox_override("hover", make_style(Color("238ccc") if primary else Color("e9f6ff"), Color("238ccc")))
	button.add_theme_stylebox_override("pressed", make_style(Color("197dbb"), Color("197dbb")))

func style_field(control: Control) -> void:
	control.add_theme_font_size_override("font_size", 14)
	control.add_theme_color_override("font_color", Color("173f63"))
	control.add_theme_stylebox_override("normal", make_style(Color("ffffff"), Color("aed5ec")))

func build_window() -> void:
	window = Window.new()
	window.title = "梁鲸 · 规则中心"
	window.size = WINDOW_SIZE
	window.borderless = false
	window.transparent = false
	window.unresizable = false
	window.always_on_top = true
	window.transient = false
	window.exclusive = false
	window.visible = false
	host.add_child(window)
	NativeWindows.configure(window)
	window.close_requested.connect(close)

	var background := ColorRect.new()
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background.color = Color("f3faff")
	window.add_child(background)

	var panel := PanelContainer.new()
	panel.position = Vector2(10, 10)
	panel.size = Vector2(WINDOW_SIZE) - Vector2(20, 20)
	var panel_style := make_style(Color("f3faff"), Color("58b8ee"), 18)
	panel_style.set_border_width_all(2)
	panel_style.content_margin_left = 18
	panel_style.content_margin_right = 18
	panel_style.content_margin_top = 15
	panel_style.content_margin_bottom = 15
	panel.add_theme_stylebox_override("panel", panel_style)
	window.add_child(panel)
	NativeWindows.mount(window, panel)

	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 10)
	panel.add_child(outer)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.gui_input.connect(on_header_input)
	outer.add_child(header)
	var title := Label.new()
	title.text = "●  我的规则"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("173f63"))
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(42, 34)
	style_button(close_button)
	close_button.pressed.connect(close)
	header.add_child(close_button)

	var hint := Label.new()
	hint.text = "规则由你定义。模型只能协助整理；未确认的内容不会自动成为长期规则。"
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color("5b7f9e"))
	outer.add_child(hint)

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	outer.add_child(body)
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(245, 0)
	left.add_theme_constant_override("separation", 8)
	body.add_child(left)
	var add_button := Button.new()
	add_button.text = "＋ 新建规则"
	add_button.custom_minimum_size = Vector2(0, 38)
	style_button(add_button, true)
	add_button.pressed.connect(create_rule)
	left.add_child(add_button)
	rule_list = ItemList.new()
	rule_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rule_list.add_theme_font_size_override("font_size", 14)
	rule_list.add_theme_stylebox_override("panel", make_style(Color("ffffff"), Color("c3ddeb")))
	rule_list.item_selected.connect(select_rule)
	left.add_child(rule_list)

	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 8)
	body.add_child(right)
	name_input = add_labeled_line(right, "规则名称", "例如：删除文件必须确认")
	var choice_row := HBoxContainer.new()
	choice_row.add_theme_constant_override("separation", 8)
	right.add_child(choice_row)
	category_select = add_labeled_option(choice_row, "类别", ["文件", "应用", "网络", "隐私", "记忆", "模型", "其他"])
	scope_select = add_labeled_option(choice_row, "范围", ["全局", "当前项目", "当前任务", "指定对象"])
	decision_select = add_labeled_option(choice_row, "处理方式", ["允许", "执行前询问", "预览后提交", "禁止"])
	var desc_label := Label.new()
	desc_label.text = "自然语言说明"
	desc_label.add_theme_font_size_override("font_size", 13)
	desc_label.add_theme_color_override("font_color", Color("315c7d"))
	right.add_child(desc_label)
	description_input = TextEdit.new()
	description_input.placeholder_text = "用你自己的话写清楚这条规则、适用对象和例外情况。"
	description_input.custom_minimum_size = Vector2(0, 150)
	description_input.size_flags_vertical = Control.SIZE_EXPAND_FILL
	style_field(description_input)
	right.add_child(description_input)
	enabled_check = CheckButton.new()
	enabled_check.text = "启用这条规则"
	enabled_check.button_pressed = true
	enabled_check.add_theme_font_size_override("font_size", 14)
	right.add_child(enabled_check)
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	right.add_child(actions)
	var delete_button := Button.new()
	delete_button.text = "删除"
	delete_button.custom_minimum_size = Vector2(82, 38)
	style_button(delete_button)
	delete_button.pressed.connect(delete_selected)
	actions.add_child(delete_button)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(spacer)
	var save_button := Button.new()
	save_button.text = "保存规则"
	save_button.custom_minimum_size = Vector2(120, 38)
	style_button(save_button, true)
	save_button.pressed.connect(save_selected)
	actions.add_child(save_button)
	status_label = Label.new()
	status_label.text = "规则仅保存在这台电脑。"
	status_label.add_theme_font_size_override("font_size", 12)
	status_label.add_theme_color_override("font_color", Color("397397"))
	right.add_child(status_label)
	refresh_list()

func add_labeled_line(parent: VBoxContainer, label_text: String, placeholder: String) -> LineEdit:
	var label := Label.new()
	label.text = label_text
	label.add_theme_font_size_override("font_size", 13)
	label.add_theme_color_override("font_color", Color("315c7d"))
	parent.add_child(label)
	var line := LineEdit.new()
	line.placeholder_text = placeholder
	line.custom_minimum_size = Vector2(0, 38)
	style_field(line)
	parent.add_child(line)
	return line

func add_labeled_option(parent: HBoxContainer, label_text: String, options: Array) -> OptionButton:
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(box)
	var label := Label.new()
	label.text = label_text
	label.add_theme_font_size_override("font_size", 13)
	label.add_theme_color_override("font_color", Color("315c7d"))
	box.add_child(label)
	var option := OptionButton.new()
	option.custom_minimum_size = Vector2(0, 38)
	for value in options:
		option.add_item(str(value))
	style_field(option)
	box.add_child(option)
	return option

func open() -> void:
	refresh_list()
	NativeWindows.fit(window)
	window.show()
	center_window()
	window.grab_focus()
	DisplayServer.window_move_to_foreground(window.get_window_id())

func close() -> void:
	window.hide()

func center_window() -> void:
	var usable := DisplayServer.screen_get_usable_rect(host.get_window().current_screen)
	window.position = usable.position + (usable.size - window.size) / 2

func on_header_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		DisplayServer.window_start_drag(window.get_window_id())
		window.get_viewport().set_input_as_handled()

func create_rule() -> void:
	rules.append({
		"id": "rule_%d" % Time.get_unix_time_from_system(),
		"name": "新规则",
		"category": "其他",
		"scope": "全局",
		"decision": "执行前询问",
		"description": "",
		"enabled": true,
		"confirmed": true,
		"created_at": Time.get_datetime_string_from_system()
	})
	selected_index = rules.size() - 1
	refresh_list()
	rule_list.select(selected_index)
	show_rule(selected_index)

func select_rule(index: int) -> void:
	selected_index = index
	show_rule(index)

func show_rule(index: int) -> void:
	if index < 0 or index >= rules.size():
		return
	var rule := rules[index]
	name_input.text = str(rule.get("name", ""))
	select_text(category_select, str(rule.get("category", "其他")))
	select_text(scope_select, str(rule.get("scope", "全局")))
	select_text(decision_select, str(rule.get("decision", "执行前询问")))
	description_input.text = str(rule.get("description", ""))
	enabled_check.button_pressed = bool(rule.get("enabled", true))
	status_label.text = "已确认 · %s" % str(rule.get("created_at", "本机规则"))

func select_text(option: OptionButton, value: String) -> void:
	for index in option.item_count:
		if option.get_item_text(index) == value:
			option.select(index)
			return

func save_selected() -> void:
	if selected_index < 0 or selected_index >= rules.size():
		status_label.text = "请先新建或选择一条规则。"
		return
	if name_input.text.strip_edges().is_empty():
		status_label.text = "规则名称不能为空。"
		return
	var rule := rules[selected_index]
	rule["name"] = name_input.text.strip_edges()
	rule["category"] = category_select.get_item_text(category_select.selected)
	rule["scope"] = scope_select.get_item_text(scope_select.selected)
	rule["decision"] = decision_select.get_item_text(decision_select.selected)
	rule["description"] = description_input.text.strip_edges()
	rule["enabled"] = enabled_check.button_pressed
	rule["confirmed"] = true
	rule["updated_at"] = Time.get_datetime_string_from_system()
	rules[selected_index] = rule
	persist()
	refresh_list()
	rule_list.select(selected_index)
	status_label.text = "规则已保存到本机，并标记为用户确认。"
	changed.emit()

func delete_selected() -> void:
	if selected_index < 0 or selected_index >= rules.size():
		return
	rules.remove_at(selected_index)
	selected_index = mini(selected_index, rules.size() - 1)
	persist()
	refresh_list()
	if selected_index >= 0:
		rule_list.select(selected_index)
		show_rule(selected_index)
	else:
		name_input.text = ""
		description_input.text = ""
		status_label.text = "当前还没有用户规则。"
	changed.emit()

func refresh_list() -> void:
	if not rule_list:
		return
	rule_list.clear()
	for rule in rules:
		var state := "●" if bool(rule.get("enabled", true)) else "○"
		rule_list.add_item("%s  %s\n    %s · %s" % [state, str(rule.get("name", "未命名规则")), str(rule.get("scope", "全局")), str(rule.get("decision", "询问"))])
	if rules.is_empty():
		status_label.text = "还没有规则。点击“新建规则”从零开始。" if status_label else ""

func load_rules() -> void:
	rules.clear()
	if not FileAccess.file_exists(data_path):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(data_path))
	if parsed is Dictionary and parsed.get("rules", []) is Array:
		for item in parsed.get("rules", []):
			if item is Dictionary:
				rules.append(item)

func persist() -> void:
	# 原子写：规则被写坏会被静默回落成“没有规则”，用户会以为规则丢了。
	if not AtomicFile.write_text(data_path, JSON.stringify({"version": 1, "rules": rules}, "\t", false)):
		status_label.text = "规则保存失败，请检查灵魂仓库权限。"
