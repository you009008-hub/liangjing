import {prepare} from './bootstrap.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=fs.mkdtempSync(path.join(os.tmpdir(),'liangjing-bootstrap-'));
const app=path.join(root,'runtime/harness/app');
const entry=path.join(app,'node_modules/@deepseek-ai/dsh/lib/bin.js');
fs.mkdirSync(app,{recursive:true});fs.writeFileSync(path.join(app,'package-lock.json'),'{}');
let calls=0;
const success=()=>{calls++;fs.mkdirSync(path.dirname(entry),{recursive:true});fs.writeFileSync(entry,'// mock');return {status:0};};
try{
 assert.equal(prepare(root,success),true);assert.equal(calls,1);
 assert.equal(prepare(root,success),true);assert.equal(calls,1);
 fs.writeFileSync(path.join(app,'package-lock.json'),'{"changed":true}');
 assert.equal(prepare(root,()=>({status:1})),false);
 assert.equal(prepare(root,success),true);assert.equal(calls,2);
 fs.unlinkSync(entry);fs.writeFileSync(path.join(app,'.liangjing-install.lock'),'other');
 assert.equal(prepare(root,success),false);assert.equal(calls,2);
 fs.unlinkSync(path.join(app,'.liangjing-install.lock'));
 assert.equal(prepare(root,()=>({status:0})),false);
 console.log('BOOTSTRAP_TEST=PASS checks=6');
}finally{
 const real=fs.realpathSync(root), tmp=fs.realpathSync(os.tmpdir());
 if(path.dirname(real)===tmp&&path.basename(real).startsWith('liangjing-bootstrap-'))fs.rmSync(real,{recursive:true});
}
