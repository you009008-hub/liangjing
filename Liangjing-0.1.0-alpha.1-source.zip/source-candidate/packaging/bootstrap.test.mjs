import {prepare} from './bootstrap.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const root=fs.mkdtempSync(path.join(os.tmpdir(),'liangjing-bootstrap-'));
const app=path.join(root,'runtime/harness/app');
const entry=path.join(app,'node_modules/@deepseek-ai/dsh/lib/bin.js');
fs.mkdirSync(app,{recursive:true});fs.writeFileSync(path.join(app,'package-lock.json'),'{}');
let calls=0;
const success=(command,args,options)=>{calls++;assert.equal(command,path.join(root,'runtime/harness/node.exe'));assert.equal(options.cwd,app);assert.deepEqual(Object.keys(options.env).filter(k=>k.toLowerCase()==='path'),['PATH']);assert.equal(options.env.PATH.split(path.delimiter)[0],path.join(root,'runtime/harness'));fs.mkdirSync(path.dirname(entry),{recursive:true});fs.writeFileSync(entry,'// mock');return {status:0};};
try{
 assert.equal(prepare(root,success),true);assert.equal(calls,1);
 assert.equal(prepare(root,success),true);assert.equal(calls,1);
 fs.writeFileSync(path.join(app,'package-lock.json'),'{"changed":true}');
 assert.equal(prepare(root,()=>({status:1})),false);
 assert.equal(fs.existsSync(path.join(app,'.liangjing-dependencies-ready')),false);
 assert.equal(prepare(root,success),true);assert.equal(calls,2);
 fs.unlinkSync(entry);fs.writeFileSync(path.join(app,'.liangjing-install.lock'),'other');
 assert.equal(prepare(root,success),false);assert.equal(calls,2);
 fs.unlinkSync(path.join(app,'.liangjing-install.lock'));
 assert.equal(prepare(root,()=>({status:0})),false);
 if(process.platform==='win32'){
  // Real Windows command resolution with no globally installed Node on PATH.
  fs.copyFileSync(process.execPath,path.join(root,'runtime/harness/node.exe'));
  const savedPath=process.env.PATH;
  process.env.PATH=path.join(process.env.SystemRoot,'System32');
  try {
   const missing=spawnSync(process.env.ComSpec,['/d','/s','/c','node --version'],{env:{...process.env},encoding:'utf8',windowsHide:true});
   assert.notEqual(missing.status,0,'fixture must not resolve a system Node');
   assert.equal(prepare(root,(command,args,options)=>{
    const child=spawnSync(process.env.ComSpec,['/d','/s','/c','node --version'],{...options,stdio:'pipe',encoding:'utf8'});
    assert.equal(child.status,0,child.stderr);assert.equal(child.stdout.trim(),process.version);
    return success(command,args,options);
   }),true);
  } finally {if(savedPath===undefined)delete process.env.PATH;else process.env.PATH=savedPath;}
 }
 console.log('BOOTSTRAP_TEST=PASS checks=8 (includes real Windows child node resolution)');
}finally{
 const real=fs.realpathSync(root), tmp=fs.realpathSync(os.tmpdir());
 if(path.dirname(real)===tmp&&path.basename(real).startsWith('liangjing-bootstrap-'))fs.rmSync(real,{recursive:true});
}
