import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

export function prepare(root, run=spawnSync){
 const app=path.join(root,'runtime/harness/app');
 const lock=path.join(app,'.liangjing-install.lock');
 const marker=path.join(app,'.liangjing-dependencies-ready');
 const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(app,'package-lock.json'))).digest('hex');
 if(fs.existsSync(marker)&&fs.readFileSync(marker,'utf8')===hash&&fs.existsSync(path.join(app,'node_modules/@deepseek-ai/dsh/lib/bin.js')))return true;
 let handle;
 try {handle=fs.openSync(lock,'wx');}
 catch {console.error('依赖安装正被其他启动进程占用；请等待完成。若上次安装中断，请确认无安装进程后移除 runtime/harness/app/.liangjing-install.lock 再试。');return false;}
 try {
  fs.writeSync(handle,String(process.pid));
  console.log('首次启动或内核依赖变化：正在联网安装 Harness，请勿关闭此窗口。');
  const result=run(path.join(root,'runtime/harness/node.exe'),[path.join(root,'runtime/harness/updater/npm/bin/npm-cli.js'),'ci','--prefix',app,'--registry=https://registry.npmjs.org','--no-audit','--no-fund'],{stdio:'inherit',windowsHide:true});
  if(result.status!==0||!fs.existsSync(path.join(app,'node_modules/@deepseek-ai/dsh/lib/bin.js'))){console.error('Harness 安装失败，请检查网络后重新启动。');return false;}
  fs.writeFileSync(marker,hash);
  return true;
 } finally {fs.closeSync(handle);fs.unlinkSync(lock);}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try {process.exitCode=prepare(path.dirname(fileURLToPath(import.meta.url)))?0:1;}
 catch {console.error('依赖准备失败。请确认安装目录可写，安装文件齐全。');process.exitCode=1;}
}
