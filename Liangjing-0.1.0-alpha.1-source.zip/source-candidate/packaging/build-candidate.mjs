import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const scripts=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(process.argv[2]), base=path.resolve(process.argv[3]??'work/release-build');
const payload=path.join(base,'payload');
fs.mkdirSync(payload,{recursive:true});
const copy=(src,dst)=>{fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);};
copy(path.join(root,'Godot_v4.7.1-stable_win64.exe'),path.join(payload,'Liangjing.exe'));
copy(path.join(base,'liangjing.pck'),path.join(payload,'liangjing.pck'));
copy(path.join(root,'runtime/harness/node.exe'),path.join(payload,'runtime/harness/node.exe'));
for(const name of ['LICENSE','LICENSE_STATUS.md','THIRD_PARTY_NOTICES.md'])copy(path.join(root,name),path.join(payload,name));
const runtimeFiles=['app/package.json','app/package-lock.json','app/runtime-version.json','app/blue-whale-harness.mjs','app/blue-whale-connection.mjs','app/blue-whale-interaction-guard.mjs','updater/update_harness.ps1','updater/resolve-release.cjs'];
for(const f of runtimeFiles)copy(path.join(root,'runtime/harness',f),path.join(payload,'runtime/harness',f));
const npmRoot=path.join(root,'runtime/harness/updater/npm');
const excluded=[];
function copyNpm(dir=''){
 for(const e of fs.readdirSync(path.join(npmRoot,dir),{withFileTypes:true})){
  const rel=path.posix.join(dir,e.name);
  if(e.isSymbolicLink())throw Error('Unexpected link '+rel);
  if(['.npmrc','.git','.cache','.env'].includes(e.name)||/\.(?:log|key|pem|pfx)$/i.test(e.name)){excluded.push(rel);continue;}
  if(e.isDirectory())copyNpm(rel);else copy(path.join(npmRoot,rel),path.join(payload,'runtime/harness/updater/npm',rel));
 }
}
copyNpm();
for(const f of fs.readdirSync(path.join(root,'licenses')))copy(path.join(root,'licenses',f),path.join(payload,'licenses',f));
copy(path.join(base,'inno/License.txt'),path.join(payload,'licenses/INNO-LICENSE.txt'));
copy(path.join(npmRoot,'LICENSE'),path.join(payload,'licenses/NPM-LICENSE.txt'));
copy(path.join(scripts,'launch.cmd'),path.join(payload,'启动梁鲸.cmd'));
copy(path.join(scripts,'bootstrap.mjs'),path.join(payload,'bootstrap.mjs'));
fs.writeFileSync(path.join(payload,'安装与使用.txt'),`梁鲸 0.1.0-alpha.1 · Windows x64\r\n\r\n使用“启动梁鲸”快捷方式。首次需要联网安装锁定版本的 Harness 依赖。\r\n进入模型中心配置自己的模型服务；本包不包含任何用户 Key、聊天或知识库。\r\n当前为 Alpha：顺序工作流可执行，分支/循环尚不执行。模型调用可能计费。\r\n用户数据默认在系统文档目录的“梁鲸灵魂仓库”；升级/卸载不会删除该目录。\r\n代码 GPL-3.0-only，允许商用，分发时遵守对应源码等义务。\r\n对应源码应与本安装包作为同一版本提供。第三方软件保留各自许可，见 licenses。\r\n安装包未做发布者代码签名，不宣称已签名。\r\n`);
const entries=[];
function inventory(dir=''){for(const e of fs.readdirSync(path.join(payload,dir),{withFileTypes:true})){const rel=path.posix.join(dir,e.name);if(e.isDirectory())inventory(rel);else{const b=fs.readFileSync(path.join(payload,rel));entries.push({file:rel,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')});}}}
inventory();
fs.writeFileSync(path.join(base,'payload-manifest.json'),JSON.stringify({version:'0.1.0-alpha.1',harness:'first-run npm ci, no installed app node_modules bundled',files:entries,excludedNpmFiles:excluded},null,2));
console.log(JSON.stringify({files:entries.length,bytes:entries.reduce((n,f)=>n+f.bytes,0),excluded:excluded.length}));
