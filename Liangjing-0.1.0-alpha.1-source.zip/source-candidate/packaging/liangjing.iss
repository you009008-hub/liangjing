﻿#define AppVersion "0.1.0-alpha.1"
[Setup]
AppId={{C607F389-39B2-4DBB-9387-15FD064F4C2A}
AppName=梁鲸
AppVersion={#AppVersion}
AppVerName=梁鲸 {#AppVersion}
AppPublisher=梁鲸项目
DefaultDirName={code:InstallDir}
DefaultGroupName=梁鲸
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=output
OutputBaseFilename=Liangjing-0.1.0-alpha.1-windows-x64-setup
Compression=lzma2/normal
SolidCompression=yes
WizardStyle=modern
LicenseFile=payload\LICENSE
InfoAfterFile=payload\安装与使用.txt
UninstallDisplayIcon={app}\Liangjing.exe
Uninstallable=not PortableMode
CreateUninstallRegKey=not PortableMode
CloseApplications=no
RestartApplications=no
SetupLogging=yes

[Languages]
Name: "chinesesimplified"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"

[Tasks]
Name: desktopicon; Description: "Create a desktop shortcut"; Flags: unchecked; Check: not PortableMode

[Files]
Source: "payload\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\梁鲸"; Filename: "{app}\启动梁鲸.cmd"; WorkingDir: "{app}"; IconFilename: "{app}\Liangjing.exe"; Check: not PortableMode
Name: "{autodesktop}\梁鲸"; Filename: "{app}\启动梁鲸.cmd"; WorkingDir: "{app}"; IconFilename: "{app}\Liangjing.exe"; Tasks: desktopicon; Check: not PortableMode
Name: "{group}\Uninstall 梁鲸"; Filename: "{uninstallexe}"; Check: not PortableMode

[Code]
function PortableMode: Boolean;
begin
  Result := ExpandConstant('{param:PORTABLE|0}') = '1';
end;

function InstallDir(Param: String): String;
begin
  Result := ExpandConstant('{param:DIR|}');
  if Result = '' then Result := ExpandConstant('{localappdata}\Programs\Liangjing');
end;
