# Windows Alpha 安装包构建

此目录记录 0.1.0-alpha.1 候选包的构建输入。公开发布前仍检查项目发布审查状态；构建成功不等于可公开发布。

工具：项目指定 Godot、Node；Inno Setup 7.1.0 x64（官方 jrsoftware/issrc release，SHA256 0362a383ed217d4c4239b5933866dd96d3eb2102737da92f80f6057a4b40df2f，签名 Pyrsys B.V.）。可以使用官方 /PORTABLE=1 安装到独立构建目录，不改文件关联。

构建时在独立 build 目录准备 inno/License.txt、licenses 与输出 PCK；项目根应有正式引擎、runtime/harness/node.exe 和 updater/npm。不得复制用户数据或 app/node_modules 到本方案安装包。

1. Godot 使用 --headless --path <源码根> --export-pack "Windows Desktop" <build>/liangjing.pck。
2. 从当前引擎 Engine.get_license_text/get_copyright_info/get_license_info 获取版权记录；本源码 licenses 已包含当前基线记录。Node 的完整 LICENSE 来自 nodejs/node v24.19.0；升级二进制时同步这些记录。
3. 运行 node packaging/build-candidate.mjs <源码根> <build>。
4. 将 packaging/liangjing.iss 复制到 <build>/liangjing.iss，用 ISCC 编译。输出位于 <build>/output。
5. 运行 node packaging/bootstrap.test.mjs。用 /PORTABLE=1 /DIR=<独立测试目录> 验证解包，再核对 payload-manifest.json 中每个 SHA256。

源码候选归档必须包含源码清单、这组构建脚本、原装资产及其派生资源、LICENSE、第三方声明；不包含私人配置、引擎/Node 二进制、日志、缓存或 node_modules。引擎和 Node 由官方发行版单独准备。

首次启动通过 bootstrap.mjs 运行锁定版本的 npm ci，成功后写入锁文件哈希标记。失败不启动主程序、不写成功标记；并发安装被锁文件阻止。该包需要首次联网，未捆绑已安装的 Harness 依赖，不是完全离线版。

安装目录默认当前用户 LocalAppData/Programs/梁鲸对应的 Liangjing 子目录；快捷方式使用 launch.cmd。无自动启动和后台计划任务。卸载只删除安装器登记的文件，不递归删除用户文档、聊天、知识库或新增文件。普通用户安装/卸载界面仍需真实账号环境验收；沙箱仅实测便携安装。