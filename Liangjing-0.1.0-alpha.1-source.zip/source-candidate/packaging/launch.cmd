@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
"runtime\harness\node.exe" "bootstrap.mjs"
if errorlevel 1 goto failed
start "" "Liangjing.exe" --main-pack "%~dp0liangjing.pck"
exit /b 0
:failed
pause
exit /b 1