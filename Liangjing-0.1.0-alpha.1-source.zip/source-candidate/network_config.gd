# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：网络配置改为原子写。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 梁鲸网络配置存储器。
#
# 网络配置与模型 Key 分开保存：这里仅记录直连/系统代理/自定义代理，
# 不读取或修改 v2rayN 等第三方程序的配置。系统代理会在每次启动时重新检测。
class_name NetworkConfigStore
extends RefCounted

const AtomicFile = preload("res://atomic_file.gd")

const CONFIG_VERSION := 1
const DEFAULT_NO_PROXY := "localhost,127.0.0.1,::1"

var config_directory := ""
var config_path := ""
var current := {}

func initialize(soul_root: String) -> Dictionary:
	config_directory = soul_root.path_join("配置")
	config_path = config_directory.path_join("网络配置.json")
	var error := DirAccess.make_dir_recursive_absolute(config_directory)
	if error != OK and error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法创建网络配置目录。"}
	current = load_config()
	if not write_config():
		return {"ok": false, "error": "无法写入网络配置。"}
	return {"ok": true, "config": current.duplicate(true), "resolved": resolve_proxy(current)}

func default_config() -> Dictionary:
	return {
		"version": CONFIG_VERSION,
		"mode": "system",
		"proxy_url": "",
		"no_proxy": DEFAULT_NO_PROXY
	}

func load_config() -> Dictionary:
	var parsed = null
	if FileAccess.file_exists(config_path):
		parsed = JSON.parse_string(FileAccess.get_file_as_string(config_path))
	if not parsed is Dictionary:
		parsed = default_config()
	var defaults := default_config()
	for field in defaults:
		if not parsed.has(field):
			parsed[field] = defaults[field]
	parsed["version"] = CONFIG_VERSION
	var mode := str(parsed.get("mode", "system")).strip_edges().to_lower()
	parsed["mode"] = mode if mode in ["direct", "system", "custom"] else "system"
	parsed["proxy_url"] = normalize_proxy_url(str(parsed.get("proxy_url", "")))
	parsed["no_proxy"] = normalize_no_proxy(str(parsed.get("no_proxy", DEFAULT_NO_PROXY)))
	current = parsed
	return current.duplicate(true)

func save_config(settings: Dictionary) -> Dictionary:
	var mode := str(settings.get("mode", "system")).strip_edges().to_lower()
	if not mode in ["direct", "system", "custom"]:
		return {"ok": false, "message": "请选择有效的联网方式。"}
	var proxy_url := normalize_proxy_url(str(settings.get("proxy_url", "")))
	if mode == "custom" and proxy_url.is_empty():
		return {"ok": false, "message": "请填写 http:// 或 https:// 开头的代理地址。"}
	var no_proxy := normalize_no_proxy(str(settings.get("no_proxy", DEFAULT_NO_PROXY)))
	current = {
		"version": CONFIG_VERSION,
		"mode": mode,
		"proxy_url": proxy_url,
		"no_proxy": no_proxy
	}
	if not write_config():
		return {"ok": false, "message": "网络配置保存失败。"}
	var resolved := resolve_proxy(current)
	return {
		"ok": true,
		"message": str(resolved.get("detail", "网络配置已保存。")),
		"config": current.duplicate(true),
		"resolved": resolved
	}

func resolve_proxy(settings: Dictionary = {}) -> Dictionary:
	var source_settings := settings if not settings.is_empty() else current
	if source_settings.is_empty():
		source_settings = load_config()
	var mode := str(source_settings.get("mode", "system"))
	var no_proxy := normalize_no_proxy(str(source_settings.get("no_proxy", DEFAULT_NO_PROXY)))
	if mode == "direct":
		return resolved_value(false, "", mode, "直连", no_proxy, "已使用直连；不会读取系统代理。")
	if mode == "custom":
		var custom_url := normalize_proxy_url(str(source_settings.get("proxy_url", "")))
		if custom_url.is_empty():
			return resolved_value(false, "", mode, "自定义代理", no_proxy, "自定义代理地址无效。")
		return resolved_value(true, custom_url, mode, "自定义代理", no_proxy, "已使用自定义代理。")
	var system_value := detect_system_proxy()
	if not bool(system_value.get("enabled", false)):
		return resolved_value(false, "", mode, "Windows 系统代理", no_proxy, str(system_value.get("detail", "系统代理未启用。")))
	return resolved_value(true, str(system_value.get("url", "")), mode, "Windows 系统代理", no_proxy, str(system_value.get("detail", "已读取 Windows 系统代理。")))

func resolved_value(enabled: bool, url: String, mode: String, source: String, no_proxy: String, detail: String) -> Dictionary:
	var host := ""
	var port := -1
	if enabled:
		var parts := proxy_host_port(url)
		host = str(parts.get("host", ""))
		port = int(parts.get("port", -1))
	return {
		"enabled": enabled and not host.is_empty() and port > 0,
		"url": url,
		"host": host,
		"port": port,
		"mode": mode,
		"source": source,
		"no_proxy": no_proxy,
		"detail": detail
	}

# [DSH] 把已解析的代理设置套到一次 HTTPRequest 上。
#
# 为什么要有这个共用函数：聊天走 HTTPClient（自己 apply_proxy），模型列表与视觉走
# main.gd 的 configure_http_request_proxy，而**换装生成自己 new 了一个 HTTPRequest，
# 从头到尾没设过代理**——于是"开了代理也连不上"，而且症状只是"生成失败"，
# 看不出是代理没生效。抽成一处，谁再新增网络调用都得走它。
# 返回值可直接断言（Godot 没有代理读取接口，只能靠返回值和真实流量验证）。
static func apply_to_request(request: HTTPRequest, resolved: Dictionary) -> Dictionary:
	if request == null:
		return {"applied": false, "host": "", "port": -1, "reason": "没有请求对象"}
	var host := str(resolved.get("host", ""))
	var port := int(resolved.get("port", -1))
	if bool(resolved.get("enabled", false)) and not host.is_empty() and port > 0:
		request.set_http_proxy(host, port)
		request.set_https_proxy(host, port)
		return {"applied": true, "host": host, "port": port, "reason": "已套用代理"}
	# 直连时必须显式清空：请求对象是复用的，上一次的代理会留在里面。
	request.set_http_proxy("", -1)
	request.set_https_proxy("", -1)
	return {"applied": false, "host": "", "port": -1, "reason": "直连（已清空代理）"}

func detect_system_proxy() -> Dictionary:
	# 命令行环境变量优先，方便免安装版被脚本或企业桌面统一启动。
	for variable_name in ["HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"]:
		var environment_value := normalize_proxy_url(OS.get_environment(variable_name))
		if not environment_value.is_empty():
			return {"enabled": true, "url": environment_value, "detail": "已读取环境变量 %s。" % variable_name}
	if OS.get_name() != "Windows":
		return {"enabled": false, "url": "", "detail": "当前系统没有检测到 HTTP/HTTPS 代理。"}
	var enable_output: Array = []
	var enable_code := OS.execute(
		"reg.exe",
		PackedStringArray(["query", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "/v", "ProxyEnable"]),
		enable_output,
		true
	)
	var enable_text := "\n".join(enable_output)
	if enable_code != 0 or (not enable_text.contains("0x1") and not enable_text.contains("    1")):
		return {"enabled": false, "url": "", "detail": "Windows 系统代理当前未启用。"}
	var server_output: Array = []
	var server_code := OS.execute(
		"reg.exe",
		PackedStringArray(["query", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "/v", "ProxyServer"]),
		server_output,
		true
	)
	if server_code != 0:
		return {"enabled": false, "url": "", "detail": "Windows 已启用代理，但没有读到代理地址。"}
	var raw_server := registry_value("\n".join(server_output), "ProxyServer")
	var selected_server := select_proxy_server(raw_server)
	var normalized := normalize_proxy_url(selected_server)
	if normalized.is_empty():
		return {"enabled": false, "url": "", "detail": "Windows 系统代理地址格式不受支持。"}
	return {"enabled": true, "url": normalized, "detail": "已读取 Windows 系统代理：%s" % display_proxy_url(normalized)}

func registry_value(output: String, value_name: String) -> String:
	for raw_line in output.replace("\r", "").split("\n"):
		var line := str(raw_line).strip_edges()
		if not line.begins_with(value_name):
			continue
		var marker := "REG_SZ"
		var marker_index := line.find(marker)
		if marker_index >= 0:
			return line.substr(marker_index + marker.length()).strip_edges()
	return ""

func select_proxy_server(raw_value: String) -> String:
	var value := raw_value.strip_edges()
	if not value.contains(";") and not value.contains("="):
		return value
	var candidates := {}
	for raw_part in value.split(";"):
		var part := str(raw_part).strip_edges()
		var separator := part.find("=")
		if separator <= 0:
			continue
		candidates[part.substr(0, separator).strip_edges().to_lower()] = part.substr(separator + 1).strip_edges()
	for protocol in ["https", "http"]:
		if candidates.has(protocol):
			return str(candidates[protocol])
	return ""

func normalize_proxy_url(raw_value: String) -> String:
	var value := raw_value.strip_edges().trim_suffix("/")
	if value.is_empty() or value.contains("\n") or value.contains("\r"):
		return ""
	if not value.contains("://"):
		value = "http://" + value
	if not value.begins_with("http://") and not value.begins_with("https://"):
		return ""
	var parsed := proxy_host_port(value)
	if str(parsed.get("host", "")).is_empty() or int(parsed.get("port", -1)) <= 0:
		return ""
	return value

func proxy_host_port(proxy_url: String) -> Dictionary:
	var authority := proxy_url.trim_prefix("http://").trim_prefix("https://").get_slice("/", 0)
	if authority.contains("@"):
		authority = authority.get_slice("@", 1)
	var separator := authority.rfind(":")
	if separator <= 0:
		return {"host": "", "port": -1}
	var host := authority.substr(0, separator).trim_prefix("[").trim_suffix("]")
	var port := int(authority.substr(separator + 1))
	return {"host": host, "port": port}

func normalize_no_proxy(raw_value: String) -> String:
	var values: Array[String] = []
	for raw_part in raw_value.replace(";", ",").split(","):
		var part := str(raw_part).strip_edges()
		if not part.is_empty() and not part.contains("\n") and not values.has(part):
			values.append(part)
	for required in ["localhost", "127.0.0.1", "::1"]:
		if not values.has(required):
			values.append(required)
	return ",".join(values)

func display_proxy_url(proxy_url: String) -> String:
	# 界面状态不展示代理 URL 中可能携带的用户名或密码。
	var parsed := proxy_host_port(proxy_url)
	return "%s:%d" % [str(parsed.get("host", "")), int(parsed.get("port", -1))]

func write_config() -> bool:
	# 原子写：网络配置被强杀写坏后会被静默回落成“跟随系统代理”，属于难以排查的故障。
	return AtomicFile.write_text(config_path, JSON.stringify(current, "  ", false))
