# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：换装后仍启用分层动态；新增四肢摆动下发；闭眼参数下发。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
extends Node2D

# A reversible visible-surface rig, not an occlusion-complete clothing model.
const MotionProfile = preload("res://motion_profile.gd")
const PARTS := ["hair_left", "hair_right", "leg_left", "leg_right", "skirt", "torso", "arm_left", "arm_right", "head"]
var parts: Dictionary = {}
var materials: Array[ShaderMaterial] = []
# 与 materials 一一对应的部件 id，用来判断哪一份材质属于头部。
var material_ids: Array[String] = []
var phase := 0.0
var ready_for_use := false
# 原装纹理与闭眼贴图单独留住：换装时只替换 appearance_texture，
# 闭眼合成是否启用由 is_original_art 决定。
var original_texture: Texture2D
var closed_eye_texture: Texture2D
var appearance_texture: Texture2D
var is_original_art := true
var appearance_supported := false
var profile: Dictionary = MotionProfile.defaults()

func setup(original: Texture2D, closed: Texture2D, resource_root := "res://assets/layered_character", shader_path := "res://layered_character.gdshader") -> bool:
	if original == null or closed == null or original.get_size() != Vector2(1024,1536):
		return false
	if not ResourceLoader.exists(shader_path):
		return false
	var shader := load(shader_path) as Shader
	if shader == null:
		return false
	# Validate the complete bundle before attaching any layers.
	var meshes: Array[ArrayMesh] = []
	for id in PARTS:
		var path: String = resource_root.path_join(id + ".res")
		if not ResourceLoader.exists(path):
			return false
		var mesh := load(path) as ArrayMesh
		if mesh == null or mesh.get_surface_count() != 1:
			return false
		meshes.append(mesh)
	original_texture = original
	closed_eye_texture = closed
	appearance_texture = original
	for index in PARTS.size():
		var id: String = PARTS[index]
		var part := MeshInstance2D.new()
		part.name = id
		part.mesh = meshes[index]
		part.texture = appearance_texture
		var material := ShaderMaterial.new()
		material.shader = shader
		material.set_shader_parameter("closed_eyes", closed_eye_texture)
		material.set_shader_parameter("face_layer", id == "head")
		part.material = material
		add_child(part)
		materials.append(material)
		material_ids.append(id)
		parts[id] = part
	ready_for_use = true
	appearance_supported = true
	set_motion_profile(profile)
	return true

# 接受一张可用于分层网格的外观纹理。
#
# 网格是一张覆盖整块 1024×1536 画布的 UV 位移场，位移只由 UV 决定，
# 与纹理内容无关；而换装产物经 normalize_image() 后同样是 1024×1536、
# 人物按包围盒缩放并对齐底部，可沿用网格；头部、肩线与眼睛仍需按形象校准。
# 反过来，尺寸不符的纹理（例如未归一化的原始生成图）必须拒绝，否则会被拉伸错位。
func set_appearance(texture: Texture2D) -> bool:
	if not ready_for_use:
		appearance_supported = false
		return false
	if texture == null or texture.get_size() != Vector2(1024, 1536):
		appearance_supported = false
		visible = false
		return false
	appearance_supported = true
	appearance_texture = texture
	is_original_art = texture == original_texture
	# 闭眼贴图是按原装五官位置绘制的；换成生成形象后五官位置未知，
	# 继续合成会把闭眼画到错误的地方，因此只在原装形象上启用。
	for id in parts:
		var part := parts[id] as MeshInstance2D
		part.texture = appearance_texture
	set_motion_profile(profile)
	return true

func set_motion_profile(value: Dictionary) -> void:
	profile = MotionProfile.sanitize(value)
	for material in materials:
		material.set_shader_parameter("appearance_art", appearance_texture)
		material.set_shader_parameter("head_y", profile["head_y"])
		material.set_shader_parameter("shoulder_y", profile["shoulder_y"])
		material.set_shader_parameter("feet_y", profile["feet_y"])
		material.set_shader_parameter("breath_strength", profile["breath"])
		material.set_shader_parameter("hair_strength", profile["hair"])
		material.set_shader_parameter("arm_strength", profile["arm_swing"])
		material.set_shader_parameter("leg_strength", profile["leg_swing"])
		# UV masks, not fixed mesh ownership, define the eyes after calibration.
		material.set_shader_parameter("face_layer", is_original_art or profile["eyes_enabled"] or profile["blink_enabled"])
		material.set_shader_parameter("original_art", is_original_art)
		material.set_shader_parameter("custom_gaze", not is_original_art and profile["eyes_enabled"])
		material.set_shader_parameter("custom_blink", not is_original_art and profile["blink_enabled"])
		# 合成眨眼的观感参数：闭眼残余高度与边缘柔度（推导见着色器内注释）。
		material.set_shader_parameter("lid_closure", float(profile.get("lid_closure", 0.88)))
		material.set_shader_parameter("lid_softness", float(profile.get("lid_softness", 0.30)))
		material.set_shader_parameter("eye_left", Vector2(0.444, 0.182) if is_original_art else Vector2(profile["eye_left_x"], profile["eye_left_y"]))
		material.set_shader_parameter("eye_right", Vector2(0.544, 0.182) if is_original_art else Vector2(profile["eye_right_x"], profile["eye_right_y"]))
		material.set_shader_parameter("eye_radius", Vector2(0.043, 0.030) if is_original_art else Vector2(profile["eye_radius_x"], profile["eye_radius_y"]))
	# 换装/换姿态配置会重建整套参数，情绪必须跟着重发，否则表情会静默丢失。
	_push_emotion()
	pose(phase)

func uses_original_art() -> bool:
	return is_original_art

# [DSH] 情绪：0 平静 / 1 专注（等待授权：压眉微眯）/ 2 沮丧（失败：眉眼下垂、略低头）。
# 只改面部采样 UV，不动几何——安全变换，不可能产生网格撕裂或空洞。
# 切换时由 _emotion_weight 淡入，避免表情瞬间跳变。
const EMOTION_CALM := 0
const EMOTION_FOCUS := 1
const EMOTION_DOWN := 2
const EMOTION_FADE_SECONDS := 0.28
var _emotion := EMOTION_CALM
var _emotion_weight := 0.0
var _emotion_target_weight := 0.0

func set_emotion(value: int, immediate := false) -> void:
	var clamped := clampi(value, EMOTION_CALM, EMOTION_DOWN)
	_emotion = clamped
	_emotion_target_weight = 0.0 if clamped == EMOTION_CALM else 1.0
	if immediate:
		_emotion_weight = _emotion_target_weight
		_push_emotion()
	else:
		# 情绪种类立刻切换，强度由 advance() 淡入；这样从"专注"转到"沮丧"
		# 不会先退回平静再进沮丧。
		_push_emotion()

func current_emotion() -> int:
	return _emotion

func current_emotion_weight() -> float:
	return _emotion_weight

func _push_emotion() -> void:
	for material in materials:
		material.set_shader_parameter("emotion", _emotion)
		material.set_shader_parameter("emotion_weight", _emotion_weight)

func _advance_emotion(delta: float) -> void:
	if is_equal_approx(_emotion_weight, _emotion_target_weight):
		return
	var step := clampf(delta, 0.0, 0.1) / maxf(0.01, EMOTION_FADE_SECONDS)
	_emotion_weight = move_toward(_emotion_weight, _emotion_target_weight, step)
	for material in materials:
		material.set_shader_parameter("emotion_weight", _emotion_weight)

func advance(delta: float, animate: bool, gaze: Vector2, blink: float) -> void:
	# 情绪淡入与静止/移动无关：站着不动也会等待授权、也可能失败。
	_advance_emotion(delta)
	var moving: bool = animate and profile["enabled"] and float(profile["speed"]) > 0.0
	if moving:
		# Common period of the shader's 1.7 and 1.15 frequencies: no wrap jump.
		var step := clampf(delta, 0.0, 0.1) if is_finite(delta) else 0.0
		phase = fposmod(phase + step * float(profile["speed"]), TAU * 20.0)
	pose(phase, gaze if moving else Vector2.ZERO, blink if moving else 0.0, 1.0 if moving else 0.0)

func pose(time: float, gaze := Vector2.ZERO, blink := 0.0, strength := 1.0) -> void:
	var moving: bool = profile["enabled"] and float(profile["speed"]) > 0.0 and appearance_supported
	var safe_gaze := Vector2(clampf(gaze.x, -1.0, 1.0) if is_finite(gaze.x) else 0.0, clampf(gaze.y, -1.0, 1.0) if is_finite(gaze.y) else 0.0)
	var safe_strength := clampf(strength, 0.0, 1.0) if is_finite(strength) and moving else 0.0
	var safe_blink := clampf(blink, 0.0, 1.0) if is_finite(blink) and safe_strength > 0.0 else 0.0
	for material in materials:
		material.set_shader_parameter("phase", fposmod(time, TAU * 20.0) if is_finite(time) else 0.0)
		material.set_shader_parameter("gaze", safe_gaze * float(profile["gaze"]) if safe_strength > 0.0 else Vector2.ZERO)
		material.set_shader_parameter("blink", safe_blink)
		material.set_shader_parameter("motion_strength", safe_strength)
