# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：模型配置与 API Key 改为原子写；不再写死模型候选清单。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 多模型配置存储器。
# 同时维护对话模型与视觉模型配置；API Key 经 Windows DPAPI 加密后才写入本地文件。
# 文件名沿用历史命名，但接口并不限定只能使用 DeepSeek。
class_name ModelConfigStore
extends RefCounted

const AtomicFile = preload("res://atomic_file.gd")

const DEFAULT_BASE_URL := "https://api.deepseek.com"
const DEFAULT_MODEL := "deepseek-v4-flash"
const PROFILE_ROLES := ["chat", "vision"]

var config_directory := ""
var config_path := ""
var legacy_secret_path := ""
var current := {}

func initialize(soul_root: String) -> Dictionary:
	config_directory = soul_root.path_join("配置")
	config_path = config_directory.path_join("模型配置.json")
	legacy_secret_path = config_directory.path_join("deepseek.key")
	var error := DirAccess.make_dir_recursive_absolute(config_directory)
	if error != OK and error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法创建配置目录。"}
	current = load_config()
	migrate_legacy_key()
	refresh_key_flags()
	if not write_config():
		return {"ok": false, "error": "无法写入模型配置。"}
	return {"ok": true, "config": current.duplicate(true), "has_key": has_api_key("chat")}

func default_profile(role: String) -> Dictionary:
	if role == "chat":
		return {
			"provider": "deepseek",
			"base_url": DEFAULT_BASE_URL,
			"model": DEFAULT_MODEL,
			"thinking": false,
			"reasoning_effort": "off",
			"models": ["deepseek-v4-flash", "deepseek-v4-pro"],
			"key_stored": false
		}
	return {
		"provider": "openai_compatible",
		"base_url": "",
		"model": "",
		"thinking": false,
		"reasoning_effort": "off",
		"models": [],
		"key_stored": false
	}

func load_config() -> Dictionary:
	var parsed = null
	if FileAccess.file_exists(config_path):
		parsed = JSON.parse_string(FileAccess.get_file_as_string(config_path))
	if not parsed is Dictionary:
		parsed = {}
	if not parsed.has("profiles"):
		var legacy_chat := default_profile("chat")
		for field in ["provider", "base_url", "model", "thinking", "reasoning_effort", "models", "key_stored"]:
			if parsed.has(field):
				legacy_chat[field] = parsed[field]
		parsed = {
			"version": 2,
			"key_protection": "device-bound-aes-v1",
			"profiles": {
				"chat": legacy_chat,
				"vision": default_profile("vision")
			}
		}
	parsed["version"] = 2
	parsed["key_protection"] = "device-bound-aes-v1"
	var orchestration: Dictionary = parsed.get("orchestration", {})
	if not orchestration.has("mode"):
		orchestration["mode"] = "vision_then_chat"
	# 默认沿用旧版本的处理方式：先用独立视觉模型读取图片，再把文字交给 Harness。
	# 用户可在对话窗口关闭此项，让原图直接进入支持视觉的 Harness 模型。
	if not orchestration.has("external_vision_enabled"):
		orchestration["external_vision_enabled"] = true
	parsed["orchestration"] = orchestration
	var profiles: Dictionary = parsed.get("profiles", {})
	for role in PROFILE_ROLES:
		var defaults := default_profile(role)
		var profile: Dictionary = profiles.get(role, {})
		for field in defaults:
			if not profile.has(field):
				profile[field] = defaults[field]
		profiles[role] = profile
	parsed["profiles"] = profiles
	return parsed

func get_profile(role: String) -> Dictionary:
	var safe_role := normalize_role(role)
	var profiles: Dictionary = current.get("profiles", {})
	return Dictionary(profiles.get(safe_role, default_profile(safe_role))).duplicate(true)

func save_profile(role: String, api_key: String, base_url: String, model: String, provider: String, thinking: bool, reasoning_effort := "") -> Dictionary:
	var safe_role := normalize_role(role)
	var normalized_url := base_url.strip_edges().trim_suffix("/")
	if normalized_url.is_empty():
		return {"ok": false, "message": "请填写接口地址。"}
	if not is_safe_base_url(normalized_url):
		return {"ok": false, "message": "接口地址必须使用 HTTPS；本机地址可使用 HTTP。"}
	var clean_model := model.strip_edges()
	if clean_model.is_empty():
		return {"ok": false, "message": "请填写或读取模型 ID。"}
	var clean_key := api_key.strip_edges()
	if not clean_key.is_empty() and not save_api_key(clean_key, safe_role):
		return {"ok": false, "message": "API Key 加密保存失败。"}
	var profiles: Dictionary = current.get("profiles", {})
	var previous: Dictionary = profiles.get(safe_role, default_profile(safe_role))
	var safe_effort := normalize_reasoning_effort(reasoning_effort if not str(reasoning_effort).is_empty() else ("high" if thinking else "off"))
	var model_candidates: Array = previous.get("models", []) if previous.get("models", []) is Array else []
	if not model_candidates.has(clean_model):
		model_candidates.append(clean_model)
	profiles[safe_role] = {
		"provider": provider if provider in ["deepseek", "openai_compatible"] else "openai_compatible",
		"base_url": normalized_url,
		"model": clean_model,
		"thinking": safe_effort != "off" if safe_role == "chat" else false,
		"reasoning_effort": safe_effort if safe_role == "chat" else "off",
		"models": model_candidates,
		"key_stored": has_api_key(safe_role)
	}
	current["profiles"] = profiles
	if not write_config():
		return {"ok": false, "message": "模型配置保存失败。"}
	return {"ok": true, "message": "%s配置已保存在本机。" % role_display_name(safe_role)}

func get_settings() -> Dictionary:
	return get_profile("chat")

func save_settings(api_key: String, base_url: String, model: String, thinking: bool) -> Dictionary:
	return save_profile("chat", api_key, base_url, model, "deepseek", thinking)

func get_model_candidates(role: String = "chat") -> Array[String]:
	var profile := get_profile(role)
	var result: Array[String] = []
	var source = profile.get("models", [])
	if source is Array:
		for value in source:
			var model_id := str(value).strip_edges()
			if not model_id.is_empty() and not result.has(model_id):
				result.append(model_id)
	var configured := str(profile.get("model", "")).strip_edges()
	if not configured.is_empty() and not result.has(configured):
		result.append(configured)
	if role == "chat" and str(profile.get("provider", "")) == "deepseek":
		# 只补一个稳定的兜底项：具体型号随官方发布变化，把一份写死的清单塞进下拉框
		# 反而会在新模型上线后误导用户，因此优先使用用户在“读取模型”里拿到的真实列表。
		if not result.has(DEFAULT_MODEL):
			result.append(DEFAULT_MODEL)
	return result

func save_model_candidates(role: String, model_ids: Array[String]) -> bool:
	var safe_role := normalize_role(role)
	var profiles: Dictionary = current.get("profiles", {})
	var profile: Dictionary = profiles.get(safe_role, default_profile(safe_role))
	var normalized: Array[String] = []
	for value in model_ids:
		var model_id := str(value).strip_edges()
		if not model_id.is_empty() and not normalized.has(model_id) and normalized.size() < 500:
			normalized.append(model_id)
	profile["models"] = normalized
	profiles[safe_role] = profile
	current["profiles"] = profiles
	return write_config()

func save_chat_runtime_selection(model: String, reasoning_effort: String) -> bool:
	var clean_model := model.strip_edges()
	if clean_model.is_empty():
		return false
	var profiles: Dictionary = current.get("profiles", {})
	var profile: Dictionary = profiles.get("chat", default_profile("chat"))
	var effort := normalize_reasoning_effort(reasoning_effort)
	profile["model"] = clean_model
	profile["reasoning_effort"] = effort
	profile["thinking"] = effort != "off"
	var candidates: Array = profile.get("models", []) if profile.get("models", []) is Array else []
	if not candidates.has(clean_model):
		candidates.append(clean_model)
	profile["models"] = candidates
	profiles["chat"] = profile
	current["profiles"] = profiles
	return write_config()

func normalize_reasoning_effort(value: String) -> String:
	var effort := value.strip_edges().to_lower()
	return effort if effort in ["off", "low", "high", "max"] else "off"

func get_orchestration() -> Dictionary:
	return Dictionary(current.get("orchestration", {
		"mode": "vision_then_chat",
		"external_vision_enabled": true
	})).duplicate(true)

func save_orchestration(mode: String) -> bool:
	var safe_mode := mode if mode in ["vision_then_chat", "vision_direct", "auto"] else "vision_then_chat"
	var orchestration := get_orchestration()
	orchestration["mode"] = safe_mode
	current["orchestration"] = orchestration
	return write_config()

func is_external_vision_enabled() -> bool:
	return bool(get_orchestration().get("external_vision_enabled", true))

func save_external_vision_enabled(enabled: bool) -> bool:
	var orchestration := get_orchestration()
	orchestration["external_vision_enabled"] = enabled
	current["orchestration"] = orchestration
	return write_config()

func has_api_key(role: String = "chat") -> bool:
	return FileAccess.file_exists(secret_path_for(normalize_role(role)))

func save_api_key(api_key: String, role: String = "chat") -> bool:
	var safe_role := normalize_role(role)
	var path := secret_path_for(safe_role)
	var previous_key := load_api_key(safe_role)
	# 关键：open_encrypted(WRITE) 会先清空旧密钥文件再写。如果这时进程被杀，
	# 用户会永久失去已保存的 Key。因此先写 .tmp 并把旧文件一直留到最后，
	# 写入与回读校验都由原子写工具负责。
	if not AtomicFile.write_encrypted(path, api_key, device_key()):
		# 写入失败时必须把旧 Key 恢复回去，不能留下一个解不开的文件。
		if not previous_key.is_empty() and load_api_key(safe_role) != previous_key:
			AtomicFile.write_encrypted(path, previous_key, device_key())
		return false
	# 删除旧 Key 后重新填写时，必须确认刚写入的内容能被同一设备密钥立即读回。
	# 这样不会因为残留的旧加密文件或写入失败而在测试时继续使用旧值。
	return load_api_key(safe_role) == api_key

func load_api_key(role: String = "chat") -> String:
	var path := secret_path_for(normalize_role(role))
	return load_api_key_from_path(path)

# 读取用户选中的梁鲸加密 Key 文件。该格式与模型中心保存的 chat_model.key /
# vision_model.key 完全一致；设备绑定文件只能在生成它的 Windows 用户与电脑上解密。
func load_api_key_from_path(path: String) -> String:
	if not FileAccess.file_exists(path):
		return ""
	var file := FileAccess.open_encrypted(path, FileAccess.READ, device_key())
	if file == null:
		return ""
	var api_key := file.get_as_text().strip_edges()
	file.close()
	return api_key

func secret_path_for(role: String) -> String:
	return config_directory.path_join("%s_model.key" % role)

func migrate_legacy_key() -> void:
	if not FileAccess.file_exists(legacy_secret_path) or has_api_key("chat"):
		return
	var legacy := FileAccess.open_encrypted(legacy_secret_path, FileAccess.READ, device_key())
	if legacy == null:
		return
	var key := legacy.get_as_text().strip_edges()
	legacy.close()
	if not key.is_empty():
		save_api_key(key, "chat")

func refresh_key_flags() -> void:
	var profiles: Dictionary = current.get("profiles", {})
	for role in PROFILE_ROLES:
		var profile: Dictionary = profiles.get(role, default_profile(role))
		profile["key_stored"] = has_api_key(role)
		profiles[role] = profile
	current["profiles"] = profiles

func is_safe_base_url(url: String) -> bool:
	return url.begins_with("https://") or url.begins_with("http://127.0.0.1") or url.begins_with("http://localhost")

func normalize_role(role: String) -> String:
	return role if role in PROFILE_ROLES else "chat"

func role_display_name(role: String) -> String:
	return "视觉模型" if role == "vision" else "对话模型"

func write_config() -> bool:
	# 原子写：强杀/崩溃时不会留下半截 JSON，避免用户配置被静默回落成默认值。
	return AtomicFile.write_text(config_path, JSON.stringify(current, "  ", false))

func device_key() -> PackedByteArray:
	# 早期版本把 Godot 的 user:// 目录写入设备指纹。产品更名会改变该目录名，
	# 若直接使用新目录，旧版本已经加密保存的 Key 会在同一台电脑上失效。
	# 因此把这一段固定为历史兼容路径；新用户也使用同一稳定规则，后续改名不再影响解密。
	var stable_user_data_dir := OS.get_environment("APPDATA").strip_edges()
	if stable_user_data_dir.is_empty():
		stable_user_data_dir = OS.get_user_data_dir()
	else:
		stable_user_data_dir = stable_user_data_dir.path_join("Godot/app_userdata/蓝鲸智能体桌宠")
	stable_user_data_dir = stable_user_data_dir.replace("\\", "/")
	var identity := "%s|%s|%s|blue-whale-agent-v1" % [
		OS.get_environment("COMPUTERNAME"),
		OS.get_environment("USERNAME"),
		stable_user_data_dir
	]
	var hashing := HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(identity.to_utf8_buffer())
	return hashing.finish()
