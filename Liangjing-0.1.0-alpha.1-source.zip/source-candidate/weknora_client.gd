# [DSH] WeKnora 知识库客户端（梁鲸作为中台时使用）。
#
# 只做两件事：把请求发出去、把响应解析成梁鲸内部好用的形状。
# 判定逻辑（地址拼装、分页推进、multipart 组包、错误文案）全部写成**静态纯函数**，
# 这样不用联网、不用起服务就能断言；真正的 HTTP 走 request_json()，自检里用
# weknora_mock_server.gd 起一个本地假服务真跑一遍。
#
# 与官方文档的对应关系（docs/api/）：知识库列表/详情见 knowledge-base.md、
# 知识增删查与解析状态见 knowledge.md、分块见 chunk.md、检索见 knowledge-search.md。
extends Node

const DEFAULT_TIMEOUT := 20.0
const UPLOAD_TIMEOUT := 120.0
const CLIENT_HEADER := "X-Blue-Whale-Client: godot"

var base_url := ""
var api_key := ""
# 诊断开关：置 true 时把收到的原始 SSE 帧记进 captured_frames（默认关闭）。
# 用途：真机上出现"有事件但没答案"时，靠它看清服务端到底发了什么，而不是靠猜。
var capture_stream_frames := false
var captured_frames: Array = []

var cancellation_check := Callable()

func is_cancelled() -> bool:
	return cancellation_check.is_valid() and bool(cancellation_check.call())

func initialize(api_base_url: String, key: String) -> void:
	base_url = api_base_url.strip_edges().trim_suffix("/")
	api_key = key.strip_edges()

func is_ready() -> bool:
	return not base_url.is_empty() and not api_key.is_empty()

# ── 纯函数区（可断言）────────────────────────────────────────────────

# 分页推进：返回下一页页码，0 表示已经取完。
# 服务端给了 total 就按 total 算；没给就只能靠"这一页是否取满"推断——
# 后者会在总数正好是页大小整数倍时多请求一次空页，所以优先用 total。
static func next_page(page: int, page_size: int, total: int, received: int) -> int:
	if page <= 0 or page_size <= 0 or received <= 0:
		return 0
	if total > 0:
		return page + 1 if page * page_size < total else 0
	return page + 1 if received >= page_size else 0

static func status_message(status: int) -> String:
	match status:
		400:
			return "请求被拒绝：参数不合法"
		401:
			return "API Key 无效或已过期"
		403:
			return "这个 Key 没有权限执行该操作（限定知识库的 Key 不能访问文件直链等接口）"
		404:
			return "在 WeKnora 里找不到对应的知识库或资料"
		409:
			return "这份资料已经在知识库里了"
		413:
			return "文件超过 WeKnora 允许的大小上限"
		429:
			return "请求过于频繁，稍后再试"
		500, 502, 503, 504:
			return "WeKnora 服务端暂时出错"
		_:
			return "WeKnora 返回了 HTTP %d" % status

# 服务端错误体：{"success":false,"error":{"code":...,"message":...,"details":...}}
static func server_error_message(payload: Variant) -> String:
	if not payload is Dictionary:
		return ""
	var source: Dictionary = payload
	var error_value: Variant = source.get("error", null)
	if error_value is Dictionary:
		return str(Dictionary(error_value).get("message", "")).strip_edges()
	if error_value is String:
		return str(error_value).strip_edges()
	return str(source.get("message", "")).strip_edges()

static func describe_error(status: int, payload: Variant) -> String:
	var base := status_message(status)
	var detail := server_error_message(payload)
	if detail.is_empty() or detail == base:
		return base
	return "%s（服务端：%s）" % [base, detail]

# 成功判定：WeKnora 统一返回 {"success":true,...}；HTTP 2xx 但 success=false 仍是失败。
static func payload_ok(status: int, payload: Variant) -> bool:
	if status < 200 or status >= 300:
		return false
	if payload is Dictionary and Dictionary(payload).has("success"):
		return bool(Dictionary(payload).get("success", false))
	return true

static func data_of(payload: Variant) -> Variant:
	if payload is Dictionary:
		return Dictionary(payload).get("data", null)
	return null

static func parse_knowledge_bases(payload: Variant) -> Array:
	var rows: Array = []
	var data: Variant = data_of(payload)
	if not data is Array:
		return rows
	for item in data:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		rows.append({
			"id": str(row.get("id", "")),
			"name": str(row.get("name", "")),
			"type": str(row.get("type", "document")),
			"description": str(row.get("description", "")),
			"knowledge_count": int(row.get("knowledge_count", 0)),
			"chunk_count": int(row.get("chunk_count", 0)),
			"processing_count": int(row.get("processing_count", 0)),
			"embedding_model_id": str(row.get("embedding_model_id", "")),
			# 图谱是**按库**开关的，所以判断"图谱能不能用"要看知识库本身，
			# 而不是找一个全局接口——用户部署的版本上 GET /system 是 404。
			"graph_enabled": is_graph_enabled(row),
		})
	return rows

# 纯函数：这个知识库启用知识图谱了吗。两个字段名来自不同版本，都要认。
static func is_graph_enabled(knowledge_base: Dictionary) -> bool:
	var strategy: Variant = knowledge_base.get("indexing_strategy", null)
	if strategy is Dictionary and bool(Dictionary(strategy).get("graph_enabled", false)):
		return true
	var extract: Variant = knowledge_base.get("extract_config", null)
	if extract is Dictionary and bool(Dictionary(extract).get("enabled", false)):
		return true
	return false

static func parse_knowledge_list(payload: Variant) -> Dictionary:
	var rows: Array = []
	var data: Variant = data_of(payload)
	if data is Array:
		for item in data:
			if not item is Dictionary:
				continue
			rows.append(parse_knowledge_row(item))
	var total := 0
	if payload is Dictionary:
		total = int(Dictionary(payload).get("total", 0))
	return {"items": rows, "total": total}

static func parse_knowledge_row(row: Dictionary) -> Dictionary:
	return {
		"id": str(row.get("id", "")),
		"title": str(row.get("title", "")),
		"file_name": str(row.get("file_name", "")),
		"file_type": str(row.get("file_type", "")),
		"file_size": int(row.get("file_size", 0)),
		"file_hash": str(row.get("file_hash", "")),
		"type": str(row.get("type", "")),
		"source": str(row.get("source", "")),
		"parse_status": str(row.get("parse_status", "")),
		"enable_status": str(row.get("enable_status", "")),
		"summary": str(row.get("description", "")),
		"updated_at": str(row.get("updated_at", "")),
		"folder_path": str(row.get("folder_path", "")),
		"error_message": str(row.get("error_message", "")),
	}

# 解析状态是否还能变（用于决定要不要继续轮询）。
static func is_parse_pending(status: String) -> bool:
	return status in ["pending", "processing", "finalizing", "deleting"]

static func parse_status_text(status: String) -> String:
	match status:
		"pending":
			return "排队中"
		"processing":
			return "正在解析"
		"finalizing":
			return "正在生成摘要与索引"
		"completed":
			return "已完成"
		"failed":
			return "解析失败"
		"cancelled":
			return "已取消"
		"deleting":
			return "正在删除"
		_:
			return status

# 检索结果 → 中台用的统一形状。WeKnora 的 hybrid-search 与 knowledge-search 同形。
static func parse_search_results(payload: Variant) -> Array:
	var rows: Array = []
	var data: Variant = data_of(payload)
	if not data is Array:
		return rows
	for item in data:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		var title := str(row.get("knowledge_title", "")).strip_edges()
		if title.is_empty():
			title = str(row.get("knowledge_filename", "")).strip_edges()
		if title.is_empty():
			title = "本机知识库资料"
		var content := str(row.get("content", "")).strip_edges()
		if content.is_empty():
			continue
		rows.append({
			"content": content,
			"title": title,
			"filename": str(row.get("knowledge_filename", "")),
			"chunk_id": str(row.get("id", "")),
			"knowledge_id": str(row.get("knowledge_id", "")),
			"chunk_index": int(row.get("chunk_index", 0)),
			"chunk_type": str(row.get("chunk_type", "text")),
			"score": float(row.get("score", 0.0)),
			"source": str(row.get("knowledge_source", "")),
		})
	return rows

static func parse_chunks(payload: Variant) -> Dictionary:
	var rows: Array = []
	var data: Variant = data_of(payload)
	if data is Array:
		for item in data:
			if not item is Dictionary:
				continue
			var row: Dictionary = item
			rows.append({
				"id": str(row.get("id", "")),
				"content": str(row.get("content", "")),
				"chunk_index": int(row.get("chunk_index", 0)),
				"chunk_type": str(row.get("chunk_type", "text")),
				"is_enabled": bool(row.get("is_enabled", true)),
				"knowledge_id": str(row.get("knowledge_id", "")),
			})
	var total := 0
	if payload is Dictionary:
		total = int(Dictionary(payload).get("total", 0))
	return {"items": rows, "total": total}

# 把检索结果拼成注入提示词的文本。与 collect_local_knowledge_context 的输出同构，
# 这样两条来源（本机词法 / WeKnora 混合检索）在提示词里长得一样，不用改上层。
static func format_context(results: Array, max_chars_per_item := 1200) -> Dictionary:
	var sections: Array = []
	for item in results:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		var text := str(row.get("content", ""))
		if text.length() > max_chars_per_item:
			text = text.left(max_chars_per_item) + "……"
		sections.append("【%s】\n%s" % [str(row.get("title", "本地资料")), text])
	if sections.is_empty():
		return {"text": "", "count": 0}
	return {
		"text": "以下内容来自用户本机知识库（WeKnora 检索），仅在与问题相关时使用：\n\n%s" % "\n\n".join(sections),
		"count": sections.size(),
	}

# ── multipart 组包（上传文件用；Godot 没有内置构造器）─────────────────

static func make_boundary(seed_text: String) -> String:
	# 边界必须足够不可能出现在正文里；同时带上调用方给的种子，便于复现与断言。
	return "----BlueWhaleBoundary%s" % seed_text.sha256_text().substr(0, 24)

static func mime_for_file(file_name: String) -> String:
	match file_name.get_extension().to_lower():
		"pdf":
			return "application/pdf"
		"md", "markdown":
			return "text/markdown"
		"txt", "log", "csv", "json", "ini", "yaml", "yml":
			return "text/plain"
		"docx":
			return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
		"xlsx":
			return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
		"pptx":
			return "application/vnd.openxmlformats-officedocument.presentationml.presentation"
		"png":
			return "image/png"
		"jpg", "jpeg":
			return "image/jpeg"
		_:
			return "application/octet-stream"

static func multipart_content_type(boundary: String) -> String:
	return "multipart/form-data; boundary=%s" % boundary

# 组包规则（RFC 7578）：文本字段在前（按键名排序，保证可复现），文件字段最后，
# 每个部分之间用 CRLF 分隔，结尾是 --boundary--。文件字节原样写入，不做任何转义。
static func multipart_body(
	fields: Dictionary,
	file_field: String,
	file_name: String,
	file_bytes: PackedByteArray,
	boundary: String
) -> PackedByteArray:
	var body := PackedByteArray()
	var keys: Array = fields.keys()
	keys.sort()
	for key in keys:
		var value := str(fields[key])
		body.append_array(("--%s\r\n" % boundary).to_utf8_buffer())
		body.append_array(('Content-Disposition: form-data; name="%s"\r\n\r\n' % str(key)).to_utf8_buffer())
		body.append_array(value.to_utf8_buffer())
		body.append_array("\r\n".to_utf8_buffer())
	body.append_array(("--%s\r\n" % boundary).to_utf8_buffer())
	body.append_array(
		('Content-Disposition: form-data; name="%s"; filename="%s"\r\n' % [file_field, file_name]).to_utf8_buffer()
	)
	body.append_array(("Content-Type: %s\r\n\r\n" % mime_for_file(file_name)).to_utf8_buffer())
	body.append_array(file_bytes)
	body.append_array("\r\n".to_utf8_buffer())
	body.append_array(("--%s--\r\n" % boundary).to_utf8_buffer())
	return body

# PackedByteArray.find() 找的是**字节值**而不是子串，所以这里自己实现一个子串查找。
# multipart 的边界检测依赖它，找错了就会切坏文件。
static func bytes_index_of(haystack: PackedByteArray, needle: PackedByteArray, from := 0) -> int:
	if needle.is_empty() or haystack.size() < needle.size():
		return -1
	var limit := haystack.size() - needle.size()
	var start_index := maxi(from, 0)
	while start_index <= limit:
		if haystack[start_index] == needle[0]:
			var matched := true
			for offset in range(1, needle.size()):
				if haystack[start_index + offset] != needle[offset]:
					matched = false
					break
			if matched:
				return start_index
		start_index += 1
	return -1

# 边界如果出现在正文里，帧就会被打断。这里给出一个不会撞车的边界（撞了就换种子重来）。
static func safe_boundary(seed_text: String, payload: PackedByteArray) -> String:
	var boundary := make_boundary(seed_text)
	var marker := boundary.to_utf8_buffer()
	var attempt := 0
	while bytes_index_of(payload, marker) >= 0 and attempt < 8:
		attempt += 1
		boundary = make_boundary("%s#%d" % [seed_text, attempt])
		marker = boundary.to_utf8_buffer()
	return boundary

# ── SSE 解析（纯函数）────────────────────────────────────────────────
#
# 为什么按**字节**分帧而不是按字符串：SSE 的一个事件可能被 TCP 切成好几段，
# 而中文一个字占 3 字节，切断在字符中间时 get_string_from_utf8() 会把它变成
# 替换字符（U+FFFD）——答案里就会出现乱码。所以缓冲区始终是 PackedByteArray，
# 只有拿到**完整的一帧**才解码。这条在 openai_stream_client.gd 上踩过一次。

# 从缓冲区头部取出一个完整事件帧；返回 {frame, rest}。frame 为空表示还不完整。
static func take_sse_frame(buffer: PackedByteArray) -> Dictionary:
	var lf := bytes_index_of(buffer, "\n\n".to_utf8_buffer())
	var crlf := bytes_index_of(buffer, "\r\n\r\n".to_utf8_buffer())
	var cut := -1
	var width := 0
	if lf >= 0 and (crlf < 0 or lf < crlf):
		cut = lf
		width = 2
	elif crlf >= 0:
		cut = crlf
		width = 4
	if cut < 0:
		return {"frame": "", "rest": buffer}
	return {"frame": buffer.slice(0, cut).get_string_from_utf8(), "rest": buffer.slice(cut + width)}

# 解析一个事件帧：可能是 "event: message" + "data: {...}"，也可能只有 data 行。
static func parse_sse_frame(frame: String) -> Dictionary:
	var event_name := "message"
	var data_lines: Array = []
	for raw_line in frame.replace("\r\n", "\n").split("\n"):
		var line := raw_line
		if line.is_empty() or line.begins_with(":"):
			continue
		if line.begins_with("event:"):
			event_name = line.substr(6).strip_edges()
		elif line.begins_with("data:"):
			# 规范规定 data: 后最多去掉一个空格，其余空格属于数据。
			var value := line.substr(5)
			if value.begins_with(" "):
				value = value.substr(1)
			data_lines.append(value)
	if data_lines.is_empty():
		return {}
	return {"event": event_name, "data": "\n".join(data_lines)}

# 把 WeKnora 的问答事件转成梁鲸内部形状。
# response_type 取值：references / answer / thinking / tool_call / tool_result / error / session_title ...
static func interpret_chat_frame(frame: String) -> Dictionary:
	var parsed_event := parse_sse_frame(frame)
	if parsed_event.is_empty():
		return {}
	var payload: Variant = JSON.parse_string(str(parsed_event.get("data", "")))
	if not payload is Dictionary:
		return {}
	var row: Dictionary = payload
	var type := str(row.get("response_type", ""))
	if type.is_empty() and str(parsed_event.get("event", "")) == "error":
		type = "error"
	return {
		"type": type,
		"content": str(row.get("content", "")),
		"done": bool(row.get("done", false)),
		"message_id": str(row.get("id", "")),
		"references": parse_knowledge_references(row.get("knowledge_references", null)),
		"error": str(row.get("error", "")) if type == "error" else "",
	}

# 引用条目：WeKnora 的 knowledge_references 与检索结果同形，字段取我们需要的那些。
static func parse_knowledge_references(value: Variant) -> Array:
	var rows: Array = []
	if not value is Array:
		return rows
	for item in value:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		var title := str(row.get("knowledge_title", "")).strip_edges()
		if title.is_empty():
			title = str(row.get("knowledge_filename", "")).strip_edges()
		rows.append({
			"chunk_id": str(row.get("id", "")),
			"knowledge_id": str(row.get("knowledge_id", "")),
			"title": title,
			"filename": str(row.get("knowledge_filename", "")),
			"content": str(row.get("content", "")),
			"chunk_index": int(row.get("chunk_index", 0)),
			"chunk_type": str(row.get("chunk_type", "text")),
			"score": float(row.get("score", 0.0)),
			"match_type": int(row.get("match_type", 0)),
		})
	return rows

# 引用 → 界面文案。用户要能一眼看出这句话是从哪份资料来的。
static func format_citations(references: Array, limit := 3) -> String:
	var seen := {}
	var labels: Array = []
	for item in references:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		var title := str(row.get("title", "")).strip_edges()
		if title.is_empty() or seen.has(title):
			continue
		seen[title] = true
		labels.append(title)
		if labels.size() >= limit:
			break
	if labels.is_empty():
		return ""
	return "参考资料：" + "、".join(labels)

# ── HTTP ────────────────────────────────────────────────────────────

func request_json(method: int, path: String, body: Variant = null, timeout := DEFAULT_TIMEOUT) -> Dictionary:
	var headers := PackedStringArray([
		"Accept: application/json",
		"X-API-Key: %s" % api_key,
		"X-Request-ID: blue-whale-%d-%d" % [Time.get_ticks_usec(), randi()],
		CLIENT_HEADER,
	])
	var payload_bytes := PackedByteArray()
	if body != null:
		headers.append("Content-Type: application/json")
		payload_bytes = JSON.stringify(body).to_utf8_buffer()
	return await _send(method, path, headers, payload_bytes, timeout)

func request_multipart(
	path: String,
	fields: Dictionary,
	file_field: String,
	file_name: String,
	file_bytes: PackedByteArray,
	timeout := UPLOAD_TIMEOUT
) -> Dictionary:
	var boundary := safe_boundary("%s|%s" % [file_name, str(file_bytes.size())], file_bytes)
	var headers := PackedStringArray([
		"Accept: application/json",
		"X-API-Key: %s" % api_key,
		"X-Request-ID: blue-whale-upload-%d" % Time.get_ticks_usec(),
		CLIENT_HEADER,
		"Content-Type: %s" % multipart_content_type(boundary),
	])
	var payload := multipart_body(fields, file_field, file_name, file_bytes, boundary)
	return await _send(HTTPClient.METHOD_POST, path, headers, payload, timeout)

func _send(method: int, path: String, headers: PackedStringArray, body: PackedByteArray, timeout: float) -> Dictionary:
	if not is_ready():
		return {"ok": false, "status": 0, "error": "WeKnora 连接还没配置好（地址或 Key 为空）。"}
	if not is_inside_tree():
		return {"ok": false, "status": 0, "error": "知识库客户端还没有挂到场景里。"}
	var request := HTTPRequest.new()
	request.timeout = timeout
	add_child(request)
	var url := base_url + path
	var start_error := request.request_raw(url, headers, method, body)
	if start_error != OK:
		request.queue_free()
		return {"ok": false, "status": 0, "error": "无法发起请求（%d），请检查地址。" % start_error}
	var completed: Array = []
	request.request_completed.connect(func(result: int, code: int, response_headers: PackedStringArray, response_body: PackedByteArray): completed.append_array([result, code, response_headers, response_body]))
	while completed.is_empty():
		if is_cancelled():
			request.cancel_request()
			request.queue_free()
			return {"ok": false, "error": "本地知识库请求已取消。"}
		await get_tree().process_frame
	request.queue_free()
	var transport := int(completed[0])
	var status := int(completed[1])
	var response_body: PackedByteArray = completed[3]
	if transport != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "status": 0, "error": _transport_error(transport, timeout), "transport": transport}
	var text := response_body.get_string_from_utf8()
	var payload: Variant = null
	# 只在看起来是 JSON 时才解析：Gin 的 404/500 会返回纯文本（"404 page not found"），
	# 对它调 JSON.parse_string 会往日志里写一条 ERROR，把真问题淹掉。
	var trimmed := text.strip_edges()
	if trimmed.begins_with("{") or trimmed.begins_with("["):
		payload = JSON.parse_string(trimmed)
	elif not trimmed.is_empty():
		payload = {"success": false, "message": trimmed.left(200)}
	if not payload_ok(status, payload):
		return {"ok": false, "status": status, "payload": payload, "error": describe_error(status, payload)}
	return {"ok": true, "status": status, "payload": payload}

func _transport_error(transport: int, timeout: float) -> String:
	match transport:
		HTTPRequest.RESULT_TIMEOUT:
			return "等待 WeKnora 超过 %.0f 秒没有响应。" % timeout
		HTTPRequest.RESULT_CANT_CONNECT, HTTPRequest.RESULT_CANT_RESOLVE, HTTPRequest.RESULT_CONNECTION_ERROR:
			return "连不上 WeKnora（%s）。请确认服务已启动、地址填写正确。" % base_url
		HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
			return "与 WeKnora 的 HTTPS 握手失败，请检查证书。"
		_:
			return "请求 WeKnora 失败（传输错误 %d）。" % transport

# ── 业务方法 ────────────────────────────────────────────────────────

func ping() -> Dictionary:
	var result := await request_json(HTTPClient.METHOD_GET, "/knowledge-bases")
	if not bool(result.get("ok", false)):
		return result
	return {"ok": true, "status": int(result.get("status", 200))}

func list_knowledge_bases() -> Dictionary:
	var result := await request_json(HTTPClient.METHOD_GET, "/knowledge-bases")
	if not bool(result.get("ok", false)):
		return result
	return {"ok": true, "items": parse_knowledge_bases(result.get("payload", null))}

func list_knowledge(kb_id: String, page := 1, page_size := 50) -> Dictionary:
	var path := "/knowledge-bases/%s/knowledge?page=%d&page_size=%d" % [kb_id, page, page_size]
	var result := await request_json(HTTPClient.METHOD_GET, path)
	if not bool(result.get("ok", false)):
		return result
	var parsed := parse_knowledge_list(result.get("payload", null))
	parsed["ok"] = true
	return parsed

func knowledge_detail(knowledge_id: String) -> Dictionary:
	var result := await request_json(HTTPClient.METHOD_GET, "/knowledge/%s" % knowledge_id)
	if not bool(result.get("ok", false)):
		return result
	var data: Variant = data_of(result.get("payload", null))
	if not data is Dictionary:
		return {"ok": false, "status": int(result.get("status", 0)), "error": "WeKnora 没有返回资料详情。"}
	return {"ok": true, "item": parse_knowledge_row(data)}

func list_chunks(knowledge_id: String, page := 1, page_size := 100) -> Dictionary:
	var path := "/chunks/%s?page=%d&page_size=%d" % [knowledge_id, page, page_size]
	var result := await request_json(HTTPClient.METHOD_GET, path)
	if not bool(result.get("ok", false)):
		return result
	var parsed := parse_chunks(result.get("payload", null))
	parsed["ok"] = true
	return parsed

func upload_file(kb_id: String, file_name: String, file_bytes: PackedByteArray, extra_fields := {}) -> Dictionary:
	if file_bytes.is_empty():
		return {"ok": false, "status": 0, "error": "没有可上传的内容。"}
	var fields: Dictionary = {}
	for key in extra_fields.keys():
		fields[str(key)] = str(extra_fields[key])
	var result := await request_multipart("/knowledge-bases/%s/knowledge/file" % kb_id, fields, "file", file_name, file_bytes)
	if not bool(result.get("ok", false)):
		# 409 是"这份资料已经在库里"，对中台来说不是错误，而是一个需要提示的状态。
		return result
	var data: Variant = data_of(result.get("payload", null))
	var knowledge_id := ""
	if data is Dictionary:
		knowledge_id = str(Dictionary(data).get("id", ""))
	return {"ok": true, "knowledge_id": knowledge_id, "item": parse_knowledge_row(data) if data is Dictionary else {}}

func delete_knowledge(knowledge_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_DELETE, "/knowledge/%s" % knowledge_id)

func reparse(knowledge_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/knowledge/%s/reparse" % knowledge_id, {})

func cancel_parse(knowledge_id: String) -> Dictionary:
	return await request_json(HTTPClient.METHOD_POST, "/knowledge/%s/cancel-parse" % knowledge_id, {})

# 检索：单库走 hybrid-search（向量+关键词+重排），多库走 knowledge-search。
# 上层只关心"给我最相关的几段"，不关心走哪个端点。
func search(query: String, kb_ids: Array, match_count := 6, vector_threshold := 0.0) -> Dictionary:
	var clean := query.strip_edges()
	if clean.is_empty():
		return {"ok": false, "status": 0, "error": "空问题不检索。"}
	var ids: Array = []
	for value in kb_ids:
		var text := str(value).strip_edges()
		if not text.is_empty() and not ids.has(text):
			ids.append(text)
	if ids.is_empty():
		return {"ok": false, "status": 0, "error": "还没有选择要检索的知识库。"}
	var result: Dictionary = {}
	if ids.size() == 1:
		var body := {"query_text": clean, "match_count": match_count}
		if vector_threshold > 0.0:
			body["vector_threshold"] = vector_threshold
		result = await request_json(HTTPClient.METHOD_POST, "/knowledge-bases/%s/hybrid-search" % str(ids[0]), body)
	else:
		result = await request_json(HTTPClient.METHOD_POST, "/knowledge-search", {
			"query": clean,
			"knowledge_base_ids": ids,
		})
	if not bool(result.get("ok", false)):
		return result
	return {"ok": true, "items": parse_search_results(result.get("payload", null))}

# 等一份资料解析完（中台投喂后显示进度用）。返回最后的详情行。
func wait_for_parse(knowledge_id: String, timeout_seconds := 300.0, interval := 2.0) -> Dictionary:
	var deadline := Time.get_ticks_msec() + int(timeout_seconds * 1000.0)
	var last: Dictionary = {}
	while Time.get_ticks_msec() < deadline:
		var detail := await knowledge_detail(knowledge_id)
		if not bool(detail.get("ok", false)):
			return detail
		last = detail.get("item", {})
		var status := str(last.get("parse_status", ""))
		if not is_parse_pending(status):
			return {"ok": true, "item": last, "status": status, "timed_out": false}
		await get_tree().create_timer(interval).timeout
	return {"ok": true, "item": last, "status": str(last.get("parse_status", "")), "timed_out": true}

func create_session(title := "梁鲸知识库问答") -> Dictionary:
	var result := await request_json(HTTPClient.METHOD_POST, "/sessions", {"title": title})
	if not bool(result.get("ok", false)):
		return result
	var data: Variant = data_of(result.get("payload", null))
	if not data is Dictionary:
		return {"ok": false, "status": int(result.get("status", 0)), "error": "WeKnora 没有返回会话 ID。"}
	return {"ok": true, "session_id": str(Dictionary(data).get("id", ""))}

func system_info() -> Dictionary:
	# 不同版本挂的路径不一样（用户的私有部署上 /system 就是 404），逐个试。
	for path in ["/system", "/system/info", "/system/status"]:
		var result := await request_json(HTTPClient.METHOD_GET, path)
		if bool(result.get("ok", false)):
			var data: Variant = data_of(result.get("payload", null))
			var row: Dictionary = data if data is Dictionary else {}
			return {
				"ok": true,
				"path": path,
				"graph_engine": str(row.get("graph_database_engine", row.get("graph_engine", ""))),
				"vector_engine": str(row.get("retriever_engine", row.get("vector_store_engine", ""))),
				"raw": row,
			}
	return {"ok": false, "error": "这个 WeKnora 版本没有暴露 /system 信息接口（图谱状态改由知识库自身的开关判断）"}

# [DSH] 知识库问答（走 WeKnora 自己的 RAG 管道）。
#
# 为什么必须是这条端点而不是 /hybrid-search：**知识图谱只在这条管道里生效**
# （QUERY_UNDERSTAND 抽实体 + ENTITY_SEARCH 查一跳邻居补充召回），
# 图谱没有独立的 REST 端点。所以"用图谱"就等于"让 WeKnora 生成答案"。
#
# 流式做法：用 HTTPClient 逐块读，缓冲区保持字节形态，只在拿到完整 SSE 帧时才解码，
# 避免中文被 TCP 切断后变成替换字符。每解析出一个事件就回调 on_event。
func stream_knowledge_chat(
	session_id: String,
	query: String,
	kb_ids: Array,
	on_event: Callable = Callable(),
	timeout_seconds := 180.0
) -> Dictionary:
	if not is_ready():
		return {"ok": false, "error": "WeKnora 连接还没配置好（地址或 Key 为空）。"}
	var clean := query.strip_edges()
	if clean.is_empty():
		return {"ok": false, "error": "空问题不发送。"}
	if session_id.strip_edges().is_empty():
		return {"ok": false, "error": "缺少会话 ID。"}
	var parsed := _split_base_url(base_url)
	if parsed.is_empty():
		return {"ok": false, "error": "WeKnora 地址无法解析：%s" % base_url}
	var body := {"query": clean, "channel": "api"}
	var ids: Array = []
	for value in kb_ids:
		var text := str(value).strip_edges()
		if not text.is_empty() and not ids.has(text):
			ids.append(text)
	if not ids.is_empty():
		body["knowledge_base_ids"] = ids

	var client := HTTPClient.new()
	# 第三个参数是 TLSOptions 对象而不是布尔值：https 要么传 TLSOptions.client()，要么传 null。
	var tls_options: TLSOptions = TLSOptions.client() if bool(parsed["tls"]) else null
	var connect_error := client.connect_to_host(str(parsed["host"]), int(parsed["port"]), tls_options)
	if connect_error != OK:
		return {"ok": false, "error": "无法连接 WeKnora（%d）。" % connect_error}
	var deadline := Time.get_ticks_msec() + int(timeout_seconds * 1000.0)
	while client.get_status() in [HTTPClient.STATUS_CONNECTING, HTTPClient.STATUS_RESOLVING]:
		if is_cancelled():
			client.close()
			return {"ok": false, "error": "本地知识库请求已取消。"}
		if Time.get_ticks_msec() > deadline:
			client.close()
			return {"ok": false, "error": "连接 WeKnora 超时。"}
		client.poll()
		await get_tree().process_frame
	if client.get_status() != HTTPClient.STATUS_CONNECTED:
		client.close()
		return {"ok": false, "error": "连不上 WeKnora（状态 %d）。" % client.get_status()}

	var headers := PackedStringArray([
		"Accept: text/event-stream",
		"Content-Type: application/json",
		"Cache-Control: no-cache",
		"X-API-Key: %s" % api_key,
		"X-Request-ID: blue-whale-chat-%d" % Time.get_ticks_usec(),
		CLIENT_HEADER,
	])
	var path := "%s/knowledge-chat/%s" % [str(parsed["path"]), session_id]
	var request_error := client.request(HTTPClient.METHOD_POST, path, headers, JSON.stringify(body))
	if request_error != OK:
		client.close()
		return {"ok": false, "error": "无法发起问答请求（%d）。" % request_error}

	while not client.has_response():
		if is_cancelled():
			client.close()
			return {"ok": false, "error": "本地知识库请求已取消。"}
		if Time.get_ticks_msec() > deadline:
			client.close()
			return {"ok": false, "error": "WeKnora 没有响应（超时）。"}
		client.poll()
		await get_tree().process_frame
	var status := client.get_response_code()
	if status != 200:
		var raw := PackedByteArray()
		while client.get_status() == HTTPClient.STATUS_BODY:
			if is_cancelled():
				client.close()
				return {"ok": false, "error": "本地知识库请求已取消。"}
			client.poll()
			var piece := client.read_response_body_chunk()
			if piece.size() > 0:
				raw.append_array(piece)
			await get_tree().process_frame
		client.close()
		var text := raw.get_string_from_utf8()
		var payload: Variant = JSON.parse_string(text)
		if payload == null and not text.strip_edges().is_empty():
			payload = {"success": false, "error": {"message": text.left(200)}}
		return {"ok": false, "status": status, "error": describe_error(status, payload)}

	var buffer := PackedByteArray()
	var answer := ""
	var references: Array = []
	var message_id := ""
	var done := false
	var event_count := 0
	var stream_error := ""
	while not done:
		if is_cancelled():
			client.close()
			return {"ok": false, "error": "本地知识库请求已取消。"}
		if Time.get_ticks_msec() > deadline:
			stream_error = "等待回答超时（%.0f 秒）。" % timeout_seconds
			break
		client.poll()
		var chunk := client.read_response_body_chunk() if client.get_status() == HTTPClient.STATUS_BODY else PackedByteArray()
		if chunk.size() > 0:
			buffer.append_array(chunk)
		var progressed := true
		while progressed:
			progressed = false
			var taken := take_sse_frame(buffer)
			buffer = taken["rest"]
			var frame := str(taken["frame"])
			if frame.is_empty():
				continue
			if capture_stream_frames and captured_frames.size() < 20:
				captured_frames.append(frame.left(600))
			var event := interpret_chat_frame(frame)
			if event.is_empty():
				continue
			event_count += 1
			progressed = true
			var type := str(event.get("type", ""))
			if type == "answer":
				answer += str(event.get("content", ""))
			# 引用可能挂在任何一条事件上，不限于 references 类型。
			var event_references: Array = event.get("references", [])
			if not event_references.is_empty():
				references = event_references
			if not str(event.get("message_id", "")).is_empty():
				message_id = str(event.get("message_id", ""))
			if type == "error":
				stream_error = str(event.get("error", "WeKnora 返回了错误。"))
				if bool(event.get("done", false)):
					done = true
					break
			# 结束条件只认这两种，**不能一看到 done=true 就退**：
			# 真服务的第一帧是 agent_query 且带 done=true——那时它只表示"这一条事件完整"，
			# 整条流还在后面。早期版本因此在第一帧就退出，答案永远是空的（真机复现过）。
			if bool(event.get("done", false)) and (type == "answer" or type == "complete"):
				done = true
				break
			if on_event.is_valid():
				on_event.call(event)
		if client.get_status() == HTTPClient.STATUS_DISCONNECTED:
			break
		await get_tree().process_frame
	client.close()
	if not stream_error.is_empty() and answer.strip_edges().is_empty():
		return {"ok": false, "error": stream_error, "status": 200}
	return {
		"ok": true,
		"answer": answer.strip_edges(),
		"references": references,
		"message_id": message_id,
		"event_count": event_count,
		"truncated": not done,
		"error": stream_error,
	}

# 把 http(s)://主机:端口/api/v1 拆成 connect_to_host 需要的四元组。
static func _split_base_url(url: String) -> Dictionary:
	var clean := url.strip_edges()
	var tls := false
	if clean.begins_with("https://"):
		tls = true
		clean = clean.substr(8)
	elif clean.begins_with("http://"):
		clean = clean.substr(7)
	else:
		return {}
	var slash := clean.find("/")
	var authority := clean if slash < 0 else clean.substr(0, slash)
	var path := "/" if slash < 0 else clean.substr(slash)
	var host := authority
	var port := 443 if tls else 80
	var colon := authority.rfind(":")
	if colon > 0:
		host = authority.substr(0, colon)
		var parsed_port := int(authority.substr(colon + 1))
		if parsed_port > 0:
			port = parsed_port
	if host.is_empty():
		return {}
	return {"host": host, "port": port, "tls": tls, "path": path.trim_suffix("/")}
