# 梁鲸桌面助手

基于 Godot 的 Windows 桌面助手，将人物互动、AI 对话、模型配置、知识库与任务执行整合到桌面。

**当前状态：0.1.0-alpha.1 公开测试版。** 自有代码采用 GPL-3.0-only；人物、家具等素材的许可范围另见 LICENSE_STATUS.md，逐图生成记录尚未补齐。

官方仓库：https://github.com/you009008-hub/liangjing

Windows x64 安装包与对应源码：请查看仓库 Releases。首次启动需要联网安装锁定的 Harness 依赖。此版本没有代码签名，普通 Windows 安装/卸载与多设备兼容性仍需反馈；不要把 Alpha 当作稳定版。

首次发布通过网页上传，完整源码目录保存在仓库附带的 Liangjing-0.1.0-alpha.1-source.zip 及 Release 同名附件中。请下载该文件并解压 source-candidate 目录；GitHub 自动生成的 Source code 压缩包可能只是仓库外层文件。

## 功能

- 桌宠分层动态、屏幕边缘停靠、换装生成和衣柜。
- 对话历史、模型配置、审批及追问界面，连接 DeepSeek Harness 执行任务。
- 本地资料与已有 WeKnora 服务连接；工作流可检索指定知识库或调用知识问答。
- 可视化节点编排、顺序执行、运行记录、工作流分享包导入导出。
- Windows 原生功能窗与异步系统文件选择。

## 当前限制

- 主要验证 Windows x64；不宣称已支持 Linux/macOS。
- 工作流执行支持顺序链；分支、合流和循环图目前只能保存，不能执行。服务器工作流市场尚未接入。
- 换装需兼容的图片服务，可能收费；普通对话模型不等于图像编辑模型。
- 第三方服务需用户自行配置；不提供共享 API Key。知识库专项使用模拟服务验证，不代表所有真实部署兼容。
- 窗口、DPI 与角色渲染仍需更广泛的设备测试。

## 开始使用

当前完整开发目录可通过根目录的 **启动梁鲸.bat** 启动。不要直接运行历史发布副本。

开发环境、依赖准备和验证见 [开发说明](docs/DEVELOPMENT.md)。使用 Node 运行只读环境检查：

~~~powershell
node tools/check-environment.mjs
~~~

安装完成后再进入模型中心配置自己的服务。不要把配置、Key、聊天记录、换装参考照片或知识库内容提交到仓库。

## 开发与贡献

[模块结构](docs/ARCHITECTURE.md) · [贡献约定](CONTRIBUTING.md) · [安全反馈](SECURITY.md) · [第三方依赖](THIRD_PARTY_NOTICES.md)

项目使用独立的文件白名单和发布检查，不能通过直接上传整个开发目录来发布。发布地址以上方官方仓库及其 Releases 为准。
