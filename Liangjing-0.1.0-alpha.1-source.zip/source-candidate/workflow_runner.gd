extends Node

# A persisted, sequential runner. Natural-language rules remain instructions;
# only the explicit global decisions below are enforced by this controller.
const AtomicFile = preload("res://atomic_file.gd")
const ACTIVE_STATES := ["preparing", "running", "pausing", "paused", "waiting_input", "waiting_confirmation", "cancelling", "stop_unconfirmed"]
const Knowledge = preload("res://workflow_knowledge.gd")
const REMOTE_TYPES := ["知识库检索", "知识库问答", "模型处理", "Harness执行", "技能", "验证", "输出"]
const LOCAL_TYPES := ["输入", "用户交互"]

signal changed

var record: Dictionary = {}
var records_path := ""
var _transport: Node
var _generation := 0
var _driver_generation := -1
var _prepared := false
var _remote_in_flight := false
var _confirmed_step := -1
# [DSH] 本次运行中发生过几次步骤失败（用于让最终文案如实反映实际发生了什么）。
var _failures_this_run := 0
var _setup_error := ""

func setup(soul_root: String, transport: Node) -> void:
	if is_active():
		return
	_transport = transport
	records_path = soul_root.path_join("工作流运行")
	_setup_error = ""
	if soul_root.strip_edges().is_empty():
		_setup_error = "运行记录目录尚未配置。"
	elif DirAccess.make_dir_recursive_absolute(records_path) != OK:
		_setup_error = "无法创建工作流运行记录目录。"

func snapshot() -> Dictionary:
	return record.duplicate(true)

func is_active() -> bool:
	return str(record.get("state", "")) in ACTIVE_STATES

func validate(workflow: Dictionary, context: Dictionary) -> Dictionary:
	if not bool(workflow.get("enabled", false)):
		return _error("请先启用此工作流。")
	if not bool(workflow.get("confirmed", false)):
		return _error("请先确认并保存工作流，再开始运行。")
	if str(workflow.get("name", "")).strip_edges().is_empty():
		return _error("工作流名称不能为空。")
	var steps: Variant = workflow.get("steps", [])
	if not steps is Array or steps.is_empty():
		return _error("工作流还没有步骤。")
	for index in steps.size():
		if not steps[index] is Dictionary:
			return _error("第 %d 步格式不正确。" % (index + 1))
		var kind := str(steps[index].get("type", ""))
		if kind in Knowledge.TYPES and Knowledge.settings(steps[index].get("knowledge", {})).kb_ids.is_empty():
			return _error("第 %d 步尚未绑定知识库，请在节点设置里选库并保存。" % (index + 1))
		if kind == "条件分支":
			return _error("第 %d 步为条件分支；当前版本仅支持顺序执行，请先改成明确的顺序步骤。" % (index + 1))
		if not kind in REMOTE_TYPES and not kind in LOCAL_TYPES:
			return _error("第 %d 步的类型暂不支持：%s" % [index + 1, kind])
		if str(steps[index].get("name", "")).strip_edges().is_empty():
			return _error("第 %d 步缺少名称。" % (index + 1))
	var rules: Variant = context.get("rules", [])
	if not rules is Array:
		return _error("规则快照格式不正确。")
	for rule in rules:
		if not rule is Dictionary:
			return _error("规则快照中存在格式不正确的规则。")
		if not bool(rule.get("enabled", false)) or not bool(rule.get("confirmed", false)):
			continue
		var title := str(rule.get("name", "未命名规则"))
		if str(rule.get("scope", "")) != "全局":
			return _error("规则“%s”的范围暂不支持运行时绑定；请先明确为全局规则，或停用此规则后再运行。" % title)
		var decision := str(rule.get("decision", ""))
		if decision == "禁止":
			return _error("全局规则“%s”设为禁止；当前版本无法精确判断自然语言适用对象，因此阻止本次运行。" % title)
		if not decision in ["允许", "执行前询问", "预览后提交"]:
			return _error("规则“%s”的处理方式暂不支持。" % title)
	var note := ""
	if str(context.get("trigger_source", "")) == "conversation":
		note = "本次由对话中的明确执行指令触发。"
	elif str(workflow.get("trigger", "手动运行")) != "手动运行":
		note = "本次由按钮手动运行；定时和事件触发尚未启用。"
	return {"ok": true, "message": note}

func start(workflow: Dictionary, context: Dictionary) -> Dictionary:
	if is_active():
		return _error("当前工作流仍在运行、等待处理或尚未确认停止，请先处理当前任务。")
	if not _setup_error.is_empty() or records_path.is_empty():
		return _error(_setup_error if not _setup_error.is_empty() else "运行器尚未初始化。")
	var check := validate(workflow, context)
	if not bool(check.get("ok", false)):
		return check
	check = _availability()
	if not bool(check.get("ok", false)):
		return check
	var now := _now()
	var candidate := {
		"id": _new_id(), "workflow": _workflow_snapshot(workflow),
		"context": _context_snapshot(context), "steps": [], "step_index": 0,
		"state": "preparing", "message": "准备运行。", "failure_stage": "",
		"created_at": now, "updated_at": now, "finished_at": "",
		"updated_unix": Time.get_unix_time_from_system(),
		"trigger_note": str(validate(workflow, context).get("message", "")),
		"pause_requested": false
	}
	for step in candidate["workflow"]["steps"]:
		var item: Dictionary = step.duplicate(true)
		item.merge({"state": "pending", "output": "", "error": "", "attempts": []})
		candidate["steps"].append(item)
	if not _persist_record(candidate):
		return _error("无法保存运行记录，尚未派发任何步骤。请检查数据目录是否可写。")
	# 每次开始新运行顺手回收旧的已完成记录；未结束的一律保留（见 prune_records）。
	prune_records()
	record = candidate
	_generation += 1
	_prepared = false
	_remote_in_flight = false
	_confirmed_step = -1
	_failures_this_run = 0
	changed.emit()
	_drive.call_deferred(_generation)
	return {"ok": true, "id": str(record["id"]), "message": str(record["trigger_note"])}

func pause() -> void:
	if not str(record.get("state", "")) in ["preparing", "running", "pausing"]:
		return
	record["pause_requested"] = true
	record["state"] = "pausing"
	record["message"] = "已请求暂停；当前步骤完成后停止派发下一步。"
	_save()

func resume() -> void:
	if str(record.get("state", "")) != "paused":
		return
	var available := _availability()
	if not bool(available.get("ok", false)):
		record["message"] = str(available.get("error", "执行通道暂不可用。"))
		_save()
		return
	record["pause_requested"] = false
	record["state"] = "running"
	record["message"] = "继续运行。"
	if _save():
		_drive.call_deferred(_generation)

func retry() -> void:
	if str(record.get("state", "")) != "failed":
		return
	var available := _availability()
	if not bool(available.get("ok", false)):
		record["message"] = str(available.get("error", "执行通道暂不可用。"))
		_save()
		return
	var index := int(record.get("step_index", -1))
	if index < 0 or index >= record.get("steps", []).size():
		return
	var step: Dictionary = record["steps"][index]
	# An uncertain result never reaches failed; it must first be confirmed stopped.
	# A retry is always a new, explicit user operation and retains prior attempts.
	step["state"] = "pending"
	step["error"] = ""
	step["output"] = ""
	record["pause_requested"] = false
	record["finished_at"] = ""
	record["failure_stage"] = ""
	record["state"] = "preparing"
	record["message"] = "按你的操作重试当前步骤；此前完成的步骤不会重复执行。"
	_generation += 1
	_prepared = false
	_confirmed_step = -1
	if _save():
		_drive.call_deferred(_generation)

func cancel() -> void:
	if not is_active() or str(record.get("state", "")) == "cancelling":
		return
	_generation += 1
	var token := _generation
	record["pause_requested"] = false
	record["state"] = "cancelling"
	record["message"] = "正在请求停止；确认停止前不会允许新运行。"
	# Cancellation must still be attempted when the disk is unwritable.
	_touch()
	if not _persist_record(record):
		record["storage_error"] = "停止状态暂未写入磁盘。"
	changed.emit()
	_cancel_remote.call_deferred(token)

func answer(text: String) -> void:
	var state := str(record.get("state", ""))
	if not state in ["waiting_input", "waiting_confirmation"]:
		return
	if text.strip_edges().is_empty():
		return
	var index := int(record["step_index"])
	if state == "waiting_confirmation":
		if text.strip_edges() != "确认":
			record["message"] = "请点击确认执行，或取消本次运行。"
			_save()
			return
		_confirmed_step = index
		record["steps"][index]["state"] = "pending"
		record["steps"][index]["confirmed_at"] = _now()
	else:
		_begin_attempt(index)
		_finish_attempt(index, {"ok": true, "text": text})
		record["step_index"] = index + 1
	record["state"] = "running"
	record["message"] = "已收到，继续运行。"
	if _save():
		_drive.call_deferred(_generation)

func _drive(token: int) -> void:
	if token != _generation or _driver_generation == token:
		return
	_driver_generation = token
	await _drive_loop(token)
	if _driver_generation == token:
		_driver_generation = -1

func _drive_loop(token: int) -> void:
	while _can_continue(token):
		if bool(record.get("pause_requested", false)):
			record["state"] = "paused"
			record["message"] = "已暂停。继续后从下一待执行步骤开始。"
			_save()
			return
		var index := int(record["step_index"])
		if index >= record["steps"].size():
			record["state"] = "completed"
			record["message"] = "全部步骤已完成。"
			record["finished_at"] = _now()
			_save()
			return
		var step: Dictionary = record["steps"][index]
		var kind := str(step["type"])
		if kind == "用户交互":
			step["state"] = "waiting_input"
			record["state"] = "waiting_input"
			record["message"] = str(step["detail"]) if not str(step["detail"]).strip_edges().is_empty() else "请补充本步骤需要的信息。"
			_save()
			return
		if kind == "输入":
			_begin_attempt(index)
			record["state"] = "running"
			record["message"] = "整理输入：%s" % str(step["name"])
			if not _save():
				return
			var parts: Array[String] = []
			for value in [str(record["context"].get("input", "")), str(step["detail"])]:
				if not value.strip_edges().is_empty():
					parts.append(value)
			_finish_attempt(index, {"ok": true, "text": "\n\n".join(parts)})
			record["step_index"] = index + 1
			if not _save():
				return
			continue
		if _needs_confirmation() and _confirmed_step != index:
			step["state"] = "waiting_confirmation"
			record["state"] = "waiting_confirmation"
			record["message"] = "规则要求逐步确认。即将执行第 %d 步“%s”（%s）：\n%s\n\n确认后将把本轮输入、前步结果、技能及规则说明交给对应的执行服务（Harness 或 WeKnora）。" % [index + 1, str(step["name"]), kind, str(step["detail"])]
			_save()
			return
		if not _prepared:
			record["state"] = "preparing"
			record["message"] = "准备 Harness 执行通道。"
			if not _save():
				return
			_remote_in_flight = true
			var prepared: Dictionary = await _transport.prepare(_execution_context(index))
			if not _can_continue(token):
				return
			_remote_in_flight = false
			if not bool(prepared.get("ok", false)):
				if _fail(index, prepared, "prepare"):
					continue
				return
			_prepared = true
			if bool(record.get("pause_requested", false)):
				continue
		_begin_attempt(index)
		record["state"] = "running"
		record["message"] = "正在执行第 %d / %d 步：%s" % [index + 1, record["steps"].size(), str(step["name"])]
		if not _save():
			return
		_remote_in_flight = true
		var result: Dictionary = await _transport.execute_step(_step_snapshot(step), _execution_context(index))
		if not _can_continue(token):
			return
		_remote_in_flight = false
		_confirmed_step = -1
		_finish_attempt(index, result)
		if not bool(result.get("ok", false)) or bool(result.get("uncertain", false)):
			if _fail(index, result, "step"):
				continue
			return
		record["step_index"] = index + 1
		if not _save():
			return

func _cancel_remote(token: int) -> void:
	var result: Dictionary = {"ok": true}
	if is_instance_valid(_transport) and _transport.has_method("cancel"):
		result = await _transport.cancel()
	elif _remote_in_flight:
		result = {"ok": false, "error": "执行通道不可用，无法确认远端是否停止。"}
	if token != _generation or str(record.get("state", "")) != "cancelling":
		return
	if bool(result.get("ok", false)):
		_remote_in_flight = false
		record["state"] = "cancelled"
		record["message"] = "已确认停止；已完成的步骤和结果仍保留。"
		record["finished_at"] = _now()
		var index := int(record.get("step_index", -1))
		if index >= 0 and index < record["steps"].size() and str(record["steps"][index]["state"]) != "completed":
			record["steps"][index]["state"] = "cancelled"
			_close_open_attempt(index, "cancelled", "已确认停止。")
	else:
		record["state"] = "stop_unconfirmed"
		record["message"] = "停止尚未确认，不能新建或重试，以免重复执行。请再次点击取消或在 Harness 中检查。\n" + str(result.get("error", ""))
	_touch()
	if not _persist_record(record):
		record["storage_error"] = "当前停止结果暂未保存，关闭程序前请保留处理结果。"
	changed.emit()

func _fail(index: int, result: Dictionary, stage: String) -> bool:
	var uncertain := bool(result.get("uncertain", false))
	var error := str(result.get("error", "执行失败。"))
	# 只有明确未投递、或执行通道明确声明可安全重试的失败才能自动重试。
	# “停止成功”不等于“没有产生副作用”；远端任务可能在停止前已经修改过文件。
	var safe_to_retry := stage == "prepare" or bool(result.get("safe_to_retry", false))
	# ── [DSH] 失败处理策略 ────────────────────────────────────────────
	# 工作流中心里的“默认失败处理”选项此前只是个摆设：runner 写死了失败即停。
	# 这里让它真正生效。两条不可逾越的边界：
	#   1) uncertain（远端状态未确认）永不自动重试——那正是 uncertain 机制存在的理由：
	#      远端可能已经执行过，重试会造成重复操作；
	#   2) 每次尝试都重新建会话（transport 侧的 step_used 机制保证），
	#      因此重试时 _confirmed_step 必须复位，否则“执行前询问”规则会把重试卡在确认页。
	if not uncertain:
		var step_ref: Dictionary = record["steps"][index] if index >= 0 and index < record["steps"].size() else {}
		var action := decide_failure_action(_failure_policy(), uncertain, int(step_ref.get("retry_count", 0)), safe_to_retry)
		if action == "retry":
			step_ref["retry_count"] = int(step_ref.get("retry_count", 0)) + 1
			step_ref["state"] = "pending"
			step_ref["error"] = ""
			# 回退本步 output：本次尝试的失败输出不能留给后续步骤。
			step_ref["output"] = str(step_ref.get("output_before_attempt", ""))
			step_ref.erase("output_before_attempt")
			_confirmed_step = -1
			record["state"] = "running"
			record["message"] = "%s\n已按“重试一次”重新执行本步（%s）。" % [error, stage]
			_remote_in_flight = false
			_failures_this_run += 1
			if _save():
				return true
		if action == "skip":
			step_ref["state"] = "skipped"
			step_ref["error"] = error
			step_ref["output"] = ""
			# 跳过时清掉本步的部分结果，避免后面的步骤把它当成可用前序结果。
			step_ref.erase("output_before_attempt")
			_failures_this_run += 1
			record["step_index"] = index + 1
			record["state"] = "running"
			record["message"] = "第 %d 步失败（%s），已按“跳过步骤”继续：%s" % [index + 1, stage, error]
			_remote_in_flight = false
			if _save():
				return true
	_remote_in_flight = uncertain
	record["failure_stage"] = stage
	record["state"] = "stop_unconfirmed" if uncertain else "failed"
	record["message"] = error
	if uncertain:
		record["message"] += "\n远端状态尚未确认，不能重新运行。请先点击取消确认停止。"
	else:
		record["finished_at"] = _now()
		# 文案要反映当前策略：原来的“旧的自动重试/跳过设置不会自动执行”已经不成立。
		var policy := _failure_policy()
		if policy == "重试一次" and _failures_this_run > 0:
			record["message"] += "\n已按“重试一次”重试过本步，仍然失败；已停止派发后续步骤。"
		elif policy == "跳过步骤" and _failures_this_run > 0:
			record["message"] += "\n已停止派发后续步骤。"
		else:
			record["message"] += "\n已停止派发后续步骤。请检查已有产物后手动重试。"
	if index >= 0 and index < record["steps"].size():
		record["steps"][index]["state"] = "stop_unconfirmed" if uncertain else "failed"
		record["steps"][index]["error"] = error
		record["steps"][index].erase("output_before_attempt")
	_save()
	return false

# 本次运行的“默认失败处理”设置。取自工作流快照，缺省为暂停并询问（即停下等用户）。
func _failure_policy() -> String:
	return normalize_failure_policy(record.get("workflow", {}).get("failure", "暂停并询问"))

static func normalize_failure_policy(value: Variant) -> String:
	var policy := str(value)
	return policy if policy in ["暂停并询问", "停止", "重试一次", "跳过步骤"] else "暂停并询问"

# 失败后该怎么做。抽成纯函数以便直接断言——它承载两条安全边界，不能只靠人工检查：
#   · uncertain（远端状态未确认）永不自动重试，否则会造成重复操作；
#   · 只有明确 safe_to_retry 的失败才可自动重试；
#   · 自动重试最多一次，靠 retry_count 强制，避免无限循环。
# 返回 "retry" / "skip" / "stop"。
static func decide_failure_action(policy: Variant, uncertain: bool, retry_count: int, safe_to_retry := false) -> String:
	if uncertain:
		return "stop"
	match normalize_failure_policy(policy):
		"重试一次":
			return "retry" if safe_to_retry and retry_count < 1 else "stop"
		"跳过步骤":
			return "skip"
		_:
			# “暂停并询问”与“停止”都停在失败处等用户决定；
			# 两者当前的差别只在文案，行为一致，不做过度区分。
			return "stop"

func _begin_attempt(index: int) -> void:
	var step: Dictionary = record["steps"][index]
	step["state"] = "running"
	step["attempts"].append({"started_at": _now(), "finished_at": "", "state": "running", "output": "", "error": "", "safe_to_retry": false})
	# 自动重试要把本步结果回退到本次尝试之前：_finish_attempt 会把 output 写成
	# 本次（失败的）结果，而后续步骤看到的前序结果必须是上一次成功的内容。
	if not step.has("output_before_attempt"):
		step["output_before_attempt"] = str(step.get("output", ""))

func _finish_attempt(index: int, result: Dictionary) -> void:
	var step: Dictionary = record["steps"][index]
	var state := "completed" if bool(result.get("ok", false)) else "failed"
	if bool(result.get("uncertain", false)):
		state = "stop_unconfirmed"
	step["state"] = state
	step["output"] = str(result.get("text", ""))
	step["error"] = str(result.get("error", ""))
	var attempt: Dictionary = step["attempts"].back()
	attempt.merge({"finished_at": _now(), "state": state, "output": step["output"], "error": step["error"], "safe_to_retry": bool(result.get("safe_to_retry", false))}, true)

func _close_open_attempt(index: int, state: String, error: String) -> void:
	var attempts: Array = record["steps"][index].get("attempts", [])
	if attempts.is_empty():
		return
	var attempt: Dictionary = attempts.back()
	if str(attempt.get("state", "")) == "running":
		attempt.merge({"state": state, "finished_at": _now(), "error": error}, true)

func _can_continue(token: int) -> bool:
	return token == _generation and str(record.get("state", "")) in ["preparing", "running", "pausing"]

func _needs_confirmation() -> bool:
	for rule in record.get("context", {}).get("rules", []):
		if str(rule.get("decision", "")) in ["执行前询问", "预览后提交"]:
			return true
	return false

func _availability() -> Dictionary:
	if not is_instance_valid(_transport):
		return _error("Harness 执行通道尚未初始化。")
	for method in ["is_available", "prepare", "execute_step", "cancel"]:
		if not _transport.has_method(method):
			return _error("Harness 执行通道缺少必要接口：%s。" % method)
	return _transport.is_available()

func _execution_context(index: int) -> Dictionary:
	var context: Dictionary = record["context"].duplicate(true)
	var outputs: Array = []
	for previous in index:
		var step: Dictionary = record["steps"][previous]
		if str(step.get("state", "")) == "completed":
			outputs.append({"name": str(step["name"]), "output": str(step["output"])})
	context["previous_outputs"] = outputs
	return context

func _save() -> bool:
	_touch()
	if _persist_record(record):
		var token := _generation
		changed.emit()
		return token == _generation
	_generation += 1
	var uncertain := _remote_in_flight or str(record.get("state", "")) == "stop_unconfirmed"
	record["state"] = "stop_unconfirmed" if uncertain else "failed"
	record["message"] = "运行记录写入失败，已停止派发后续步骤。请检查数据目录。"
	if uncertain:
		record["message"] += "当前远端步骤可能仍在运行，请点击取消确认停止。"
	record["storage_error"] = record["message"]
	changed.emit()
	return false

func _persist_record(value: Dictionary) -> bool:
	var id := str(value.get("id", ""))
	if records_path.is_empty() or not _safe_id(id):
		return false
	return AtomicFile.write_text(records_path.path_join(id + ".json"), JSON.stringify(value, "\t"))

# 运行记录保留策略。
#
# 每次状态转换都会把整份记录写盘（含每步 output 与 attempts），而且从不清理，
# 所以跑得越多目录越大，history() 每次还要遍历全部文件。
# 这里按"文件修改时间"保留最近 KEEP_RECENT_RUNS 份已完成运行；
# 未结束的运行（含 stop_unconfirmed）一律保留——它们承载着"远端可能仍在执行"
# 这个必须让用户看到的信息，删掉会让重复执行的风险变得不可见。
const KEEP_RECENT_RUNS := 40

func prune_records(keep := KEEP_RECENT_RUNS) -> Dictionary:
	return prune_records_in(records_path, keep)

# 保留策略本体。做成静态 + 显式传目录，是为了能脱离运行器实例单独自检。
static func prune_records_in(directory: String, keep := KEEP_RECENT_RUNS) -> Dictionary:
	var removed := 0
	var kept := 0
	if directory.is_empty() or not DirAccess.dir_exists_absolute(directory):
		return {"removed": 0, "kept": 0}
	var candidates: Array[Dictionary] = []
	for file_name in DirAccess.get_files_at(directory):
		if not file_name.ends_with(".json"):
			continue
		var path := directory.path_join(file_name)
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		var data: Dictionary = parsed if parsed is Dictionary else {}
		var state := str(data.get("state", ""))
		var finished := not state.is_empty() and not state in ACTIVE_STATES
		# 只有"正常结束"的运行才可回收；异常收尾的一律留着——
		# stop_unconfirmed 承载着"远端可能仍在执行"这个必须让用户看到的信息，
		# 删掉它会让重复执行的风险变得不可见。
		var reclaimable := finished and not state in ["stop_unconfirmed", "failed"]
		candidates.append({
			"path": path, "name": file_name, "reclaimable": reclaimable,
			"modified": FileAccess.get_modified_time(path)
		})
	# 修改时间是秒级精度：同一秒内写入的多条记录时间戳相同，只按时间排序结果不确定。
	# 用文件名做确定性的二级排序，保证"保留哪些、回收哪些"是可复现的。
	candidates.sort_custom(func(left: Dictionary, right: Dictionary) -> bool:
		var left_time := int(left["modified"])
		var right_time := int(right["modified"])
		if left_time != right_time:
			return left_time > right_time
		return str(left["name"]) > str(right["name"])
	)
	# 按"全部记录"的位次判断是否超出保留窗口，再决定能否删：
	# 这样前面堆着大量异常运行时，也不会把正常记录挤掉。
	var sighted := 0
	for entry in candidates:
		sighted += 1
		if not bool(entry["reclaimable"]) or sighted <= keep:
			kept += 1
			continue
		if DirAccess.remove_absolute(str(entry["path"])) == OK:
			removed += 1
		else:
			kept += 1
	return {"removed": removed, "kept": kept}

# 自检：确认保留策略只回收"正常结束且超出窗口"的记录，
# 并且绝不动未结束、失败或待确认停止的记录。
static func selftest(directory: String) -> Dictionary:
	var failures: Array[String] = []
	if DirAccess.make_dir_recursive_absolute(directory) != OK and not DirAccess.dir_exists_absolute(directory):
		return {"ok": false, "failures": ["无法创建自检目录：%s" % directory], "cases": 0}
	# 必须从干净状态开始：上一轮失败的用例会留下同名记录，
	# 残留文件会改变"位次"，让断言因无关原因失败（实测踩过）。
	for stale in DirAccess.get_files_at(directory):
		if stale.ends_with(".json"):
			DirAccess.remove_absolute(directory.path_join(stale))
	# 造 8 条记录：6 条正常完成 + 1 条失败 + 1 条待确认停止。
	# 命名保证"字母越大越新"：修改时间是秒级，同一秒内写入时排序只能靠文件名，
	# 因此自检必须按文件名设计预期，否则断言会随机失败（实测踩过）。
	var definitions := [
		{"id": "run_a1_completed", "state": "completed"},
		{"id": "run_a2_completed", "state": "completed"},
		{"id": "run_a3_completed", "state": "completed"},
		{"id": "run_a4_completed", "state": "completed"},
		{"id": "run_a5_completed", "state": "completed"},
		{"id": "run_a6_completed", "state": "completed"},
		{"id": "run_a7_failed", "state": "failed"},
		{"id": "run_a8_unconfirmed", "state": "stop_unconfirmed"},
	]
	for definition in definitions:
		var record := {"id": definition["id"], "state": definition["state"], "steps": []}
		var path := directory.path_join(str(definition["id"]) + ".json")
		AtomicFile.write_text(path, JSON.stringify(record))
	# 保留窗口 = 4。最新的 4 条是 a8、a7、a6、a5：
	# a7/a8 本身就不可回收，a5/a6 在窗口内，因此只有 a1~a4 里超出窗口的两条会被删。
	# 注意窗口按"全部记录的位次"计，不可回收的记录同样占位次——
	# 否则前面堆一堆失败运行就会把正常记录挤掉。
	# 保留窗口 = 4：8 条记录里最旧的 4 条都是 completed，因此应删 4 条，
	# 留下 a5/a6（窗口内）与 a7/a8（本来就不回收）。
	# 这里刻意让"窗口内"同时包含可回收与不可回收两种记录，覆盖位次计算的边界。
	var result := prune_records_in(directory, 4)
	if int(result.get("removed", 0)) != 4:
		failures.append("应回收 4 条，实际 %d" % int(result.get("removed", 0)))
	for must_keep in ["run_a5_completed", "run_a6_completed", "run_a7_failed", "run_a8_unconfirmed"]:
		if not FileAccess.file_exists(directory.path_join(must_keep + ".json")):
			failures.append("不该被回收的记录被删了：%s" % must_keep)
	for must_remove in ["run_a1_completed", "run_a2_completed", "run_a3_completed", "run_a4_completed"]:
		if FileAccess.file_exists(directory.path_join(must_remove + ".json")):
			failures.append("超出窗口的已完成记录没有被回收：%s" % must_remove)
	# 关键安全断言：保留窗口小到 1 时，异常收尾的记录也一条都不能删。
	# 注意不能断言"removed=0"——这里文件的修改时间可能已经跨过秒边界，
	# 窗口内还剩哪几条 completed 取决于实际 mtime，而不是名字。
	# 真正要守的是一条与排序无关的性质：不可回收的记录永不消失。
	var tiny := prune_records_in(directory, 1)
	for must_keep in ["run_a7_failed", "run_a8_unconfirmed"]:
		if not FileAccess.file_exists(directory.path_join(must_keep + ".json")):
			failures.append("窗口极小时异常记录被删了：%s" % must_keep)
	# 再连跑几次极小窗口：无论排序如何变化，异常记录都必须一直在。
	for _round in range(3):
		prune_records_in(directory, 1)
		for must_keep in ["run_a7_failed", "run_a8_unconfirmed"]:
			if not FileAccess.file_exists(directory.path_join(must_keep + ".json")):
				failures.append("反复回收后异常记录消失：%s" % must_keep)
	print("RETENTION_SAFETY tiny_removed=", int(tiny.get("removed", 0)), " 异常记录仍在=", FileAccess.file_exists(directory.path_join("run_a8_unconfirmed.json")))
	# 目录不存在时不能崩。
	var missing := prune_records_in(directory.path_join("不存在"), 2)
	if int(missing.get("removed", 0)) != 0:
		failures.append("目录不存在时应回收 0 条")
	# 清理自检产物。
	for definition in definitions:
		var path := directory.path_join(str(definition["id"]) + ".json")
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)

	# 失败处理策略的决策断言。这里守的是两条安全边界，
	# 它们一旦被改坏会造成"重复执行"或"无限重试"，必须由断言而不是人工检查来保证。
	var policy_cases := [
		# [策略, uncertain, 已有重试次数, safe_to_retry, 期望动作]
		["暂停并询问", false, 0, false, "stop"],
		["停止", false, 0, false, "stop"],
		["重试一次", false, 0, true, "retry"],
		["重试一次", false, 1, true, "stop"],
		["重试一次", false, 0, false, "stop"],
		["跳过步骤", false, 0, false, "skip"],
		["跳过步骤", false, 5, false, "skip"],
		# 关键：远端状态未确认时，任何策略都不允许自动重试或跳过。
		["重试一次", true, 0, true, "stop"],
		["跳过步骤", true, 0, false, "stop"],
		["暂停并询问", true, 0, false, "stop"],
		# 未知/异常设置一律回落到最保守的"停下等用户"。
		["乱填的值", false, 0, true, "stop"],
		["", false, 0, true, "stop"],
	]
	for case_value in policy_cases:
		var case: Array = case_value
		var observed := decide_failure_action(case[0], bool(case[1]), int(case[2]), bool(case[3]))
		if observed != str(case[4]):
			failures.append("失败策略判定错误：policy=%s uncertain=%s retries=%s safe=%s 期望 %s 实际 %s" % [case[0], case[1], case[2], case[3], case[4], observed])
	# 两次失败必须只有一次自动重试：连续调用下动作应当从 retry 变为 stop。
	if decide_failure_action("重试一次", false, 0, true) != "retry" or decide_failure_action("重试一次", false, 1, true) != "stop":
		failures.append("“重试一次”没有做到最多重试一次")

	# ── [DSH] 失败处理策略的**状态流转**断言 ────────────────────────────
	# 只断言上面那个纯决策函数是不够的：曾经的真实缺陷是"决策函数返回 retry，
	# 但 _fail() 仍然直接 return，驱动循环就此停住"，任务被留在 running 状态不再推进。
	# 纯函数断言对这种缺陷完全无效，所以这里必须跑真正的 _fail()，检查
	#   ① 它告诉驱动循环"继续还是停止"（返回值），② 记录被改成了什么状态。
	failures.append_array(selftest_failure_flow(directory))

	return {"ok": failures.is_empty(), "failures": failures, "cases": 4 + policy_cases.size() + 10}

# [DSH] 失败策略端到端自检：真跑 _fail()，断言"是否继续驱动循环"与记录状态。
static func selftest_failure_flow(directory: String) -> Array[String]:
	var failures: Array[String] = []
	var fixture_ids: Array[String] = []
	if not directory.is_empty():
		DirAccess.make_dir_recursive_absolute(directory)
	var cases := [
		# [说明, 策略, safe_to_retry, 已有重试次数, uncertain, 期望继续驱动, 期望本步状态]
		["重试一次·安全失败", "重试一次", true, 0, false, true, "pending"],
		["重试一次·已重试过", "重试一次", true, 1, false, false, "failed"],
		["重试一次·但失败不安全", "重试一次", false, 0, false, false, "failed"],
		["跳过步骤", "跳过步骤", false, 0, false, true, "skipped"],
		["暂停并询问", "暂停并询问", true, 0, false, false, "failed"],
		["停止", "停止", true, 0, false, false, "failed"],
		# 关键安全边界：远端状态未确认时，即使策略是重试也要停，并且进入待确认状态。
		["重试一次·远端未确认", "重试一次", true, 0, true, false, "stop_unconfirmed"],
		["跳过步骤·远端未确认", "跳过步骤", false, 0, true, false, "stop_unconfirmed"],
		# 重试必须回退本步输出，否则失败结果会污染后续步骤的前序输入。
		["重试一次·输出回退", "重试一次", true, 0, false, true, "pending"],
		# 跳过必须清空本步输出。
		["跳过步骤·输出清空", "跳过步骤", false, 0, false, true, "skipped"],
	]
	for index in cases.size():
		var case: Array = cases[index]
		var runner: Node = _make_failure_fixture(directory, index, str(case[1]), bool(case[2]), int(case[3]))
		# 先记下 id：_fail() 的成功分支会提前返回，收尾代码不能依赖执行到末尾，
		# 否则夹具记录会留在自检目录里，让下一轮保留策略断言看到脏状态（实测踩过）。
		var fixture_id := str(runner.record.get("id", ""))
		fixture_ids.append(fixture_id)
		var result := {"error": "模拟失败", "uncertain": bool(case[4]), "safe_to_retry": bool(case[2])}
		var continued: bool = runner._fail(0, result, "step")
		var step: Dictionary = runner.record["steps"][0]
		if continued != bool(case[5]):
			failures.append("%s：期望继续驱动=%s，实际=%s" % [case[0], case[5], continued])
		if str(step.get("state", "")) != str(case[6]):
			failures.append("%s：期望本步状态=%s，实际=%s" % [case[0], case[6], step.get("state", "")])
		# 继续驱动时整体状态必须是 running，否则驱动循环看到非活动状态就不会推进。
		if bool(case[5]) and str(runner.record.get("state", "")) != "running":
			failures.append("%s：要继续驱动，但整体状态是 %s" % [case[0], runner.record.get("state", "")])
		# 不继续时必须真的停下。注意 stop_unconfirmed 按设计属于"活动"状态
		# （它承载"远端可能仍在执行"，要等用户确认停止），所以这里只否定 failed。
		if not bool(case[5]) and str(runner.record.get("state", "")) not in ["failed", "stop_unconfirmed"]:
			failures.append("%s：应当停止，但整体状态是 %s" % [case[0], runner.record.get("state", "")])
		if index == 0:
			if int(step.get("retry_count", 0)) != 1:
				failures.append("重试一次·安全失败：retry_count 没有递增")
			if str(step.get("output", "")) != "上一次的结果":
				failures.append("重试一次·安全失败：没有回退本步输出，失败结果会污染后续步骤")
		if index == 3 and not str(step.get("output", "")).is_empty():
			failures.append("跳过步骤：没有清空本步输出")
		runner.free()
	# 统一收尾：无论上面哪条分支提前返回，夹具记录都必须清干净。
	if not directory.is_empty():
		for fixture_id in fixture_ids:
			var fixture_path := directory.path_join(fixture_id + ".json")
			if FileAccess.file_exists(fixture_path):
				DirAccess.remove_absolute(fixture_path)
	return failures

# 造一个只用于失败流转断言的运行器：一步、处于 running、带一次在途尝试。
static func _make_failure_fixture(directory: String, index: int, policy: String, safe_to_retry: bool, retry_count: int) -> Node:
	var script: GDScript = load("res://workflow_runner.gd")
	var runner: Node = script.new()
	runner.setup(directory, null)
	var step := {
		"id": "step_%d" % index, "name": "第 %d 步" % (index + 1), "type": "Harness执行",
		"state": "running", "output": "本次尝试已产生的部分结果", "error": "", "retry_count": retry_count,
		# output_before_attempt 由 _begin_attempt() 在本次尝试开始前写入，
		# 这里必须照同样的约定造出来，否则测不到"重试要回退输出"这条性质。
		"output_before_attempt": "上一次的结果",
		"attempts": [{"state": "running", "safe_to_retry": safe_to_retry}]
	}
	runner.record = {
		# id 必须以 run_ 开头：_safe_id() 会拒绝其他前缀，导致 _save() 静默失败，
		# 于是所有"继续驱动"路径都会退化成"停止"——这个夹具自己踩过一次。
		"id": "run_failure_flow_%d" % index, "state": "running", "step_index": 0,
		"workflow": {"failure": policy, "steps": []}, "steps": [step]
	}
	return runner

func read_record_file(path: String) -> Dictionary:
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	return parsed if parsed is Dictionary else {}

func _touch() -> void:
	record["updated_at"] = _now()
	record["updated_unix"] = Time.get_unix_time_from_system()

func history() -> Array:
	var result: Array = []
	if records_path.is_empty() or not DirAccess.dir_exists_absolute(records_path):
		return result
	for file in DirAccess.get_files_at(records_path):
		if not file.ends_with(".json"):
			continue
		var item := load_record(file.trim_suffix(".json"))
		if not item.is_empty():
			result.append(item)
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return float(a.get("updated_unix", 0.0)) > float(b.get("updated_unix", 0.0)))
	return result.slice(0, 30)

func load_record(id: String) -> Dictionary:
	if not _safe_id(id) or records_path.is_empty():
		return {}
	if id == str(record.get("id", "")):
		return snapshot()
	var path := records_path.path_join(id + ".json")
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 64 * 1024 * 1024:
		return {}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary or str(parsed.get("id", "")) != id:
		return {}
	if not parsed.get("workflow", null) is Dictionary or not parsed.get("context", null) is Dictionary or not parsed.get("steps", null) is Array:
		return {}
	for step in parsed["steps"]:
		if not step is Dictionary or not step.get("attempts", []) is Array:
			return {}
		for attempt in step.get("attempts", []):
			if not attempt is Dictionary:
				return {}
	var restored: Dictionary = parsed
	restored["read_only"] = true
	if str(restored.get("state", "")) in ACTIVE_STATES:
		restored["previous_state"] = restored["state"]
		restored["state"] = "interrupted"
		restored["message"] = "上次运行未正常结束，记录仅供查看。不会自动恢复或重放；重新运行前请先确认 Harness 和已有产物。"
	return restored

func _new_id() -> String:
	var id := "run_" + Crypto.new().generate_random_bytes(16).hex_encode()
	while FileAccess.file_exists(records_path.path_join(id + ".json")):
		id = "run_" + Crypto.new().generate_random_bytes(16).hex_encode()
	return id

func _safe_id(id: String) -> bool:
	if not id.begins_with("run_") or id.length() < 5 or id.length() > 80:
		return false
	for character in id:
		if not character in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-":
			return false
	return true

func _workflow_snapshot(source: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for key in ["id", "name", "trigger", "failure", "created_at", "updated_at"]:
		result[key] = str(source.get(key, ""))
	result["version"] = int(source.get("version", 0))
	result["enabled"] = bool(source.get("enabled", false))
	result["confirmed"] = bool(source.get("confirmed", false))
	result["steps"] = []
	for step in source.get("steps", []):
		result["steps"].append(_step_snapshot(step))
	return result

func _step_snapshot(source: Dictionary) -> Dictionary:
	var result := {"id": str(source.get("id", "")), "name": str(source.get("name", "")), "type": str(source.get("type", "")), "detail": str(source.get("detail", ""))}
	if str(source.get("type", "")) in Knowledge.TYPES:
		result["knowledge"] = Knowledge.settings(source.get("knowledge", {}))
	return result

func _context_snapshot(source: Dictionary) -> Dictionary:
	var result := {"input": str(source.get("input", "")), "workspace": str(source.get("workspace", "")), "skill_context": str(source.get("skill_context", "")), "rules": []}
	for rule in source.get("rules", []):
		if not bool(rule.get("enabled", false)) or not bool(rule.get("confirmed", false)):
			continue
		var cleaned := {"enabled": true, "confirmed": true}
		for key in ["id", "name", "scope", "category", "decision", "description"]:
			cleaned[key] = str(rule.get(key, ""))
		result["rules"].append(cleaned)
	return result

func _now() -> String:
	return Time.get_datetime_string_from_system(false, true)

func _error(message: String) -> Dictionary:
	return {"ok": false, "error": message}
