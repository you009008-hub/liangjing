# 透明宿主窗口调试网格。
# 只负责可视化真实窗口边界，MOUSE_FILTER_IGNORE 保证它永远不拦截桌面或桌宠交互。
extends Control

const GRID_STEP := 32.0
const MAJOR_GRID_EVERY := 5

var grid_enabled := true
var input_shape := PackedVector2Array()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	sync_to_window()
	get_window().size_changed.connect(sync_to_window)
	queue_redraw()

func sync_to_window() -> void:
	position = Vector2.ZERO
	size = Vector2(get_window().size)
	queue_redraw()

func set_grid_enabled(enabled: bool) -> void:
	grid_enabled = enabled
	visible = enabled
	queue_redraw()

func set_input_shape(shape: PackedVector2Array) -> void:
	if input_shape == shape:
		return
	input_shape = shape
	queue_redraw()

func _draw() -> void:
	if not grid_enabled:
		return
	var bounds := Rect2(Vector2.ZERO, size)
	# 网格属于真实桌宠宿主窗口本身，不创建第二个透明窗口。
	draw_rect(bounds, Color(0.035, 0.24, 0.43, 0.055 if not input_shape.is_empty() else 0.20), true)
	if not input_shape.is_empty():
		draw_colored_polygon(input_shape, Color(0.035, 0.24, 0.43, 0.20))

	var column_count := int(ceil(size.x / GRID_STEP))
	var row_count := int(ceil(size.y / GRID_STEP))
	for column in range(column_count):
		for row in range(row_count):
			var cell_center := Vector2((float(column) + 0.5) * GRID_STEP, (float(row) + 0.5) * GRID_STEP)
			if not input_shape.is_empty() and not Geometry2D.is_point_in_polygon(cell_center, input_shape):
				continue
			if (column + row) % 2 == 0:
				var cell_position := Vector2(float(column) * GRID_STEP, float(row) * GRID_STEP)
				draw_rect(Rect2(cell_position, Vector2(GRID_STEP, GRID_STEP)), Color(0.10, 0.63, 0.92, 0.035), true)

	if input_shape.is_empty():
		for column in range(column_count + 1):
			var x := minf(float(column) * GRID_STEP, size.x)
			var major := column % MAJOR_GRID_EVERY == 0
			draw_line(Vector2(x, 0), Vector2(x, size.y), Color(0.28, 0.76, 1.0, 0.42 if major else 0.20), 1.5 if major else 1.0)
		for row in range(row_count + 1):
			var y := minf(float(row) * GRID_STEP, size.y)
			var major := row % MAJOR_GRID_EVERY == 0
			draw_line(Vector2(0, y), Vector2(size.x, y), Color(0.28, 0.76, 1.0, 0.42 if major else 0.20), 1.5 if major else 1.0)
	else:
		var closed_shape := input_shape.duplicate()
		closed_shape.append(input_shape[0])
		draw_polyline(closed_shape, Color(0.35, 0.86, 1.0, 0.98), 3.0, true)

	# 没有自定义命中区时继续显示真实矩形；工作区则只突出 T 形有效点击区。
	if input_shape.is_empty():
		draw_rect(bounds.grow(-1.5), Color(0.38, 0.86, 1.0, 0.95), false, 3.0)
		draw_rect(bounds.grow(-5.0), Color(0.05, 0.34, 0.66, 0.72), false, 1.0)

	var label_text := ""
	if size.x < 500.0:
		if absf(size.x - 271.0) < 2.0 and absf(size.y - 522.0) < 2.0:
			label_text = "人物投影区  %d × %d px" % [int(size.x), int(size.y)]
		else:
			label_text = "知识工具  %d × %d px  ·  F8 关闭网格" % [int(size.x), int(size.y)]
	elif absf(size.x - 978.0) < 2.0 and absf(size.y - 514.0) < 2.0:
		label_text = "家具场景  %d × %d px  ·  F8 关闭网格" % [int(size.x), int(size.y)]
	elif absf(size.x - 560.0) < 2.0 and absf(size.y - 760.0) < 2.0:
		label_text = "模型中心  %d × %d px  ·  F8 关闭网格" % [int(size.x), int(size.y)]
	else:
		label_text = "智能工作区  %d × %d px  ·  F8 关闭网格" % [int(size.x), int(size.y)]
	var font := ThemeDB.fallback_font
	var font_size := 16
	var text_size := font.get_string_size(label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)
	var label_rect := Rect2(Vector2(14, 12), text_size + Vector2(22, 14))
	draw_style_box(make_label_style(), label_rect)
	draw_string(font, label_rect.position + Vector2(11, 7 + font.get_ascent(font_size)), label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0.86, 0.97, 1.0, 0.98))

func make_label_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.18, 0.34, 0.88)
	style.border_color = Color(0.33, 0.79, 1.0, 0.82)
	style.set_border_width_all(1)
	style.set_corner_radius_all(8)
	return style
