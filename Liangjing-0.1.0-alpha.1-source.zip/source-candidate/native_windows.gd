extends RefCounted

# Only the pet and screenshot overlay are frameless. Tools use the OS frame.
static func configure(window: Window) -> void:
	window.gui_embed_subwindows = false
	window.borderless = false
	window.transparent = false
	window.unresizable = false
	window.transient = false
	window.exclusive = false
	window.always_on_top = false
	window.wrap_controls = false
	window.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	window.content_scale_size = Vector2i.ZERO
	window.max_size = Vector2i.ZERO
	window.min_size = Vector2i(320, 240)
	window.transparent_bg = false
	window.mouse_passthrough = false
	window.mouse_passthrough_polygon = PackedVector2Array()


static func fit(window: Window, requested: Vector2i = Vector2i.ZERO) -> void:
	var usable := DisplayServer.screen_get_usable_rect(window.current_screen)
	if usable.size.x <= 0 or usable.size.y <= 0:
		return
	# Reserve space for the Windows title bar, borders, and taskbar.
	var limit := Vector2i(maxi(160, usable.size.x - 32), maxi(120, usable.size.y - 72))
	window.min_size = Vector2i(mini(320, limit.x), mini(240, limit.y))
	window.max_size = Vector2i.ZERO
	var wanted := window.size if requested == Vector2i.ZERO else requested
	window.size = Vector2i(clampi(wanted.x, window.min_size.x, limit.x), clampi(wanted.y, window.min_size.y, limit.y))
	window.position = usable.position + (usable.size - window.size) / 2


static func mount(window: Window, panel: Control) -> void:
	if panel.has_meta("native_scroll_host"):
		return
	var scroll := ScrollContainer.new()
	scroll.name = "NativeContentScroll"
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	window.add_child(scroll)
	panel.reparent(scroll)
	panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	panel.position = Vector2.ZERO
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.set_meta("native_scroll_host", true)
	if panel is PanelContainer:
		var previous := panel.get_theme_stylebox("panel")
		var style: StyleBoxFlat = previous.duplicate() if previous is StyleBoxFlat else StyleBoxFlat.new()
		style.set_corner_radius_all(0)
		style.set_border_width_all(0)
		style.shadow_size = 0
		style.set_content_margin_all(12)
		panel.add_theme_stylebox_override("panel", style)
	strip_chrome.call_deferred(panel)


static func strip_chrome(node: Node) -> void:
	for child in node.get_children():
		if child is HBoxContainer and child.mouse_default_cursor_shape == Control.CURSOR_MOVE:
			child.hide()
		else:
			strip_chrome(child)
