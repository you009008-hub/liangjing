# [DSH] 知识库连接配置（梁鲸作为中台时的后端选择）。
#
# 定位：梁鲸负责投喂与提问，WeKnora 负责解析、分块、索引与检索。
# 本文件只管"连哪儿、用哪个知识库、钥匙怎么存"，不做任何网络请求（见 weknora_client.gd）。
#
# 两条硬约定，与模型中心保持一致：
#   1. 配置走原子写（崩溃不会留下半截 JSON）；
#   2. API Key 走设备绑定加密，**永远不落明文**。加密密钥复用 deepseek_config.device_key()，
#      不另写一套派生逻辑——两套派生迟早会漂移。
#
# 地址安全策略：只允许 https，或回环 http。WeKnora 自建在本机时用 127.0.0.1；
# 如果它跑在另一台机器上，必须走反向代理加 TLS，不能拿 http 明文传 API Key。
extends Node

const AtomicFile = preload("res://atomic_file.gd")

const CONFIG_FILE := "知识库连接.json"
const SECRET_FILE := "weknora.key"
const MODE_LOCAL := "local"
const MODE_WEKNORA := "weknora"
const DEFAULT_HOST := "http://127.0.0.1:8080"
const API_SUFFIX := "/api/v1"

var config_directory := ""
var config_path := ""
var secret_path := ""
# 只要求"有个 device_key() 方法"：模型配置是 RefCounted 而不是 Node，所以这里用 Object。
var device_key_source: Object = null
var current := {}

func initialize(soul_root: String, key_source: Object) -> Dictionary:
	device_key_source = key_source
	config_directory = soul_root.path_join("配置")
	config_path = config_directory.path_join(CONFIG_FILE)
	secret_path = config_directory.path_join(SECRET_FILE)
	var error := DirAccess.make_dir_recursive_absolute(config_directory)
	if error != OK and error != ERR_ALREADY_EXISTS:
		return {"ok": false, "error": "无法创建配置目录。"}
	current = load_config()
	if not write_config():
		return {"ok": false, "error": "无法写入知识库连接配置。"}
	return {"ok": true, "config": current.duplicate(true), "has_key": has_api_key()}

func default_config() -> Dictionary:
	return {
		"version": 1,
		# 默认仍然是"本机知识库"：没有配好 WeKnora 之前，行为与以前完全一致。
		"mode": MODE_LOCAL,
		"host": "",
		"knowledge_base_ids": [],
		"default_knowledge_base_id": "",
		# 明文 HTTP 的显式放行开关。默认关闭：公网明文意味着 API Key 与资料正文
		# 经过的每一跳都能读到。用户自己的私有部署如果暂时没上 TLS，可以在面板里
		# 主动勾选——但必须是他知情的选择，不能是默认行为。
		"allow_insecure_http": false,
		"key_protection": "device-bound-aes-v1",
		"key_stored": false,
	}

func load_config() -> Dictionary:
	var parsed = null
	if FileAccess.file_exists(config_path):
		parsed = JSON.parse_string(FileAccess.get_file_as_string(config_path))
	var config := default_config()
	if parsed is Dictionary:
		for key in config.keys():
			if parsed.has(key):
				config[key] = parsed[key]
	# 类型兜底：坏配置不能让中台直接崩，也不能把 mode 变成空值。
	if not str(config.get("mode", "")) in [MODE_LOCAL, MODE_WEKNORA]:
		config["mode"] = MODE_LOCAL
	if not config.get("knowledge_base_ids", []) is Array:
		config["knowledge_base_ids"] = []
	var ids: Array = []
	for value in config.get("knowledge_base_ids", []):
		var text := str(value).strip_edges()
		if not text.is_empty() and not ids.has(text):
			ids.append(text)
	config["knowledge_base_ids"] = ids
	config["host"] = str(config.get("host", "")).strip_edges()
	config["default_knowledge_base_id"] = str(config.get("default_knowledge_base_id", "")).strip_edges()
	config["allow_insecure_http"] = bool(config.get("allow_insecure_http", false))
	config["key_protection"] = "device-bound-aes-v1"
	config["key_stored"] = has_api_key()
	return config

func write_config() -> bool:
	current["key_stored"] = has_api_key()
	return AtomicFile.write_text(config_path, JSON.stringify(current, "  ", false))

func get_mode() -> String:
	return str(current.get("mode", MODE_LOCAL))

func uses_weknora() -> bool:
	return get_mode() == MODE_WEKNORA and not get_host().is_empty() and has_api_key()

func set_mode(mode: String) -> Dictionary:
	if not mode in [MODE_LOCAL, MODE_WEKNORA]:
		return {"ok": false, "error": "不支持的知识库来源。"}
	if mode == MODE_WEKNORA:
		if get_host().is_empty():
			return {"ok": false, "error": "还没有填写 WeKnora 地址。"}
		if not has_api_key():
			return {"ok": false, "error": "还没有填写 WeKnora API Key。"}
	current["mode"] = mode
	if not write_config():
		return {"ok": false, "error": "配置写入失败。"}
	return {"ok": true}

func get_host() -> String:
	return str(current.get("host", "")).strip_edges()

func set_host(host: String) -> Dictionary:
	var clean := host.strip_edges().trim_suffix("/")
	if clean.is_empty():
		current["host"] = ""
		if not write_config():
			return {"ok": false, "error": "配置写入失败。"}
		return {"ok": true}
	var verdict := check_host(clean)
	if not bool(verdict.get("ok", false)):
		return {"ok": false, "error": str(verdict.get("error", "地址不可用。"))}
	current["host"] = clean
	if not write_config():
		return {"ok": false, "error": "配置写入失败。"}
	return {"ok": true}

# [DSH] 纯函数：地址安全策略。可断言，见 run_weknora_client_selftest。
static func is_safe_host(url: String) -> bool:
	var clean := url.strip_edges().to_lower()
	if clean.is_empty():
		return false
	if clean.begins_with("https://"):
		return clean.length() > "https://".length() + 1
	if clean.begins_with("http://127.0.0.1"):
		return true
	if clean.begins_with("http://localhost"):
		return true
	return false

# 纯函数：是不是一个"语法上合法的明文 http 地址"。放行开关只放宽这一个维度，
# 不会顺带把 ftp:// file:// 这类别的协议也放进来。
static func is_plain_http_host(url: String) -> bool:
	var clean := url.strip_edges().to_lower()
	if not clean.begins_with("http://"):
		return false
	var rest := clean.substr("http://".length())
	var authority := rest.split("/")[0]
	return not authority.strip_edges().is_empty()

func get_allow_insecure_http() -> bool:
	return bool(current.get("allow_insecure_http", false))

func set_allow_insecure_http(enabled: bool) -> bool:
	current["allow_insecure_http"] = enabled
	return write_config()

# 判定一个地址能不能用。返回 {ok, insecure, error}：
# insecure 为真表示"用户主动同意走明文公网"，界面必须持续提示这件事。
func check_host(url: String) -> Dictionary:
	var clean := url.strip_edges()
	if clean.is_empty():
		return {"ok": false, "insecure": false, "error": "请填写 WeKnora 的服务地址。"}
	if is_safe_host(clean):
		return {"ok": true, "insecure": false, "error": ""}
	if is_plain_http_host(clean):
		if get_allow_insecure_http():
			return {"ok": true, "insecure": true, "error": ""}
		return {
			"ok": false,
			"insecure": false,
			"error": "地址不安全：只允许 https，或本机的 http://127.0.0.1 / http://localhost。\n如果这是你自己的私有部署、暂时没有证书，可以在下面勾选「允许明文 HTTP」继续（风险自负）。",
		}
	return {"ok": false, "insecure": false, "error": "地址格式不支持：只接受 http:// 或 https:// 开头的服务根地址。"}

# [DSH] 纯函数：拼 API 根地址。用户可能填 http://127.0.0.1:8080、带尾斜杠、
# 或者直接把 /api/v1 也粘进来；这里统一成一个规范形态，避免出现 /api/v1/api/v1。
static func api_base_url(host: String) -> String:
	var clean := host.strip_edges().trim_suffix("/")
	if clean.is_empty():
		return ""
	if clean.ends_with(API_SUFFIX):
		return clean
	return clean + API_SUFFIX

func get_api_base_url() -> String:
	return api_base_url(get_host())

func get_knowledge_base_ids() -> Array:
	var ids: Array = []
	for value in current.get("knowledge_base_ids", []):
		ids.append(str(value))
	return ids

func set_knowledge_base_ids(ids: Array) -> bool:
	var cleaned: Array = []
	for value in ids:
		var text := str(value).strip_edges()
		if not text.is_empty() and not cleaned.has(text):
			cleaned.append(text)
	current["knowledge_base_ids"] = cleaned
	if not str(current.get("default_knowledge_base_id", "")) in cleaned:
		current["default_knowledge_base_id"] = str(cleaned[0]) if not cleaned.is_empty() else ""
	return write_config()

func get_default_knowledge_base_id() -> String:
	var configured := str(current.get("default_knowledge_base_id", "")).strip_edges()
	if configured.is_empty() or not get_knowledge_base_ids().has(configured):
		var ids := get_knowledge_base_ids()
		return str(ids[0]) if not ids.is_empty() else ""
	return configured

func set_default_knowledge_base_id(id: String) -> bool:
	current["default_knowledge_base_id"] = id.strip_edges()
	return write_config()

func has_api_key() -> bool:
	return not secret_path.is_empty() and FileAccess.file_exists(secret_path)

func save_api_key(api_key: String) -> bool:
	# 与模型中心同一条路径：先原子写，再回读校验。写坏了就把旧 Key 放回去。
	var previous := load_api_key()
	if AtomicFile.write_encrypted(secret_path, api_key.strip_edges(), device_key()) == false:
		if not previous.is_empty():
			AtomicFile.write_encrypted(secret_path, previous, device_key())
		return false
	var ok := load_api_key() == api_key.strip_edges()
	current["key_stored"] = has_api_key()
	write_config()
	return ok

func load_api_key() -> String:
	if not has_api_key():
		return ""
	var file := FileAccess.open_encrypted(secret_path, FileAccess.READ, device_key())
	if file == null:
		return ""
	var key := file.get_as_text().strip_edges()
	file.close()
	return key

func clear_api_key() -> void:
	AtomicFile.remove_quietly(secret_path)
	current["key_stored"] = false
	write_config()

func device_key() -> PackedByteArray:
	if device_key_source and device_key_source.has_method("device_key"):
		return device_key_source.device_key()
	# 没有注入来源（例如单独跑本文件的断言）时退回同一套派生规则，保证读得回自己写的文件。
	var stable_user_data_dir := OS.get_environment("APPDATA").strip_edges()
	if stable_user_data_dir.is_empty():
		stable_user_data_dir = OS.get_user_data_dir()
	else:
		stable_user_data_dir = stable_user_data_dir.path_join("Godot/app_userdata/蓝鲸智能体桌宠")
	stable_user_data_dir = stable_user_data_dir.replace("\\", "/")
	var identity := "%s|%s|%s|blue-whale-agent-v1" % [
		OS.get_environment("COMPUTERNAME"),
		OS.get_environment("USERNAME"),
		stable_user_data_dir
	]
	var hashing := HashingContext.new()
	hashing.start(HashingContext.HASH_SHA256)
	hashing.update(identity.to_utf8_buffer())
	return hashing.finish()

func status_line() -> String:
	if get_mode() == MODE_WEKNORA:
		if not uses_weknora():
			return "WeKnora 未配置完整"
		var warning := "（明文 HTTP）" if get_allow_insecure_http() and not is_safe_host(get_host()) else ""
		return "WeKnora · %s%s" % [get_host(), warning]
	return "本机知识库"
