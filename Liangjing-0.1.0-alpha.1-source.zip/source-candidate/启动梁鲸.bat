@echo off
rem Liang Jing portable launcher.
rem Import assets once, then start the desktop companion.
setlocal
set "APP_DIR=%~dp0"
set "APP_PATH=%APP_DIR:~0,-1%"
set "GODOT_EXE=%APP_PATH%\Godot_v4.7.1-stable_win64.exe"
set "IMPORT_MARKER=%APP_PATH%\.godot\liang_jing_import_ready"

if not exist "%GODOT_EXE%" (
  echo [Liang Jing] Runtime was not found. Please unzip the complete package first.
  pause
  exit /b 1
)

rem The marker prevents repeating the asset import on every launch.
if not exist "%IMPORT_MARKER%" (
  echo [Liang Jing] First launch: importing model and animation assets. Please wait...
  "%GODOT_EXE%" --headless --path "%APP_PATH%" --import
  if errorlevel 1 (
    echo [Liang Jing] Asset import failed. Keep this window open and contact the tester coordinator.
    pause
    exit /b 1
  )
  >"%IMPORT_MARKER%" echo ready
)

start "" "%GODOT_EXE%" --path "%APP_PATH%"
endlocal
