# 梁鲸工作流图与分享包格式。
#
# 目标不是复刻某个平台的私有格式，而是给梁鲸建立稳定的本地协议：
# - 编辑器保存节点与连线；
# - 当前运行器把“单入口、单出口、无分叉”的图编译为旧 steps 顺序执行；
# - 含分支的图可以保存和分享，但在分支执行器完成前明确阻止运行；
# - 本机导入导出与未来服务器下载使用完全相同的包，不把 API Key 或运行记录放进包里。
class_name BlueWhaleWorkflowPackage
extends RefCounted

const Knowledge = preload("res://workflow_knowledge.gd")

const FORMAT := "liangjing.workflow.package"
const FORMAT_VERSION := 2
const WORKFLOW_SCHEMA_VERSION := 2
const MAX_NODES := 200
const MAX_EDGES := 400
const MAX_TEXT_LENGTH := 20000
const SUPPORTED_TYPES := ["输入", "知识库检索", "知识库问答", "模型处理", "技能", "Harness执行", "条件分支", "用户交互", "验证", "输出"]


static func new_id(prefix: String) -> String:
	return "%s_%d_%d_%06d" % [prefix, Time.get_unix_time_from_system(), Time.get_ticks_usec() % 1000000, randi() % 1000000]


static func normalize_workflow(value: Variant, regenerate_identity := false) -> Dictionary:
	if not value is Dictionary:
		return {}
	var source: Dictionary = value
	var workflow := source.duplicate(true)
	var workflow_id := str(source.get("id", "")).strip_edges()
	if regenerate_identity or workflow_id.is_empty():
		workflow_id = new_id("workflow")
	workflow["id"] = workflow_id
	workflow["schema_version"] = WORKFLOW_SCHEMA_VERSION
	workflow["name"] = _limited(str(source.get("name", "未命名工作流")).strip_edges(), 120)
	if str(workflow["name"]).is_empty():
		workflow["name"] = "未命名工作流"
	workflow["description"] = _limited(str(source.get("description", "")).strip_edges(), 1000)
	workflow["version"] = maxi(int(source.get("version", 1)), 1)
	workflow["trigger"] = str(source.get("trigger", "手动运行"))
	workflow["failure"] = str(source.get("failure", "暂停并询问"))
	workflow["enabled"] = bool(source.get("enabled", true))
	workflow["confirmed"] = bool(source.get("confirmed", true))
	workflow["created_at"] = str(source.get("created_at", Time.get_datetime_string_from_system()))
	workflow["updated_at"] = str(source.get("updated_at", ""))

	var graph_source: Variant = source.get("graph", null)
	var graph := _normalize_graph(graph_source) if graph_source is Dictionary else _graph_from_steps(source.get("steps", []))
	workflow["graph"] = graph
	var compiled := compile_linear_graph(graph)
	workflow["graph_executable"] = bool(compiled.get("ok", false))
	workflow["graph_error"] = str(compiled.get("error", ""))
	if bool(compiled.get("ok", false)):
		workflow["steps"] = compiled.get("steps", [])
	elif not source.get("steps", []) is Array:
		workflow["steps"] = []
	return workflow


static func _normalize_graph(value: Dictionary) -> Dictionary:
	var nodes: Array = []
	var seen_nodes := {}
	var raw_nodes: Variant = value.get("nodes", [])
	if raw_nodes is Array:
		for raw_node in raw_nodes:
			if nodes.size() >= MAX_NODES:
				break
			if not raw_node is Dictionary:
				continue
			var node := _normalize_node(raw_node, nodes.size())
			var node_id := str(node.get("id", ""))
			if node_id.is_empty() or seen_nodes.has(node_id):
				node["id"] = new_id("node")
				node_id = str(node["id"])
			seen_nodes[node_id] = true
			nodes.append(node)

	var edges: Array = []
	var seen_edges := {}
	var raw_edges: Variant = value.get("edges", [])
	if raw_edges is Array:
		for raw_edge in raw_edges:
			if edges.size() >= MAX_EDGES:
				break
			if not raw_edge is Dictionary:
				continue
			var edge: Dictionary = raw_edge
			var from_id := str(edge.get("from_node", "")).strip_edges()
			var to_id := str(edge.get("to_node", "")).strip_edges()
			if from_id.is_empty() or to_id.is_empty() or from_id == to_id:
				continue
			if not seen_nodes.has(from_id) or not seen_nodes.has(to_id):
				continue
			var signature := "%s:%d>%s:%d" % [from_id, int(edge.get("from_port", 0)), to_id, int(edge.get("to_port", 0))]
			if seen_edges.has(signature):
				continue
			seen_edges[signature] = true
			edges.append({
				"id": str(edge.get("id", new_id("edge"))),
				"from_node": from_id,
				"from_port": maxi(int(edge.get("from_port", 0)), 0),
				"to_node": to_id,
				"to_port": maxi(int(edge.get("to_port", 0)), 0),
			})

	var viewport_source: Variant = value.get("viewport", {})
	var viewport: Dictionary = viewport_source if viewport_source is Dictionary else {}
	return {
		"nodes": nodes,
		"edges": edges,
		"viewport": {
			"scroll_x": float(viewport.get("scroll_x", 0.0)),
			"scroll_y": float(viewport.get("scroll_y", 0.0)),
			"zoom": clampf(float(viewport.get("zoom", 1.0)), 0.25, 2.0),
		},
	}


static func _graph_from_steps(value: Variant) -> Dictionary:
	var nodes: Array = []
	var edges: Array = []
	if value is Array:
		for index in range(mini(value.size(), MAX_NODES)):
			var raw_step: Variant = value[index]
			if not raw_step is Dictionary:
				continue
			var node := _normalize_node(raw_step, nodes.size())
			nodes.append(node)
			if nodes.size() > 1:
				var previous: Dictionary = nodes[nodes.size() - 2]
				edges.append(_edge(str(previous["id"]), str(node["id"])))
	return {"nodes": nodes, "edges": edges, "viewport": {"scroll_x": 0.0, "scroll_y": 0.0, "zoom": 1.0}}


static func _normalize_node(value: Dictionary, index: int) -> Dictionary:
	var kind := str(value.get("type", "输入"))
	if not kind in SUPPORTED_TYPES:
		kind = "输入"
	var position_source: Variant = value.get("position", {})
	var position: Dictionary = position_source if position_source is Dictionary else {}
	var node := value.duplicate(true)
	node["id"] = str(value.get("id", new_id("node"))).strip_edges()
	node["type"] = kind
	if kind in Knowledge.TYPES:
		node["knowledge"] = Knowledge.settings(value.get("knowledge", {}))
	node["name"] = _limited(str(value.get("name", "新节点")).strip_edges(), 120)
	if str(node["name"]).is_empty():
		node["name"] = "新节点"
	node["detail"] = _limited(str(value.get("detail", "")).strip_edges(), MAX_TEXT_LENGTH)
	node["position"] = {
		"x": float(position.get("x", 70.0 + index * 245.0)),
		"y": float(position.get("y", 105.0 + (index % 2) * 42.0)),
	}
	if not node.get("inputs", []) is Array:
		node["inputs"] = []
	if not node.get("outputs", []) is Array:
		node["outputs"] = []
	return node


static func _edge(from_node: String, to_node: String) -> Dictionary:
	return {"id": new_id("edge"), "from_node": from_node, "from_port": 0, "to_node": to_node, "to_port": 0}


static func compile_linear_workflow(workflow: Dictionary) -> Dictionary:
	var graph: Variant = workflow.get("graph", {})
	if not graph is Dictionary:
		return {"ok": false, "error": "工作流图格式不正确。", "steps": []}
	return compile_linear_graph(graph)


static func compile_linear_graph(graph: Dictionary) -> Dictionary:
	var nodes_value: Variant = graph.get("nodes", [])
	var edges_value: Variant = graph.get("edges", [])
	if not nodes_value is Array or not edges_value is Array:
		return {"ok": false, "error": "节点或连线格式不正确。", "steps": []}
	var nodes: Array = nodes_value
	var edges: Array = edges_value
	if nodes.is_empty():
		return {"ok": false, "error": "画布中还没有节点。", "steps": []}
	var by_id := {}
	var incoming := {}
	var outgoing := {}
	for item in nodes:
		if not item is Dictionary:
			return {"ok": false, "error": "画布中存在格式错误的节点。", "steps": []}
		var node: Dictionary = item
		var node_id := str(node.get("id", "")).strip_edges()
		if node_id.is_empty() or by_id.has(node_id):
			return {"ok": false, "error": "节点 ID 为空或重复。", "steps": []}
		by_id[node_id] = node
		incoming[node_id] = []
		outgoing[node_id] = []
	for item in edges:
		if not item is Dictionary:
			return {"ok": false, "error": "画布中存在格式错误的连线。", "steps": []}
		var edge: Dictionary = item
		var from_id := str(edge.get("from_node", ""))
		var to_id := str(edge.get("to_node", ""))
		if not by_id.has(from_id) or not by_id.has(to_id) or from_id == to_id:
			return {"ok": false, "error": "连线指向了不存在的节点。", "steps": []}
		outgoing[from_id].append(to_id)
		incoming[to_id].append(from_id)
	for node_id in by_id.keys():
		if Array(incoming[node_id]).size() > 1 or Array(outgoing[node_id]).size() > 1:
			return {"ok": false, "error": "当前运行器只支持单线流程；分支图可以保存和分享，但暂不能运行。", "steps": []}
	var starts: Array = []
	for node_id in by_id.keys():
		if Array(incoming[node_id]).is_empty():
			starts.append(node_id)
	if starts.size() != 1:
		return {"ok": false, "error": "可运行画布必须只有一个起点；当前可能有断开的节点或环。", "steps": []}
	var ordered: Array = []
	var visited := {}
	var cursor := str(starts[0])
	while not cursor.is_empty():
		if visited.has(cursor):
			return {"ok": false, "error": "工作流连线形成了循环；当前运行器暂不支持循环。", "steps": []}
		visited[cursor] = true
		var node: Dictionary = by_id[cursor]
		var step := node.duplicate(true)
		step.erase("position")
		ordered.append(step)
		var next_nodes: Array = outgoing[cursor]
		cursor = str(next_nodes[0]) if not next_nodes.is_empty() else ""
	if visited.size() != nodes.size():
		return {"ok": false, "error": "画布中有未连接到主流程的节点。", "steps": []}
	return {"ok": true, "error": "", "steps": ordered}


static func build_package(workflow: Dictionary) -> Dictionary:
	var normalized := normalize_workflow(workflow)
	var shareable := {
		"id": str(normalized.get("id", "")),
		"schema_version": WORKFLOW_SCHEMA_VERSION,
		"name": str(normalized.get("name", "未命名工作流")),
		"description": str(normalized.get("description", "")),
		"version": int(normalized.get("version", 1)),
		"failure": str(normalized.get("failure", "暂停并询问")),
		"tags": _scrub_share_value(normalized.get("tags", [])),
		"graph": _scrub_share_value(normalized.get("graph", {})),
		"created_at": str(normalized.get("created_at", "")),
		"updated_at": str(normalized.get("updated_at", "")),
	}
	clear_knowledge_bindings(shareable)
	return {
		"format": FORMAT,
		"format_version": 2 if Array(normalized.get("graph", {}).get("nodes", [])).any(func(step): return str(step.get("type", "")) in Knowledge.TYPES) else 1,
		"package_id": new_id("package"),
		"exported_at": Time.get_datetime_string_from_system(),
		"producer": {"name": "梁鲸", "workflow_schema": WORKFLOW_SCHEMA_VERSION},
		"workflow": shareable,
		"catalog": {
			"name": str(normalized.get("name", "未命名工作流")),
			"description": str(normalized.get("description", "")),
			"tags": normalized.get("tags", []) if normalized.get("tags", []) is Array else [],
		},
	}


static func _scrub_share_value(value: Variant) -> Variant:
	if value is Dictionary:
		var cleaned := {}
		for raw_key in value.keys():
			var key := str(raw_key)
			var lowered := key.to_lower()
			var sensitive := false
			for marker in ["api_key", "apikey", "token", "secret", "password", "authorization", "credential"]:
				if lowered.contains(marker):
					sensitive = true
					break
			if not sensitive:
				cleaned[key] = _scrub_share_value(value[raw_key])
		return cleaned
	if value is Array:
		var cleaned_array: Array = []
		for item in value:
			cleaned_array.append(_scrub_share_value(item))
		return cleaned_array
	if value is String:
		return _limited(value, MAX_TEXT_LENGTH)
	return value


static func package_json(workflow: Dictionary) -> String:
	return JSON.stringify(build_package(workflow), "  ", false)


static func parse_package(text: String, regenerate_identity := true) -> Dictionary:
	var parsed: Variant = JSON.parse_string(text)
	if not parsed is Dictionary:
		return {"ok": false, "error": "文件不是有效的 JSON 工作流包。"}
	var package: Dictionary = parsed
	if str(package.get("format", "")) != FORMAT:
		return {"ok": false, "error": "这不是梁鲸工作流包，或格式标识缺失。"}
	if int(package.get("format_version", 0)) > FORMAT_VERSION:
		return {"ok": false, "error": "工作流包版本比当前梁鲸新，请先升级程序。"}
	var raw_workflow: Variant = package.get("workflow", null)
	if not raw_workflow is Dictionary:
		return {"ok": false, "error": "工作流包中缺少 workflow。"}
	var raw_graph: Variant = Dictionary(raw_workflow).get("graph", {})
	if raw_graph is Dictionary:
		var raw_nodes: Variant = Dictionary(raw_graph).get("nodes", [])
		var raw_edges: Variant = Dictionary(raw_graph).get("edges", [])
		if raw_nodes is Array and raw_nodes.size() > MAX_NODES:
			return {"ok": false, "error": "工作流节点超过 200 个，已拒绝导入。"}
		if raw_edges is Array and raw_edges.size() > MAX_EDGES:
			return {"ok": false, "error": "工作流连线超过 400 条，已拒绝导入。"}
	var import_source: Dictionary = raw_workflow.duplicate(true)
	clear_knowledge_bindings(import_source)
	var normalized := normalize_workflow(import_source, regenerate_identity)
	var graph: Dictionary = normalized.get("graph", {})
	if Array(graph.get("nodes", [])).size() > MAX_NODES or Array(graph.get("edges", [])).size() > MAX_EDGES:
		return {"ok": false, "error": "工作流节点或连线过多，已拒绝导入。"}
	return {"ok": true, "workflow": normalized, "package": package}


static func suggested_file_name(workflow: Dictionary) -> String:
	var name := str(workflow.get("name", "workflow")).strip_edges()
	var safe := ""
	for index in name.length():
		var character := name.substr(index, 1)
		if character in ["\\", "/", ":", "*", "?", "\"", "<", ">", "|"]:
			safe += "_"
		else:
			safe += character
	safe = safe.strip_edges()
	if safe.is_empty():
		safe = "workflow"
	return safe.left(80) + ".liangjing-workflow.json"


static func _limited(value: String, limit: int) -> String:
	return value if value.length() <= limit else value.left(limit)


static func selftest() -> Dictionary:
	var failures: Array[String] = []
	var cases := 0
	var legacy := {
		"id": "legacy",
		"name": "旧顺序工作流",
		"steps": [
			{"id": "a", "type": "输入", "name": "开始", "detail": "接收输入"},
			{"id": "b", "type": "输出", "name": "结束", "detail": "返回结果"},
		],
	}
	var normalized := normalize_workflow(legacy)
	cases += 1
	if int(normalized.get("schema_version", 0)) != WORKFLOW_SCHEMA_VERSION:
		failures.append("旧工作流没有迁移到图结构版本")
	cases += 1
	if Array(Dictionary(normalized.get("graph", {})).get("nodes", [])).size() != 2 or Array(Dictionary(normalized.get("graph", {})).get("edges", [])).size() != 1:
		failures.append("旧顺序步骤没有生成两节点一连线")
	cases += 1
	if not bool(compile_linear_workflow(normalized).get("ok", false)):
		failures.append("合法单线图无法编译")

	var branched := normalized.duplicate(true)
	var graph: Dictionary = branched["graph"]
	graph["nodes"].append(_normalize_node({"id": "c", "type": "输出", "name": "另一出口"}, 2))
	graph["edges"].append(_edge("a", "c"))
	cases += 1
	if bool(compile_linear_workflow(branched).get("ok", false)):
		failures.append("分支图被当前顺序运行器接受")

	normalized["api_key"] = "must-not-export"
	var graph_with_secret: Dictionary = normalized["graph"]
	Dictionary(Array(graph_with_secret["nodes"])[0])["config"] = {"token": "must-not-export", "model": "demo"}
	var package_text := package_json(normalized)
	cases += 1
	if package_text.contains("must-not-export"):
		failures.append("分享包包含凭据字段")
	var imported := parse_package(package_text, true)
	cases += 1
	if not bool(imported.get("ok", false)):
		failures.append("自己导出的包无法重新导入")
	cases += 1
	if str(Dictionary(imported.get("workflow", {})).get("id", "")) == "legacy":
		failures.append("导入分享包没有生成新的本机工作流 ID")
	cases += 1
	if bool(parse_package("{\"format\":\"other\"}").get("ok", false)):
		failures.append("错误格式标识被接受")
	cases += 1
	if not suggested_file_name({"name": "月报:测试/一"}).ends_with(".liangjing-workflow.json"):
		failures.append("导出文件名没有使用工作流包扩展名")
	return {"ok": failures.is_empty(), "cases": cases, "failures": failures}

static func clear_knowledge_bindings(workflow: Dictionary) -> void:
	for node in workflow.get("graph", {}).get("nodes", []):
		if node is Dictionary and str(node.get("type", "")) in Knowledge.TYPES:
			var config := Knowledge.settings(node.get("knowledge", {}))
			config["kb_ids"] = []
			config["connection"] = ""
			node["knowledge"] = config
