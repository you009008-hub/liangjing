# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 新增：原子写工具（tmp+rename、加密写回读校验、失败不破坏原文件）。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 原子文件写入工具。
#
# 背景：FileAccess.open(path, WRITE) 会先把文件截断再写。梁鲸是常驻的桌宠进程，
# 被任务管理器强杀、崩溃或断电都算正常退出路径，一旦在截断之后、写完之后之间出事，
# 用户拿到的就是一个半截 JSON：read_json 会静默回落到默认值，配置和长期记忆看起来
# “无缘无故消失”。API Key 更严重——open_encrypted 也是先截断旧密钥再写，写坏就再也解不开。
#
# 因此所有覆盖写都走这里：先写同名 .tmp，成功后再替换目标文件。
# 替换方式按平台区分：POSIX 有原子 rename 语义，Windows 的 rename 不能覆盖已存在文件，
# 必须先删除再改名，中间存在极短的窗口——这是 Godot 在 Windows 上的现实限制，
# 但相比“直接截断目标文件”已经是数量级的改善（旧的完好内容一直保留到最后一刻）。
class_name BlueWhaleAtomicFile
extends RefCounted

const TEMP_SUFFIX := ".tmp"

# 覆盖写文本。返回 true 表示目标文件已经是新内容。
static func write_text(path: String, content: String) -> bool:
	var temporary_path := path + TEMP_SUFFIX
	var file := FileAccess.open(temporary_path, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(content)
	# flush + close 必须在替换之前完成，否则可能替换了一个还没落盘的空文件。
	file.flush()
	file.close()
	return _replace(temporary_path, path)

# 用设备密钥加密覆盖写（用于 API Key）。写完立刻用同一把密钥回读校验，
# 避免“写进去了但解不开”这种更隐蔽的失败被当成成功。
static func write_encrypted(path: String, content: String, device_key: PackedByteArray) -> bool:
	var temporary_path := path + TEMP_SUFFIX
	var file := FileAccess.open_encrypted(temporary_path, FileAccess.WRITE, device_key)
	if file == null:
		return false
	file.store_string(content)
	file.flush()
	file.close()
	var verify := FileAccess.open_encrypted(temporary_path, FileAccess.READ, device_key)
	if verify == null:
		remove_quietly(temporary_path)
		return false
	var readback := verify.get_as_text()
	verify.close()
	if readback != content:
		remove_quietly(temporary_path)
		return false
	return _replace(temporary_path, path)

# 把 .tmp 换成正式文件。失败时清理临时文件，绝不留下垃圾。
static func _replace(temporary_path: String, path: String) -> bool:
	# POSIX 可以直接 rename 覆盖；Windows 必须先删。
	var error := DirAccess.rename_absolute(temporary_path, path)
	if error == OK:
		return true
	if not FileAccess.file_exists(path):
		# 目标本来就不存在，rename 仍然失败说明是权限或路径问题。
		remove_quietly(temporary_path)
		return false
	var remove_error := DirAccess.remove_absolute(path)
	if remove_error != OK:
		remove_quietly(temporary_path)
		return false
	var retry_error := DirAccess.rename_absolute(temporary_path, path)
	if retry_error != OK:
		remove_quietly(temporary_path)
		return false
	return true

static func remove_quietly(path: String) -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)

# 清理历史遗留的 .tmp（例如上一轮正好在写入时被杀）。启动时调用一次即可。
static func sweep_stale_temps(directory: String) -> int:
	var removed := 0
	if directory.is_empty() or not DirAccess.dir_exists_absolute(directory):
		return removed
	for file_name in DirAccess.get_files_at(directory):
		if file_name.ends_with(TEMP_SUFFIX):
			if DirAccess.remove_absolute(directory.path_join(file_name)) == OK:
				removed += 1
	return removed

# ── 自检 ──────────────────────────────────────────────────────────────
# 覆盖：正常覆盖写、目标不存在、目录不可写时不破坏原文件、.tmp 不残留、加密写回读一致。
static func selftest(directory: String) -> Dictionary:
	var failures: Array[String] = []
	if DirAccess.make_dir_recursive_absolute(directory) != OK and not DirAccess.dir_exists_absolute(directory):
		return {"ok": false, "failures": ["无法创建自检目录：%s" % directory], "cases": 0}

	var target := directory.path_join("atomic_probe.json")
	remove_quietly(target)
	remove_quietly(target + TEMP_SUFFIX)

	# 1. 目标不存在时也要能写成功。
	if not write_text(target, "first"):
		failures.append("目标文件不存在时写入失败")
	if read_text(target) != "first":
		failures.append("首次写入内容不正确：%s" % read_text(target))

	# 2. 覆盖写必须替换为新内容，而不是追加或残留旧尾巴。
	if not write_text(target, "second-longer-content"):
		failures.append("覆盖写失败")
	if read_text(target) != "second-longer-content":
		failures.append("覆盖写后内容不正确：%s" % read_text(target))

	# 3. 短内容覆盖长内容不能留下旧尾巴（截断语义必须正确）。
	if not write_text(target, "x"):
		failures.append("短内容覆盖写失败")
	if read_text(target) != "x":
		failures.append("短内容覆盖后残留旧数据：%s" % read_text(target))

	# 4. 写完后不能留下 .tmp。
	if FileAccess.file_exists(target + TEMP_SUFFIX):
		failures.append("写入完成后 .tmp 没有被清理")

	# 5. 目录不可写时，原文件必须保持完好（这正是原子写的核心价值）。
	var missing_directory := directory.path_join("不存在的子目录")
	var broken_target := missing_directory.path_join("nested.json")
	if write_text(broken_target, "should-fail"):
		failures.append("目标目录不存在时不应报告成功")
	if FileAccess.file_exists(broken_target):
		failures.append("写入失败却产生了目标文件")

	# 6. sweep 必须清掉遗留的 .tmp。
	var stale := directory.path_join("stale.json" + TEMP_SUFFIX)
	var stale_file := FileAccess.open(stale, FileAccess.WRITE)
	if stale_file:
		stale_file.store_string("leftover")
		stale_file.close()
	var swept := sweep_stale_temps(directory)
	if swept < 1 or FileAccess.file_exists(stale):
		failures.append("sweep_stale_temps 没有清掉遗留 .tmp（swept=%d）" % swept)

	# 7. 加密写：回读必须一致；用错误密钥必须解不开（证明真的加密了）。
	# 注意 Godot 的加密文件要求密钥恰好 32 字节（生产侧用 SHA256 正好满足）。
	# 这里必须显式断言长度：长度不对时 open_encrypted 直接返回 null，“错误密钥打不开”
	# 这条断言会因为错误的原因通过——这个坑真的踩过一次。
	var key := "selftest-device-key-32-bytes!!!!".to_utf8_buffer()
	var wrong_key := "different-device-key-32-bytes!!!".to_utf8_buffer()
	if key.size() != 32 or wrong_key.size() != 32:
		return {
			"ok": false,
			"failures": ["自检夹具缺陷：加密密钥必须恰好 32 字节，实际 key=%d wrong_key=%d" % [key.size(), wrong_key.size()]],
			"cases": 0
		}
	var secret := directory.path_join("atomic_probe_secret.bin")
	remove_quietly(secret)
	if not write_encrypted(secret, "secret-value", key):
		failures.append("加密写入失败")
	else:
		var secret_file := FileAccess.open_encrypted(secret, FileAccess.READ, key)
		if secret_file == null or secret_file.get_as_text() != "secret-value":
			failures.append("加密写入后无法用同一密钥回读")
		if secret_file:
			secret_file.close()
		var wrong_file := FileAccess.open_encrypted(secret, FileAccess.READ, wrong_key)
		if wrong_file != null:
			failures.append("错误的设备密钥竟然能解开密钥文件")
			wrong_file.close()
		# 加密写也不能留下 .tmp。
		if FileAccess.file_exists(secret + TEMP_SUFFIX):
			failures.append("加密写入完成后 .tmp 没有被清理")
	remove_quietly(secret)
	remove_quietly(target)
	return {"ok": failures.is_empty(), "failures": failures, "cases": 11}

static func read_text(path: String) -> String:
	if not FileAccess.file_exists(path):
		return ""
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return ""
	var content := file.get_as_text()
	file.close()
	return content
