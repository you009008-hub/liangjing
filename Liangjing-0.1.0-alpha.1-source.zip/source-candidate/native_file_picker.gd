extends Node

# Windows owns the dialog on a separate STA process. The Godot event loop never
# enters IFileDialog's modal loop, and no Liangjing HWND can remain disabled.
var source: FileDialog
var process_id := -1
var request_path := ""
var response_path := ""
# [DSH] 运行时落地的 .ps1 副本路径。
# 为什么不能直接把 res://native_file_picker.ps1 交给 PowerShell：
#   1. 导出成 .pck 后，非资源文件默认根本不进包（export_filter=all_resources 且 include_filter 为空），
#      实测评测过：包里没有 native_file_picker.ps1；
#   2. 就算把它列进 include_filter，包内文件也不是磁盘文件，globalize_path 给出的路径上什么都没有。
# 两种情况都表现为"对话框静默打不开"——最难查的那种。所以统一在运行时把脚本写到临时目录再启动。
var script_path := ""
var topmost_windows: Array[Window] = []
var elapsed := 0.0

static func open(dialog: FileDialog) -> void:
	if not is_instance_valid(dialog) or dialog.has_meta("native_picker_active"):
		return
	if dialog.get_tree().root.has_meta("native_picker_busy"):
		dialog.canceled.emit()
		return
	dialog.get_tree().root.set_meta("native_picker_busy", true)
	var picker = load("res://native_file_picker.gd").new()
	picker.source = dialog
	dialog.get_tree().root.add_child(picker)
	dialog.set_meta("native_picker_active", true)
	picker.start()


static func confirm(dialog: ConfirmationDialog) -> void:
	var proxy := FileDialog.new()
	proxy.title = dialog.title
	proxy.set_meta("confirmation_text", dialog.dialog_text)
	dialog.get_tree().root.add_child(proxy)
	proxy.file_selected.connect(func(_path: String):
		dialog.confirmed.emit()
		proxy.queue_free())
	proxy.canceled.connect(func():
		dialog.canceled.emit()
		proxy.queue_free())
	open(proxy)


func start() -> void:
	var token := "%d_%d" % [OS.get_process_id(), Time.get_ticks_usec()]
	var temp := OS.get_environment("TEMP")
	request_path = temp.path_join("liangjing-picker-" + token + ".request.json")
	response_path = temp.path_join("liangjing-picker-" + token + ".response.json")
	var script_text := FileAccess.get_file_as_string("res://native_file_picker.ps1")
	if script_text.strip_edges().is_empty():
		complete({"ok": false, "error": "读不到文件选择脚本（安装包可能不完整）"})
		return
	var file := FileAccess.open(request_path, FileAccess.WRITE)
	if file == null:
		complete({"ok": false, "error": "无法创建文件选择请求"})
		return
	file.store_string(JSON.stringify({"mode": 5 if source.has_meta("confirmation_text") else source.file_mode, "message": source.get_meta("confirmation_text", ""), "title": source.title, "directory": source.current_dir, "file": source.current_file, "filters": Array(source.filters), "response": response_path}))
	file.close()
	collect_topmost(get_tree().root)
	# 每次都重新落地一份：进程号+微秒做后缀，既不会互相覆盖，也不会用到上一次留下的旧脚本。
	script_path = temp.path_join("liangjing-picker-" + token + ".ps1")
	var script_file := FileAccess.open(script_path, FileAccess.WRITE)
	if script_file == null:
		complete({"ok": false, "error": "无法写入文件选择脚本"})
		return
	script_file.store_string(script_text)
	script_file.close()
	var powershell := OS.get_environment("SystemRoot").path_join("System32/WindowsPowerShell/v1.0/powershell.exe")
	process_id = OS.create_process(powershell, PackedStringArray(["-NoProfile", "-STA", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", script_path, "-RequestPath", request_path]), false)
	if process_id <= 0:
		complete({"ok": false, "error": "Windows 文件选择器启动失败"})


func collect_topmost(node: Node) -> void:
	if node is Window and node.visible and node.always_on_top:
		topmost_windows.append(node)
		node.always_on_top = false
	for child in node.get_children():
		collect_topmost(child)


func _process(delta: float) -> void:
	elapsed += delta
	if elapsed < 0.1 or process_id <= 0:
		return
	elapsed = 0.0
	if FileAccess.file_exists(response_path):
		var result = JSON.parse_string(FileAccess.get_file_as_string(response_path))
		if result is Dictionary:
			complete(result)
		else:
			complete({"ok": false, "error": "Windows 文件选择器返回了无效结果"})
	elif not OS.is_process_running(process_id):
		complete({"ok": false, "error": "Windows 文件选择器已退出"})


func complete(result: Dictionary) -> void:
	set_process(false)
	get_tree().root.remove_meta("native_picker_busy")
	for window in topmost_windows:
		if is_instance_valid(window):
			window.always_on_top = true
	topmost_windows.clear()
	for path in [request_path, response_path, script_path]:
		if not path.is_empty() and FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	if is_instance_valid(source):
		source.remove_meta("native_picker_active")
		if bool(result.get("ok", false)):
			var raw_paths = result.get("paths", [])
			var paths := PackedStringArray()
			if raw_paths is String:
				paths.append(raw_paths)
			elif raw_paths is Array:
				for value in raw_paths:
					if value is String and not value.is_empty():
						paths.append(value)
			if paths.is_empty():
				source.canceled.emit()
			elif source.file_mode == FileDialog.FILE_MODE_OPEN_DIR:
				source.dir_selected.emit(paths[0])
			elif source.file_mode == FileDialog.FILE_MODE_OPEN_FILES:
				source.files_selected.emit(paths)
			else:
				source.file_selected.emit(paths[0])
		else:
			source.canceled.emit()
			if not str(result.get("error", "")).is_empty():
				push_warning(str(result.error))
	queue_free()


func _exit_tree() -> void:
	if process_id > 0 and OS.is_process_running(process_id):
		OS.kill(process_id)
	for path in [request_path, response_path, response_path + ".tmp", script_path]:
		if not path.is_empty() and FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
