# 桌宠场景的透明控件根节点。
# 使用 PASS 让子控件正常交互，同时把未命中的透明区域继续交给主控制器判断。
class_name SoulAgentScene
extends Control

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
