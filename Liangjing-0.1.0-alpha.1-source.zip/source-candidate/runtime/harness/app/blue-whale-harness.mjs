/**
 * 梁鲸 Harness 启动适配层。
 *
 * 启动 DeepSeek Harness Web 服务，并提供仅限本机访问的交互代理，
 * 把审批、追问与会话事件转换成 Godot 界面可轮询的 JSON 消息。
 * 本文件不保存 API Key；密钥由桌宠配置层写入受保护的本地配置。
 */
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
// [DSH] 本机来源守卫：43818 与 43819 共用同一套判定（见该文件顶部说明）。
// [DSH] 注意：升级器只搬运 blue-whale-*.mjs，因此本模块会被一起带进新版本目录。
import { allowedNamesFor, checkLocalRequest, describeRejection } from "./blue-whale-interaction-guard.mjs";

const appDirectory = path.dirname(fileURLToPath(import.meta.url));
const argumentsList = process.argv.slice(2);

function argumentValue(name, fallback) {
  const index = argumentsList.indexOf(name);
  return index >= 0 && index + 1 < argumentsList.length
    ? argumentsList[index + 1]
    : fallback;
}

const dataDirectory = path.resolve(argumentValue("--data-dir", path.join(appDirectory, "runtime-data")));
const host = argumentValue("--host", "127.0.0.1");
const port = argumentValue("--port", "43818");
const interactionPort = Number(argumentValue("--interaction-port", "43819"));
const parentPid = Number(argumentValue("--parent-pid", "0"));
const harnessHome = path.join(dataDirectory, "Harness");
const dshEntry = path.join(appDirectory, "node_modules", "@deepseek-ai", "dsh", "lib", "bin.js");

fs.mkdirSync(harnessHome, { recursive: true });
process.env.DSH_HOME = harnessHome;
// 梁鲸已经提供自己的对话和审批界面，因此只启动 Harness 服务，
// 不再让官方 Web 配置页在每次打开桌宠时自动弹进浏览器。
process.argv = [process.execPath, dshEntry, "web", "--no-open", "--host", host, "--port", port];

const dshModule = await import(pathToFileURL(dshEntry).href);
// Newer DSH releases only auto-start when bin.js is the process entry point.
// When embedded, call their public entry explicitly; older releases auto-start on import.
const embeddedCli = typeof dshModule.runCli === "function";
const upstreamPort = embeddedCli ? String(Number(port) + 100) : port;
if (embeddedCli) {
  const bridgePatch = path.join(harnessHome, "blue-whale-connection.patch.json");
  fs.writeFileSync(bridgePatch, JSON.stringify([
    { id: "web-runtime", config: { openBrowser: false, printUrl: false, surfaceContext: true, trustedHosts: [] } },
    { insert: [{ id: "blue-whale-connection", name: pathToFileURL(path.join(appDirectory, "blue-whale-connection.mjs")).href }] },
  ]));
  process.argv = [process.execPath, dshEntry, "web", "--patch", bridgePatch, "--no-open", "--host", host, "--port", upstreamPort];
  await dshModule.runCli();
}

// 正常退出时 Godot 会主动关闭本进程；这里额外处理主程序崩溃、
// 被任务管理器结束等情况，避免孤立的 Harness 长驻并占用端口。
if (Number.isInteger(parentPid) && parentPid > 0) {
  const parentWatch = setInterval(() => {
    try {
      process.kill(parentPid, 0);
    } catch {
      clearInterval(parentWatch);
      process.exit(0);
    }
  }, 1500);
  parentWatch.unref();
}

const harnessOrigin = `http://${host}:${upstreamPort}`;
const harnessWebSocketOrigin = `ws://${host}:${upstreamPort}`;
const compatibility = globalThis[Symbol.for("blue-whale.compatibility")];
let harnessCookie = "";
if (embeddedCli) {
  const connection = globalThis[Symbol.for("blue-whale.connection")];
  if (!connection) throw new Error("Harness connection adapter did not initialize");
  const exchange = await fetch(connection.authenticatedUrl(harnessOrigin), { redirect: "manual" });
  harnessCookie = (exchange.headers.get("set-cookie") || "").split(";")[0];
  if (exchange.status !== 303 || !harnessCookie) throw new Error("Harness local authentication failed");
  const gateway = http.createServer(async (request, response) => {
    try {
      // [DSH] 原来是就地写死的 Host/Origin 判断，现改为共用守卫模块（行为保持等价：
      // [DSH] 白名单仍是 --host 与 localhost，不额外放宽），同时补上"跨站浏览器请求"这一条。
      const guard = checkLocalRequest(request.headers, { port: Number(port), names: [host, "localhost"], requireClientHeader: false });
      if (!guard.trusted) {
        response.writeHead(403); response.end(); return;
      }
      const url = new URL(request.url || "/", `http://${host}:${port}`);
      if (url.pathname === "/" && request.method === "GET") {
        response.writeHead(302, { location: connection.authenticatedUrl(harnessOrigin), "cache-control": "no-store", "referrer-policy": "no-referrer" });
        response.end(); return;
      }
      if (!url.pathname.startsWith("/api/")) { response.writeHead(404); response.end(); return; }
      const chunks = []; let size = 0;
      for await (const chunk of request) {
        size += chunk.length;
        if (size > 16 * 1024 * 1024) { response.writeHead(413); response.end(); return; }
        chunks.push(chunk);
      }
      if (request.method !== "POST") { response.writeHead(405); response.end(); return; }
      const envelope = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      if (envelope.type !== "client-request" || url.pathname !== "/api/" + envelope.method) { response.writeHead(400); response.end(); return; }
      let result;
      try { result = { ok: true, value: await compatibility.rpc(envelope.method, envelope.payload || {}, new AbortController().signal) }; }
      catch (error) { result = { ok: false, error: { code: "bridge/request-failed", message: error.message } }; }
      response.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
      response.end(JSON.stringify({ type: "server-response", rpcId: envelope.rpcId, result }));
    } catch { response.writeHead(502); response.end("Harness local gateway failed"); }
  });
  await new Promise((resolve, reject) => { gateway.once("error", reject); gateway.listen(Number(port), host, resolve); });
}
const pendingApprovals = new Map();
const pendingQuestions = new Map();
// When DSH exposes an embedded entry point, the in-process adapter owns every
// interaction, so the mux stream is never started and its state must not be
// reported as if it were live. The two branches are tracked separately:
// interactionMode names the live path, muxConnected only reflects the fallback.
const interactionMode = embeddedCli && compatibility ? "adapter" : "mux";
let muxConnected = false;
let muxLastError = interactionMode === "adapter" ? "" : "waiting for Harness";
let muxLastMessageAt = 0;
let blueWhalePollCount = 0;

function interactionSnapshot() {
  return {
    approvals: [...(compatibility?.approvals.values() || []), ...pendingApprovals.values()],
    questions: [...(compatibility?.questions.values() || []), ...pendingQuestions.values()],
  };
}

function sendJson(response, status, value) {
  const body = JSON.stringify(value);
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "content-length": Buffer.byteLength(body),
  });
  response.end(body);
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 1024 * 1024) throw new Error("request body is too large");
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function normalizeModelBaseUrl(value) {
  const parsed = new URL(String(value ?? "").trim());
  const localHost = parsed.hostname === "127.0.0.1" || parsed.hostname === "localhost";
  if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && localHost)) {
    throw new Error("模型接口必须使用 HTTPS；本机地址可使用 HTTP");
  }
  if (parsed.username || parsed.password) throw new Error("模型接口地址不能包含登录信息");
  return parsed.href.replace(/\/+$/, "");
}

function applyMuxEnvelope(envelope) {
  if (!envelope || envelope.type !== "server-request") return;
  const payload = envelope.payload;
  if (!payload || typeof payload !== "object") return;
  if (payload.type === "approval/requested") {
    pendingApprovals.set(envelope.rpcId, {
      rpcId: envelope.rpcId,
      sessionId: payload.sessionId,
      approvalId: payload.approvalId,
      toolName: payload.toolName,
      callId: payload.callId,
      reason: payload.reason,
    });
  } else if (payload.type === "approval/resolved") {
    for (const [rpcId, pending] of pendingApprovals) {
      if (pending.approvalId === payload.approvalId) pendingApprovals.delete(rpcId);
    }
  } else if (payload.type === "question/requested") {
    pendingQuestions.set(envelope.rpcId, {
      rpcId: envelope.rpcId,
      sessionId: payload.sessionId,
      questions: Array.isArray(payload.questions) ? payload.questions : [],
    });
  } else if (payload.type === "question/resolved") {
    pendingQuestions.delete(payload.questionRpcId);
  }
}

async function consumeMuxStream() {
  // The mux WebSocket is only needed for the fallback path where the bundled DSH
  // has no embedded entry point (embeddedCli === false). Loaded lazily so a missing
  // or de-hoisted "ws" can never prevent the embedded core from booting.
  const { default: WebSocket } = await import("ws");
  while (true) {
    await new Promise((resolve) => {
      let finished = false;
      const socket = new WebSocket(`${harnessWebSocketOrigin}/api/events.mux`, { headers: { cookie: harnessCookie } });
      const finish = (error) => {
        if (finished) return;
        finished = true;
        muxConnected = false;
        if (error) muxLastError = String(error.message ?? error);
        try { socket.close(); } catch { /* already closed */ }
        resolve();
      };
      socket.once("open", () => {
        muxConnected = true;
        muxLastError = "";
      });
      socket.on("message", (data) => {
        muxLastMessageAt = Date.now();
        try { applyMuxEnvelope(JSON.parse(data.toString("utf8"))); } catch { /* skip a corrupt frame */ }
      });
      socket.once("error", finish);
      socket.once("close", () => finish());
    });
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
}

const interactionServer = http.createServer(async (request, response) => {
  try {
    // [DSH] 交互桥此前完全没有来源校验：任何本机进程、以及靠 DNS 重绑定指向 127.0.0.1 的
    // [DSH] 网页，都能读走待审批内容并代替用户作答。这里补上与 43818 同一套判定，
    // [DSH] 并且"会改状态的路由"（非 GET/HEAD）额外要求梁鲸界面标识头。
    const guard = checkLocalRequest(request.headers, {
      port: interactionPort,
      // [DSH] 白名单 = 回环别名 + 实际监听地址：用户把接口配到内网地址时，
      // [DSH] 只认回环会把梁鲸自己的审批通道拦死（这是回归，不是安全）。
      names: allowedNamesFor(host, ["localhost"]),
      requireClientHeader: request.method !== "GET" && request.method !== "HEAD",
    });
    if (!guard.trusted) {
      sendJson(response, 403, { ok: false, error: describeRejection(guard.reason), reason: guard.reason });
      return;
    }
    const url = new URL(request.url ?? "/", `http://${host}:${interactionPort}`);
    if (request.method === "GET" && url.pathname === "/health") {
      // The bridge is usable whenever the interaction route is live. In adapter
      // mode the authenticated handshake already proved the connection, so the
      // mux-only fields are omitted entirely instead of faking a connected state.
      const snapshot = interactionSnapshot();
      const healthy = interactionMode === "adapter" || muxConnected;
      const body = {
        ok: healthy,
        interactionMode,
        pendingApprovalCount: snapshot.approvals.length,
        pendingQuestionCount: snapshot.questions.length,
        blueWhalePollCount,
      };
      if (interactionMode === "mux") {
        body.muxConnected = muxConnected;
        body.muxLastError = muxLastError;
        body.muxLastMessageAt = muxLastMessageAt;
      }
      sendJson(response, healthy ? 200 : 503, body);
      return;
    }
    if (request.method === "GET" && url.pathname === "/interactions") {
      if (request.headers["x-blue-whale-client"] === "godot") blueWhalePollCount += 1;
      sendJson(response, 200, interactionSnapshot());
      return;
    }
    if (request.method === "POST" && url.pathname === "/models") {
      if (request.headers["x-blue-whale-client"] !== "godot") {
        sendJson(response, 403, { ok: false, error: "仅允许梁鲸本地界面调用" });
        return;
      }
      const payload = await readJson(request);
      const apiKey = String(payload.apiKey ?? "").trim();
      if (!apiKey) {
        sendJson(response, 200, { ok: false, error: "请先填写 API Key" });
        return;
      }
      try {
        const baseUrl = normalizeModelBaseUrl(payload.baseUrl);
        const upstream = await fetch(`${baseUrl}/models`, {
          headers: {
            accept: "application/json",
            authorization: `Bearer ${apiKey}`,
          },
          signal: AbortSignal.timeout(60000),
        });
        const text = await upstream.text();
        let data = {};
        try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text.slice(0, 1000) }; }
        if (!upstream.ok) {
          const message = data?.error?.message ?? data?.message ?? `模型服务返回 ${upstream.status}`;
          sendJson(response, 200, { ok: false, error: String(message), status: upstream.status });
          return;
        }
        sendJson(response, 200, { ok: true, status: upstream.status, data });
      } catch (error) {
        const message = error?.name === "TimeoutError"
          ? "模型接口连接超时，请检查网络或代理"
          : String(error?.message ?? error);
        sendJson(response, 200, { ok: false, error: message });
      }
      return;
    }
    if (request.method === "POST" && url.pathname === "/approval-test") {
      const rpcId = `blue-whale-test-${Date.now()}`;
      pendingApprovals.set(rpcId, {
        rpcId,
        sessionId: "blue-whale-local-test",
        approvalId: `approval-${rpcId}`,
        toolName: "审批交互测试",
        callId: `call-${rpcId}`,
        reason: "这是本地审批通道测试，不会读取、修改或删除任何文件。请选择允许或拒绝，验证结果能否正常返回。",
        testOnly: true,
      });
      sendJson(response, 200, { ok: true, rpcId });
      return;
    }
    if (request.method === "POST" && url.pathname === "/question-test") {
      const rpcId = `blue-whale-question-test-${Date.now()}`;
      pendingQuestions.set(rpcId, {
        rpcId,
        sessionId: "blue-whale-local-test",
        questions: [
          {
            id: "save_mode",
            header: "提交方式",
            question: "请选择本次测试的提交方式",
            detail: "这是本地问题交互测试，不会读取、修改或删除任何文件。",
            options: [
              { label: "直接提交", description: "确认桌宠能返回单选结果" },
              { label: "先预览", description: "确认第二个选项也能正常提交" },
            ],
          },
          {
            id: "notes",
            header: "补充说明",
            question: "可以填写一段补充文字",
          },
        ],
        testOnly: true,
      });
      sendJson(response, 200, { ok: true, rpcId });
      return;
    }
    if (request.method === "POST" && url.pathname === "/approval-seen") {
      const notice = await readJson(request);
      const pending = pendingApprovals.get(notice.rpcId) || compatibility?.approvals.get(notice.rpcId);
      if (!pending) {
        sendJson(response, 404, { ok: false, error: "approval is no longer pending" });
        return;
      }
      pending.clientSeenAt = Date.now();
      sendJson(response, 200, { ok: true, clientSeenAt: pending.clientSeenAt });
      return;
    }
    if (request.method === "POST" && url.pathname === "/approval") {
      const answer = await readJson(request);
      if (compatibility?.approvals.has(answer.rpcId)) { sendJson(response, 200, compatibility.respond("approval", answer)); return; }
      const pending = pendingApprovals.get(answer.rpcId);
      if (!pending || pending.sessionId !== answer.sessionId || pending.approvalId !== answer.approvalId) {
        sendJson(response, 409, { ok: false, error: "approval is no longer pending" });
        return;
      }
      if (answer.outcome !== "allowed-once" && answer.outcome !== "rejected") {
        sendJson(response, 400, { ok: false, error: "invalid approval outcome" });
        return;
      }
      if (pending.testOnly === true) {
        pendingApprovals.delete(pending.rpcId);
        sendJson(response, 200, { ok: true, testOnly: true, outcome: answer.outcome });
        return;
      }
      const upstream = await fetch(`${harnessOrigin}/api/respond`, {
        method: "POST",
        headers: { "content-type": "application/json", cookie: harnessCookie },
        body: JSON.stringify({
          type: "client-response",
          rpcId: pending.rpcId,
          result: {
            ok: true,
            value: {
              sessionId: pending.sessionId,
              approvalId: pending.approvalId,
              outcome: answer.outcome,
            },
          },
        }),
      });
      const receipt = await upstream.json();
      if (upstream.ok && receipt.accepted === true) {
        pendingApprovals.delete(pending.rpcId);
        sendJson(response, 200, { ok: true });
      } else {
        sendJson(response, 409, { ok: false, error: receipt.reason ?? "approval was not accepted" });
      }
      return;
    }
    if (request.method === "POST" && url.pathname === "/question") {
      const answer = await readJson(request);
      if (compatibility?.questions.has(answer.rpcId)) { sendJson(response, 200, compatibility.respond("question", answer)); return; }
      const pending = pendingQuestions.get(answer.rpcId);
      if (!pending || pending.sessionId !== answer.sessionId) {
        sendJson(response, 409, { ok: false, error: "question is no longer pending" });
        return;
      }
      const cancelled = answer.cancelled === true;
      const answers = Array.isArray(answer.answers) ? answer.answers : [];
      if (!cancelled && answers.length !== pending.questions.length) {
        sendJson(response, 400, { ok: false, error: "question answer batch is incomplete" });
        return;
      }
      if (pending.testOnly === true) {
        pendingQuestions.delete(pending.rpcId);
        sendJson(response, 200, { ok: true, testOnly: true, cancelled, answers });
        return;
      }
      const result = cancelled
        ? {
            ok: false,
            error: {
              code: "cancelled",
              message: "the user closed this question request",
              details: {},
            },
          }
        : {
            ok: true,
            value: {
              sessionId: pending.sessionId,
              answer: { answers },
            },
          };
      const upstream = await fetch(`${harnessOrigin}/api/respond`, {
        method: "POST",
        headers: { "content-type": "application/json", cookie: harnessCookie },
        body: JSON.stringify({
          type: "client-response",
          rpcId: pending.rpcId,
          result,
        }),
      });
      const receipt = await upstream.json();
      if (upstream.ok && receipt.accepted === true) {
        pendingQuestions.delete(pending.rpcId);
        sendJson(response, 200, { ok: true, cancelled });
      } else {
        sendJson(response, 409, { ok: false, error: receipt.reason ?? "question response was not accepted" });
      }
      return;
    }
    sendJson(response, 404, { ok: false, error: "not found" });
  } catch (error) {
    sendJson(response, 500, { ok: false, error: String(error) });
  }
});

interactionServer.listen(interactionPort, host);
if (!embeddedCli) {
  // Never let the fallback stream kill the process: it is optional infrastructure.
  void consumeMuxStream().catch((error) => {
    muxConnected = false;
    muxLastError = String(error?.message ?? error);
  });
}
