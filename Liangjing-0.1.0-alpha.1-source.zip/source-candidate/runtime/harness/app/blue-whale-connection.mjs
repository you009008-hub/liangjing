// Keep the DSH launch credential inside the embedding process, never in logs/files.
export const name = "blue-whale-connection";
import { randomUUID } from "node:crypto";
export const inject = ["connection", "sessionController", "credentials", "settings", "workspaceRegistry", "commands", "agents", "sessions"];
export function apply(ctx) {
  globalThis[Symbol.for("blue-whale.connection")] = ctx.connection;
  const owned = new Set();
  const assistantStreams = new Map();
  function assistantStreamState(sessionId) {
    let state = assistantStreams.get(sessionId);
    if (!state) {
      state = { cursor: 0, frames: [] };
      assistantStreams.set(sessionId, state);
    }
    return state;
  }
  const disposeAssistantStream = ctx.on("agent/assistant-stream", ({ agent, frame }) => {
    const sessionId = String(agent?.session?.id ?? "");
    if (!owned.has(sessionId)) return;
    const state = assistantStreamState(sessionId);
    state.cursor += 1;
    state.frames.push({ ordinal: state.cursor, ...frame });
    if (state.frames.length > 4096) state.frames.splice(0, state.frames.length - 4096);
  }, { global: true });
  // Workflow sessions have their own admission lane. Sealing survives a stop
  // timeout so a late HTTP submission cannot restart an apparently stopped run.
  const workflowSessions = new Map();
  const workflowStopTimeoutMs = 15000;
  const approvals = new Map();
  const questions = new Map();
  const resolvers = new Map();
  function workflowState(sessionId) {
    if (typeof sessionId !== "string" || !owned.has(sessionId) || !workflowSessions.has(sessionId)) {
      throw new Error("Session is not owned by the Liang Jing workflow runner");
    }
    return workflowSessions.get(sessionId);
  }
  function sealedError() {
    const error = new Error("Workflow session is sealed; create a new session to retry");
    error.code = "WORKFLOW_SEALED";
    return error;
  }
  function cancelWorkflowAgent(sessionId) {
    const agent = ctx.agents.get(sessionId);
    if (!agent || typeof agent.cancel !== "function" || typeof agent.whenIdle !== "function") {
      throw new Error("Workflow session agent is not active");
    }
    // The ordinary session.cancel API keeps inbox items. A workflow stop must
    // discard queued work as well as abort the current turn.
    agent.cancel({ kind: "user" }, { keepInbox: false });
    return agent;
  }
  function promptWorkflow(payload, signal) {
    const state = workflowState(payload.sessionId);
    if (state.sealed) throw sealedError();
    if (typeof payload.requestId !== "string" || !payload.requestId.trim()) {
      throw new Error("Workflow prompt requires a stable requestId");
    }
    if (payload.mode !== "queue") throw new Error("Workflow prompts only support queue mode");
    const request = {
      sessionId: payload.sessionId,
      requestId: payload.requestId,
      mode: "queue",
      content: payload.content,
      ...(payload.clientTimeZone === undefined ? {} : { clientTimeZone: payload.clientTimeZone }),
    };
    const fingerprint = JSON.stringify(request);
    const previous = state.requests.get(payload.requestId);
    if (previous) {
      if (previous.fingerprint !== fingerprint) throw new Error("Workflow requestId was already used with different content");
      return previous.admission;
    }
    let admission;
    admission = Promise.resolve().then(() => {
      if (state.sealed) throw sealedError();
      return ctx.sessionController.prompt(request, signal);
    }).finally(() => {
      state.admissions.delete(admission);
      // prompt() may yield before it actually enqueues input. A cancel issued
      // during that admission cannot affect work that is not enqueued yet.
      if (state.sealed) cancelWorkflowAgent(payload.sessionId);
    });
    state.admissions.add(admission);
    state.requests.set(payload.requestId, { fingerprint, admission });
    return admission;
  }
  function stopWorkflow(payload) {
    const state = workflowState(payload.sessionId);
    state.sealed = true;
    if (!state.stopTask) {
      let immediateCancelFailed = false;
      try { cancelWorkflowAgent(payload.sessionId); }
      catch { immediateCancelFailed = true; }
      const admissions = [...state.admissions];
      const stopping = (async () => {
        const results = await Promise.allSettled(admissions);
        const agent = cancelWorkflowAgent(payload.sessionId);
        await agent.whenIdle();
        const admissionFailed = results.some((result) => result.status === "rejected" && result.reason?.code !== "WORKFLOW_SEALED");
        if (immediateCancelFailed || admissionFailed || ctx.agents.get(payload.sessionId) !== agent ||
            state.admissions.size !== 0 || agent.status !== "idle" ||
            agent.inbox.nextTurn.length !== 0 || agent.inbox.nextStep.length !== 0) {
          return { stopped: false, sealed: true, reason: "stop-unconfirmed" };
        }
        return { stopped: true, sealed: true };
      })().catch(() => ({ stopped: false, sealed: true, reason: "stop-failed" }));
      state.stopTask = stopping;
      void stopping.then((result) => {
        if (!result.stopped && state.stopTask === stopping) state.stopTask = null;
      });
    }
    const stopping = state.stopTask;
    let timer;
    return Promise.race([
      stopping,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve({ stopped: false, sealed: true, reason: "stop-timeout" }), workflowStopTimeoutMs);
      }),
    ]).finally(() => clearTimeout(timer));
  }
  function ask(kind, request) {
    const rpcId = randomUUID();
    const sessionId = String(request.agent.session.id);
    const table = kind === "approval" ? approvals : questions;
    const item = kind === "approval"
      ? { rpcId, sessionId, approvalId: rpcId, toolName: request.toolName, callId: request.callId, reason: request.reason }
      : { rpcId, sessionId, questions: request.questions };
    return new Promise((resolve, reject) => {
      const finish = (value, error) => {
        table.delete(rpcId); resolvers.delete(rpcId);
        request.signal?.removeEventListener("abort", abort);
        error ? reject(error) : resolve(value);
      };
      const abort = () => finish(kind === "approval" ? "cancelled" : undefined, kind === "question" ? new Error("Question cancelled") : undefined);
      resolvers.set(rpcId, finish); table.set(rpcId, item);
      request.signal?.addEventListener("abort", abort, { once: true });
      if (request.signal?.aborted) abort();
    });
  }
  ctx.on("approval/request", (request, next) => owned.has(String(request.agent.session.id)) ? ask("approval", request) : next(), { prepend: true });
  ctx.on("user-questions/request", (request, next) => request.agent && owned.has(String(request.agent.session.id)) ? ask("question", request) : next(), { prepend: true });
  const adapter = {
    approvals, questions,
    respond(kind, answer) {
      const table = kind === "approval" ? approvals : questions;
      const item = table.get(answer.rpcId);
      if (!item || item.sessionId !== answer.sessionId) throw new Error("Interaction is no longer pending");
      if (kind === "approval") {
        if (item.approvalId !== answer.approvalId || !["allowed-once", "rejected"].includes(answer.outcome)) throw new Error("Invalid approval answer");
        resolvers.get(answer.rpcId)(answer.outcome);
      } else {
        if (!answer.cancelled && (!Array.isArray(answer.answers) || answer.answers.length !== item.questions.length)) throw new Error("Incomplete question answer");
        resolvers.get(answer.rpcId)({ answers: answer.answers || [] }, answer.cancelled ? new Error("Question cancelled") : undefined);
      }
      return { ok: true };
    },
    async rpc(method, payload, signal) {
      switch (method) {
        case "workflow.session.create": {
          if (typeof payload.cwd !== "string" || !payload.cwd.trim()) throw new Error("Workflow session requires a workspace path");
          const result = await ctx.sessionController.create({ cwd: payload.cwd });
          if (!result || typeof result.sessionId !== "string" || !result.sessionId.trim() || owned.has(result.sessionId)) {
            throw new Error("Harness did not create a new workflow session");
          }
          owned.add(result.sessionId);
          assistantStreamState(result.sessionId);
          workflowSessions.set(result.sessionId, { sealed: false, admissions: new Set(), requests: new Map(), stopTask: null });
          return { ...result, workflowProtocol: 1, capabilities: { sealedStop: true, requestIdDeduplication: true } };
        }
        case "workflow.session.prompt": return promptWorkflow(payload, signal);
        case "workflow.session.stop": return stopWorkflow(payload);
        case "session.list": return ctx.sessionController.list(payload, signal);
        case "session.create": {
          const result = await ctx.sessionController.create(payload);
          owned.add(String(result.sessionId)); assistantStreamState(String(result.sessionId)); return result;
        }
        case "workspace.create": {
          const workspace = await ctx.workspaceRegistry.create(payload.path);
          return { workspace: { workspaceId: workspace.id, path: workspace.path } };
        }
        case "credentials.set":
          if (payload.ref !== "DEEPSEEK_API_KEY") throw new Error("Unsupported model credential reference");
          await ctx.credentials.set(payload.ref, payload.value); return {};
        case "settings.update":
          if (!["llm-deepseek", "agent-default-model"].includes(payload.ns)) throw new Error("Unsupported model settings namespace");
          await ctx.settings.update(payload.ns, payload.patch); return {};
        case "session.stream": {
          if (!owned.has(payload.sessionId)) throw new Error("Session is not owned by this Liang Jing connection");
          const state = assistantStreamState(payload.sessionId);
          const afterOrdinal = Number.isSafeInteger(payload.afterOrdinal) && payload.afterOrdinal >= 0 ? payload.afterOrdinal : 0;
          return { cursor: state.cursor, frames: state.frames.filter((item) => item.ordinal > afterOrdinal) };
        }
        // 中止当前轮次：与 DSH 自身的 session.cancel 同语义（保留收件箱里已排队的内容）。
        // 桌面端的"停止"按钮走这里，因此不需要客户端自己去猜上游的取消入口。
        case "session.stop": {
          if (!owned.has(payload.sessionId)) throw new Error("Session is not owned by this Liang Jing connection");
          const ack = ctx.sessionController.cancel({ sessionId: payload.sessionId });
          return { accepted: ack && ack.accepted !== false };
        }
        case "session.history": {
          if (!owned.has(payload.sessionId)) throw new Error("Session is not owned by this Liang Jing connection");
          const session = ctx.sessions.get(payload.sessionId);
          if (!session) throw new Error("Session is not active");
          const events = [];
          for (let i = Math.max(0, session.seq - 10000); i < session.seq; i++) {
            const event = session.eventAt(i); if (event) events.push({ event });
          }
          return { events };
        }
        case "session.prompt":
          if (!owned.has(payload.sessionId)) throw new Error("Session is not owned by this Liang Jing connection");
          if (workflowSessions.has(payload.sessionId)) return promptWorkflow(payload, signal);
          return ctx.sessionController.prompt({ ...payload, requestId: payload.requestId || randomUUID() }, signal);
        case "commands.execute": {
          if (!owned.has(payload.agentId)) throw new Error("Session is not owned by this Liang Jing connection");
          const agent = ctx.agents.get(payload.agentId);
          if (!agent) throw new Error("Session agent is not active");
          return await ctx.commands.execute(agent, payload.line, payload.images || [], signal) || {};
        }
        default: throw new Error(`Unsupported Liang Jing method: ${method}`);
      }
    },
  };
  globalThis[Symbol.for("blue-whale.compatibility")] = adapter;
  ctx.on("dispose", () => {
    disposeAssistantStream();
    assistantStreams.clear();
    for (const finish of resolvers.values()) finish(undefined, new Error("Harness stopped"));
    delete globalThis[Symbol.for("blue-whale.compatibility")];
    delete globalThis[Symbol.for("blue-whale.connection")];
  });
}
