// [DSH] 梁鲸本地接口访问守卫（2026-09-14 新增）。
// [DSH] 纯函数、零依赖、无副作用：只根据请求头做判断，便于放在 tmp\test_interaction_guard.mjs
// [DSH] 里直接断言，也便于在真机起一份带外 Harness 做端到端验证。
//
// 为什么需要它：43818（RPC 网关）与 43819（交互桥）都只监听 127.0.0.1，但
// “只监听本机”并不等于“只有本机程序能用”：
//   1. DNS 重绑定：恶意网页把自有域名解析到 127.0.0.1，浏览器就会把请求送进本机端口。
//      这时 Host 头是攻击者域名，而不是本地地址——这是 Host 判定存在的唯一理由。
//   2. 跨站简单请求：跨站 POST（text/plain）不触发预检也会送达。虽然跨站读不到响应，
//      但 /approval、/question、/approval-test 只要“请求到达”就能造成影响。
//   3. 重绑定之后攻击页与目标同源，/interactions 里的审批与追问内容（含工具名、
//      风险说明）会被直接读走，所以只读路由同样要判。
//
// 三道判定按代价从低到高执行，任何一道不过都拒绝，并给出可断言的原因码。
// 43818 与 43819 共用本模块，只是 names 白名单与是否要求客户端标识头不同。

export const CLIENT_HEADER = "x-blue-whale-client";
export const CLIENT_HEADER_VALUE = "godot";
// 本机回环别名。配置里的 --host 也会被并入白名单（见 checkLocalRequest 的 names 选项）。
export const DEFAULT_ALLOWED_NAMES = Object.freeze(["127.0.0.1", "localhost", "::1"]);

export const REJECTION_DESCRIPTIONS = Object.freeze({
  "host-header-missing": "请求没有带 Host 头，无法确认它来自本机",
  "host-header-invalid": "请求的 Host 头格式不正确",
  "host-not-allowed": "请求的目标不是本机地址：可能是网页通过 DNS 重绑定访问了本地接口",
  "host-port-mismatch": "请求的 Host 端口与梁鲸接口端口不一致",
  "origin-not-allowed": "请求来源不是梁鲸本机界面",
  "cross-site-browser-request": "浏览器标记该请求来自其它站点",
  "client-header-required": "缺少梁鲸界面标识头（X-Blue-Whale-Client: godot）",
});

export function describeRejection(reason) {
  return REJECTION_DESCRIPTIONS[reason] ?? "请求未通过本机来源校验";
}

// 通配绑定地址：它代表"监听所有网卡"，不是一个可以被信任的 Host 名字，
// 因此绝不能因为它出现在 --host 里就把 "0.0.0.0" 当成合法 Host 放进来。
const WILDCARD_NAMES = Object.freeze(["0.0.0.0", "::", "*", "0"]);

function normalizeName(value) {
  let name = String(value ?? "").trim().toLowerCase();
  if (name.startsWith("[") && name.endsWith("]")) name = name.slice(1, -1);
  return name;
}

/**
 * 白名单 = 回环别名 + 实际监听地址（由 --host 传入）。
 * 必须并入监听地址：用户若把接口指向内网地址，只认回环会把梁鲸自己的审批通道拦死。
 * 但通配绑定不并入，否则等于"任意 Host 都放行"。
 * @param {string} host 服务实际监听的主机名/IP。
 * @param {string[]} [extra] 额外允许的名字。
 */
export function allowedNamesFor(host, extra = []) {
  const names = [...DEFAULT_ALLOWED_NAMES, ...extra].map(normalizeName).filter(Boolean);
  const bind = normalizeName(host);
  if (bind && !WILDCARD_NAMES.includes(bind)) names.push(bind);
  return [...new Set(names)];
}

// 解析 Host 头。只接受 `名字[:端口]` 与 `[IPv6][:端口]` 两种形态：
// 带路径、带用户信息、裸 IPv6、非法端口的写法一律判无效，避免"看起来像本机"的伪造值漏过。
export function parseHostHeader(value) {
  if (typeof value !== "string") return { ok: false, reason: "host-header-missing" };
  const text = value.trim().toLowerCase();
  if (!text) return { ok: false, reason: "host-header-missing" };
  if (/[\s/\\@?#]/.test(text)) return { ok: false, reason: "host-header-invalid" };
  let name = "";
  let portText = null;
  if (text.startsWith("[")) {
    const close = text.indexOf("]");
    if (close < 0) return { ok: false, reason: "host-header-invalid" };
    name = text.slice(1, close);
    const rest = text.slice(close + 1);
    if (rest) {
      if (!rest.startsWith(":")) return { ok: false, reason: "host-header-invalid" };
      portText = rest.slice(1);
    }
  } else {
    const first = text.indexOf(":");
    const last = text.lastIndexOf(":");
    // 裸 IPv6（出现多个冒号）必须写成 [::1]，否则无法与"名字:端口"区分。
    if (first !== last) return { ok: false, reason: "host-header-invalid" };
    if (last >= 0) {
      name = text.slice(0, last);
      portText = text.slice(last + 1);
    } else {
      name = text;
    }
  }
  if (!name) return { ok: false, reason: "host-header-invalid" };
  if (portText === null) return { ok: true, name: normalizeName(name), port: null };
  if (!/^\d{1,5}$/.test(portText)) return { ok: false, reason: "host-header-invalid" };
  const port = Number(portText);
  if (port < 1 || port > 65535) return { ok: false, reason: "host-header-invalid" };
  return { ok: true, name: normalizeName(name), port };
}

// Origin 只会由浏览器发出。`Origin: null`（沙箱 iframe、file://）与 https 来源都必须判否：
// 本服务是明文 http，任何 https 来源都不可能是它自己的页面。
export function parseOrigin(value) {
  const text = String(value ?? "").trim();
  if (!text || text.toLowerCase() === "null") return null;
  let parsed;
  try {
    parsed = new URL(text);
  } catch {
    return null;
  }
  if (parsed.protocol !== "http:") return null;
  return { name: normalizeName(parsed.hostname), port: parsed.port ? Number(parsed.port) : 80 };
}

/**
 * 判定一次本机接口请求是否可信。
 * @param {object} headers Node 的 request.headers（键已小写）。
 * @param {object} [options]
 * @param {number} [options.port] 服务监听端口；Host/Origin 带的端口必须与它一致。
 * @param {string[]} [options.names] 允许的名字白名单，缺省用 DEFAULT_ALLOWED_NAMES。
 * @param {boolean} [options.requireClientHeader] 是否要求梁鲸界面标识头（改状态的路由必须为 true）。
 * @returns {{trusted: boolean, reason: string}}
 */
export function checkLocalRequest(headers, options = {}) {
  const source = headers && typeof headers === "object" ? headers : {};
  const expectedPort = options.port === undefined || options.port === null ? null : Number(options.port);
  const allowed = (Array.isArray(options.names) && options.names.length ? options.names : DEFAULT_ALLOWED_NAMES)
    .map(normalizeName)
    .filter(Boolean);

  const host = parseHostHeader(source.host);
  if (!host.ok) return { trusted: false, reason: host.reason };
  if (!allowed.includes(host.name)) return { trusted: false, reason: "host-not-allowed" };
  // Host 不带端口时不判端口：请求能到达这个 socket，说明对端本来就连的是该端口。
  if (host.port !== null && expectedPort !== null && host.port !== expectedPort) {
    return { trusted: false, reason: "host-port-mismatch" };
  }

  const rawOrigin = source.origin;
  if (rawOrigin !== undefined && rawOrigin !== null && String(rawOrigin).trim() !== "") {
    const origin = parseOrigin(rawOrigin);
    if (!origin || !allowed.includes(origin.name)) return { trusted: false, reason: "origin-not-allowed" };
    if (expectedPort !== null && origin.port !== expectedPort) return { trusted: false, reason: "origin-not-allowed" };
  }

  // 浏览器独有。地址栏直接打开是 none、同源是 same-origin，只有别站页面才会是 cross-site。
  // 重绑定场景这里同样是 same-origin，所以它只是补充，Host 判定才是主防线。
  const site = String(source["sec-fetch-site"] ?? "").trim().toLowerCase();
  if (site === "cross-site") return { trusted: false, reason: "cross-site-browser-request" };

  // 自定义头跨站必须过预检，而预检请求不会被放行，所以这一条挡住了"直连 127.0.0.1"的网页。
  if (options.requireClientHeader === true) {
    const client = String(source[CLIENT_HEADER] ?? "").trim().toLowerCase();
    if (client !== CLIENT_HEADER_VALUE) return { trusted: false, reason: "client-header-required" };
  }

  return { trusted: true, reason: "ok" };
}
