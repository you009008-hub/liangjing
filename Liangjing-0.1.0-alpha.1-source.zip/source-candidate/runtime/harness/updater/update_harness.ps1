﻿param([Parameter(Mandatory=$true)][string]$ProjectRoot,[Parameter(Mandatory=$true)][ValidatePattern('^[0-9A-Za-z._-]+$')][string]$RunId,[switch]$PrepareOnly,[string]$WorkRoot='')
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest

# 只替换 runtime/harness/app；Key、会话和知识库均在该目录之外。
$project=[IO.Path]::GetFullPath($ProjectRoot)
$runtime=[IO.Path]::GetFullPath((Join-Path $project 'runtime\harness'))
$targetApp=[IO.Path]::GetFullPath((Join-Path $runtime 'app'))
$node=Join-Path $runtime 'node.exe'
$npmCli=Join-Path $runtime 'updater\npm\bin\npm-cli.js'
$statusPath=Join-Path $runtime 'update-status.json'
$backupRoot=Join-Path $runtime 'backups'
$backupPath=''; $touchedRuntime=$false; $latest=''; $current=''
$npmStep=0
if(-not $WorkRoot){$WorkRoot=Join-Path $env:TEMP "blue-whale-harness-update-$RunId"}
$stageRoot=[IO.Path]::GetFullPath($WorkRoot)
$stageApp=Join-Path $stageRoot 'app'
if($PrepareOnly){$statusPath=Join-Path $stageRoot 'update-status.json'}

function Write-UpdateStatus {
 param([string]$Phase,[string]$Message,[bool]$Done=$false,[bool]$Ok=$false,[bool]$Updated=$false,[string]$Version='',[string]$Backup='',[bool]$TouchedRuntime=$false)
 $data=[ordered]@{run_id=$RunId;phase=$Phase;message=$Message;done=$Done;ok=$Ok;updated=$Updated;version=$Version;backup=$Backup;touched_runtime=$TouchedRuntime;timestamp=[DateTimeOffset]::Now.ToUnixTimeSeconds()}
 [IO.File]::WriteAllText($statusPath,($data|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
}
function Assert-ChildPath([string]$Parent,[string]$Child) {
 $p=[IO.Path]::GetFullPath($Parent).TrimEnd('\')+'\'; $c=[IO.Path]::GetFullPath($Child)
 if(-not $c.StartsWith($p,[StringComparison]::OrdinalIgnoreCase)){throw '安全检查失败：目标不在允许目录内。'}
}
function Invoke-Npm([string[]]$Arguments,[string]$Entry=$npmCli) {
 $script:npmStep++
 $logRoot=Join-Path $stageRoot 'logs';New-Item -ItemType Directory -Path $logRoot -Force|Out-Null
 $outLog=Join-Path $logRoot "npm-$script:npmStep.stdout.log"
 $errLog=Join-Path $logRoot "npm-$script:npmStep.stderr.log"
 $argsList=@($Entry)+$Arguments+@('--registry=https://registry.npmjs.org','--prefer-online','--cache',(Join-Path $stageRoot 'npm-cache'),'--fetch-retries=2','--fetch-timeout=60000')
 $quoted=@($argsList|ForEach-Object{ConvertTo-NativeArgument $_})
 $proc=Start-Process -FilePath $node -ArgumentList ($quoted -join ' ') -WorkingDirectory $stageApp -WindowStyle Hidden -PassThru -RedirectStandardOutput $outLog -RedirectStandardError $errLog
 try{
  $processHandle=$proc.Handle
  $deadline=[DateTime]::UtcNow.AddMinutes(15)
  while(-not $proc.WaitForExit(1000)){if([DateTime]::UtcNow -gt $deadline){$proc.Kill();throw '组件安装超过 15 分钟，已停止本次安装，请检查网络后重试。'}}
  $proc.WaitForExit()
  if($proc.ExitCode -ne 0){
   $text=[IO.File]::ReadAllText($errLog)
   $missing=[regex]::Match($text,'No matching version found for ([^\r\n]+)')
   if($missing.Success){throw "官方源版本列表不完整，找不到依赖 $($missing.Groups[1].Value) 请稍后重试；原版未替换。"}
   $code=[regex]::Match($text,'(?im)^npm (?:error|ERR!) code (\S+)')
   $detail=if($code.Success){$code.Groups[1].Value}else{"exit=$($proc.ExitCode)"}
   throw "官方组件安装失败（$detail）；诊断日志：$logRoot"
  }
 }finally{$proc.Dispose()}
}
function ConvertTo-NativeArgument([string]$Value) {
 return '"'+[regex]::Replace([regex]::Replace($Value,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"'
}
function Get-PackagePath([string]$ModulesRoot,[string]$PackageName) {
 if($PackageName.StartsWith('@')){$parts=$PackageName.Split('/');if($parts.Count-ne 2){return ''};return Join-Path $ModulesRoot (Join-Path $parts[0] (Join-Path $parts[1] 'package.json'))}
 return Join-Path $ModulesRoot (Join-Path $PackageName 'package.json')
}
function Get-MissingDeepSeekPeers([string]$AppRoot) {
 $modules=Join-Path $AppRoot 'node_modules';$scope=Join-Path $modules '@deepseek-ai';$missing=[ordered]@{}
 if(-not(Test-Path -LiteralPath $scope -PathType Container)){return @()}
 foreach($dir in Get-ChildItem -LiteralPath $scope -Directory){
  $pj=Join-Path $dir.FullName 'package.json';if(-not(Test-Path -LiteralPath $pj -PathType Leaf)){continue}
  $package=[IO.File]::ReadAllText($pj,[Text.Encoding]::UTF8)|ConvertFrom-Json
  $peerDepsProp=$package.PSObject.Properties['peerDependencies'];if(-not$peerDepsProp-or-not$peerDepsProp.Value){continue}
  foreach($peer in $peerDepsProp.Value.PSObject.Properties){
   $optional=$false
   $metaProp=$package.PSObject.Properties['peerDependenciesMeta']
   if($metaProp-and$metaProp.Value){$meta=$metaProp.Value.PSObject.Properties[$peer.Name];if($meta-and$meta.Value){$optProp=$meta.Value.PSObject.Properties['optional'];if($optProp-and$optProp.Value){$optional=$true}}}
   if($optional){continue};$installed=Get-PackagePath $modules $peer.Name
   if([string]::IsNullOrWhiteSpace($installed)-or-not(Test-Path -LiteralPath $installed -PathType Leaf)){$missing[$peer.Name]=[string]$peer.Value}
  }
 }
 return @($missing.GetEnumerator()|ForEach-Object{"$($_.Key)@$($_.Value)"})
}
function Enable-InstalledLifecycleScripts([string]$AppRoot) {
 $modules=Join-Path $AppRoot 'node_modules';$files=New-Object System.Collections.Generic.List[string]
 foreach($entry in Get-ChildItem -LiteralPath $modules -Directory){
  if($entry.Name.StartsWith('@')){foreach($scoped in Get-ChildItem -LiteralPath $entry.FullName -Directory){$f=Join-Path $scoped.FullName 'package.json';if(Test-Path -LiteralPath $f -PathType Leaf){$files.Add($f)}}}
  else{$f=Join-Path $entry.FullName 'package.json';if(Test-Path -LiteralPath $f -PathType Leaf){$files.Add($f)}}
 }
 $allow=[ordered]@{}
 foreach($f in $files){try{$p=[IO.File]::ReadAllText($f,[Text.Encoding]::UTF8)|ConvertFrom-Json;if(-not$p.name-or-not$p.version-or-not$p.scripts){continue};$names=@($p.scripts.PSObject.Properties.Name);if($names-contains'preinstall'-or$names-contains'install'-or$names-contains'postinstall'){$allow["$($p.name)@$($p.version)"]=$true}}catch{}}
 if($allow.Count-eq 0){return};$manifestPath=Join-Path $AppRoot 'package.json';$manifest=[IO.File]::ReadAllText($manifestPath,[Text.Encoding]::UTF8)|ConvertFrom-Json
 $manifest|Add-Member -NotePropertyName allowScripts -NotePropertyValue $allow -Force
 [IO.File]::WriteAllText($manifestPath,($manifest|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false));Invoke-Npm @('rebuild','--prefix',$AppRoot,'--no-audit','--no-fund')
}
function Wait-ProjectHarnessProcesses {
 $nodeFull=[IO.Path]::GetFullPath($node)
 $deadline=[DateTime]::UtcNow.AddMinutes(10)
 while($true){
  $running=@(Get-Process -Name node -ErrorAction SilentlyContinue|Where-Object{$_.Path-and[IO.Path]::GetFullPath($_.Path).Equals($nodeFull,[StringComparison]::OrdinalIgnoreCase)})
  if($running.Count-eq 0){return}
  Write-UpdateStatus 'waiting_for_exit' '新版已通过验证。请正常退出梁鲸，升级器会自动完成替换，然后重新打开梁鲸。' $false $false $false $latest
  if([DateTime]::UtcNow-ge$deadline){throw '等待梁鲸退出超时，原版未替换。请重新升级，并在提示时正常退出梁鲸。'}
  Start-Sleep -Seconds 1
 }
}
function Test-InteractionRejected([string]$Uri,[hashtable]$Headers,[string]$Body) {
 # [DSH] 安全回归断言：只关心"被拒了"，不关心拒绝文案。4xx/5xx 都算拒绝，
 # [DSH] 但连接失败、超时不算——那属于通道本身坏了，不能当成安全防线生效。
 try{Invoke-RestMethod -Method Post -Uri $Uri -ContentType 'application/json' -Headers $Headers -Body $Body -TimeoutSec 10|Out-Null;return $false}
 catch{$response=$_.Exception.Response;if($response-and[int]$response.StatusCode-ge 400){return $true};return $false}
}
function Invoke-HarnessSmokeTest([string]$AppRoot,[int]$CorePort,[int]$InteractionPort) {
 $launcher=Join-Path $AppRoot 'blue-whale-harness.mjs';if(-not(Test-Path -LiteralPath $launcher -PathType Leaf)){throw '升级包缺少蓝鲸通信入口。'}
 $testData=Join-Path $env:TEMP "blue-whale-harness-test-$RunId-$CorePort";New-Item -ItemType Directory -Path $testData -Force|Out-Null
 $testArgs=@($launcher,'--data-dir',$testData,'--host','127.0.0.1','--port',"$CorePort",'--interaction-port',"$InteractionPort")|ForEach-Object{ConvertTo-NativeArgument $_}
 $proc=Start-Process -FilePath $node -ArgumentList ($testArgs -join ' ') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $testData 'stdout.log') -RedirectStandardError (Join-Path $testData 'stderr.log')
 try{
  $health=$null
  for($i=0;$i-lt 60;$i++){Start-Sleep -Milliseconds 500;if($proc.HasExited){throw '新版 Harness 试运行时提前退出。'};try{$health=Invoke-RestMethod -Uri "http://127.0.0.1:$InteractionPort/health" -TimeoutSec 2;if($health.ok){break}}catch{}}
  if(-not$health-or-not$health.ok){throw '新版 Harness 健康检查超时。'}
  # [DSH] 交互桥安全回归：下面三条以前全部会被放行（43819 当初没有任何来源校验）。
  # [DSH] 注意上面那次 /health 没有带标识头也通过了——被拦的只是"会改状态"的路由，
  # [DSH] 只读通道保持可访问，便于用户自己用浏览器排查。
  $legit=@{'X-Blue-Whale-Client'='godot'}
  if(-not(Test-InteractionRejected -Uri "http://127.0.0.1:$InteractionPort/approval-test" -Headers @{} -Body '{}')){throw '交互桥未拒绝缺少梁鲸标识头的写请求。'}
  if(-not(Test-InteractionRejected -Uri "http://127.0.0.1:$InteractionPort/approval-test" -Headers @{'X-Blue-Whale-Client'='godot';'Origin'='https://evil.example'} -Body '{}')){throw '交互桥未拒绝跨站来源的写请求。'}
  if(-not(Test-InteractionRejected -Uri "http://127.0.0.1:$InteractionPort/approval-test" -Headers @{'X-Blue-Whale-Client'='godot';'Sec-Fetch-Site'='cross-site'} -Body '{}')){throw '交互桥未拒绝浏览器跨站标记的请求。'}
  # [DSH] 43818 网关的来源校验改由同一个守卫模块承担，这里回归一次，
  # [DSH] 确认重构没有把网关原有的 Origin 白名单丢掉。
  $body=@{type='client-request';rpcId='upgrade-test';method='session.list';payload=@{}}|ConvertTo-Json -Depth 4
  if(-not(Test-InteractionRejected -Uri "http://127.0.0.1:$CorePort/api/session.list" -Headers @{'Origin'='https://evil.example'} -Body $body)){throw '本地网关未拒绝跨站来源请求。'}
  $rpc=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$CorePort/api/session.list" -ContentType 'application/json' -Body $body -TimeoutSec 10
  if(-not$rpc-or-not$rpc.result.ok){throw '新版 Harness 会话通道测试失败。'}
  $body=@{type='client-request';rpcId='upgrade-create-test';method='session.create';payload=@{cwd=$testData}}|ConvertTo-Json -Depth 4
  $created=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$CorePort/api/session.create" -ContentType 'application/json' -Body $body -TimeoutSec 20
  if(-not$created.result.ok-or-not$created.result.value.sessionId){throw '新版 Harness 创建会话测试失败。'}
  $approval=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$InteractionPort/approval-test" -ContentType 'application/json' -Headers $legit -Body (@{title='升级安全检查';message='自动验证审批返回通道';risk='low'}|ConvertTo-Json) -TimeoutSec 10
  if(-not$approval.ok-or-not$approval.rpcId){throw '新版 Harness 审批通道测试失败。'}
  $pending=Invoke-RestMethod -Uri "http://127.0.0.1:$InteractionPort/interactions" -TimeoutSec 10
  $item=@($pending.approvals|Where-Object{$_.rpcId-eq$approval.rpcId})
  if($item.Count-ne 1){throw '新版 Harness 审批轮询测试失败。'}
  $answer=@{rpcId=$item[0].rpcId;sessionId=$item[0].sessionId;approvalId=$item[0].approvalId;outcome='rejected'}|ConvertTo-Json
  $receipt=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$InteractionPort/approval" -ContentType 'application/json' -Headers $legit -Body $answer -TimeoutSec 10
  if(-not$receipt.ok){throw '新版 Harness 审批返回测试失败。'}
  $question=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$InteractionPort/question-test" -ContentType 'application/json' -Headers $legit -Body '{}' -TimeoutSec 10
  $pending=Invoke-RestMethod -Uri "http://127.0.0.1:$InteractionPort/interactions" -TimeoutSec 10
  $item=@($pending.questions|Where-Object{$_.rpcId-eq$question.rpcId})
  if($item.Count-ne 1){throw '新版 Harness 追问轮询测试失败。'}
  $answer=@{rpcId=$item[0].rpcId;sessionId=$item[0].sessionId;cancelled=$true;answers=@()}|ConvertTo-Json
  $receipt=Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$InteractionPort/question" -ContentType 'application/json' -Headers $legit -Body $answer -TimeoutSec 10
  if(-not$receipt.ok){throw '新版 Harness 追问返回测试失败。'}
 }finally{if($proc-and-not$proc.HasExited){Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue}}
}

try{
 if(Test-Path -LiteralPath $stageRoot){throw '本次升级临时目录已存在，请使用新的运行编号。'}
 New-Item -ItemType Directory -Path $stageApp -Force|Out-Null
 Write-UpdateStatus 'starting' '升级服务已启动，正在准备升级流程……';Assert-ChildPath $project $runtime;Assert-ChildPath $runtime $targetApp
 if(-not(Test-Path -LiteralPath $node -PathType Leaf)){throw '免安装运行核心 node.exe 不完整。'}
 if(-not(Test-Path -LiteralPath $npmCli -PathType Leaf)){throw '一键升级组件不完整，请重新取得免安装版。'}
 if(-not$PrepareOnly){New-Item -ItemType Directory -Path $backupRoot -Force|Out-Null};Write-UpdateStatus 'checking' '正在查询 DeepSeek Harness 官方最新版……'
 $currentPackage=Join-Path $targetApp 'node_modules\@deepseek-ai\dsh\package.json'
 if(Test-Path -LiteralPath $currentPackage -PathType Leaf){$current=[string](([IO.File]::ReadAllText($currentPackage,[Text.Encoding]::UTF8)|ConvertFrom-Json).version)}
 if([string]::IsNullOrWhiteSpace($current)){$vf=Join-Path $targetApp 'runtime-version.json';if(Test-Path -LiteralPath $vf -PathType Leaf){$current=[string](([IO.File]::ReadAllText($vf,[Text.Encoding]::UTF8)|ConvertFrom-Json).version)}}
 $registry=Invoke-RestMethod -Uri 'https://registry.npmjs.org/%40deepseek-ai%2Fdsh' -TimeoutSec 20;$latest=[string]$registry.'dist-tags'.latest
 if([string]::IsNullOrWhiteSpace($latest)){throw '官方软件源没有返回可用版本。'}
 if($current-eq$latest){Write-UpdateStatus 'complete' "Harness $current 已是最新版。" $true $true $false $current;exit 0}
 # [DSH] 梁鲸自己的适配层文件全部以 blue-whale- 开头，必须原样带进新版本目录。
 # [DSH] 这里用通配符而不是逐个列举：以前每新增一个适配模块都得记得改这份名单，
 # [DSH] 一旦漏改，新版本 app 目录就会缺文件，Harness 因 import 失败整体起不来
 # [DSH] （桌宠会彻底连不上核心，而不是少一个功能），所以改成"有几个搬几个"。
 $adapterFiles=@(Get-ChildItem -LiteralPath $targetApp -Filter 'blue-whale-*.mjs' -File)
 if($adapterFiles.Count-lt 2){throw '当前 Harness 目录缺少梁鲸适配层文件，已停止升级。'}
 foreach($adapterFile in $adapterFiles){Copy-Item -LiteralPath $adapterFile.FullName -Destination (Join-Path $stageApp $adapterFile.Name)}
 # blue-whale-harness.mjs imports "ws" for its legacy fallback stream, so it must be
 # an explicit dependency. Depending on a hoisted transitive copy is not guaranteed.
 $wsVersion='8.21.3'
 $currentWs=Join-Path $targetApp 'node_modules\ws\package.json'
 if(Test-Path -LiteralPath $currentWs -PathType Leaf){$detected=[string](([IO.File]::ReadAllText($currentWs,[Text.Encoding]::UTF8)|ConvertFrom-Json).version);if(-not[string]::IsNullOrWhiteSpace($detected)){$wsVersion=$detected}}
 $manifest=[ordered]@{name='blue-whale-harness-runtime';private=$true;version=$latest;dependencies=[ordered]@{'@deepseek-ai/dsh'=$latest;'ws'=$wsVersion}}
 [IO.File]::WriteAllText((Join-Path $stageApp 'package.json'),($manifest|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false));$env:Path=$runtime+';'+$env:Path
 Write-UpdateStatus 'resolving' "正在锁定 Harness $latest 同批兼容组件……" $false $false $false $latest
 $resolver=Join-Path $PSScriptRoot 'resolve-release.cjs'
 if(-not(Test-Path -LiteralPath $resolver -PathType Leaf)){throw '升级组件缺少版本解析器。'}
 Invoke-Npm -Entry $resolver -Arguments @($npmCli,$stageApp,$latest,(Join-Path $stageRoot 'npm-cache'))
 Write-UpdateStatus 'downloading' "正在下载并安装 Harness $latest，首次升级可能需要几分钟……" $false $false $false $latest
 Invoke-Npm @('install','--prefix',$stageApp,'--omit=dev','--no-audit','--no-fund','--save-exact','--legacy-peer-deps',"@deepseek-ai/dsh@$latest")
 for($round=0;$round-lt 8;$round++){$missing=@(Get-MissingDeepSeekPeers $stageApp);if($missing.Count-eq 0){break};Write-UpdateStatus 'preparing' "正在补齐新版运行组件（第 $($round+1) 轮）……" $false $false $false $latest;Invoke-Npm (@('install','--prefix',$stageApp,'--omit=dev','--no-audit','--no-fund','--save-exact','--legacy-peer-deps')+$missing)}
 if(@(Get-MissingDeepSeekPeers $stageApp).Count-gt 0){throw '新版依赖没有完整安装。'};Enable-InstalledLifecycleScripts $stageApp
 # Preserve the contract fields of runtime-version.json. Earlier builds of this updater
 # rewrote the file with only five keys, silently dropping upstream_port and
 # implementation_revision that the shipped manifest carries.
 $rvPrevious=$null
 $rvPreviousPath=Join-Path $targetApp 'runtime-version.json'
 if(Test-Path -LiteralPath $rvPreviousPath -PathType Leaf){try{$rvPrevious=([IO.File]::ReadAllText($rvPreviousPath,[Text.Encoding]::UTF8)|ConvertFrom-Json)}catch{$rvPrevious=$null}}
 $rvUpstream=43918
 $rvRevision=1
 if($rvPrevious){
  # Set-StrictMode -Version Latest turns a missing property into a terminating error,
  # so every field is probed through PSObject.Properties instead of dot access. Files
  # written by the previous updater build are missing both fields by definition.
  $rvUpstreamProp=$rvPrevious.PSObject.Properties['upstream_port']
  if($rvUpstreamProp){
   $parsedUpstream=0
   if([int]::TryParse([string]$rvUpstreamProp.Value,[ref]$parsedUpstream)-and$parsedUpstream-gt 0){$rvUpstream=$parsedUpstream}
  }
  $rvRevisionProp=$rvPrevious.PSObject.Properties['implementation_revision']
  if($rvRevisionProp){
   $parsedRevision=0
   if([int]::TryParse([string]$rvRevisionProp.Value,[ref]$parsedRevision)-and$parsedRevision-gt 0){$rvRevision=$parsedRevision+1}
  }
 }
 $rv=[ordered]@{component='DeepSeek Harness';version=$latest;upstream_port=$rvUpstream;integration='blue-whale-agent-v1';implementation_revision=$rvRevision;port=43818;updated_at=[DateTimeOffset]::Now.ToString('o')};[IO.File]::WriteAllText((Join-Path $stageApp 'runtime-version.json'),($rv|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
 if((Get-ChildItem -LiteralPath $stageApp -File -Recurse|Measure-Object).Count-lt 1000){throw '新版文件数量异常，已停止替换。'}
 Write-UpdateStatus 'testing' '正在隔离试运行新版聊天与审批通道……' $false $false $false $latest;$testPort=Get-Random -Minimum 45200 -Maximum 47800;Invoke-HarnessSmokeTest $stageApp $testPort ($testPort+1)
 if($PrepareOnly){Write-UpdateStatus 'prepared' "Harness $latest 已完成隔离安装与验证，尚未替换当前版本。" $true $true $false $latest;exit 0}
 Wait-ProjectHarnessProcesses
 Write-UpdateStatus 'switching' '新版验证通过，正在备份旧版并安全切换……' $false $false $false $latest
 $stamp=Get-Date -Format 'yyyyMMdd-HHmmss';$safeCurrent=if($current){$current-replace'[^0-9A-Za-z._-]','_'}else{'unknown'};$backupPath=Join-Path $backupRoot "app-$safeCurrent-$stamp";Assert-ChildPath $backupRoot $backupPath
 Assert-ChildPath $stageRoot $stageApp
 if(-not(Test-Path -LiteralPath $targetApp -PathType Container)){throw '当前 Harness 目录不存在，已停止切换。'};Move-Item -LiteralPath $targetApp -Destination $backupPath;$touchedRuntime=$true;Move-Item -LiteralPath $stageApp -Destination $targetApp
 Write-UpdateStatus 'verifying' '正在对正式版本做最后一次健康检查……' $false $false $false $latest $backupPath $true;Invoke-HarnessSmokeTest $targetApp 47818 47819
 Write-UpdateStatus 'complete' "Harness 已安全升级到 $latest。" $true $true $true $latest $backupPath $true;exit 0
}catch{
 $failure=$_.Exception.Message
 try{if($backupPath-and(Test-Path -LiteralPath $backupPath -PathType Container)){Assert-ChildPath $runtime $targetApp;Assert-ChildPath $backupRoot $backupPath;if(Test-Path -LiteralPath $targetApp -PathType Container){$failedPath=Join-Path $backupRoot ('failed-app-'+(Get-Date -Format 'yyyyMMdd-HHmmss'));Assert-ChildPath $backupRoot $failedPath;Move-Item -LiteralPath $targetApp -Destination $failedPath};if(-not(Test-Path -LiteralPath $targetApp)){Move-Item -LiteralPath $backupPath -Destination $targetApp}}}catch{$failure="$failure；自动恢复也遇到问题：$($_.Exception.Message)"}
 Write-UpdateStatus 'failed' "升级失败：$failure。原版本已保留或恢复。" $true $false $false $current $backupPath $touchedRuntime;exit 1
}
