// Resolve the DSH release as a consistent graph instead of floating to partial prereleases.
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const [npmCli, appRoot, version, cache] = process.argv.slice(2);
const npmRequire = createRequire(npmCli);
const pacote = npmRequire('pacote');
const semver = npmRequire('semver');
const manifests = new Map();
const requirements = new Map([['@deepseek-ai/dsh', [version]]]);
const chosen = new Map();
const isDsh = name => name === '@deepseek-ai/dsh' || name.startsWith('@deepseek-ai/dsh-');
async function main() {
  while (true) {
    const pending = [...requirements.keys()].filter(name => !chosen.has(name));
    if (!pending.length) break;
    if (requirements.size > 1000) throw new Error('Dependency graph exceeded expected size');
    for (let start = 0; start < pending.length; start += 8) {
      await Promise.all(pending.slice(start, start + 8).map(async name => {
        const pack = await pacote.packument(name, { cache, registry: 'https://registry.npmjs.org', fullMetadata: true, preferOnline: true, fetchRetries: 2, fetchTimeout: 60000 });
        const ranges = requirements.get(name);
        const compatible = v => ranges.every(range => semver.satisfies(v, range));
        // Only a published, range-compatible version can be selected.
        const selected = pack.versions[version] && compatible(version) ? version
          : Object.keys(pack.versions).filter(v => compatible(v) && semver.lte(v, version)).sort(semver.rcompare)[0];
        if (!selected) throw new Error(`No compatible published dependency: ${name} ${ranges.join(', ')}`);
        chosen.set(name, selected);
        manifests.set(name, pack.versions[selected]);
      }));
    }
    for (const [name, manifest] of manifests) {
      for (const field of ['dependencies', 'peerDependencies']) {
        for (const [dep, range] of Object.entries(manifest[field] || {})) {
          if (!isDsh(dep)) continue;
          if (field === 'peerDependencies' && manifest.peerDependenciesMeta?.[dep]?.optional) continue;
          const list = requirements.get(dep) || [];
          if (!list.includes(range)) list.push(range);
          requirements.set(dep, list);
          if (chosen.has(dep) && !semver.satisfies(chosen.get(dep), range)) {
            throw new Error(`Incompatible release graph: ${name} requires ${dep}@${range}, selected ${chosen.get(dep)}`);
          }
        }
      }
    }
  }
  const dependencies = Object.fromEntries([...chosen].sort(([a], [b]) => a.localeCompare(b)));
  const manifest = { name: 'blue-whale-harness-runtime', private: true, version, dependencies, overrides: dependencies };
  fs.writeFileSync(path.join(appRoot, 'package.json'), JSON.stringify(manifest, null, 2));
  fs.writeFileSync(path.join(appRoot, 'release-resolution.json'), JSON.stringify({version, count: chosen.size, dependencies}, null, 2));
  console.log(`Resolved ${chosen.size} compatible DSH components for ${version}`);
}
main().catch(error => {console.error(error.message); process.exitCode = 1;});
