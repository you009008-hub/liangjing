# Windows 开发环境

## 当前验证基线

- Windows x64、PowerShell 5.1、Godot 4.7.1（当前目录可执行文件报告的版本，尚未核验官方下载校验值）。
- 当前捆绑 Node 报告 v24.19.0；Harness 依赖锁定在 runtime/harness/app/package-lock.json，以 npm ci 为准。Harness 组件版本不是梁鲸应用版本。
- 对应源码附件含原装资源，来源记录与独立许可状态见 LICENSE_STATUS.md；代码白名单与资产清单分开维护。不要使用私人素材的非授权下载链接补齐。

## 依赖准备步骤（尚未在全新机器完整实测）

1. 从 Godot 官方渠道获取对应 Windows x64 引擎和需要的导出模板，核验其校验值。当前启动脚本查找根目录 Godot_v4.7.1-stable_win64.exe。若官方无法取得该版本，不要把别的版本重命名冒充，应先做兼容验证再修改启动与测试脚本。
2. 从 Node 官方渠道获取兼容的 Windows x64 发行版，核验校验值。当前适配层需要 runtime/harness/node.exe，升级器需要 runtime/harness/updater/npm/bin/npm-cli.js；将发行版的 node.exe 与 node_modules/npm 按该布局放置。这些二进制和第三方模块不提交 Git。
3. 在项目根目录运行依赖安装（需要网络，npm 可能执行依赖安装脚本）：

~~~powershell
Push-Location runtime/harness/app
try {
  & ../node.exe ../updater/npm/bin/npm-cli.js ci
  if ($LASTEXITCODE -ne 0) { throw 'Harness dependency install failed' }
} finally { Pop-Location }
~~~

4. 补齐已经确认可分发的 assets 资源后运行 node tools/check-environment.mjs。此脚本仅检查文件布局/版本，不启动服务、不读取用户配置。
5. 通过根目录 启动梁鲸.bat 启动并首次导入资源。模型与 WeKnora 配置使用自己的服务；无共享凭据。

## 验证

从项目根目录执行 verify.cmd。该脚本依赖当前目录，不应从其他目录用绝对路径调用。它包含编码守卫（可能为已知脚本补 BOM）、升级器/适配器测试、本机来源守卫及隔离 headless 自检。产物放在 tmp 中，不加入版本控制。

~~~powershell
node tools/release-audit.test.mjs
node tools/release-audit.mjs
.\verify.cmd
~~~

默认自检不启动真实 Harness，使用独立测试数据。不要在普通验证中启用 -RealUserData 或真实知识库探针。真实窗口、外部服务、安装与打包需要单独验证并记录。

Windows .ps1 文件含中文时保留 UTF-8 BOM；.mjs/.gd 使用 UTF-8。不得按进程名称批量结束用户实例。

## 发布

先完成 docs/RELEASE_READINESS.md 的阻断项，再运行 node tools/release-audit.mjs --release。命令会在授权、素材或干净环境验证未完成时拒绝放行。Godot 导出预设不等于源码公开清单；不要直接压缩开发目录上传。

## 本地版本基线

仓库已初始化 main 分支，但自动化沙箱在补充 .git 写权限后仍拒绝 index.lock 写入，因此尚无首次提交。不要把初始化误认为已有可回滚的 Git 基线；原备份保留。

可在项目根目录、普通用户 PowerShell 中运行 tools/create-baseline.ps1。它会先验证公开清单，使用你配置的 Git 身份，仅提交白名单，并在已有提交时拒绝重复初始化；不会创建远程或推送。若没有配置 Git 身份，先设置本仓库 user.name / user.email。