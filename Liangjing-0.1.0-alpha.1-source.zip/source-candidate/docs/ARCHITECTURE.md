# 模块概览

| 层 | 主要文件 | 职责 |
|---|---|---|
| 桌面与接线 | main.gd、main.tscn | 桌宠生命周期、窗口和业务模块接线；当前仍较大，应渐进拆分 |
| 原生窗口 | native_windows.gd、native_file_picker.gd/.ps1 | 响应式功能窗、独立进程文件选择 |
| 人物与衣柜 | layered_character.gd、outfit_center.gd、着色器 | 角色动态、生成外观和收藏 |
| 对话与模型 | chat_response.gd、agent_bridge.gd、配置模块 | 消息呈现、模型配置、Harness 通信 |
| 资料 | soul_store.gd、weknora_client.gd、weknora_config.gd | 本地资料与外部知识库连接 |
| 工作流 | workflow_center.gd、workflow_package.gd、workflow_runner.gd | 编辑、分享格式、状态机和记录 |
| 工作流执行 | workflow_harness.gd、workflow_knowledge.gd | Harness 执行及 WeKnora 检索/问答 |
| 行为约束 | rule_center.gd、skill_registry.gd | 梁鲸自己的行为规则和技能配置 |
| 运行适配 | runtime/harness/app/blue-whale-*.mjs | 本机服务适配、请求来源守卫、交互协议 |

图节点编译为顺序步骤后交给运行器；知识库节点直接使用独立 WeKnora 客户端，其他远程节点经 Harness。配置和执行记录存放在用户数据目录，不应作为源码依赖。

分享包只包含可分享定义，知识库绑定在导出时清除。包含知识库节点的包使用格式版本 2，普通包仍可使用版本 1。导入后必须重新选库；图结构版本与应用版本并非同一概念。
