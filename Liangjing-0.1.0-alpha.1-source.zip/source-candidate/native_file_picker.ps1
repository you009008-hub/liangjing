﻿param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference = 'Stop'
$request = Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$result = @{ ok = $false; paths = @() }
try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()
    if ([int]$request.mode -eq 5) {
        $answer = [System.Windows.Forms.MessageBox]::Show([string]$request.message, [string]$request.title, [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Warning, [System.Windows.Forms.MessageBoxDefaultButton]::Button2)
        if ($answer -eq [System.Windows.Forms.DialogResult]::OK) { $result.ok = $true; $result.paths = @('confirmed') }
    } elseif ([int]$request.mode -eq 2) {
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = [string]$request.title
        if (Test-Path -LiteralPath $request.directory -PathType Container) { $dialog.SelectedPath = ([string]$request.directory).Replace('/','\') }
    } else {
        if ([int]$request.mode -eq 4) { $dialog = New-Object System.Windows.Forms.SaveFileDialog }
        else { $dialog = New-Object System.Windows.Forms.OpenFileDialog; $dialog.Multiselect = ([int]$request.mode -eq 1) }
        $dialog.Title = [string]$request.title
        $dialog.AutoUpgradeEnabled = $true
        if (Test-Path -LiteralPath $request.directory -PathType Container) { $dialog.InitialDirectory = ([string]$request.directory).Replace('/','\') }
        $dialog.FileName = [string]$request.file
        $filters = foreach ($filter in $request.filters) {
            $parts = ([string]$filter).Split(';', 2)
            $pattern = $parts[0].Trim().Replace(',', ';')
            $label = if ($parts.Length -gt 1) { $parts[1].Trim() } else { $pattern }
            if ($pattern) { $label.Replace('|',' ') + '|' + $pattern.Replace('|','') }
        }
        $dialog.Filter = if ($filters) { $filters -join '|' } else { 'All files (*.*)|*.*' }
        if ($dialog -is [System.Windows.Forms.SaveFileDialog]) { $dialog.OverwritePrompt = $true }
    }
    # This modal dialog has no Liangjing owner: it cannot disable the app HWND.
    if ($dialog -and $dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $result.ok = $true
        [string[]]$selectedPaths = if ([int]$request.mode -eq 2) { $dialog.SelectedPath } else { $dialog.FileNames }
        $result.paths = @($selectedPaths)
    }
    if ($dialog) { $dialog.Dispose() }
} catch {
    $result.error = 'Windows file picker failed: ' + $_.Exception.Message
}
$outputPath = [string]$request.response
$tempPath = $outputPath + '.tmp'
[System.IO.File]::WriteAllText($tempPath, ($result | ConvertTo-Json -Depth 4 -Compress), [System.Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $tempPath -Destination $outputPath -Force
