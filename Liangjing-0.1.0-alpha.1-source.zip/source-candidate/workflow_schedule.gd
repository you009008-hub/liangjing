# [DSH] 工作流「定时」触发的决策层。
#
# 本文件由 DeepSeek Harness 增加，不属于 GPT 的改动。
#
# 背景：工作流中心的触发方式里有「定时」，此前同样只保存配置、从不触发。
# 与「对话自动匹配」不同，定时触发**没有人在旁边看着**——它会在你不在电脑前时
# 自己执行一串可能改动文件的操作。因此这里的判据必须比自动匹配更保守：
#
#   1) 只认 enabled + confirmed + trigger == "定时" 的工作流，且必须是可执行的步骤；
#   2) 必须**真的到达**计划时间才跑，不到就什么都不做；
#   3) 同一时间点只跑一次（哪怕主循环一秒调用十次）；
#   4) 错过太久的计划**不补跑**——补跑意味着"你不在时它突然动你的文件"，
#      而用户对错过的预期是"这次算了"，不是"下次开机一起补上"；
#   5) 两次运行之间有最小间隔兜底，避免配置有误时高频执行。
#
# 时间比较全部用"距零点的分钟数"，不碰时区、不碰日期格式，便于断言。
class_name BlueWhaleWorkflowSchedule
extends RefCounted

const TRIGGER_SCHEDULE := "定时"
# 计划时间过去多久之内还算"可以执行"；超过就判定为错过（不补跑）。
# 取 5 分钟：足够吸收主循环/启动延迟，又不会把"昨晚错过的"拖到今早补跑。
const CATCH_UP_WINDOW_MINUTES := 5
# 两次运行之间的最小间隔（分钟），异常配置的兜底。
const MIN_GAP_MINUTES := 1


# 判断某个计划工作流此刻是否该执行。
#
# schedule 字段：
#   mode       : "每天" | "每隔"（缺失时按"每天"处理）
#   time       : "HH:MM"（mode == "每天" 时使用）
#   every_minutes : 整数（mode == "每隔" 时使用）
#   workflow   : 工作流字典
# last_run     : 上次运行时间戳（unix 秒），从未运行为 0
#
# now 字段：
#   unix        : 当前 unix 时间
#   minute_of_day : 当前距零点分钟数（0..1439）
#   day_key     : 当天标识（"YYYY-MM-DD"，用于"每天只跑一次"）
#   last_day_key: 上次运行当天的标识
#
# 返回 {"run": bool, "reason": String, "workflow": Dictionary, "schedule_key": String}
static func decide(schedule: Dictionary, now: Dictionary) -> Dictionary:
	var workflow: Dictionary = schedule.get("workflow", {}) if schedule.get("workflow", {}) is Dictionary else {}
	if workflow.is_empty():
		return _no("计划里没有工作流")
	if not _is_runnable(workflow):
		return _no("工作流未启用、未确认或步骤不可执行")
	var unix := float(now.get("unix", 0.0))
	var last_run := float(schedule.get("last_run", 0.0))
	var minute_of_day := int(now.get("minute_of_day", -1))
	var day_key := str(now.get("day_key", ""))
	var last_day_key := str(schedule.get("last_day_key", ""))
	if minute_of_day < 0 or minute_of_day > 1439:
		return _no("当前时刻无效")
	# 兜底：两次运行之间必须有最小间隔，避免配置异常时高频执行。
	if last_run > 0.0 and unix - last_run < MIN_GAP_MINUTES * 60.0:
		return _no("距上次运行不足 %d 分钟" % MIN_GAP_MINUTES)
	var mode := str(schedule.get("mode", "每天"))
	if mode == "每隔":
		var every := int(schedule.get("every_minutes", 0))
		if every <= 0:
			return _no("间隔分钟数无效")
		if last_run <= 0.0:
			# 从未运行过：不立刻跑，等满一个间隔，避免"刚配好就动文件"。
			return _no("尚未运行过，先等满一个间隔")
		if unix - last_run < float(every) * 60.0:
			return _no("未到下一个间隔")
		return _yes("按间隔触发（每 %d 分钟）" % every, workflow, "every:%d" % every)
	# 默认按"每天"处理。
	var target := parse_time_of_day(str(schedule.get("time", "")))
	if target < 0:
		return _no("时间格式无效（应为 HH:MM）")
	if last_day_key == day_key and not day_key.is_empty():
		return _no("今天已经运行过")
	var delta := minute_of_day - target
	if delta < 0:
		return _no("还没到今天的计划时间")
	if delta > CATCH_UP_WINDOW_MINUTES:
		# 关键：错过太久不补跑。补跑等于"用户不在时突然动他的文件"。
		return _no("已错过计划时间 %d 分钟，不补跑" % delta)
	return _yes("到达每天 %s 的计划时间" % str(schedule.get("time", "")), workflow, "daily:%s" % day_key)


# "HH:MM" → 距零点分钟数；格式不对返回 -1。
#
# 严格要求**两位小时 + 两位分钟**：只判数值范围会放过 "09:0"、"9:5" 这类残缺写法，
# 它们看起来像时间却不是（断言实测到 "09:0" 被当成 09:00 接受）。
static func parse_time_of_day(text: String) -> int:
	var value := text.strip_edges()
	if value.is_empty():
		return -1
	var parts := value.split(":", false)
	if parts.size() != 2:
		return -1
	var hour_text := parts[0].strip_edges()
	var minute_text := parts[1].strip_edges()
	if hour_text.length() != 2 or minute_text.length() != 2:
		return -1
	if not hour_text.is_valid_int() or not minute_text.is_valid_int():
		return -1
	var hour := int(hour_text)
	var minute := int(minute_text)
	if hour < 0 or hour > 23 or minute < 0 or minute > 59:
		return -1
	return hour * 60 + minute


# 距零点的分钟数（用本地时间，与用户在界面里填的"HH:MM"同一口径）。
static func minute_of_day_now() -> int:
	var parts := Time.get_time_dict_from_system(false)
	return int(parts.get("hour", 0)) * 60 + int(parts.get("minute", 0))


static func day_key_now() -> String:
	return Time.get_date_string_from_system(false)


static func _is_runnable(workflow: Dictionary) -> bool:
	if str(workflow.get("trigger", "")) != TRIGGER_SCHEDULE:
		return false
	if not bool(workflow.get("enabled", false)) or not bool(workflow.get("confirmed", false)):
		return false
	if str(workflow.get("name", "")).strip_edges().is_empty():
		return false
	var steps: Variant = workflow.get("steps", [])
	if not steps is Array or steps.is_empty():
		return false
	for step in steps:
		if not step is Dictionary:
			return false
		var kind := str(step.get("type", ""))
		if kind == "条件分支":
			return false
		if not kind in ["模型处理", "Harness执行", "技能", "验证", "输出", "输入", "用户交互"]:
			return false
	return true


static func _no(reason: String) -> Dictionary:
	return {"run": false, "reason": reason, "workflow": {}, "schedule_key": ""}


static func _yes(reason: String, workflow: Dictionary, key: String) -> Dictionary:
	return {"run": true, "reason": reason, "workflow": workflow, "schedule_key": key}


# ── 自检 ──────────────────────────────────────────────────────────────
# 注意：断言的重点是"**不该跑**"的分支。定时任务在用户不在时执行有副作用的操作，
# 判错方向的代价（误跑）远大于漏跑。
static func selftest() -> Dictionary:
	var failures: Array[String] = []
	var cases := 0
	var step := {"type": "模型处理", "name": "整理昨日会话"}
	var workflow := {
		"name": "每日整理",
		"trigger": TRIGGER_SCHEDULE,
		"enabled": true,
		"confirmed": true,
		"steps": [step]
	}
	var nine := 9 * 60
	var base_now := {"unix": 1_800_000_000.0, "minute_of_day": nine, "day_key": "2026-09-15"}

	# 正常：到达每天 09:00 → 应该跑。
	var on_time := decide({"mode": "每天", "time": "09:00", "workflow": workflow, "last_run": 1_799_000_000.0}, base_now)
	cases += 1
	if not bool(on_time.get("run", false)):
		failures.append("到达计划时间却没有触发：%s" % str(on_time.get("reason", "")))

	# 不该跑之一：还没到时间。
	var early := decide({"mode": "每天", "time": "10:30", "workflow": workflow, "last_run": 1_799_000_000.0}, base_now)
	cases += 1
	if bool(early.get("run", false)):
		failures.append("还没到计划时间就跑了")

	# 不该跑之二：错过太久（不补跑）。这是本模块最重要的安全边界。
	var missed := decide({"mode": "每天", "time": "07:00", "workflow": workflow, "last_run": 1_799_000_000.0}, base_now)
	cases += 1
	if bool(missed.get("run", false)):
		failures.append("错过计划时间很久后仍然补跑——用户不在时不该突然执行")
	cases += 1
	if not str(missed.get("reason", "")).contains("不补跑"):
		failures.append("错过时的原因没有说明不补跑：%s" % str(missed.get("reason", "")))

	# 刚好在容许窗口内（差 5 分钟）→ 应该跑。
	var edge := decide({"mode": "每天", "time": "08:55", "workflow": workflow, "last_run": 1_799_000_000.0}, base_now)
	cases += 1
	if not bool(edge.get("run", false)):
		failures.append("在容许窗口边界（差 5 分钟）没有触发")

	# 不该跑之三：今天已经跑过（哪怕时间点又到了）。
	var ran_today := decide({"mode": "每天", "time": "09:00", "workflow": workflow, "last_run": 1_799_996_000.0, "last_day_key": "2026-09-15"}, base_now)
	cases += 1
	if bool(ran_today.get("run", false)):
		failures.append("同一天内重复运行了")

	# 不该跑之四：未启用 / 未确认 / 触发方式不符 / 步骤不可执行。
	for field in ["enabled", "confirmed"]:
		var off := workflow.duplicate(true)
		off[field] = false
		cases += 1
		if bool(decide({"mode": "每天", "time": "09:00", "workflow": off, "last_run": 1_799_000_000.0}, base_now).get("run", false)):
			failures.append("工作流 %s=false 时仍然按时执行了" % field)
	var manual := workflow.duplicate(true)
	manual["trigger"] = "手动运行"
	cases += 1
	if bool(decide({"mode": "每天", "time": "09:00", "workflow": manual, "last_run": 1_799_000_000.0}, base_now).get("run", false)):
		failures.append("非定时触发的工作流被定时执行了")
	var branch := workflow.duplicate(true)
	branch["steps"] = [{"type": "条件分支", "name": "判断"}]
	cases += 1
	if bool(decide({"mode": "每天", "time": "09:00", "workflow": branch, "last_run": 1_799_000_000.0}, base_now).get("run", false)):
		failures.append("含条件分支的工作流被定时执行了（本版无法执行）")
	var empty_steps := workflow.duplicate(true)
	empty_steps["steps"] = []
	cases += 1
	if bool(decide({"mode": "每天", "time": "09:00", "workflow": empty_steps, "last_run": 1_799_000_000.0}, base_now).get("run", false)):
		failures.append("没有步骤的工作流被定时执行了")

	# 不该跑之五：时间格式无效。
	for bad in ["", "9", "09:0", "25:00", "09:70", "aa:bb"]:
		cases += 1
		if parse_time_of_day(bad) != -1:
			failures.append("无效时间格式没有被拒绝：%s" % bad)
	cases += 1
	if bool(decide({"mode": "每天", "time": "25:00", "workflow": workflow, "last_run": 1_799_000_000.0}, base_now).get("run", false)):
		failures.append("无效时间格式仍然触发了执行")

	# 不该跑之六：两次运行之间的最小间隔兜底（防止配置异常高频执行）。
	var too_soon := decide({"mode": "每天", "time": "09:00", "workflow": workflow, "last_run": base_now["unix"] - 30.0}, base_now)
	cases += 1
	if bool(too_soon.get("run", false)):
		failures.append("距上次运行仅 30 秒仍然再次执行")

	# 间隔模式：未运行过不立刻跑。
	var every_first := decide({"mode": "每隔", "every_minutes": 60, "workflow": workflow, "last_run": 0.0}, base_now)
	cases += 1
	if bool(every_first.get("run", false)):
		failures.append("间隔模式在从未运行过时立刻执行了（刚配好就动文件）")
	# 间隔模式：未到间隔不跑；到点则跑。
	var every_early := decide({"mode": "每隔", "every_minutes": 60, "workflow": workflow, "last_run": base_now["unix"] - 600.0}, base_now)
	cases += 1
	if bool(every_early.get("run", false)):
		failures.append("间隔模式未到间隔就执行了")
	var every_due := decide({"mode": "每隔", "every_minutes": 60, "workflow": workflow, "last_run": base_now["unix"] - 3700.0}, base_now)
	cases += 1
	if not bool(every_due.get("run", false)):
		failures.append("间隔模式到点却没有执行")
	# 间隔模式：无效间隔不跑。
	var every_bad := decide({"mode": "每隔", "every_minutes": 0, "workflow": workflow, "last_run": base_now["unix"] - 3700.0}, base_now)
	cases += 1
	if bool(every_bad.get("run", false)):
		failures.append("间隔为 0 时仍然执行了")

	# 不该跑之七：计划里没有工作流。
	cases += 1
	if bool(decide({"mode": "每天", "time": "09:00"}, base_now).get("run", false)):
		failures.append("空计划被执行了")

	# 时刻解析：合法值必须解对（否则"每天"模式永远不会触发）。
	# 注意 "9:05" 也必须被拒绝——格式一旦宽松，界面上就会出现"看着像时间其实不是"的值。
	cases += 1
	if parse_time_of_day("00:00") != 0 or parse_time_of_day("23:59") != 1439:
		failures.append("合法时间解析错误")
	cases += 1
	if parse_time_of_day("9:05") != -1:
		failures.append("单位数小时（9:05）没有被拒绝，格式要求应统一为两位")

	return {"ok": failures.is_empty(), "failures": failures, "cases": cases}
