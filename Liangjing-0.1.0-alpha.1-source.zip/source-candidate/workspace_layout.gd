# [DSH] 本文件由 DeepSeek Harness 从 main.gd 抽出（2026-09-13），不属于 GPT 的改动。
# 工作区响应式布局的纯几何计算。
#
# 抽出原因：这段逻辑（约 40 行）原先内联在 main.gd 的 apply_responsive_chat_layout() 里，
# 与控件操作混在一起，既无法单独断言，也很难在不动界面的情况下调整。
# 现在它是纯函数：给定画布与真实最小尺寸，返回两个面板的矩形，不接触任何控件。
#
# 注意：最小尺寸必须由调用方从**控件树真实值**传入（get_combined_minimum_size()），
# 不能退化成设计常量——字体放大后真实最小尺寸会变大，用常量会导致子控件溢出、
# 盖到相邻面板上（这是原注释里记录过的真实缺陷）。
class_name BlueWhaleWorkspaceLayout
extends RefCounted

# 与 main.gd 的同名常量保持一致；放在这里是为了让布局模块自包含、可单独断言。
const WORKSPACE_MAX_WIDTH := 1640.0
const CHAT_MAX_WIDTH := 1080.0
const ANALYSIS_MAX_WIDTH := 520.0
const CHAT_MAX_HEIGHT := 920.0
const ANALYSIS_MAX_HEIGHT := 850.0
const PANEL_GAP_Y := 9.0
const EDGE_BOTTOM := 18.0
const PANEL_VISUAL_GAP_MIN := 32.0
const PANEL_VISUAL_GAP_MAX := 42.0

# 保存布局与自动布局必须使用同一条阴影安全距离，旧布局不能绕过这里。
static func safe_gap_for_width(width: float) -> float:
	return clampf(width * 0.024, PANEL_VISUAL_GAP_MIN, PANEL_VISUAL_GAP_MAX)

# 返回 {"chat": Rect2, "analysis": Rect2, "gap": float, "margin": float}
# canvas: 宿主画布尺寸
# chat_min / analysis_min: 两个面板的**真实**最小尺寸（由调用方从控件树读取）
static func compute(canvas: Vector2, chat_min: Vector2, analysis_min: Vector2) -> Dictionary:
	var margin := clampf(canvas.x * 0.022, 14.0, 42.0)
	# 两块 StyleBox 阴影分别为 14px 和 15px；间距小于 29px 时矩形虽不相交，视觉仍会叠压。
	var gap := safe_gap_for_width(canvas.x)
	var available_width := maxf(1.0, canvas.x - margin * 2.0)
	var workspace_width := minf(available_width, WORKSPACE_MAX_WIDTH)
	var chat_ratio := 0.66 if canvas.x >= 1600.0 else (0.64 if canvas.x >= 1100.0 else 0.60)
	# 控件树的真实最小宽度可能大于设计常量。按真实值分配，避免子控件
	# 从聊天面板溢出并盖到解析面板上。
	var chat_min_width := maxf(chat_min.x, 0.0)
	var analysis_min_width := maxf(analysis_min.x, 0.0)
	var column_width := maxf(1.0, workspace_width - gap)
	var chat_width: float
	var analysis_width: float
	if chat_min_width + analysis_min_width <= column_width:
		var maximum_chat_width := column_width - analysis_min_width
		chat_width = clampf(column_width * chat_ratio, chat_min_width, minf(CHAT_MAX_WIDTH, maximum_chat_width))
		analysis_width = column_width - chat_width
		if analysis_width > ANALYSIS_MAX_WIDTH:
			analysis_width = ANALYSIS_MAX_WIDTH
			chat_width = minf(CHAT_MAX_WIDTH, column_width - analysis_width)
	else:
		# 画布装不下两栏真实最小宽度时，必须**按缺额比例同时收缩两栏**。
		#
		# 真机缺陷就出在这里：旧写法仍然把对话栏按它的最小宽度分配，
		# 而 911(对话最小) + 32(间隙) + 340(解析最小) + 57(边距) = 1340 > 1300，
		# 于是解析栏被挤到对话栏身上——实测间隙 -105px，两侧阴影整片叠压，
		# 用户看到的就是"解析窗压住对话窗"。
		# 按缺额比例收缩后实测间隙恢复到 32px；代价是两栏都比自己的最小尺寸略窄
		# （内容由控件自行裁剪/滚动），但这是唯一能保证不重叠的做法。
		var total_minimum := maxf(1.0, chat_min_width + analysis_min_width)
		var shortage := total_minimum - column_width
		var chat_floor := maxf(1.0, chat_min_width - shortage * (chat_min_width / total_minimum))
		var analysis_floor := maxf(1.0, analysis_min_width - shortage * (analysis_min_width / total_minimum))
		chat_width = maxf(1.0, floor((chat_floor + analysis_floor) * chat_ratio))
		analysis_width = maxf(1.0, column_width - chat_width)
	# 如果任一栏触及最大宽度，以实际总宽度重新居中，避免高分屏上左右失衡。
	var actual_workspace_width := chat_width + gap + analysis_width
	var workspace_x := (canvas.x - actual_workspace_width) * 0.5
	# 无人物立绘，默认布局从顶部边距开始，给对话内容更多高度。
	var desired_y := margin
	var chat_min_height := maxf(chat_min.y, 0.0)
	var analysis_min_height := maxf(analysis_min.y, 0.0)
	var workspace_min_height := maxf(chat_min_height, analysis_min_height + PANEL_GAP_Y)
	var latest_y_for_minimum := maxf(8.0, canvas.y - minf(workspace_min_height, maxf(1.0, canvas.y - 26.0)) - EDGE_BOTTOM)
	var chat_y := minf(desired_y, latest_y_for_minimum)
	var available_height := maxf(1.0, canvas.y - chat_y - EDGE_BOTTOM)
	var chat_height := minf(available_height, CHAT_MAX_HEIGHT)
	if available_height >= chat_min_height:
		chat_height = maxf(chat_height, chat_min_height)
	var analysis_y := chat_y + PANEL_GAP_Y
	var analysis_available_height := maxf(1.0, canvas.y - analysis_y - EDGE_BOTTOM)
	var analysis_height := minf(
		analysis_available_height,
		clampf(chat_height - 18.0, analysis_min_height, ANALYSIS_MAX_HEIGHT)
	)
	return {
		"chat": Rect2(Vector2(workspace_x, chat_y), Vector2(chat_width, chat_height)),
		"analysis": Rect2(Vector2(workspace_x + chat_width + gap, analysis_y), Vector2(analysis_width, analysis_height)),
		"gap": gap,
		"margin": margin
	}

# 布局是否完整落在画布内（自检与保存布局的可用性判断都用它）。
static func fits(chat: Rect2, analysis: Rect2, canvas: Vector2) -> bool:
	if chat.size.x <= 0.0 or chat.size.y <= 0.0 or analysis.size.x <= 0.0 or analysis.size.y <= 0.0:
		return false
	return (
		chat.position.x >= -0.5 and chat.position.y >= -0.5
		and analysis.position.x >= -0.5 and analysis.position.y >= -0.5
		and chat.end.x <= canvas.x + 0.5 and chat.end.y <= canvas.y + 0.5
		and analysis.end.x <= canvas.x + 0.5 and analysis.end.y <= canvas.y + 0.5
	)

# 自检：覆盖常见屏幕尺寸、极小画布、以及"真实最小尺寸大于设计值"的情形。
# 重点守两条不变量：面板不重叠、不出界；且真实最小尺寸必须被尊重。
static func selftest() -> Dictionary:
	var failures: Array[String] = []
	# [DSH] 真机超预算场景的定点回归，**放在最前**：它必须在其它用例之前被判定，
	# 否则前面画布的失败会掩盖这一条，反向验证时就看不到它到底有没有生效
	# （第一版就把它放在末尾，反向验证时它一条都没报，差点误判为"断言无效"）。
	# 用户机器实测：对话面板真实最小宽度 911、解析面板最小 340、窗口 1300×929。
	# 911 + 32(间隙) + 340 + 57(边距) = 1340 > 1300，即"两栏最小宽度本身放不下"。
	# 旧实现在这个分支仍然按对话栏最小宽度分配，于是对话栏 911、解析栏被挤到它身上
	# （真机实测间隙 -105px，两侧阴影整片叠压，解析窗盖住发送按钮）。
	# 断言：即使超预算，也必须是"两栏都略窄但互不重叠、间隙达标、完整在画布内"。
	var over_budget_canvas := Vector2(1300, 929)
	var over_budget := compute(over_budget_canvas, Vector2(911, 527), Vector2(340, 787))
	var over_chat: Rect2 = over_budget["chat"]
	var over_analysis: Rect2 = over_budget["analysis"]
	var over_gap := over_analysis.position.x - over_chat.end.x
	var over_required := safe_gap_for_width(over_budget_canvas.x)
	if over_gap + 0.5 < over_required:
		failures.append("超预算画布下两栏重叠/贴太近：间隙 %.1f < %.1f（chat=%s analysis=%s）" % [over_gap, over_required, over_chat, over_analysis])
	if not fits(over_chat, over_analysis, over_budget_canvas):
		failures.append("超预算画布下布局越界：chat=%s analysis=%s" % [over_chat, over_analysis])
	if over_chat.size.x <= 1.0 or over_analysis.size.x <= 1.0:
		failures.append("超预算画布下有栏被压到消失：chat=%.1f analysis=%.1f" % [over_chat.size.x, over_analysis.size.x])
	var canvases := [
		Vector2(1300, 929), Vector2(1920, 1080), Vector2(2560, 1440),
		Vector2(1024, 768), Vector2(800, 600), Vector2(640, 480),
	]
	# [聊天最小, 解析最小]——第二组模拟字体放大后的真实最小尺寸。
	# 第三组是**真机实测值**：字体放大后对话栏真实最小宽度已达 911，
	# 加上解析栏 340 与间隙 32、边距 57 后总计 1340 > 1300，
	# 也就是"两栏最小宽度根本放不下"。这一组必须存在，否则
	# 那个让解析窗压住对话窗的分支永远不会被自检走到。
	var minimums := [
		[Vector2(720, 440), Vector2(340, 330)],
		[Vector2(900, 620), Vector2(420, 520)],
		[Vector2(911, 527), Vector2(340, 787)],
	]
	var checked := 0
	for canvas in canvases:
		for pair in minimums:
			var chat_min: Vector2 = pair[0]
			var analysis_min: Vector2 = pair[1]
			var result := compute(canvas, chat_min, analysis_min)
			var chat: Rect2 = result["chat"]
			var analysis: Rect2 = result["analysis"]
			checked += 1
			if not fits(chat, analysis, canvas):
				failures.append("画布 %s 下布局越界：chat=%s analysis=%s" % [canvas, chat, analysis])
			# 不重叠：解析面板必须完全在聊天面板右侧（间隙为正）。
			if analysis.position.x < chat.end.x:
				failures.append("画布 %s 下两栏重叠：chat.end.x=%.1f analysis.x=%.1f" % [canvas, chat.end.x, analysis.position.x])
			# 间隙必须达到"阴影安全距离"：两块 StyleBox 阴影合计约 29px，
			# 几何上不相交不代表视觉上不叠压。保存布局与自动布局必须用同一条标准，
			# 否则旧坐标会被判为有效并覆盖掉正确分栏。
			var required_gap := safe_gap_for_width(canvas.x)
			if analysis.position.x + 0.5 < chat.end.x + required_gap:
				failures.append("画布 %s 下两栏间隙不足：%.1f < %.1f" % [canvas, analysis.position.x - chat.end.x, required_gap])
			# 尊重真实最小尺寸（画布装得下时必须满足）。
			var available_for_columns := maxf(1.0, minf(canvas.x - clampf(canvas.x * 0.022, 14.0, 42.0) * 2.0, WORKSPACE_MAX_WIDTH) - float(result["gap"]))
			var both_minimums_fit := chat_min.x + analysis_min.x <= available_for_columns
			if both_minimums_fit and chat.size.x + 0.5 < chat_min.x:
				failures.append("画布 %s 下聊天宽度小于真实最小：%.1f < %.1f" % [canvas, chat.size.x, chat_min.x])
			if both_minimums_fit and analysis.size.x + 0.5 < analysis_min.x:
				failures.append("画布 %s 下解析宽度小于真实最小：%.1f < %.1f" % [canvas, analysis.size.x, analysis_min.x])
			# 尺寸必须为正，否则控件会消失。
			if chat.size.x <= 0.0 or chat.size.y <= 0.0 or analysis.size.x <= 0.0 or analysis.size.y <= 0.0:
				failures.append("画布 %s 下出现非正尺寸：chat=%s analysis=%s" % [canvas, chat.size, analysis.size])
			# 居中：整组左右边距应对称。
			var left: float = chat.position.x
			var right: float = canvas.x - analysis.end.x
			if absf(left - right) > 1.0:
				failures.append("画布 %s 下未居中：左边距 %.1f 右边距 %.1f" % [canvas, left, right])
	# fits() 的边界
	if not fits(Rect2(0, 0, 100, 100), Rect2(110, 0, 100, 100), Vector2(220, 200)):
		failures.append("fits() 把合法布局判为不合规")
	if fits(Rect2(0, 0, 100, 100), Rect2(110, 0, 200, 100), Vector2(220, 200)):
		failures.append("fits() 没有发现右侧出界")
	if fits(Rect2(0, 0, 0, 100), Rect2(10, 0, 100, 100), Vector2(220, 200)):
		failures.append("fits() 没有发现零尺寸面板")
	return {"ok": failures.is_empty(), "failures": failures, "cases": checked + 3}
