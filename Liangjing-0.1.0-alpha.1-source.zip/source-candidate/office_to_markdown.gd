# Office 文档本地转换器。
# 直接读取 DOCX/XLSX 的 ZIP/XML 内容并转换为 Markdown，供本地知识库切片与索引使用。
# 转换过程不调用云端服务，也不会改写用户原文件。
class_name OfficeToMarkdown
extends RefCounted

func convert(path: String) -> Dictionary:
	var extension := path.get_extension().to_lower()
	if extension == "docx":
		return docx_to_markdown(path)
	if extension == "xlsx":
		return xlsx_to_markdown(path)
	return {"ok": false, "error": "暂不支持该 Office 格式。"}

func docx_to_markdown(path: String) -> Dictionary:
	var archive := ZIPReader.new()
	var open_error := archive.open(path)
	if open_error != OK:
		return {"ok": false, "error": "无法打开 Word 文件。"}
	var xml := archive.read_file("word/document.xml")
	archive.close()
	if xml.is_empty():
		return {"ok": false, "error": "Word 文件缺少正文。"}
	var parser := XMLParser.new()
	if parser.open_buffer(xml) != OK:
		return {"ok": false, "error": "Word 正文解析失败。"}
	var lines: Array[String] = []
	var paragraph := ""
	var paragraph_style := ""
	var in_paragraph := false
	var in_text := false
	while parser.read() == OK:
		var node_type := parser.get_node_type()
		var node_name := parser.get_node_name() if node_type in [XMLParser.NODE_ELEMENT, XMLParser.NODE_ELEMENT_END] else ""
		if node_type == XMLParser.NODE_ELEMENT:
			if node_name == "w:p":
				in_paragraph = true
				paragraph = ""
				paragraph_style = ""
			elif in_paragraph and node_name == "w:pStyle":
				paragraph_style = parser.get_named_attribute_value_safe("w:val")
			elif in_paragraph and node_name == "w:t":
				in_text = true
			elif in_paragraph and node_name == "w:tab":
				paragraph += "    "
			elif in_paragraph and node_name == "w:br":
				paragraph += "\n"
		elif node_type == XMLParser.NODE_TEXT and in_text:
			paragraph += parser.get_node_data()
		elif node_type == XMLParser.NODE_ELEMENT_END:
			if node_name == "w:t":
				in_text = false
			elif node_name == "w:p" and in_paragraph:
				var clean := paragraph.strip_edges()
				if not clean.is_empty():
					lines.append(markdown_paragraph(clean, paragraph_style))
				in_paragraph = false
	var markdown := "\n\n".join(lines).strip_edges()
	if markdown.is_empty():
		return {"ok": false, "error": "Word 文件没有可索引的文字。"}
	return {"ok": true, "text": markdown, "format": "docx_markdown"}

func markdown_paragraph(text: String, style: String) -> String:
	var normalized_style := style.to_lower()
	var heading_level := 0
	if normalized_style.begins_with("heading"):
		heading_level = int(normalized_style.trim_prefix("heading"))
	elif normalized_style in ["1", "2", "3", "4", "5", "6"]:
		heading_level = int(normalized_style)
	if heading_level >= 1 and heading_level <= 6:
		return "%s %s" % ["#".repeat(heading_level), text]
	return text

func xlsx_to_markdown(path: String) -> Dictionary:
	var archive := ZIPReader.new()
	var open_error := archive.open(path)
	if open_error != OK:
		return {"ok": false, "error": "无法打开 Excel 文件。"}
	var shared_strings := parse_shared_strings(archive.read_file("xl/sharedStrings.xml"))
	var sheets := workbook_sheets(archive)
	if sheets.is_empty():
		for file_name in archive.get_files():
			if file_name.begins_with("xl/worksheets/sheet") and file_name.ends_with(".xml"):
				sheets.append({"name": file_name.get_file().get_basename(), "path": file_name})
	var sections: Array[String] = []
	for sheet_value in sheets:
		var sheet: Dictionary = sheet_value
		var rows := parse_worksheet(archive.read_file(str(sheet.get("path", ""))), shared_strings)
		if not rows.is_empty():
			sections.append("## %s\n\n%s" % [sheet.get("name", "工作表"), rows_to_markdown(rows)])
	archive.close()
	var markdown := "\n\n".join(sections).strip_edges()
	if markdown.is_empty():
		return {"ok": false, "error": "Excel 文件没有可索引的单元格。"}
	return {"ok": true, "text": markdown, "format": "xlsx_markdown"}

func parse_shared_strings(xml: PackedByteArray) -> Array[String]:
	var strings: Array[String] = []
	if xml.is_empty():
		return strings
	var parser := XMLParser.new()
	if parser.open_buffer(xml) != OK:
		return strings
	var in_item := false
	var in_text := false
	var value := ""
	while parser.read() == OK:
		var node_type := parser.get_node_type()
		var node_name := parser.get_node_name() if node_type in [XMLParser.NODE_ELEMENT, XMLParser.NODE_ELEMENT_END] else ""
		if node_type == XMLParser.NODE_ELEMENT:
			if node_name == "si":
				in_item = true
				value = ""
			elif in_item and node_name == "t":
				in_text = true
		elif node_type == XMLParser.NODE_TEXT and in_text:
			value += parser.get_node_data()
		elif node_type == XMLParser.NODE_ELEMENT_END:
			if node_name == "t":
				in_text = false
			elif node_name == "si" and in_item:
				strings.append(value)
				in_item = false
	return strings

func workbook_sheets(archive: ZIPReader) -> Array:
	var relations := workbook_relationships(archive.read_file("xl/_rels/workbook.xml.rels"))
	var xml := archive.read_file("xl/workbook.xml")
	var sheets: Array = []
	if xml.is_empty():
		return sheets
	var parser := XMLParser.new()
	if parser.open_buffer(xml) != OK:
		return sheets
	while parser.read() == OK:
		if parser.get_node_type() == XMLParser.NODE_ELEMENT and parser.get_node_name() == "sheet":
			var name := parser.get_named_attribute_value_safe("name")
			var relation_id := parser.get_named_attribute_value_safe("r:id")
			var target := str(relations.get(relation_id, ""))
			if not target.is_empty():
				if target.begins_with("/"):
					target = target.trim_prefix("/")
				elif not target.begins_with("xl/"):
					target = "xl/" + target.trim_prefix("../")
				sheets.append({"name": name, "path": target})
	return sheets

func workbook_relationships(xml: PackedByteArray) -> Dictionary:
	var relations := {}
	if xml.is_empty():
		return relations
	var parser := XMLParser.new()
	if parser.open_buffer(xml) != OK:
		return relations
	while parser.read() == OK:
		if parser.get_node_type() == XMLParser.NODE_ELEMENT and parser.get_node_name() == "Relationship":
			relations[parser.get_named_attribute_value_safe("Id")] = parser.get_named_attribute_value_safe("Target")
	return relations

func parse_worksheet(xml: PackedByteArray, shared_strings: Array[String]) -> Array:
	var rows: Array = []
	if xml.is_empty():
		return rows
	var parser := XMLParser.new()
	if parser.open_buffer(xml) != OK:
		return rows
	var row_cells := {}
	var in_cell := false
	var in_value := false
	var in_inline_text := false
	var cell_type := ""
	var cell_reference := ""
	var cell_value := ""
	while parser.read() == OK:
		var node_type := parser.get_node_type()
		var node_name := parser.get_node_name() if node_type in [XMLParser.NODE_ELEMENT, XMLParser.NODE_ELEMENT_END] else ""
		if node_type == XMLParser.NODE_ELEMENT:
			if node_name == "row":
				row_cells = {}
			elif node_name == "c":
				in_cell = true
				cell_type = parser.get_named_attribute_value_safe("t")
				cell_reference = parser.get_named_attribute_value_safe("r")
				cell_value = ""
			elif in_cell and node_name == "v":
				in_value = true
			elif in_cell and node_name == "t":
				in_inline_text = true
		elif node_type == XMLParser.NODE_TEXT:
			if in_value or in_inline_text:
				cell_value += parser.get_node_data()
		elif node_type == XMLParser.NODE_ELEMENT_END:
			if node_name == "v":
				in_value = false
			elif node_name == "t":
				in_inline_text = false
			elif node_name == "c" and in_cell:
				var resolved := cell_value
				if cell_type == "s" and cell_value.is_valid_int():
					var shared_index := int(cell_value)
					if shared_index >= 0 and shared_index < shared_strings.size():
						resolved = shared_strings[shared_index]
				row_cells[column_index(cell_reference)] = resolved
				in_cell = false
			elif node_name == "row":
				if not row_cells.is_empty():
					var max_column := 0
					for column in row_cells:
						max_column = maxi(max_column, int(column))
					var row: Array[String] = []
					for column in range(max_column + 1):
						row.append(str(row_cells.get(column, "")))
					rows.append(row)
	return rows

func column_index(reference: String) -> int:
	var letters := ""
	for character in reference:
		if character.to_upper() >= "A" and character.to_upper() <= "Z":
			letters += character.to_upper()
		else:
			break
	var result := 0
	for character in letters:
		result = result * 26 + character.unicode_at(0) - 64
	return maxi(0, result - 1)

func rows_to_markdown(rows: Array) -> String:
	var width := 0
	for row_value in rows:
		width = maxi(width, Array(row_value).size())
	if width == 0:
		return ""
	var normalized: Array = []
	for row_value in rows:
		var row := Array(row_value).duplicate()
		while row.size() < width:
			row.append("")
		normalized.append(row)
	var header: Array = normalized[0]
	for index in range(width):
		if str(header[index]).strip_edges().is_empty():
			header[index] = "列%d" % (index + 1)
	var lines: Array[String] = []
	lines.append("| " + " | ".join(escape_markdown_row(header)) + " |")
	var separator: Array[String] = []
	for _index in range(width):
		separator.append("---")
	lines.append("| " + " | ".join(separator) + " |")
	for row_index in range(1, normalized.size()):
		lines.append("| " + " | ".join(escape_markdown_row(normalized[row_index])) + " |")
	return "\n".join(lines)

func escape_markdown_row(row: Array) -> Array[String]:
	var escaped: Array[String] = []
	for value in row:
		escaped.append(str(value).replace("|", "\\|").replace("\r", " ").replace("\n", " "))
	return escaped
