# 解析窗口顶部的状态动画。
# active 表示模型正在处理，completion 用于结束阶段的收束动画；本控件不接收鼠标输入。
class_name BlueWhaleAnalysisOrb
extends Control

var active := false
var phase := 0.0
var completion := 0.0

func _ready() -> void:
	custom_minimum_size = Vector2(76, 76)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)

func set_active(value: bool) -> void:
	active = value
	if value:
		completion = 0.0
	queue_redraw()

func mark_complete() -> void:
	active = false
	completion = 1.0
	queue_redraw()

func _process(delta: float) -> void:
	phase = fmod(phase + delta * (3.4 if active else 0.72), TAU)
	completion = move_toward(completion, 0.0, delta * 0.45)
	queue_redraw()

func _draw() -> void:
	var center := size * 0.5
	var breath := 1.0 + sin(phase * 1.7) * 0.035
	var glow_alpha := 0.17 + (0.08 if active else 0.0) + completion * 0.13
	draw_circle(center, 32.0 * breath, Color(0.18, 0.66, 1.0, glow_alpha))
	draw_circle(center, 22.0, Color(0.035, 0.20, 0.43, 0.96))
	draw_circle(center, 14.0 + sin(phase * 2.0) * 1.1, Color(0.14, 0.60, 0.96, 0.98))
	draw_circle(center - Vector2(4, 5), 4.2, Color(0.76, 0.95, 1.0, 0.9))

	var rotation := phase if active else phase * 0.32
	for ring_index in range(2):
		var radius := 27.0 + ring_index * 7.0
		var width := 2.7 - ring_index * 0.5
		var offset := rotation * (1.0 if ring_index == 0 else -0.72)
		for segment in range(3):
			var start := offset + float(segment) * TAU / 3.0
			draw_arc(center, radius, start, start + 0.72, 18, Color(0.22, 0.72, 1.0, 0.92 - ring_index * 0.22), width, true)

	for dot_index in range(3):
		var angle := -rotation * 1.18 + float(dot_index) * TAU / 3.0
		var dot_position := center + Vector2(cos(angle), sin(angle)) * 34.0
		draw_circle(dot_position, 2.8, Color(0.69, 0.93, 1.0, 0.95))
