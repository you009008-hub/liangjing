# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 从 main.gd 抽出：模型回复的 Markdown → BBCode 渲染，含 18 条用例自检。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 模型回复的 Markdown → BBCode 渲染器（纯函数，无副作用）。
#
# 背景：RichTextLabel 不会自动理解模型返回的 Markdown，如果原样塞进去，用户会看到
# 满屏的 ##、** 和竖线。这里把常见标题、粗体、行内代码、列表、引用、分隔线与表格
# 转换成安全 BBCode；方括号一律转义，避免模型输出把界面样式弄坏。
#
# 从 main.gd 抽出，便于单独自检，也让主控制器不再承担渲染细节。
class_name BlueWhaleMarkdownFormatter
extends RefCounted

const HEADING_SIZES := {1: 20, 2: 18, 3: 16}

static func to_bbcode(markdown: String) -> String:
	var lines := markdown.replace("\r\n", "\n").replace("\r", "\n").split("\n")
	var output := ""
	var index := 0
	var in_code_block := false
	while index < lines.size():
		var line := str(lines[index])
		var trimmed := line.strip_edges()
		if trimmed.begins_with("```"):
			output += "[/code]\n" if in_code_block else "[code]"
			in_code_block = not in_code_block
			index += 1
			continue
		if in_code_block:
			output += escape_bbcode(line) + "\n"
			index += 1
			continue
		if index + 1 < lines.size() and line.contains("|") and is_table_separator(str(lines[index + 1])):
			var header_cells := table_cells(line)
			output += "[table=%d]" % maxi(1, header_cells.size())
			for cell in header_cells:
				output += "[cell][b]%s[/b][/cell]" % inline_to_bbcode(str(cell))
			index += 2
			while index < lines.size():
				var row_line := str(lines[index])
				if row_line.strip_edges().is_empty() or not row_line.contains("|"):
					break
				var row_cells := table_cells(row_line)
				for column in range(header_cells.size()):
					var cell_text := str(row_cells[column]) if column < row_cells.size() else ""
					output += "[cell]%s[/cell]" % inline_to_bbcode(cell_text)
				index += 1
			output += "[/table]\n\n"
			continue
		if trimmed.is_empty():
			output += "\n"
			index += 1
			continue
		var heading_level := heading_level_of(trimmed)
		if heading_level > 0:
			var heading_text := trimmed.substr(heading_level).strip_edges()
			var heading_size := int(HEADING_SIZES.get(heading_level, 16))
			output += "[color=#2388c7]◆[/color] [font_size=%d][b]%s[/b][/font_size]\n" % [heading_size, inline_to_bbcode(heading_text)]
		elif trimmed.begins_with("- ") or trimmed.begins_with("* ") or trimmed.begins_with("+ "):
			output += "  [color=#3ba7df]•[/color] %s\n" % inline_to_bbcode(trimmed.substr(2))
		elif trimmed.begins_with("> "):
			output += "[color=#3ba7df]▌[/color] %s\n" % inline_to_bbcode(trimmed.substr(2))
		elif trimmed in ["---", "***", "___"]:
			output += "[color=#b8d5e8]────────────────────────[/color]\n"
		else:
			output += inline_to_bbcode(line) + "\n"
		index += 1
	if in_code_block:
		output += "[/code]\n"
	return output.trim_suffix("\n")

# 返回 1..6 表示 # 到 ###### 标题；0 表示不是标题。
static func heading_level_of(line: String) -> int:
	var count := 0
	while count < mini(6, line.length()) and line.substr(count, 1) == "#":
		count += 1
	if count > 0 and count < line.length() and line.substr(count, 1) == " ":
		return count
	return 0

static func table_cells(line: String) -> Array[String]:
	var clean := line.strip_edges()
	if clean.begins_with("|"):
		clean = clean.substr(1)
	if clean.ends_with("|"):
		clean = clean.left(clean.length() - 1)
	var cells: Array[String] = []
	for value in clean.split("|"):
		cells.append(str(value).strip_edges())
	return cells

# 形如 | --- | :--: | 的分隔行。
static func is_table_separator(line: String) -> bool:
	var cells := table_cells(line)
	if cells.is_empty():
		return false
	for cell in cells:
		var core := str(cell).strip_edges().trim_prefix(":").trim_suffix(":")
		if core.length() < 3 or not core.replace("-", "").is_empty():
			return false
	return true

# 行内渲染：**粗体** 与 `行内代码`，其余字符一律转义。
static func inline_to_bbcode(source: String) -> String:
	var output := ""
	var index := 0
	while index < source.length():
		if index + 1 < source.length() and source.substr(index, 2) == "**":
			var end := source.find("**", index + 2)
			if end >= 0:
				output += "[b]%s[/b]" % escape_bbcode(source.substr(index + 2, end - index - 2))
				index = end + 2
				continue
		if source.substr(index, 1) == "`":
			var code_end := source.find("`", index + 1)
			if code_end >= 0:
				output += "[bgcolor=#e8f1f7][color=#173f63]%s[/color][/bgcolor]" % escape_bbcode(source.substr(index + 1, code_end - index - 1))
				index = code_end + 1
				continue
		output += escape_bbcode(source.substr(index, 1))
		index += 1
	return output

static func escape_bbcode(value: String) -> String:
	# 必须单遍扫描：链式 replace 会把 [lb] 自带的方括号再转义一次，
	# 产出 [lb[rb] 这种坏标记（这一点是被自检抓出来的，不要再改回 replace 链）。
	var output := ""
	for index in range(value.length()):
		var character := value.substr(index, 1)
		if character == "[":
			output += "[lb]"
		elif character == "]":
			output += "[rb]"
		else:
			output += character
	return output

# 自检：覆盖标题、粗体、行内代码、列表、引用、分隔线、代码块、表格与转义。
# 返回 {"ok": bool, "failures": Array[String], "cases": int}。
static func selftest() -> Dictionary:
	var failures: Array[String] = []
	# [输入, 必须包含的子串, 必须不包含的子串]
	var cases := [
		["# 标题一", "[font_size=20]", "##"],
		["## 标题二", "[font_size=18]", "##"],
		["### 标题三", "[font_size=16]", "###"],
		["#### 四级标题", "[font_size=16]", "####"],
		["这是 **粗体** 文本", "[b]粗体[/b]", "**"],
		["这是 `code` 文本", "[bgcolor=#e8f1f7]", "`"],
		["- 项目一", "[color=#3ba7df]•[/color]", "- "],
		["* 星号项目", "[color=#3ba7df]•[/color]", "* "],
		["> 引用内容", "[color=#3ba7df]▌[/color]", "> "],
		["---", "────", "---"],
		["```\nx = 1\n```", "[code]", "```"],
		["| A | B |\n| --- | --- |\n| 1 | 2 |", "[cell][b]A[/b][/cell]", "|"],
		["普通 [方括号] 文本", "[lb]方括号[rb]", "[方括号]"],
		["#没有空格的井号", "", "font_size"],
	]
	# 转义必须用「长度变化」判定，不能用打印出来的文本判定：
	# Godot 控制台会把 [lb]/[rb] 当作 BBCode 渲染成尖括号，肉眼看会误以为没有转义。
	# 这一点此前真的误导过一次排查，所以下面用程序化断言而不是靠肉眼。
	# 每个裸方括号转义后增加 3 个字符。
	for escape_case in [["a]b", 3], ["a[b", 3], ["x]y", 3], ["abc]def", 3], ["[a]", 6]]:
		var escape_input := str(escape_case[0])
		var expected_delta := int(escape_case[1])
		var escaped := escape_bbcode(escape_input)
		if escaped.length() - escape_input.length() != expected_delta:
			failures.append("转义长度异常：输入=%s 长度=%d 输出长度=%d 期望增量=%d" % [escape_input, escape_input.length(), escaped.length(), expected_delta])
	# 转义后的文本里不允许再出现未转义的方括号，否则模型能借它改变界面样式。
	for escape_case in ["[b]注入[/b]", "a]b[c", "**加粗** [x]"]:
		var escaped_once := escape_bbcode(escape_case)
		var stripped := escaped_once.replace("[lb]", "").replace("[rb]", "")
		if stripped.contains("[") or stripped.contains("]"):
			failures.append("转义后仍有裸方括号：输入=%s 输出长度=%d" % [escape_case, escaped_once.length()])
	for case_value in cases:
		var case: Array = case_value
		var input := str(case[0])
		var must_contain := str(case[1])
		var must_not_contain := str(case[2])
		var rendered := to_bbcode(input)
		if not must_contain.is_empty() and not rendered.contains(must_contain):
			failures.append("缺少「%s」：输入=%s 输出=%s" % [must_contain, input.replace("\n", "\\n"), rendered.replace("\n", "\\n")])
		if not must_not_contain.is_empty() and rendered.contains(must_not_contain):
			failures.append("残留「%s」：输入=%s 输出=%s" % [must_not_contain, input.replace("\n", "\\n"), rendered.replace("\n", "\\n")])
	# 表格列数必须与表头一致，缺列要补空单元格而不是错位。
	var table_output := to_bbcode("| A | B |\n| --- | --- |\n| 1 |")
	if table_output.count("[cell]") != table_output.count("[/cell]"):
		failures.append("表格 cell 标签不配对：%s" % table_output)
	if table_output.count("[cell]") != 4:
		failures.append("表格单元格数量应为 4，实际 %d：%s" % [table_output.count("[cell]"), table_output])
	# 空输入不能崩，也不能产出内容。
	if not to_bbcode("").is_empty():
		failures.append("空输入应产出空字符串")
	# 未闭合的代码块必须补上 [/code]，否则后续整个会话的样式都会被带偏。
	if not to_bbcode("```\n未闭合").contains("[/code]"):
		failures.append("未闭合代码块没有补上 [/code]")
	return {"ok": failures.is_empty(), "failures": failures, "cases": cases.size() + 4}
