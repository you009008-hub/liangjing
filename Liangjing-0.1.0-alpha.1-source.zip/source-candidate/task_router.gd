# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 新增：任务分流判定（Harness / 直连模型），含 21 条用例自检。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 任务路由判定（纯函数，无副作用、不依赖场景树）。
#
# 目的：区分“只需要回答”与“需要操作这台电脑”。
#   - 只需要回答   → 走台灯里配置的对话模型，直接回答，不启动 Harness，也不涉及任何审批。
#   - 需要操作电脑 → 交给 Harness，改变电脑内容前仍然逐次弹出授权。
#
# 设计取舍：
# 1. 默认走 Harness。误判成“直接回答”会让用户的任务静默不执行，代价高于多一次 Harness 往返，
#    因此只有在明确不涉及电脑操作时才返回 direct。
# 2. 两侧都设了强信号。疑问句式、纯聊天、解释类动词不触发操作判定；
#    而“帮我/请”这类委托词只作为加分项，单独出现不足以判定为操作。
# 3. 附件一律按需要操作处理：本地解析结果要交给 Harness 才能继续，图片要交给视觉通道。
class_name BlueWhaleTaskRouter
extends RefCounted

const ROUTE_HARNESS := "harness"
const ROUTE_DIRECT := "direct"

# 命中即判定为“需要操作电脑”的强信号词组。
const OPERATION_PHRASES := [
	# 文件与目录
	"文件", "文件夹", "目录", "桌面", "文档", "下载", "磁盘", "路径", "压缩", "解压",
	# 读写类动作
	"新建", "创建", "删除", "移除", "重命名", "改名", "移动", "复制", "拷贝", "覆盖",
	"保存到", "写入", "追加", "生成文件", "导出", "导入", "批量改", "整理",
	# 执行类动作
	"运行", "执行", "启动", "打开", "关闭", "安装", "卸载", "部署", "编译", "构建",
	# 查看与检索真实环境
	"查看", "看一下", "查一下", "查询", "检查", "扫描", "列出", "统计",
	# 电脑与系统对象
	"电脑", "本机", "系统", "注册表", "进程", "服务", "环境变量", "命令行", "终端",
	"cmd", "powershell", "python", "脚本", "代码", "项目", "仓库", "git",
	# 网络与浏览器
	"网页", "网站", "浏览器", "链接", "网址", "下载",
	# 明确的电脑操作请求
	"帮我操作", "帮我改", "帮我做", "帮我处理", "帮我弄", "帮我找", "帮我装", "帮我删",
	"处理一下", "清理", "自动化", "爬取", "抓取",
]

# 明确“只是问答/解释”的信号。出现这些词且没有任何操作强信号时，判为直接回答。
const CONVERSATION_PHRASES := [
	"什么是", "是什么", "为什么", "怎么理解", "如何理解", "含义", "区别", "原理",
	"解释", "翻译", "改写", "润色", "总结一下这段", "帮我起名", "取个名字",
	"你觉得", "你认为", "建议", "推荐", "介绍", "讲讲", "聊聊", "谢谢", "你好",
]

# 委托词只用于在“无强信号”时提高操作倾向，单独出现不构成操作请求。
const DELEGATION_PHRASES := ["帮我", "帮忙", "请你", "麻烦你", "能不能", "可以吗"]

# 需要先落到本地/哈务通道的附件类型。
const ACTION_ATTACHMENT_KEYS := ["requires_vision", "requires_parser", "recognized"]

static func normalize(query: String) -> String:
	return query.strip_edges().to_lower()

# 返回 ROUTE_HARNESS 或 ROUTE_DIRECT。
static func decide(query: String, has_actionable_attachment := false) -> String:
	if has_actionable_attachment:
		return ROUTE_HARNESS
	var text := normalize(query)
	if text.is_empty():
		return ROUTE_DIRECT
	var operation_hits := count_matches(text, OPERATION_PHRASES)
	if operation_hits > 0:
		return ROUTE_HARNESS
	# 没有任何操作强信号：只有在明显是问答时才直接回答；
	# 其余含糊表述仍交给 Harness，避免把任务吞掉。
	if count_matches(text, CONVERSATION_PHRASES) > 0:
		return ROUTE_DIRECT
	if count_matches(text, DELEGATION_PHRASES) > 0:
		return ROUTE_HARNESS
	return ROUTE_DIRECT

static func count_matches(text: String, phrases: Array) -> int:
	var hits := 0
	for phrase_value in phrases:
		var phrase := str(phrase_value)
		if not phrase.is_empty() and text.contains(phrase):
			hits += 1
	return hits

# 供解析面板展示：把判定结果翻译成一句人话。
static func explain(route: String) -> String:
	return "需要操作电脑，交给 Harness" if route == ROUTE_HARNESS else "本轮只需回答，直接使用对话模型"

# 把 attach_info（soul_store.inspect_attachment 的结果）折算成“这个附件是否要求执行动作”。
static func attachment_requires_action(attachment: Dictionary) -> bool:
	if attachment.is_empty():
		return false
	for key in ACTION_ATTACHMENT_KEYS:
		if bool(attachment.get(key, false)):
			return true
	return false

# 判断某条消息是否要求操作电脑，附带判定依据，便于自检与解析面板展示。
static func classify(query: String, has_actionable_attachment := false) -> Dictionary:
	var route := decide(query, has_actionable_attachment)
	var text := normalize(query)
	return {
		"route": route,
		"operation_hits": count_matches(text, OPERATION_PHRASES),
		"conversation_hits": count_matches(text, CONVERSATION_PHRASES),
		"delegation_hits": count_matches(text, DELEGATION_PHRASES),
		"attachment": has_actionable_attachment,
		"explain": explain(route)
	}
