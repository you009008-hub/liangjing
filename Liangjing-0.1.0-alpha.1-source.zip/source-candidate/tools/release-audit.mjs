import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

// Findings contain only rule identifiers and locations, never matching values.
export function scanText(file, text) {
  const findings=[];
  const rules=[
    ['private-key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
    ['provider-token', /\b(?:sk-[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{35,}|AKIA[A-Z0-9]{16})\b/],
    ['credential-url', /https?:\/\/[^\s/"'`]+:[^\s/"'`]+@/],
    ['assigned-secret', /(?:api[_-]?key|access[_-]?token|password|secret)\s*["']?\s*[:=]\s*["'](?!\$|\{|<|example|placeholder|test|fake|isolated)[A-Za-z0-9_+\/-]{20,}["']/i],
    ['personal-windows-path', /[A-Z]:[\\/]+Users[\\/]+(?!Public\b|Default\b|<|\$)[\w. -]+[\\/]/i],
  ];
  text.split(/\r?\n/).forEach((line,index)=>{for(const [rule,re] of rules)if(re.test(line))findings.push({file,line:index+1,rule});});
  return findings;
}

export function audit(root, {release=false, checkGit=true}={}) {
  root=fs.realpathSync(root);
  const issues=[];
  const issue=(file,rule,line)=>issues.push({file,rule,...(line?{line}:{})});
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'tools/public-files.json'),'utf8').replace(/^\uFEFF/,''));
  if(manifest.schema!==1 || !Array.isArray(manifest.files))throw new Error('Invalid public manifest');
  const seen=new Set();
  for(const file of manifest.files){
    if(typeof file!=='string' || !file || /\\|\r|\n/.test(file) || path.posix.isAbsolute(file) || file.split('/').some(p=>p==='..'||p==='.'||p==='') || /^[A-Za-z]:/.test(file)){issue('<manifest>','unsafe-path');continue;}
    if(seen.has(file)){issue(file,'duplicate-entry');continue;}seen.add(file);
    if(/(^|\/)(?:\.git|node_modules|\.godot|backups|runtime-data|梁鲸数据)(\/|$)|\.(?:key|pem|pfx|log|exe|zip|pck)$|(^|\/)\.env(?:\.|$)/i.test(file)){issue(file,'forbidden-public-file');continue;}
    const full=path.join(root,file);
    if(!fs.existsSync(full)){issue(file,'missing-file');continue;}
    const real=fs.realpathSync(full), relative=path.relative(root,real);
    if(relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative)||real!==full||!fs.statSync(full).isFile()){issue(file,'link-or-outside-root');continue;}
    if(fs.statSync(full).size>8*1024*1024){issue(file,'oversize-review-required');continue;}
    const text=fs.readFileSync(full,'utf8');
    issues.push(...scanText(file,text));
    if(file.endsWith('package-lock.json')){
      try {const lock=JSON.parse(text.replace(/^\uFEFF/,''));for(const pkg of Object.values(lock.packages??{}))if(pkg.resolved){const u=new URL(pkg.resolved);if(u.protocol!=='https:'||u.hostname!=='registry.npmjs.org'||u.username||u.password)issue(file,'nonpublic-dependency-source');}}
      catch {issue(file,'invalid-lock-or-dependency-url');}
    }
  }
  if(checkGit){
    const tracked=spawnSync('git',['-C',root,'ls-files','-z'],{encoding:'utf8',windowsHide:true});
    if(tracked.status!==0)issue('<git>','git-unavailable-or-not-initialized');
    else for(const file of tracked.stdout.split('\0').filter(Boolean))if(!seen.has(file))issue(file,'tracked-outside-manifest');
    // --no-index checks rules even after files are staged/tracked.
    const ignored=spawnSync('git',['-C',root,'check-ignore','--no-index','--stdin','-z'],{input:[...seen].join('\0')+'\0',encoding:'utf8',windowsHide:true});
    if(ignored.error||![0,1].includes(ignored.status))issue('<git>','ignore-check-failed');
    else for(const file of ignored.stdout.split('\0').filter(Boolean))issue(file,'public-file-is-ignored');
  }
  const blockers=['asset-rights-confirmation','third-party-notice-review','clean-windows-install-test','private-security-reporting-channel'];
  if(release && (!seen.has('LICENSE') || !fs.existsSync(path.join(root,'LICENSE')))) blockers.unshift('missing-license');
  return {mode:release?'release':'preparation',files:seen.size,issues,releaseBlockers:blockers,ok:issues.length===0&&(!release||blockers.length===0)};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try {const result=audit(path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),{release:process.argv.includes('--release')});console.log(JSON.stringify(result,null,2));process.exitCode=result.ok?0:1;}
  catch {console.error('RELEASE_AUDIT_ERROR: inspect manifest or repository access; file contents withheld.');process.exitCode=2;}
}
