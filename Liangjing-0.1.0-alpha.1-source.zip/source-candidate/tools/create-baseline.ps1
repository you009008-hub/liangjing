﻿# Create the first LOCAL commit only. No remote, push, forced add, or cleanup.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    if (-not (Test-Path -LiteralPath '.git')) { throw 'Initialize the local Git repository first.' }
    & git rev-parse --verify --quiet HEAD | Out-Null
    if ($LASTEXITCODE -eq 0) { throw 'A commit already exists; use the normal review/commit workflow.' }
    $node = Join-Path $root 'runtime\harness\node.exe'
    if (-not (Test-Path -LiteralPath $node)) { $node = (Get-Command node -ErrorAction Stop).Source }
    & $node tools/release-audit.mjs
    if ($LASTEXITCODE -ne 0) { throw 'Preparation audit failed. Do not force-add excluded files.' }
    $name = & git config user.name
    $email = & git config user.email
    if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($email)) {
        throw 'Set your local git user.name and user.email before creating a commit.'
    }
    $manifest = Get-Content -LiteralPath 'tools/public-files.json' -Raw -Encoding UTF8 | ConvertFrom-Json
    $files = @($manifest.files)
    & git add -- @files
    if ($LASTEXITCODE -ne 0) { throw 'Git could not stage the reviewed file list.' }
    & $node tools/release-audit.mjs
    if ($LASTEXITCODE -ne 0) { throw 'Staged files did not pass the audit. Commit not created.' }
    & git commit -m 'chore: establish reviewed source baseline and open-source preparation'
    if ($LASTEXITCODE -ne 0) { throw 'Git did not create a commit.' }
    Write-Host 'LOCAL_BASELINE=PASS (not published)'
} finally { Pop-Location }
