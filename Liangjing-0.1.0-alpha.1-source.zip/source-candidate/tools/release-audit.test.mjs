import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {audit,scanText} from './release-audit.mjs';
const secret='sk-'+ 'X'.repeat(32);
let checks=0;
function test(name,fn){fn();checks++;console.log('PASS '+name);}
test('token finding redacts value',()=>{const r=scanText('sample.gd',secret);assert.equal(r[0].rule,'provider-token');assert.ok(!JSON.stringify(r).includes(secret));});
test('private key detected',()=>assert.equal(scanText('sample','-----BEGIN '+'PRIVATE KEY-----')[0].rule,'private-key'));
test('credential URL detected',()=>assert.equal(scanText('sample','https:'+'//user:pass@example.test')[0].rule,'credential-url'));
test('personal path detected',()=>assert.equal(scanText('sample','C:'+String.fromCharCode(92)+'Users'+String.fromCharCode(92)+'ExampleUser'+String.fromCharCode(92)+'data')[0].rule,'personal-windows-path'));
test('empty example not flagged',()=>assert.equal(scanText('sample','api_key = ""').length,0));
test('ordinary source not flagged',()=>assert.equal(scanText('sample','var api_key = load_api_key()').length,0));
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'liangjing-audit-'));
try{
  fs.mkdirSync(path.join(dir,'tools'));
  fs.writeFileSync(path.join(dir,'README.md'),'Example');
  const manifest=files=>fs.writeFileSync(path.join(dir,'tools/public-files.json'),JSON.stringify({schema:1,files}));
  test('clean preparation passes',()=>{manifest(['README.md']);assert.equal(audit(dir,{checkGit:false}).ok,true);});
  test('release holds for rights and clean install',()=>assert.equal(audit(dir,{checkGit:false,release:true}).ok,false));
  test('path traversal rejected',()=>{manifest(['../outside.txt']);assert.equal(audit(dir,{checkGit:false}).issues[0].rule,'unsafe-path');});
  test('absolute path rejected',()=>{manifest(['C:/outside.txt']);assert.equal(audit(dir,{checkGit:false}).issues[0].rule,'unsafe-path');});
  test('secret file rejected before reading',()=>{manifest(['config.key']);assert.equal(audit(dir,{checkGit:false}).issues[0].rule,'forbidden-public-file');});
  test('missing file rejected',()=>{manifest(['missing.gd']);assert.equal(audit(dir,{checkGit:false}).issues[0].rule,'missing-file');});
  test('duplicate rejected',()=>{manifest(['README.md','README.md']);assert.equal(audit(dir,{checkGit:false}).issues[0].rule,'duplicate-entry');});
  test('private registry rejected without URL disclosure',()=>{manifest(['package-lock.json']);fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify({packages:{x:{resolved:'https://private.invalid/a'}}}));const r=audit(dir,{checkGit:false});assert.equal(r.issues[0].rule,'nonpublic-dependency-source');assert.ok(!JSON.stringify(r).includes('private.invalid'));});
}finally{
  // Only remove this test-created directory after resolving its containment.
  const resolved=fs.realpathSync(dir), tmp=fs.realpathSync(os.tmpdir());
  if(path.dirname(resolved)===tmp&&path.basename(resolved).startsWith('liangjing-audit-'))fs.rmSync(resolved,{recursive:true});
}
console.log('RELEASE_AUDIT_TEST=PASS checks='+checks);
