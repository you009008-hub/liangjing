import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let missing=0;
const check=(name,ok)=>{console.log((ok?'PASS ':'FAIL ')+name);if(!ok)missing++;};
check('Windows x64',process.platform==='win32'&&process.arch==='x64');
const needed=['project.godot','main.tscn','native_file_picker.ps1','Godot_v4.7.1-stable_win64.exe','runtime/harness/node.exe','runtime/harness/updater/npm/bin/npm-cli.js','runtime/harness/app/node_modules/@deepseek-ai/dsh/lib/bin.js','runtime/harness/app/blue-whale-harness.mjs','runtime/harness/app/blue-whale-connection.mjs','runtime/harness/app/blue-whale-interaction-guard.mjs'];
for(const file of needed)check(file,fs.existsSync(path.join(root,file)));
const inventory=JSON.parse(fs.readFileSync(path.join(root,'docs/ASSET_INVENTORY.json'),'utf8'));
for(const item of inventory.files){const p=path.join(root,item.file);check(item.file,fs.existsSync(p)&&crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')===item.sha256);}
// Version commands do not launch the app or initialize services/user configuration.
for(const [name,args]of [['Godot_v4.7.1-stable_win64.exe',['--version']],['runtime/harness/node.exe',['--version']]]){
  if(!fs.existsSync(path.join(root,name)))continue;
  const r=spawnSync(path.join(root,name),args,{encoding:'utf8',windowsHide:true,timeout:10000});
  check(name+' version command',r.status===0);
  if(r.status===0)console.log('VERSION '+name+' '+r.stdout.trim().split(/\r?\n/)[0]);
}
console.log('This is a local layout check, not a clean-machine or public-release approval.');
console.log('ENVIRONMENT_CHECK='+(missing?'FAIL':'PASS'));
process.exitCode=missing?1:0;
