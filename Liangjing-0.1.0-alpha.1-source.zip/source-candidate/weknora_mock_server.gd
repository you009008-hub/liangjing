# [DSH] WeKnora 假服务（**只给自检用**，产品运行时不加载）。
#
# 为什么需要它：weknora_client.gd 的价值在于"HTTP 说得对、解析得对"，
# 只断言拼字符串等于没测。这里按官方文档的 schema 起一个真 HTTP 服务，
# 让客户端用真的 HTTPRequest 打过去，顺便验证 multipart 组包（文件字节原样到达）。
#
# 它同时是**契约的活文档**：字段名、分页、409 重复、解析状态流转都写在这里，
# 等接上真的 WeKnora，这份 mock 就是对照物。
extends Node

# 复用客户端的字节级子串查找（PackedByteArray.find 只按字节值找，不能找子串）。
const WeKnoraClientScript = preload("res://weknora_client.gd")

const API_PREFIX := "/api/v1"

var server := TCPServer.new()
var port := 0
var connections: Array = []
# SSE 连接单独放：它们要分多帧写，不能像普通请求那样写完就关。
var streaming_connections: Array = []
var requests: Array = []
var uploaded_files: Dictionary = {}
var parse_poll_count := 0
# 第一次查详情回 processing，之后回 completed —— 用来验证轮询真的会等到完成。
var parse_polls_before_done := 1

func start() -> bool:
	var error := server.listen(0, "127.0.0.1")
	if error != OK:
		push_warning("假服务无法监听本机端口：%d" % error)
		return false
	port = server.get_local_port()
	set_process(true)
	return true

func base_url() -> String:
	return "http://127.0.0.1:%d%s" % [port, API_PREFIX]

func stop() -> void:
	set_process(false)
	server.stop()

func _process(_delta: float) -> void:
	while server.is_connection_available():
		var peer := server.take_connection()
		if peer:
			connections.append({"peer": peer, "buffer": PackedByteArray()})
	_serve_connections()
	_pump_streams()

func _serve_connections() -> void:
	for index in range(connections.size() - 1, -1, -1):
		var entry: Dictionary = connections[index]
		var peer: StreamPeerTCP = entry["peer"]
		peer.poll()
		if peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
			connections.remove_at(index)
			continue
		var available := peer.get_available_bytes()
		if available > 0:
			var chunk: Array = peer.get_data(available)
			if int(chunk[0]) == OK:
				var buffer: PackedByteArray = entry["buffer"]
				buffer.append_array(chunk[1])
				entry["buffer"] = buffer
		var request := _parse_request(entry["buffer"])
		if request.is_empty():
			continue
		var streaming := _respond(peer, request)
		connections.remove_at(index)
		# 流式响应接管了这条连接，不能在这里断开——否则客户端只会收到第一片。
		if not streaming:
			peer.disconnect_from_host()

# 解析一个完整的 HTTP 请求：请求行 + 头 + Content-Length 指定的正文。
# 取不满就返回空字典，等下一帧继续攒——真实网络就是这样分片的。
func _parse_request(buffer: PackedByteArray) -> Dictionary:
	var header_end := _find(buffer, "\r\n\r\n".to_utf8_buffer())
	if header_end < 0:
		return {}
	var header_text := buffer.slice(0, header_end).get_string_from_utf8()
	var lines := header_text.split("\r\n")
	if lines.size() < 1:
		return {}
	var request_line := lines[0].split(" ")
	if request_line.size() < 2:
		return {}
	var headers := {}
	for line_index in range(1, lines.size()):
		var line := lines[line_index]
		var separator := line.find(":")
		if separator > 0:
			headers[line.substr(0, separator).strip_edges().to_lower()] = line.substr(separator + 1).strip_edges()
	var content_length := int(headers.get("content-length", "0"))
	var body_start := header_end + 4
	if buffer.size() < body_start + content_length:
		return {}
	return {
		"method": request_line[0].to_upper(),
		"target": request_line[1],
		"path": request_line[1].split("?")[0],
		"query": request_line[1].split("?")[1] if request_line[1].contains("?") else "",
		"headers": headers,
		"body": buffer.slice(body_start, body_start + content_length),
	}

func _respond(peer: StreamPeerTCP, request: Dictionary) -> bool:
	var record := {
		"method": request["method"],
		"path": request["path"],
		"query": request["query"],
		"api_key": str(Dictionary(request["headers"]).get("x-api-key", "")),
		"content_type": str(Dictionary(request["headers"]).get("content-type", "")),
		"body_size": PackedByteArray(request["body"]).size(),
	}
	requests.append(record)
	var status := 200
	var payload: Dictionary = {}
	if record["api_key"] == "bad-key":
		status = 401
		payload = {"success": false, "error": {"code": "unauthorized", "message": "invalid api key"}}
	else:
		var handled := _route(request, record)
		if handled.has("stream"):
			# SSE：先写响应头，正文按片段分多次写，模拟真实网络的分片。
			var pieces: Array = handled["stream"]
			var head := "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream; charset=utf-8\r\nCache-Control: no-cache\r\nConnection: close\r\nX-Accel-Buffering: no\r\n\r\n"
			var first := head.to_utf8_buffer()
			first.append_array(PackedByteArray(pieces[0]))
			peer.put_data(first)
			record["stream_index"] = 1
			record["stream_pieces"] = pieces
			streaming_connections.append({"peer": peer, "record": record})
			return true
		status = int(handled.get("status", 200))
		payload = handled.get("payload", {})
	_send(peer, status, payload)
	return false

# SSE 正文分片。注意第 2 片故意把一个中文字符切成两半：
# 客户端如果按"每次读到字节就解码成字符串"，这个字就会变成替换字符——
# 这条测试专门守那个缺陷。
func _chat_stream_frames() -> Array:
	var references := '{"id":"3475c004","response_type":"references","content":"","done":false,"knowledge_references":[{"id":"c-1","content":"彗尾由尘埃与离子组成。","knowledge_id":"k-1","chunk_index":0,"knowledge_title":"彗星.txt","score":4.04,"match_type":3,"chunk_type":"text","knowledge_filename":"彗星.txt"}]}'
	var whole := (
		# 首帧是 agent_query 且带 done=true——**这是真服务的行为**（真机抓包确认）：
		# 它只表示"这一条事件完整"，不代表整条流结束。照文档写假服务就测不出这个坑，
		# 而"照文档写的客户端"会在第一帧就退出，答案永远是空的。
		"event:message\ndata: %s\n\n" % '{"id":"3475c004","response_type":"agent_query","content":"","done":true,"session_id":"session-1"}'
		+ "event: message\ndata: %s\n\n" % references
		+ "event: message\ndata: %s\n\n" % '{"id":"3475c004","response_type":"answer","content":"彗尾的形状主要分两种：","done":false}'
		+ "event: message\ndata: %s\n\n" % '{"id":"3475c004","response_type":"answer","content":"尘埃尾和离子尾。","done":false}'
		+ "event: message\ndata: %s\n\n" % '{"id":"3475c004","response_type":"answer","content":"","done":true}'
	)
	var bytes := whole.to_utf8_buffer()
	# 在第二个事件中间切一刀（中文"尘埃"的位置），再在结尾切一刀。
	var cut_a := WeKnoraClientScript.bytes_index_of(bytes, "尘埃尾".to_utf8_buffer())
	if cut_a < 0:
		cut_a = int(bytes.size() / 2)
	else:
		cut_a += 1  # 落在"尘"字的三个字节中间
	var cut_b := int(bytes.size()) - 12
	if cut_b <= cut_a:
		cut_b = cut_a + 1
	return [bytes.slice(0, cut_a), bytes.slice(cut_a, cut_b), bytes.slice(cut_b)]

# 把剩下的 SSE 片段按帧写出去（每帧写一片，模拟流式到达）。
func _pump_streams() -> void:
	for index in range(streaming_connections.size() - 1, -1, -1):
		var entry: Dictionary = streaming_connections[index]
		var peer: StreamPeerTCP = entry["peer"]
		var record: Dictionary = entry["record"]
		peer.poll()
		if peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
			streaming_connections.remove_at(index)
			continue
		var pieces: Array = record["stream_pieces"]
		var cursor := int(record["stream_index"])
		if cursor >= pieces.size():
			peer.disconnect_from_host()
			streaming_connections.remove_at(index)
			continue
		peer.put_data(PackedByteArray(pieces[cursor]))
		record["stream_index"] = cursor + 1

func _route(request: Dictionary, record: Dictionary) -> Dictionary:
	var method := str(request["method"])
	var path := str(request["path"])
	var body := PackedByteArray(request["body"])
	if path == "/api/v1/knowledge-bases" and method == "GET":
		return {"payload": {"success": true, "data": [
			# kb-1 用新字段名、kb-2 用旧字段名打开图谱：两种拼法都要能认出来。
			{"id": "kb-1", "name": "技术文档", "type": "document", "knowledge_count": 3, "chunk_count": 210, "processing_count": 1, "embedding_model_id": "emb-1",
				"indexing_strategy": {"graph_enabled": true}},
			{"id": "kb-2", "name": "产品手册", "type": "document", "knowledge_count": 0, "chunk_count": 0, "processing_count": 0, "embedding_model_id": "emb-1",
				"extract_config": {"enabled": true}},
		]}}
	if path == "/api/v1/knowledge-bases/kb-1/knowledge" and method == "GET":
		var page := _query_int(str(request["query"]), "page", 1)
		if page <= 1:
			return {"payload": {"success": true, "total": 3, "page": 1, "page_size": 2, "data": [
				_row("k-1", "架构设计.md", "completed"),
				_row("k-2", "接口说明.md", "completed"),
			]}}
		return {"payload": {"success": true, "total": 3, "page": 2, "page_size": 2, "data": [
			_row("k-3", "部署手册.pdf", "failed"),
		]}}
	if path.begins_with("/api/v1/knowledge/") and method == "GET":
		var knowledge_id := path.get_file()
		if not knowledge_id in ["k-1", "k-2", "k-3", "k-new"]:
			# 真服务对不存在的 ID 就是 404，这里必须一样，否则"查不到"这条路径永远测不到。
			return {"status": 404, "payload": {"success": false, "error": {"code": "not_found", "message": "knowledge not found"}}}
		parse_poll_count += 1
		var status := "completed" if parse_poll_count > parse_polls_before_done else "processing"
		var row := _row(knowledge_id, "部署手册.pdf", status)
		row["description"] = "这份资料讲了怎么把服务部署起来。"
		return {"payload": {"success": true, "data": row}}
	if path.begins_with("/api/v1/chunks/") and method == "GET":
		return {"payload": {"success": true, "total": 2, "data": [
			{"id": "c-1", "knowledge_id": "k-1", "chunk_index": 0, "content": "第一段：整体架构。", "chunk_type": "text", "is_enabled": true},
			{"id": "c-2", "knowledge_id": "k-1", "chunk_index": 1, "content": "第二段：模块划分。", "chunk_type": "text", "is_enabled": true},
		]}}
	if path == "/api/v1/knowledge-bases/kb-1/knowledge/file" and method == "POST":
		var parsed := _parse_multipart(body, str(record["content_type"]))
		if parsed.is_empty():
			return {"status": 400, "payload": {"success": false, "error": {"message": "multipart 解析失败"}}}
		var file_name := str(parsed["file_name"])
		uploaded_files[file_name] = parsed["file_bytes"]
		if int(parsed["duplicate_of"]) > 0:
			return {"status": 409, "payload": {"success": false, "error": {"code": "duplicate", "message": "文件已存在"}}}
		return {"status": 201, "payload": {"success": true, "data": _row("k-new", file_name, "pending")}}
	if path.ends_with("/hybrid-search") and method == "POST":
		return {"payload": {"success": true, "data": [
			{"id": "c-9", "content": "混合检索命中的一段正文。", "knowledge_id": "k-1", "chunk_index": 4,
				"knowledge_title": "架构设计.md", "knowledge_filename": "架构设计.md", "score": 0.87,
				"chunk_type": "text", "knowledge_source": "file"},
		]}}
	if path == "/api/v1/knowledge-search" and method == "POST":
		return {"payload": {"success": true, "data": [
			{"id": "c-10", "content": "跨库检索命中的一段正文。", "knowledge_id": "k-2", "chunk_index": 1,
				"knowledge_title": "接口说明.md", "knowledge_filename": "接口说明.md", "score": 0.73,
				"chunk_type": "text", "knowledge_source": "file"},
		]}}
	if path == "/api/v1/sessions" and method == "POST":
		return {"status": 201, "payload": {"success": true, "data": {"id": "session-1", "title": "梁鲸知识库问答"}}}
	if path.begins_with("/api/v1/knowledge-chat/") and method == "POST":
		return {"stream": _chat_stream_frames()}
	if path == "/api/v1/system" and method == "GET":
		return {"payload": {"success": true, "data": {"graph_database_engine": "Neo4j", "retriever_engine": "postgres"}}}
	if path.begins_with("/api/v1/knowledge/") and method == "DELETE":
		return {"payload": {"success": true, "message": "Deleted successfully"}}
	if path.ends_with("/reparse") and method == "POST":
		return {"payload": {"success": true, "data": _row("k-3", "部署手册.pdf", "pending")}}
	return {"status": 404, "payload": {"success": false, "error": {"message": "not found"}}}

func _row(id: String, title: String, parse_status: String) -> Dictionary:
	return {
		"id": id, "title": title, "file_name": title, "file_type": title.get_extension(),
		"file_size": 1234, "file_hash": "hash-%s" % id, "type": "file", "source": "",
		"parse_status": parse_status, "enable_status": "enabled", "description": "",
		"updated_at": "2026-09-14T10:00:00+08:00", "folder_path": "", "error_message": "",
	}

# 真的按 multipart 规则把文件切出来：这是对客户端组包的端到端校验。
func _parse_multipart(body: PackedByteArray, content_type: String) -> Dictionary:
	var marker := "boundary="
	var boundary_index := content_type.find(marker)
	if boundary_index < 0:
		return {}
	var boundary := content_type.substr(boundary_index + marker.length()).strip_edges().trim_prefix('"').trim_suffix('"')
	if boundary.is_empty():
		return {}
	var result := {"file_name": "", "file_bytes": PackedByteArray(), "duplicate_of": 0}
	var cursor := 0
	while true:
		var part := _slice_part(body, cursor, boundary)
		if part.is_empty():
			break
		cursor = int(part["next"])
		var header_end := _find(part["data"], "\r\n\r\n".to_utf8_buffer())
		if header_end < 0:
			continue
		var header_text := PackedByteArray(part["data"]).slice(0, header_end).get_string_from_utf8()
		var content := PackedByteArray(part["data"]).slice(header_end + 4)
		if header_text.contains("filename="):
			var name_start := header_text.find("filename=\"") + "filename=\"".length()
			var name_end := header_text.find("\"", name_start)
			result["file_name"] = header_text.substr(name_start, name_end - name_start)
			result["file_bytes"] = content
		elif header_text.contains("name=\"file\""):
			result["file_bytes"] = content
		elif header_text.contains("name=\"duplicate_of\""):
			result["duplicate_of"] = int(content.get_string_from_utf8().strip_edges())
	if str(result["file_name"]).is_empty():
		return {}
	return result

# 取一个 --boundary ... 之间的片段，返回 {data, next}。
func _slice_part(body: PackedByteArray, cursor: int, boundary: String) -> Dictionary:
	var opening := ("--%s\r\n" % boundary).to_utf8_buffer()
	var start := WeKnoraClientScript.bytes_index_of(body, opening, cursor)
	if start < 0:
		return {}
	start += opening.size()
	var closing := ("\r\n--%s" % boundary).to_utf8_buffer()
	var end := WeKnoraClientScript.bytes_index_of(body, closing, start)
	if end < 0:
		return {}
	return {"data": body.slice(start, end), "next": end + 2}

func _find(haystack: PackedByteArray, needle: PackedByteArray) -> int:
	return WeKnoraClientScript.bytes_index_of(haystack, needle)

func _query_int(query: String, key: String, fallback: int) -> int:
	for pair in query.split("&"):
		var parts := pair.split("=")
		if parts.size() == 2 and parts[0] == key:
			return int(parts[1])
	return fallback

func _send(peer: StreamPeerTCP, status: int, payload: Dictionary) -> void:
	var body := JSON.stringify(payload).to_utf8_buffer()
	var reason := "OK" if status < 300 else ("Conflict" if status == 409 else "Error")
	var head := "HTTP/1.1 %d %s\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % [status, reason, body.size()]
	var out := head.to_utf8_buffer()
	out.append_array(body)
	peer.put_data(out)
