# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 改动：智能路由接通；布局与命中区修正；自检扩展；截图/归档/彻底删除接入；自检不启动 Harness 且自行退出。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 梁鲸桌宠主控制器
#
# 职责：组装人物、家具、聊天工作区与解析面板，处理透明窗口命中、拖动、
# 侧边停靠、响应式布局和智能体消息路由。用户数据由 soul_store.gd 管理，
# Harness 进程通信由 agent_bridge.gd 管理，本文件不直接保存 API Key。
extends Node2D

const NativeWindows = preload("res://native_windows.gd")
const NativeFilePicker = preload("res://native_file_picker.gd")

signal agent_event(payload: Dictionary)

const SoulStore = preload("res://soul_store.gd")
const SoulAgentScene = preload("res://soul_agent_scene.gd")
# [DSH] 知识库中台：WeKnora 连接配置与客户端（自检用假服务只在 --selftest 时实例化）。
const WeKnoraConfigStore = preload("res://weknora_config.gd")
const WeKnoraClientScript = preload("res://weknora_client.gd")
const WeKnoraMockServer = preload("res://weknora_mock_server.gd")
const DeepSeekConfigStore = preload("res://deepseek_config.gd")
const ExecutionFrameworkConfig = preload("res://execution_framework_config.gd")
const NetworkConfigStore = preload("res://network_config.gd")
const SkillRegistry = preload("res://skill_registry.gd")
const TaskRouter = preload("res://task_router.gd")
const RuleCenter = preload("res://rule_center.gd")
const WorkflowCenter = preload("res://workflow_center.gd")
const WorkflowPackage = preload("res://workflow_package.gd")
const WorkflowRunner = preload("res://workflow_runner.gd")
# [DSH] 工作流「对话自动匹配」的决策层（纯函数，单独自检）。
const WorkflowAutoMatch = preload("res://workflow_auto_match.gd")
# [DSH] 工作流「定时」触发的决策层（纯函数，单独自检）。
const WorkflowSchedule = preload("res://workflow_schedule.gd")
const WorkflowHarness = preload("res://workflow_harness.gd")
const OutfitCenter = preload("res://outfit_center.gd")
const LayeredCharacter = preload("res://layered_character.gd")
const MotionProfile = preload("res://motion_profile.gd")
var layered_character: Node2D
var layer_trial_enabled := true
const MarkdownFormatter = preload("res://markdown_to_bbcode.gd")
const ChatResponse = preload("res://chat_response.gd")
var analysis_reasoning: RichTextLabel
var analysis_steps_button: Button
var analysis_reasoning_button: Button
var model_reasoning_text := ""
var analysis_page_chosen := false
var history_undo_row: HBoxContainer
var history_undo_label: Label
var history_undo_button: Button
var last_deleted_conversation_id := ""
var history_delete_buttons: Array[Button] = []
var erase_confirm_dialog: ConfirmationDialog
var pending_erase_conversation_id := ""
# [DSH] 回收站清理入口的控件。
var history_recycle_label: Label
var history_recycle_button: Button
const AtomicFile = preload("res://atomic_file.gd")
const ScreenshotCenterCore = preload("res://screenshot_center.gd")
# [DSH] 工作区响应式布局的纯几何计算（从本文件抽出，可单独断言）。
const WorkspaceLayout = preload("res://workspace_layout.gd")
const OpenAIStreamClient = preload("res://openai_stream_client.gd")
var outfit_center: Node
var model_center_tabs: TabContainer
var image_model_settings_box: VBoxContainer
var screenshot_center: Node
var custom_outfit_active := false
const AgentBridgeCore = preload("res://agent_bridge.gd")
const AnalysisOrb = preload("res://analysis_orb.gd")
const DebugWindowGrid = preload("res://debug_window_grid.gd")
const MODEL_TEXTURE := "res://assets/blue_whale_girl_master_v1.png"
const BLINK_TEXTURE := "res://assets/blue_whale_girl_blink_closed_v1.png"
const DESK_MODEL_TEXTURE := "res://assets/scene_model_study_desk_v1.png"
const CABINET_MODEL_TEXTURE := "res://assets/scene_model_memory_cabinet_v1.png"
const CHARACTER_SHADER := "res://character_mesh.gdshader"
const BLINK_SHADER := "res://blink_overlay.gdshader"
const MODEL_SCALE := 0.445
const PEEK_MODEL_SCALE := 0.46
const DOCK_ACTION := "peek_side"
const DRAG_THRESHOLD := 9.0
const DEFAULT_ACTION_FRAME_RATE := 60.0
# [DSH] 编号帧扫描的上限（仅在动作清单缺失时的回退路径上使用）。
const MAX_ACTION_FRAMES := 200
# 三种宿主窗口各自独立：待机只包住人物，家具场景横向紧凑，正式工作区留足双栏空间。
const WORKSPACE_WINDOW_SIZE := Vector2i(1300, 929)
const FURNITURE_WINDOW_SIZE := Vector2i(978, 514)
const IDLE_WINDOW_SIZE := Vector2i(271, 522)
# 工具面板不再借用家具窗口；每类工具使用与自身内容匹配的独立宿主尺寸。
const MODEL_SETTINGS_WINDOW_SIZE := Vector2i(560, 760)
const EXECUTION_SETTINGS_WINDOW_SIZE := Vector2i(620, 790)
const NETWORK_SETTINGS_WINDOW_SIZE := Vector2i(570, 650)
const KNOWLEDGE_IMPORT_WINDOW_SIZE := Vector2i(360, 360)
const KNOWLEDGE_SETTINGS_WINDOW_SIZE := Vector2i(470, 500)
# [DSH] 知识库连接（WeKnora 地址 / Key / 选库）。比其它工具窗宽一些：要放知识库列表。
const KNOWLEDGE_CONNECTION_WINDOW_SIZE := Vector2i(640, 740)
const SKILL_LIBRARY_WINDOW_SIZE := Vector2i(860, 760)
const PROJECT_PICKER_WINDOW_SIZE := Vector2i(760, 610)
const LOCAL_FILE_BROWSER_WINDOW_SIZE := Vector2i(920, 680)
const WINDOW_MIN_WIDTH := 271
const WINDOW_MIN_HEIGHT := 522
const WORKSPACE_MIN_WIDTH := WORKSPACE_WINDOW_SIZE.x
const WORKSPACE_MIN_HEIGHT := WORKSPACE_WINDOW_SIZE.y
const DOCK_VISIBLE_WIDTH := 170
const DOCK_HOVER_ZONE := 184
const NORMAL_CHARACTER_POSITION := Vector2(500, 472)
const IDLE_CHARACTER_POSITION := Vector2(135.5, 262.0)
const PEEK_COMPACT_POSITION_Y := 286.0
const PEEK_HOLD_FRAME := 8
# [DSH] 停靠保持时的呼吸幅度与周期。幅度取 2 像素：她只露出 170 像素宽，
# 再大就会看出"整块贴图在上下移动"，那就不是呼吸而是漂浮了。
const PEEK_HOLD_BREATHE_PIXELS := 2.0
const PEEK_HOLD_BREATHE_SECONDS := 3.4
# [DSH] 探头动作去重后应有的不同图片数。当前美术实际只有两张（睁眼、闭眼各一张），
# 却存成了 60 个文件；这条断言把"别再把重复帧当动画带回来"钉住。
# 以后真要增加真实帧，改这个数字是一次有意识的决定，而不是被悄悄带上来。
const PEEK_UNIQUE_IMAGE_BUDGET := 2
const PEEK_REACH_PIXELS := 8.0
const PEEK_LIFT_PIXELS := 2.0
const BLINK_DURATION := 0.19
# [DSH] 表情层：与 layered_character.gd 的 EMOTION_* 取值一一对应。
# 沮丧（失败）是瞬时事件，保持一段时间后自动回到平静；否则一次失败会让她一直难过。
const EXPRESSION_CALM := 0
const EXPRESSION_FOCUS := 1
const EXPRESSION_DOWN := 2
const EXPRESSION_DOWN_HOLD := 3.6
const FACE_SCREEN_OFFSET := Vector2(-19, -160)
# 家具场景按 978×514 重新落位，三件主体的脚部都贴近窗口底边。
const FURNITURE_CHARACTER_POSITION := Vector2(500, 262)
const AGENT_SCENE_POSITION := Vector2(500, 472)
const AGENT_SCENE_SCALE := 0.34
const IDLE_CHARACTER_SCALE := 0.333
const DESK_MODEL_POSITION := Vector2(190, 332)
const CABINET_MODEL_POSITION := Vector2(845, 278)
const DESK_MODEL_SCALE := 0.325
const CABINET_MODEL_SCALE := 0.30
const CABINET_OUTFIT_HOTSPOT := Rect2(749, 350, 229, 148)
# 书桌交互按贴图物件分区，所有矩形互不重叠；后续更换贴图时只需调整这里。
const DESK_NETWORK_HOTSPOT := Rect2(110, 160, 55, 56)
const DESK_RULE_CENTER_HOTSPOT := Rect2(228, 164, 72, 51)
const DESK_EXECUTION_HOTSPOT := Rect2(112, 218, 184, 73)
const DESK_LAMP_HOTSPOT := Rect2(304, 201, 103, 135)
const DESK_KNOWLEDGE_HOTSPOT := Rect2(55, 248, 55, 101)
const DESK_WORKFLOW_HOTSPOT := Rect2(120, 294, 156, 55)
const DESK_INBOX_HOTSPOT := Rect2(-20, 352, 130, 117)
const DESK_SOUL_ROOT_HOTSPOT := Rect2(281, 352, 131, 117)
# 只让双栏面板及其边缘接收鼠标，其余透明区域由 Windows 直接穿透。
const WORKSPACE_INPUT_MARGIN := 6.0
const CHAT_PANEL_MIN_SIZE := Vector2(720, 440)
const ANALYSIS_PANEL_MIN_SIZE := Vector2(340, 330)
# [DSH] 解析窗默认尺寸（独立窗口，可自由缩放）。取原先"和对话窗并排"时的合理宽度，
# 高度贴近对话窗高度，视觉上仍然像并排的两栏。
const DEFAULT_ANALYSIS_WINDOW_SIZE := Vector2i(436, 850)
# [DSH] 2026-09-20 全局界面缩放（用户要求：1080p 机器上界面不要那么大）。
#
# 做法是"两层缩放"，布局常量一律保持**逻辑像素**不动：
#   物理窗口尺寸 = 逻辑尺寸 × ui_scale
#   画布用 CANVAS_ITEMS + content_scale_factor = ui_scale 反向放大逻辑画布
# 两者相抵后，每个窗口内部的逻辑画布仍等于布局常量，所以绝对定位、最小尺寸、
# 字体全部不用改，只是整体按 0.8 画出来、窗口也小一圈。
# 基准取 2560×1600（开发机实测分辨率）：比它小的屏幕按较小的一边等比缩小，
# 下限 0.8，避免小屏上字小到看不清。
const UI_SCALE_BASELINE := Vector2(2560.0, 1600.0)
const UI_SCALE_MIN := 0.8
# 启动时由 compute_ui_scale() 写入；测试里可以手工覆盖来验证缩放分支。
var ui_scale := 1.0
# [DSH] 合并同窗后对话栏的默认宽度（分栏分隔条的初始位置）。
# 取原解析窗宽度 436 的余量：窗口 1180 时对话栏约 620，解析栏约 560。
const WORKSPACE_CHAT_PANE_WIDTH := 620.0
# [DSH] 响应式布局的上限常量已随几何计算移入 workspace_layout.gd。
const SINGLE_INSTANCE_PORT := 43817
const UI_TEXT_SCALE := 1.12
const CONTEXT_MENU_FURNITURE := 1
const CONTEXT_MENU_WINDOW_GRID := 2
const CONTEXT_MENU_OUTFIT := 3
const CONTEXT_MENU_SCREENSHOT := 4
const CONTEXT_MENU_LAYERED := 5
# [DSH] 空闲时主动开口的开关（路线 B）。
const CONTEXT_MENU_PROACTIVE := 6
# [DSH] 知识库连接的直入口。原来只能从家具场景的"竖排资料书"热点进去，
# 用户找不到（实测问过"哪个面板"），所以要有一个一眼可见的入口。
const CONTEXT_MENU_KNOWLEDGE := 7
# [DSH] 窗口置顶开关。用户反馈"一直置顶体验很差"，所以默认关闭；
# 但他随时可以在右键菜单里打开，不必再回来找我改代码。
const CONTEXT_MENU_TOPMOST := 8
# 全局热键：截图提问与唤起桌宠。可在“外观/窗口网格”之外独立触发，
# 不必先去点人物，这也是这类桌宠最常用的入口。
const HOTKEY_SCREENSHOT := KEY_S
const HOTKEY_SUMMON := KEY_L
const HOTKEY_MODIFIERS := KEY_CTRL | KEY_ALT

var character: Node2D
var character_sprite: Sprite2D
var character_material: ShaderMaterial
var blink_sprite: Sprite2D
var blink_material: ShaderMaterial
var neutral_texture: Texture2D
var action_library := {}
# [DSH] 动作库加载耗时（毫秒）。去重前后用同一段代码打印，作为"省了多少启动时间"的证据。
var action_library_load_ms := 0.0
var action_assets := [DOCK_ACTION]
var current_frames: Array[Texture2D] = []
var current_action := ""
var action_playing := false
var frame_index := 0
var frame_clock := 0.0
var current_frame_interval := 1.0 / DEFAULT_ACTION_FRAME_RATE

var bubble: PanelContainer
var bubble_text: Label
var agent_panel: Control
var agent_input: TextEdit
var agent_status: Label
var agent_hint: Label
var agent_scene_background: Node2D
var desk_model: Sprite2D
var cabinet_model: Sprite2D
var scene_input_dock: PanelContainer
var chat_transcript: RichTextLabel
var chat_history_panel: PanelContainer
var chat_history_list: VBoxContainer
var chat_history_search: LineEdit
var chat_history_empty: Label
var chat_attachment_label: Label
var chat_archive_button: Button
var chat_remove_attachment_button: Button
var chat_maximize_button: Button
var chat_resize_grip: Button
var analysis_resize_grip: Button
var chat_attachment_dialog: FileDialog
var agent_project_dialog: FileDialog
var project_picker_window: Window
var project_picker_panel: PanelContainer
var project_picker_path_input: LineEdit
var project_picker_folder_list: ItemList
var project_picker_new_folder_input: LineEdit
var project_picker_status: Label
var project_picker_current_path := ""
var api_key_import_dialog: FileDialog
var chat_attachment_path := ""
var chat_attachment_info: Dictionary = {}
var chat_attachment_preview: TextureRect
var chat_image_bytes := PackedByteArray()
var chat_image_media_type := ""
var chat_image_name := ""
var chat_project_button: Button
var chat_model_select: OptionButton
var chat_reasoning_select: OptionButton
var chat_external_vision_check: CheckButton
var chat_skill_menu: MenuButton
var chat_permission_select: OptionButton
var chat_plugin_button: Button
var chat_skill_mode := "auto"
var chat_manual_skill_id := ""
var chat_execution_status: Label
var chat_busy := false
# 对话工作区使用独立的原生 Windows 窗口，不再借用桌宠透明主画布。
# 桌宠窗口只负责人物/家具；聊天、解析、授权和追问都绘制在这里。
var chat_workspace_window: Window
# [DSH] 解析窗现在是**独立原生窗口**，不再是对话窗里的子控件。
# 起因：两个面板挤在一个画布里，必须同时满足各自的最小尺寸，
# 于是"对话面板最小 911 + 间隙 32 + 解析面板最小 340 + 边距 57 > 窗口 1300"
# 时必然重叠——实测解析窗压住对话窗、盖住发送按钮。
# 拆成两个真窗口后，两者各自拥有自己的最小尺寸，这类冲突从根上不存在。
var analysis_window: Window
# [DSH] 窗口是否置顶（主窗口 + 对话工作区窗）。默认 **false**：用户反馈一直置顶体验很差。
# 右键菜单「窗口置顶」可随时切换，选择会记在本机界面配置里。
var window_topmost := false
var chat_workspace_root: Control
var approval_panel: PanelContainer
var approval_tool_label: Label
var approval_reason_label: Label
var approval_allow_button: Button
var approval_reject_button: Button
var approval_queue: Array[Dictionary] = []
var current_approval: Dictionary = {}
var question_panel: PanelContainer
var question_header_label: Label
var question_progress_label: Label
var question_text_label: Label
var question_detail_label: Label
var question_options_box: VBoxContainer
var question_custom_input: TextEdit
var question_error_label: Label
var question_back_button: Button
var question_submit_button: Button
var question_cancel_button: Button
var question_queue: Array[Dictionary] = []
var current_question_request: Dictionary = {}
var current_question_index := 0
var current_question_drafts: Array[Dictionary] = []
var question_option_buttons: Array[Button] = []
var analysis_panel: PanelContainer
var analysis_orb = null
var analysis_status: Label
# [DSH] 主动开口（路线 B）：空闲且有事可报告时，让她自己说一句。
# 决策逻辑在 proactive_companion.gd（纯函数，单独自检），这里只负责提供事实与显示。
var proactive_spoken_count := 0
var proactive_last_spoken_at := -1.0
var proactive_idle_clock := 0.0
var proactive_check_clock := 0.0
# [DSH] 定时工作流的检查节拍（每 5 秒一次，见 update_workflow_schedules）。
var schedule_check_clock := 0.0
# 用户可在右键菜单里关掉，避免"陪伴"变成"骚扰"。
var proactive_enabled := false
const ProactiveCompanion = preload("res://proactive_companion.gd")

var analysis_trace: RichTextLabel
var analysis_metrics: Label
# [DSH] 停止当前轮次（配合"不设等待上限"）。任务运行时显示。
var chat_stop_button: Button
# [DSH] 待发送队列。
#
# 为什么需要：取消等待上限后，一轮任务可以跑十几分钟；而原来 `submit_agent()` 开头是
# `if chat_busy: return`——执行期间用户的输入被**直接丢掉**，只能干等。
# 现在执行期间输入会入队，当前轮结束后自动发出。
# 队列项形如 {"text": String, "attachment_path": String, "image_bytes": PackedByteArray, "image_name": String, "side_note": String}
var chat_pending_queue: Array[Dictionary] = []
# [DSH] 队列状态条与"撤销排队"按钮（执行中才出现）。
var pending_queue_bar: HBoxContainer
var pending_queue_label: Label
var pending_queue_undo_button: Button
# [DSH] 本轮开始时刻，用于在状态栏显示"已等待 X 分 Y 秒"，避免长任务看起来像卡死。
var agent_turn_started_at := 0
var agent_turn_tick_clock := 0.0
# [DSH] 面板自由拖动/缩放的旧状态已随拆窗删除（原来这里有 panel_layout_mode 等 5 个变量）。
# 保留一行说明以免后来者以为漏了：现在由原生窗口负责这两件事。
var chat_windowed_position := Vector2i.ZERO
var chat_windowed_size := WORKSPACE_WINDOW_SIZE
var chat_window_custom_maximized := false
var chat_window_transitioning := false
var chat_window_transition_revision := 0
var chat_last_observed_position := Vector2i.ZERO
var chat_last_observed_size := WORKSPACE_WINDOW_SIZE
var chat_window_constraint_deferred := false
var chat_workspace_reveal_revision := 0
var pet_window_position := Vector2i.ZERO
var pet_window_size := IDLE_WINDOW_SIZE
var pet_window_geometry_valid := false
var api_settings_window: Window
var execution_settings_window: Window
var network_settings_window: Window
var knowledge_import_window: Window
var knowledge_settings_window: Window
var skill_library_window: Window
var local_file_browser_window: Window
var local_file_browser_panel: PanelContainer
var local_file_browser_title: Label
var local_file_browser_path_input: LineEdit
var local_file_browser_list: ItemList
var local_file_browser_status: Label
var local_file_browser_open_button: Button
var local_file_browser_current_path := ""
var local_file_browser_history: Array[String] = []
var local_file_browser_history_index := -1
var local_file_browser_mode := "browse"
var local_file_browser_extensions: Array[String] = []
var local_file_browser_select_callback: Callable
var restoring_pet_window_geometry := false
var constraining_window_geometry := false
var window_constraint_deferred := false
var last_observed_window_position := Vector2i.ZERO
var last_observed_window_size := Vector2i.ZERO
var window_geometry_dirty := false
var window_geometry_quiet_clock := 0.0
var window_pointer_held := false
var mouse_passthrough_active := false
var active_window_input_shape := PackedVector2Array()
var host_window_mode := "scene"
var dynamic_host_ready := false
var scene_interactive_controls: Array[Control] = []
var furniture_controls: Array[Control] = []
var interaction_hint: PanelContainer
var interaction_hint_label: Label
var scene_furniture_visible := false
var debug_window_grid: Control
var scene_context_menu: PopupMenu
var window_grid_visible := false
var scene_transition_tween: Tween
var knowledge_import_panel: PanelContainer
var knowledge_settings_panel: PanelContainer
var knowledge_file_dialog: FileDialog
var knowledge_folder_dialog: FileDialog
var knowledge_docx_check: CheckButton
var knowledge_xlsx_check: CheckButton
var knowledge_chunk_size: SpinBox
var knowledge_chunk_overlap: SpinBox
# [DSH] 知识库连接面板（WeKnora）。Key 必须走这个界面写入，配置文件里写不进明文。
var knowledge_connection_window: Window
var knowledge_connection_panel: PanelContainer
var knowledge_source_option: OptionButton
var knowledge_host_edit: LineEdit
var knowledge_key_edit: LineEdit
var knowledge_insecure_check: CheckButton
var knowledge_connection_status: Label
var knowledge_connection_test_button: Button
var knowledge_base_list: VBoxContainer
var soul_store = null
var deepseek_config = null
# [DSH] 知识库后端选择（本机 / WeKnora）与它的 HTTP 客户端。见 weknora_config.gd 顶部说明。
var weknora_config = null
var weknora_client = null
var execution_framework_config = null
var network_config = null
var skill_registry = null
var rule_center = null
var workflow_center = null
var workflow_runner: Node
var workflow_transport: Node
var workflow_owns_chat := false
var chat_profile_syncing := false
var chat_profile_sync_pending := false
var chat_session_changing := false
var agent_bridge = null
var harness_status_state := "offline"
var harness_status_detail := "本地核心尚未启动"
# [DSH] 当前想要的表情，以及"沮丧"剩余保持时间。见 update_harness_emotion()。
var harness_expression := 0
var harness_expression_hold := 0.0
# [DSH] 分层装置上一次是否处于启用态，用来识别"重新启用"并补发表情。
var layered_expression_pushed := false
var api_settings_panel: PanelContainer
var api_role_select: OptionButton
var api_provider_select: OptionButton
var api_collaboration_select: OptionButton
var api_key_input: LineEdit
var api_base_url_input: LineEdit
var api_model_input: LineEdit
var api_model_dropdown: MenuButton
var api_model_ids: Array[String] = []
var api_thinking_check: CheckButton
var api_test_status: Label
var api_test_button: Button
var api_read_models_button: Button
var api_http_request: HTTPRequest
var api_request_mode := ""
var api_request_role := "chat"
var api_request_in_progress := false
var execution_settings_panel: PanelContainer
var network_settings_panel: PanelContainer
var network_mode_select: OptionButton
var network_proxy_scheme_select: OptionButton
var network_proxy_input: LineEdit
var network_proxy_port_input: SpinBox
var network_no_proxy_input: LineEdit
var network_detected_label: Label
var network_status_label: Label
var framework_mode_select: OptionButton
var framework_name_input: LineEdit
var framework_auto_start_check: CheckButton
var framework_core_url_input: LineEdit
var framework_interaction_url_input: LineEdit
var framework_executable_input: LineEdit
var framework_launcher_input: LineEdit
var framework_arguments_input: TextEdit
var framework_status_label: Label
var framework_executable_dialog: FileDialog
var framework_launcher_dialog: FileDialog
var framework_update_button: Button
var framework_update_version_label: Label
var framework_update_process_id := -1
var framework_update_run_id := ""
var framework_update_busy := false
var skill_library_panel: PanelContainer
var skill_search_input: LineEdit
var skill_list_box: VBoxContainer
var skill_detail_title: Label
var skill_detail_meta: Label
var skill_detail_text: RichTextLabel
var skill_enable_check: CheckButton
var skill_auto_check: CheckButton
var skill_model_context_check: CheckButton
var skill_status_label: Label
var skill_import_dialog: FileDialog
var selected_skill_id := ""

var pointer_down := false
var dragging := false
var press_screen := Vector2i.ZERO
var press_window := Vector2i.ZERO

var dock_side := 0:
	set(value):
		dock_side = value
		# [DSH] 进出停靠都要立刻同步置顶状态，见 apply_dock_topmost()。
		apply_dock_topmost()
var dock_screen := -1
var dock_full := Vector2i.ZERO
var dock_hidden := Vector2i.ZERO
var dock_tween: Tween
var dock_tween_target := Vector2i(999999, 999999)
var dock_hover_armed := false
var dock_peek_holding := false
# [DSH] 停靠保持的呼吸计时（秒），进入保持状态时归零，见 update_dock_hold_breathe()。
var dock_hold_clock := 0.0
var dock_restore_chat_open := false
var dock_restore_scene_open := false
var active_screen := -1
var display_refresh_rate := 60.0
var screen_check_clock := 0.0
var idle_gaze := Vector2.ZERO
var blink_clock := 0.0
var blink_wait := 3.8
var blink_elapsed := -1.0
var character_pose_tween: Tween
var single_instance_guard: TCPServer
var native_dialog_restore_topmost := false
var native_dialog_open := false
var native_dialog_topmost_windows: Array[Window] = []
var active_native_dialog: FileDialog

func _ready() -> void:
	if not acquire_single_instance_guard():
		return
	# 免安装测试版复用 Godot 运行引擎，运行引擎可能给标题追加“(DEBUG)”。
	# 产品窗口始终显式使用正式名称，避免测试用户误以为拿到开发窗口。
	get_window().title = "梁鲸"
	call_deferred("apply_product_window_title")
	# 工具页必须成为真正的 Windows 子窗口；关闭内嵌后，Window 节点才不会
	# 被绘制在桌宠主窗口内部，也不会再借用或改变家具场景的宿主尺寸。
	get_viewport().gui_embed_subwindows = false
	get_window().transparent = true
	get_window().borderless = true
	# [DSH] 2026-09-16 用户反馈"一直置顶体验很差"，默认不再置顶。
	# 需要时可以在右键菜单里打开「窗口置顶」；截图框选遮罩不受影响，它必须浮在最上面。
	get_window().always_on_top = window_topmost
	# 使用窗口真实像素作为画布，三种宿主尺寸和自由缩放才能分别自适应，而不是拉伸固定画面。
	get_window().content_scale_size = Vector2i.ZERO
	# [DSH] 全局界面缩放：先定系数，再给主窗口装上"反向放大逻辑画布"。
	# 之后所有窗口尺寸都按逻辑像素书写，物理尺寸由 scaled_size() 换算。
	ui_scale = compute_ui_scale()
	apply_canvas_scale(get_window())
	configure_display_sync(true)
	initialize_soul_store()
	initialize_skill_registry()
	initialize_deepseek_config()
	initialize_weknora()
	initialize_execution_framework_config()
	initialize_network_config()
	initialize_agent_bridge()
	var usable := DisplayServer.screen_get_usable_rect()
	get_window().min_size = Vector2i(mini(WINDOW_MIN_WIDTH, usable.size.x), mini(WINDOW_MIN_HEIGHT, usable.size.y))
	restore_saved_app_window(usable)
	pet_window_position = get_window().position
	pet_window_size = get_window().size
	pet_window_geometry_valid = true
	build_debug_window_grid()
	build_character()
	load_action_library()
	build_bubble()
	build_agent_panel()
	build_scene_context_menu()
	initialize_outfit_center()
	initialize_screenshot_center()
	register_global_hotkeys()
	initialize_local_conversation_history()
	apply_readable_typography(self)
	dynamic_host_ready = true
	enter_compact_idle_window(get_window().size != scaled_size(IDLE_WINDOW_SIZE))
	set_agent_scene_pose(true)
	get_window().size_changed.connect(on_app_window_size_changed)
	# Windows 文件可直接拖入桌宠窗口；当前界面打开时会作为本轮附件处理。
	get_window().files_dropped.connect(on_chat_files_dropped)
	# 恢复窗口尺寸发生在信号连接之前；这里主动同步根画布，避免启动时短暂停留在项目默认尺寸。
	on_app_window_size_changed()
	last_observed_window_position = get_window().position
	last_observed_window_size = get_window().size
	agent_event.emit({"type": "pet.ready", "model": "blue_whale_girl_v1"})
	# [DSH] 真机连接自检：--weknora-probe 只读（不花模型费用）；--weknora-probe=chat 额外跑一次问答。
	if probe_requested():
		call_deferred("run_weknora_probe")
		return
	if "--selftest" in OS.get_cmdline_user_args():
		call_deferred("run_atomic_write_selftest")
		call_deferred("run_screenshot_center_selftest")
		call_deferred("run_outfit_center_selftest")
		call_deferred("run_layered_character_selftest")
		call_deferred("run_harness_emotion_selftest")
		call_deferred("run_workflow_retention_selftest")
		call_deferred("run_workspace_layout_selftest")
		call_deferred("run_openai_stream_selftest")
		call_deferred("run_harness_live_stream_selftest")
		call_deferred("run_chat_maximize_selftest")
		call_deferred("run_task_router_selftest")
		call_deferred("run_markdown_formatter_selftest")
		call_deferred("run_dynamic_window_selftest")
		# 自检必须自己退出，而且要走正常退出路径。
		# 原因：常规做法是在外面超时后强制 kill 进程，而强制 kill 不会执行 _exit_tree()
		# 里的 agent_bridge.shutdown()，于是每次自检都会留下一个孤儿 node 进程占着端口。
		# 实测这些孤儿会累积到十几个，并且占住 stdout 管道，让外层命令看起来像卡死。
		call_deferred("schedule_selftest_exit")
	# 开发期夹具入口：--fixture=<名称> 时在主场景内跑一个夹具，把结果写成文件后退出。
	# 之所以不复用 --script：--script 在有主场景时会被忽略，而且 Godot 在轮转自己日志
	# 失败时会直接段错误崩溃；走主场景 + 自退出这条路已验证可靠。


# 自检结束后主动退出。必须保持为独立函数；若函数声明丢失，下面的 await 会落入
# _ready()，导致正式应用启动后也在 35 秒后退出。
func schedule_selftest_exit() -> void:
	var seconds := 35.0
	for argument in OS.get_cmdline_user_args():
		var text := str(argument)
		if text.begins_with("--selftest-exit="):
			seconds = maxf(10.0, float(text.trim_prefix("--selftest-exit=")))
	await get_tree().create_timer(seconds).timeout
	print("SELFTEST_EXIT seconds=", seconds)
	# 正常退出路径：会触发 _exit_tree，从而按设计关闭子进程。
	get_tree().quit()


# 运行引擎会在主窗口初始化阶段追加调试标记；延迟到下一帧后再覆盖，
# 可确保任务栏和窗口管理器最终只显示产品名“梁鲸”。
func apply_product_window_title() -> void:
	get_window().title = "梁鲸"
	DisplayServer.window_set_title("梁鲸", get_window().get_window_id())

# 数据安全自检：
# 1) 原子写必须能正确覆盖、失败时不破坏原文件、不留 .tmp、加密写可回读且换密钥打不开。
# 2) 会话 jsonl 里的半截坏行（桌面进程被强杀时会产生）不能导致整段历史或整个会话列表消失。
func run_atomic_write_selftest() -> void:
	var failures: Array[String] = []
	if not soul_store or soul_store.root_path.is_empty():
		print("ATOMIC_WRITE_SELFTEST=FAIL 灵魂仓库未就绪")
		return
	var probe_directory: String = soul_store.root_path.path_join("自检临时")
	# 注意：自检数据目录可能落在受沙箱或权限策略限制的位置（旧实现解析到工作区之外，
	# 那里根本不可写）。此时“写入失败”是环境事实而不是代码缺陷，因此先探测可写性，
	# 写不了就明确标记为跳过，绝不把环境限制伪装成通过或失败。
	# 注意 AtomicFile 只负责“原子地覆盖已有目标”，不会创建父目录，所以这里要先建目录。
	DirAccess.make_dir_recursive_absolute(probe_directory)
	var probe_workspace: String = probe_directory.path_join("可写性探测.txt")
	var probe_root_writable: bool = AtomicFile.write_text(probe_workspace, "probe")
	var atomic_result: Dictionary = {"cases": 0, "failures": [], "ok": true}
	if probe_root_writable:
		atomic_result = AtomicFile.selftest(probe_directory)
		for failure in atomic_result.get("failures", []):
			failures.append("原子写：" + str(failure))
	else:
		print("ATOMIC_WRITE_SKIPPED 自检数据目录不可写（", soul_store.root_path, "）：本环境下无法验证原子写，请用可写目录重跑")

	# ── 坏行容忍 ─────────────────────────────────────────────
	var corrupt_case_ok := false
	var probe_file: String = soul_store.conversations_path.path_join("selftest_corrupt_probe.jsonl")
	if FileAccess.file_exists(probe_file):
		DirAccess.remove_absolute(probe_file)
	var good_session := "selftest-good-session"
	var file := FileAccess.open(probe_file, FileAccess.WRITE)
	if file == null:
		if probe_root_writable:
			failures.append("可写环境下却无法创建会话探测文件")
	else:
		corrupt_case_ok = true
		file.store_line(JSON.stringify({"timestamp": "2026-01-01T00:00:00", "session_id": good_session, "role": "user", "content": "第一行是完整的", "metadata": {}}))
		# 模拟被强杀：最后一行是半截 JSON。
		file.store_line("{\"timestamp\": \"2026-01-01T00:00:01\", \"session_id\": \"selftest-good-ses")
		file.close()
		var found := false
		for conversation_value in soul_store.list_conversations(200):
			if conversation_value is Dictionary and str(conversation_value.get("id", "")) == good_session:
				found = true
		if not found:
			failures.append("遇到半截坏行后，完整会话从列表里消失了（应当跳过坏行而不是放弃整个文件）")
		var records: Array = soul_store.load_conversation(good_session, 50)
		if records.size() != 1:
			failures.append("坏行影响了同文件内的正常记录：期望 1 条，实际 %d 条" % records.size())

		# ── 缓存失效 ────────────────────────────────────────
		# 缓存最容易出的问题是“读到旧数据”：追加新消息后必须立刻可见。
		soul_store.session_id = good_session
		var appended: bool = soul_store.append_message("user", "缓存失效验证消息")
		if not appended:
			failures.append("无法向探测会话追加消息")
		else:
			var after_append: Array = soul_store.load_conversation(good_session, 50)
			if after_append.size() != 2:
				failures.append("追加后没有立即读到新消息（缓存未失效）：期望 2 条，实际 %d 条" % after_append.size())
			# 直接绕开 store 追加一行，模拟外部改动；文件长度变化后同样必须可见。
			var raw_file := FileAccess.open(probe_file, FileAccess.READ_WRITE)
			if raw_file:
				raw_file.seek_end()
				raw_file.store_line(JSON.stringify({"timestamp": "2026-01-01T00:00:02", "session_id": good_session, "role": "assistant", "content": "外部追加", "metadata": {}}))
				raw_file.flush()
				raw_file.close()
				var after_external: Array = soul_store.load_conversation(good_session, 50)
				if after_external.size() != 3:
					failures.append("外部追加后没有读到新内容（缓存未按签名失效）：期望 3 条，实际 %d 条" % after_external.size())
				# clear_caches() 是文档承诺的逃生口：外部用同长度改写时靠它强制重读。
				soul_store.clear_caches()
				var after_clear: Array = soul_store.load_conversation(good_session, 50)
				if after_clear.size() != 3:
					failures.append("clear_caches 后仍未读到最新内容：期望 3 条，实际 %d 条" % after_clear.size())
		var stats: Dictionary = soul_store.cache_stats()
		if int(stats.get("conversation_files", 0)) < 1:
			failures.append("会话缓存没有生效：conversation_files=%d" % int(stats.get("conversation_files", 0)))
		DirAccess.remove_absolute(probe_file)

	# 自检不能污染真实数据目录。
	for directory in [probe_directory, soul_store.conversations_path]:
		if FileAccess.file_exists(directory.path_join("atomic_probe.json")):
			failures.append("自检在 %s 留下了探测文件" % directory)
	AtomicFile.sweep_stale_temps(soul_store.conversations_path)
	failures.append_array(run_history_management_checks())
	for failure in failures:
		print("ATOMIC_WRITE_FAILURE ", failure)
	var executed_cases := int(atomic_result.get("cases", 0)) + (7 if corrupt_case_ok else 0) + 6
	print("ATOMIC_WRITE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", executed_cases, " failures=", failures.size(), " writable=", probe_root_writable)

# 归档与彻底删除的行为断言。
# 关键要验证的是"彻底删除真的把记录从磁盘上拿掉了"，而不只是从列表里隐藏——
# 这正是它与原来的软删除（可撤销、原始记录保留）的区别，也是用户点这个按钮时的预期。
func run_history_management_checks() -> Array[String]:
	var failures: Array[String] = []
	var session := "selftest-erase-session"
	var probe_file: String = soul_store.conversations_path.path_join("selftest_erase_probe.jsonl")
	if FileAccess.file_exists(probe_file):
		DirAccess.remove_absolute(probe_file)
	var file := FileAccess.open(probe_file, FileAccess.WRITE)
	if file == null:
		failures.append("历史管理：无法创建探测文件")
		return failures
	file.store_line(JSON.stringify({"timestamp": "2026-01-02T00:00:00", "session_id": session, "role": "user", "content": "待彻底删除的记录", "metadata": {}}))
	file.store_line(JSON.stringify({"timestamp": "2026-01-02T00:00:01", "session_id": "selftest-keep-session", "role": "user", "content": "必须保留的记录", "metadata": {}}))
	file.close()
	soul_store.clear_caches()

	# 归档：可逆，且不影响可读性。
	if not bool(soul_store.archive_conversation(session).get("ok", false)):
		failures.append("历史管理：归档失败")
	if not soul_store.is_conversation_archived(session):
		failures.append("历史管理：归档后未反映为已归档")
	if soul_store.load_conversation(session, 50).size() != 1:
		failures.append("历史管理：归档影响了会话可读性（应当不影响内容）")
	# 列表要带上归档标注，界面才能把它归到“已归档”组。
	var saw_archived_flag := false
	for conversation_value in soul_store.list_conversations(50):
		if conversation_value is Dictionary and str(conversation_value.get("id", "")) == session:
			saw_archived_flag = bool(conversation_value.get("archived", false))
	if not saw_archived_flag:
		failures.append("历史管理：列表没有标注归档状态")
	if not bool(soul_store.unarchive_conversation(session).get("ok", false)):
		failures.append("历史管理：取消归档失败")
	if soul_store.is_conversation_archived(session):
		failures.append("历史管理：取消归档后仍标记为已归档")

	# 彻底删除：记录必须从磁盘消失，且不可撤销。
	var erase_result: Dictionary = soul_store.erase_conversation(session)
	if not bool(erase_result.get("ok", false)):
		failures.append("历史管理：彻底删除失败：%s" % str(erase_result.get("error", "")))
	if soul_store.load_conversation(session, 50).size() != 0:
		failures.append("历史管理：彻底删除后仍能读到该会话记录")
	# 直接读文件确认，避免只信缓存。
	var raw := AtomicFile.read_text(probe_file)
	if raw.contains(session):
		failures.append("历史管理：jsonl 文件里仍然残留已删除会话的文本")
	# 同文件里的其它会话必须完好——这是"按会话删除而不破坏整天文件"的核心要求。
	if soul_store.load_conversation("selftest-keep-session", 50).size() != 1:
		failures.append("历史管理：彻底删除误伤了同一文件里的其它会话")
	# 不可撤销：软删除的撤销入口对已彻底删除的会话必须失败。
	if bool(soul_store.restore_conversation(session).get("ok", false)):
		failures.append("历史管理：已彻底删除的会话竟然可以被撤销恢复")

	if FileAccess.file_exists(probe_file):
		DirAccess.remove_absolute(probe_file)
	DirAccess.remove_absolute(soul_store._conversation_delete_file(session))
	DirAccess.remove_absolute(soul_store._conversation_archive_file(session))
	soul_store.clear_caches()
	return failures

func run_task_router_selftest() -> void:
	var cases := [
		# [查询, 是否带需要处理的附件, 期望路由]
		["什么是向量数据库", false, TaskRouter.ROUTE_DIRECT],
		["解释一下什么是幂等", false, TaskRouter.ROUTE_DIRECT],
		["帮我翻译这段话", false, TaskRouter.ROUTE_DIRECT],
		["你好", false, TaskRouter.ROUTE_DIRECT],
		["谢谢", false, TaskRouter.ROUTE_DIRECT],
		["把桌面上的报告整理成一个文件夹", false, TaskRouter.ROUTE_HARNESS],
		["帮我删掉下载目录里的临时文件", false, TaskRouter.ROUTE_HARNESS],
		["读一下 D:\\项目\\说明.md", false, TaskRouter.ROUTE_HARNESS],
		["运行一下这个脚本看看结果", false, TaskRouter.ROUTE_HARNESS],
		["打开浏览器查一下这个网站", false, TaskRouter.ROUTE_HARNESS],
		["列出当前目录下所有文件", false, TaskRouter.ROUTE_HARNESS],
		["这台电脑的显卡是什么型号", false, TaskRouter.ROUTE_HARNESS],
		["帮我", false, TaskRouter.ROUTE_HARNESS],
		["今天天气怎么样", false, TaskRouter.ROUTE_DIRECT],
		["这份文件讲了什么", true, TaskRouter.ROUTE_HARNESS],
	]
	var failures := 0
	for case_value in cases:
		var case: Array = case_value
		var query := str(case[0])
		var has_attachment := bool(case[1])
		var expected := str(case[2])
		var observed := TaskRouter.decide(query, has_attachment)
		if observed != expected:
			failures += 1
			print("TASK_ROUTER_MISMATCH query=", query, " attachment=", has_attachment, " expected=", expected, " observed=", observed)
	# 附件的动作性判定必须与 soul_store.inspect_attachment 的字段保持一致。
	for attachment_case in [
		[{"requires_vision": true}, true],
		[{"requires_parser": true}, true],
		[{"recognized": true}, true],
		[{"ok": true}, false],
		[{}, false],
	]:
		var sample: Dictionary = attachment_case[0]
		var expected_action := bool(attachment_case[1])
		if TaskRouter.attachment_requires_action(sample) != expected_action:
			failures += 1
			print("TASK_ROUTER_ATTACHMENT_MISMATCH sample=", sample, " expected=", expected_action)
	# 空输入不能被判成需要操作电脑。
	if TaskRouter.decide("") != TaskRouter.ROUTE_DIRECT:
		failures += 1
		print("TASK_ROUTER_EMPTY_MISMATCH")
	print("TASK_ROUTER_SELFTEST=", "PASS" if failures == 0 else "FAIL", " cases=", cases.size() + 6, " failures=", failures)

# Markdown 渲染自检：确认标题、粗体、行内代码、列表、引用、分隔线、代码块、
# 表格与方括号转义都能正确转换，且不会把标记原样漏给用户。
func run_markdown_formatter_selftest() -> void:
	var result: Dictionary = MarkdownFormatter.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("MARKDOWN_FORMATTER_FAILURE ", str(failure))
	print("MARKDOWN_FORMATTER_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())

func run_dynamic_window_selftest() -> void:
	await get_tree().process_frame
	var idle_ok := get_window().size.x <= scaled_size(IDLE_WINDOW_SIZE).x and host_window_mode == "idle"
	set_furniture_visible(true, false)
	await get_tree().process_frame
	var usable_rect: Rect2i = DisplayServer.screen_get_usable_rect()
	var usable_size: Vector2i = usable_rect.size
	# [DSH] 界面缩放后窗口尺寸是物理像素，期望值也要跟着换算。
	var expected_furniture_size := scaled_size(Vector2i(
		mini(FURNITURE_WINDOW_SIZE.x, usable_size.x),
		mini(FURNITURE_WINDOW_SIZE.y, usable_size.y)
	))
	var observed_furniture_size := get_window().size
	var headless_selftest := observed_furniture_size.x < 100 or observed_furniture_size.y < 100
	var furniture_ok := (
		scene_furniture_visible
		and host_window_mode == "scene"
		and (headless_selftest or observed_furniture_size == expected_furniture_size)
	)
	print("FURNITURE_WINDOW_SELFTEST=", "PASS" if furniture_ok else "FAIL", " expected=", expected_furniture_size, " observed=", observed_furniture_size)
	# [DSH] 全局界面缩放断言（实现见 UI_SCALE_BASELINE）：
	#   1) 系数在 [0.8, 1.0]，换算自洽（scaled→logical 能回到原值）；
	#   2) 主窗口真的装上了 CANVAS_ITEMS + content_scale_factor；
	#   3) 有了真实屏幕后，逻辑画布应当回到布局常量（656×522 那套），
	#      也就是"窗口变小 + 画布反向放大"两件事同时成立，而不是只有窗口变小。
	var scale_failures: Array = []
	var scale_cases := 0
	scale_cases += 1
	if ui_scale < UI_SCALE_MIN - 0.0001 or ui_scale > 1.0 + 0.0001:
		scale_failures.append("ui_scale 越界：%s（合法区间 %s ~ 1.0）" % [ui_scale, UI_SCALE_MIN])
	scale_cases += 1
	if logical_size(scaled_size(IDLE_WINDOW_SIZE)) != IDLE_WINDOW_SIZE:
		scale_failures.append("逻辑↔物理换算不自洽：%s" % [logical_size(scaled_size(IDLE_WINDOW_SIZE))])
	scale_cases += 1
	if get_window().content_scale_mode != Window.CONTENT_SCALE_MODE_CANVAS_ITEMS or not is_equal_approx(get_window().content_scale_factor, ui_scale):
		scale_failures.append("主窗口画布没有装上反向缩放：mode=%s factor=%s（期望 CANVAS_ITEMS / %s）" % [get_window().content_scale_mode, get_window().content_scale_factor, ui_scale])
	if not headless_selftest:
		var expected_logical := Vector2i(
			mini(FURNITURE_WINDOW_SIZE.x, usable_size.x),
			mini(FURNITURE_WINDOW_SIZE.y, usable_size.y)
		)
		scale_cases += 1
		if logical_size(get_window().size) != expected_logical:
			scale_failures.append("家具窗的逻辑画布不等于布局常量：%s vs %s" % [logical_size(get_window().size), expected_logical])
		scale_cases += 1
		var visible_rect := get_window().get_viewport().get_visible_rect().size
		if absf(visible_rect.x - float(expected_logical.x)) > 1.5 or absf(visible_rect.y - float(expected_logical.y)) > 1.5:
			scale_failures.append("可见画布与逻辑尺寸不一致：%s vs %s" % [visible_rect, expected_logical])
	print("UI_SCALE_SELFTEST=", "PASS" if scale_failures.is_empty() else "FAIL", " cases=", scale_cases, " ui_scale=", ui_scale, " window=", get_window().size)
	for scale_failure in scale_failures:
		print("UI_SCALE_FAILURE ", scale_failure)
	# 检查书桌所有点击区的几何边界，并通过按钮 pressed 信号验证两个新入口的真实路由。
	var furniture_hotspots_ok := true
	for first_index in range(furniture_controls.size()):
		var first_hotspot := furniture_controls[first_index] as Control
		for second_index in range(first_index + 1, furniture_controls.size()):
			var second_hotspot := furniture_controls[second_index] as Control
			# 相邻区域允许共用一条边界线，但不能有任何实际面积重叠。
			if Rect2(first_hotspot.position, first_hotspot.size).intersects(Rect2(second_hotspot.position, second_hotspot.size), false):
				furniture_hotspots_ok = false
				print("FURNITURE_HOTSPOT_OVERLAP=", first_hotspot.name, " <-> ", second_hotspot.name)
	var rule_hotspot := agent_panel.get_node_or_null("DeskRuleCenterHotspot") as Button
	var workflow_hotspot := agent_panel.get_node_or_null("DeskWorkflowCenterHotspot") as Button
	var hotspot_geometry_ok := bool(
		rule_hotspot
		and workflow_hotspot
		and Rect2(rule_hotspot.position, rule_hotspot.size) == DESK_RULE_CENTER_HOTSPOT
		and Rect2(workflow_hotspot.position, workflow_hotspot.size) == DESK_WORKFLOW_HOTSPOT
	)
	var hotspot_routes_ok := false
	if rule_hotspot and workflow_hotspot:
		rule_hotspot.pressed.emit()
		await get_tree().process_frame
		var rule_route_ok := bool(rule_center and rule_center.get("window") and (rule_center.get("window") as Window).visible)
		if rule_center:
			rule_center.close()
		workflow_hotspot.pressed.emit()
		await get_tree().process_frame
		var workflow_route_ok := bool(workflow_center and workflow_center.get("window") and (workflow_center.get("window") as Window).visible)
		if workflow_center:
			workflow_center.close()
		hotspot_routes_ok = rule_route_ok and workflow_route_ok
	furniture_hotspots_ok = furniture_hotspots_ok and hotspot_geometry_ok and hotspot_routes_ok
	print("FURNITURE_HOTSPOT_SELFTEST=", "PASS" if furniture_hotspots_ok else "FAIL", " geometry=", hotspot_geometry_ok, " routes=", hotspot_routes_ok)
	var utility_ok := true
	var utility_cases := [
		{"name": "MODEL_SETTINGS", "panel": api_settings_panel, "window": MODEL_SETTINGS_WINDOW_SIZE, "panel_size": Vector2(460, 610)},
		{"name": "EXECUTION_SETTINGS", "panel": execution_settings_panel, "window": EXECUTION_SETTINGS_WINDOW_SIZE, "panel_size": Vector2(520, 690)},
		{"name": "NETWORK_SETTINGS", "panel": network_settings_panel, "window": NETWORK_SETTINGS_WINDOW_SIZE, "panel_size": Vector2(490, 560)},
		{"name": "KNOWLEDGE_IMPORT", "panel": knowledge_import_panel, "window": KNOWLEDGE_IMPORT_WINDOW_SIZE, "panel_size": Vector2(286, 235)},
		{"name": "KNOWLEDGE_SETTINGS", "panel": knowledge_settings_panel, "window": KNOWLEDGE_SETTINGS_WINDOW_SIZE, "panel_size": Vector2(390, 420)},
		# [DSH] 新窗口必须登记进这张表，否则"面板被内容顶出窗口"这类缺陷没人守——
		# 连接面板第一版就是这么漏掉的：底部按钮在真机上被切掉了。
		{"name": "KNOWLEDGE_CONNECTION", "panel": knowledge_connection_panel, "window": KNOWLEDGE_CONNECTION_WINDOW_SIZE, "panel_size": Vector2(480, 560)},
		{"name": "SKILL_LIBRARY", "panel": skill_library_panel, "window": SKILL_LIBRARY_WINDOW_SIZE, "panel_size": Vector2(812, 698)}
	]
	for utility_case in utility_cases:
		var utility_panel := utility_case["panel"] as Control
		var requested_utility_size := utility_case["window"] as Vector2i
		open_utility_panel(utility_panel, requested_utility_size, utility_case["panel_size"] as Vector2)
		# 必须等两帧：open_utility_panel 把一次收敛布局排在下一帧（finalize_utility_panel_layout），
		# 只等一帧会读到尚未收敛的最小尺寸，从而漏掉“面板被内容顶出窗口”这类缺陷。
		await get_tree().process_frame
		await get_tree().process_frame
		var utility_window := utility_window_for_panel(utility_panel)
		# [DSH] 期望值也要换算成物理尺寸：窗口尺寸在缩放下是物理像素。
		var expected_utility_size := scaled_size(Vector2i(
			mini(requested_utility_size.x, usable_size.x),
			mini(requested_utility_size.y, usable_size.y)
		))
		var observed_utility_size := utility_window.size if utility_window else Vector2i.ZERO
		var observed_utility_position := utility_window.position if utility_window else Vector2i.ZERO
		var utility_inside_screen: bool = (
			observed_utility_position.x >= usable_rect.position.x
			and observed_utility_position.y >= usable_rect.position.y
			and observed_utility_position.x + observed_utility_size.x <= usable_rect.end.x
			and observed_utility_position.y + observed_utility_size.y <= usable_rect.end.y
		)
		var utility_minimum := utility_panel.get_combined_minimum_size()
		var utility_content_ok := (
			utility_panel.size.x + 0.5 >= utility_minimum.x
			and utility_panel.size.y + 0.5 >= utility_minimum.y
		)
		# 面板绝不能被内容顶到窗口之外：一旦超出，标题栏和工具栏会被挤出屏幕，
		# 用户将无法关闭或操作该工具窗口。技能列表曾经真的把面板顶到 1748px（窗口只有 760px）。
		# 这里直接核对最小尺寸能否装进请求的窗口尺寸：自检环境不提供真实窗口，
		# 若改用实测 size 会在无屏幕时被跳过，从而完全失去这项保护。
		var utility_fits_requested_size: bool = (
			utility_minimum.x <= float(requested_utility_size.x) + 0.5
			and utility_minimum.y <= float(requested_utility_size.y) + 0.5
		)
		var utility_window_size := utility_window.size if utility_window else Vector2i.ZERO
		# [DSH] 面板活在逻辑画布里，窗口尺寸是物理像素；两者比较前必须换算。
		# 物理尺寸取整会让逻辑画布有不到 1px 的误差，所以这里的容差放到 1px。
		var utility_canvas_size := logical_size(utility_window_size)
		var utility_within_window: bool = (
			utility_window_size.x <= 0
			or (
				utility_panel.size.x <= float(utility_canvas_size.x) + 0.5
				and utility_panel.size.y <= float(utility_canvas_size.y) + 0.5
			)
		)
		# 无屏幕自检时原生子窗口尺寸固定为 0；此时只核对内容最小尺寸，
		# 不把系统无法提供的窗口边界当成界面缺陷。
		var utility_panel_inside_window: bool = headless_selftest or (
			utility_panel.position.x >= 0.0
			and utility_panel.position.y >= 0.0
			and utility_panel.position.x + utility_panel.size.x <= float(utility_canvas_size.x) + 1.0
			and utility_panel.position.y + utility_panel.size.y <= float(utility_canvas_size.y) + 1.0
		)
		var utility_case_ok: bool = (
			utility_window != null
			and utility_window.visible
			and utility_content_ok
			and utility_fits_requested_size
			and utility_within_window
			and utility_panel_inside_window
			and (headless_selftest or utility_inside_screen)
			and get_window().size == expected_furniture_size
			and (headless_selftest or observed_utility_size == expected_utility_size)
		)
		utility_ok = utility_ok and utility_case_ok
		print(str(utility_case["name"]), "_WINDOW_SELFTEST=", "PASS" if utility_case_ok else "FAIL", " expected=", expected_utility_size, " observed=", observed_utility_size, " position=", observed_utility_position, " inside_screen=", utility_inside_screen, " panel=", utility_panel.size, " fits_requested=", utility_fits_requested_size, " window=", utility_window_size, " panel_inside_window=", utility_panel_inside_window, " minimum=", utility_minimum)
		close_utility_panel(utility_panel)
		await get_tree().process_frame
	# 规则与工作流不是工作台画布中的遮罩层，而是两个真正独立、非模态窗口。
	# 自检同时覆盖打开和关闭，防止以后再次出现关闭子窗口后主程序失去输入的问题。
	var governance_windows_ok := true
	var governance_cases := [
		{"name": "RULE_CENTER", "center": rule_center, "size": Vector2i(860, 660)},
		{"name": "WORKFLOW_CENTER", "center": workflow_center, "size": Vector2i(1180, 780)}
	]
	for governance_case in governance_cases:
		var center = governance_case["center"]
		var expected_center_size: Vector2i = governance_case["size"]
		center.open()
		await get_tree().process_frame
		var center_window := center.get("window") as Window
		var opened_ok := bool(
			center_window
			and center_window.visible
			and not center_window.transient
			and not center_window.exclusive
			and (headless_selftest or center_window.size == expected_center_size)
			and get_window().size == expected_furniture_size
		)
		center.close()
		await get_tree().process_frame
		var closed_ok := bool(center_window and not center_window.visible and get_window().size == expected_furniture_size)
		var governance_case_ok := opened_ok and closed_ok
		governance_windows_ok = governance_windows_ok and governance_case_ok
		print(str(governance_case["name"]), "_WINDOW_SELFTEST=", "PASS" if governance_case_ok else "FAIL", " opened=", opened_ok, " closed=", closed_ok, " transient=", center_window.transient if center_window else true, " exclusive=", center_window.exclusive if center_window else true)
	set_furniture_visible(false, false)
	await get_tree().process_frame
	set_chat_workspace_visible(true)
	apply_responsive_chat_layout(false)
	await get_tree().process_frame
	var expected_workspace_size := scaled_size(Vector2i(
		mini(WORKSPACE_WINDOW_SIZE.x, usable_size.x),
		mini(WORKSPACE_WINDOW_SIZE.y, usable_size.y)
	))
	var observed_workspace_size := chat_workspace_window.size if chat_workspace_window else Vector2i.ZERO
	var expanded_ok := (
		headless_selftest
		or observed_workspace_size == expected_workspace_size
	)
	var independent_window_ok := headless_selftest or bool(
		chat_workspace_window
		and chat_workspace_window.visible
		and get_window().size != observed_workspace_size
		and get_window().mouse_passthrough
	)
	print("WORKSPACE_WINDOW_SELFTEST=", "PASS" if expanded_ok and independent_window_ok else "FAIL", " expected=", expected_workspace_size, " observed=", observed_workspace_size, " independent=", independent_window_ok)
	var selftest_canvas := layout_canvas_size()
	# OS client area owns the scroll viewport; content can exceed it and remain reachable.
	var chat_rect := Rect2(scene_input_dock.position, scene_input_dock.size)
	var layout_ok := scene_input_dock.get_parent() is ScrollContainer and scene_input_dock.get_window() == chat_workspace_window and scene_input_dock.size_flags_horizontal == Control.SIZE_EXPAND_FILL and scene_input_dock.size_flags_vertical == Control.SIZE_EXPAND_FILL
	print("WORKSPACE_LAYOUT_SELFTEST=", "PASS" if layout_ok else "FAIL", " canvas=", selftest_canvas, " chat=", chat_rect, " analysis_window=", Rect2i(analysis_window.position, analysis_window.size) if analysis_window else Rect2i())
	set_chat_workspace_visible(false)
	enter_compact_idle_window(true)
	await get_tree().process_frame
	var restored_ok := get_window().size.x <= scaled_size(IDLE_WINDOW_SIZE).x and host_window_mode == "idle"
	print("DYNAMIC_WINDOW_SELFTEST=", "PASS" if idle_ok and furniture_ok and furniture_hotspots_ok and utility_ok and governance_windows_ok and expanded_ok and independent_window_ok and layout_ok and restored_ok else "FAIL")

# 技能库面板曾经被内容顶到 1748px 高（窗口只有 760px），标题栏和工具栏因此被挤出屏幕。
# 上面用 utility_fits_requested_size 直接守住这条不变量；这个函数保留给需要定位
# 具体是哪一层控件在撑高面板时手工调用。
func print_skill_library_layout_diagnostics(panel: Control) -> void:
	print("SKILL_LAYOUT_DIAG panel_min=", panel.get_combined_minimum_size())
	var stack: Array = [panel]
	var depth := 0
	while not stack.is_empty() and depth < 7:
		var next_stack: Array = []
		var indent := ""
		for _level in range(depth):
			indent += "> "
		for node_value in stack:
			var node := node_value as Control
			if not node:
				continue
			var minimum := node.get_combined_minimum_size()
			if minimum.y > 150.0:
				print("  ", indent, node.get_class(), ":", node.name, " min=", minimum, " custom=", node.custom_minimum_size, " flags_v=", node.size_flags_vertical)
			for child in node.get_children():
				if child is Control:
					next_stack.append(child)
		stack = next_stack
		depth += 1

func build_debug_window_grid() -> void:
	debug_window_grid = DebugWindowGrid.new()
	debug_window_grid.name = "DebugWindowGrid"
	add_child(debug_window_grid)
	move_child(debug_window_grid, 0)
	debug_window_grid.call("set_grid_enabled", window_grid_visible)

func build_scene_context_menu() -> void:
	scene_context_menu = PopupMenu.new()
	scene_context_menu.name = "SceneContextMenu"
	scene_context_menu.add_item("显示家具", CONTEXT_MENU_FURNITURE)
	scene_context_menu.add_item("框选截图提问", CONTEXT_MENU_SCREENSHOT)
	scene_context_menu.add_item("知识库连接（WeKnora）", CONTEXT_MENU_KNOWLEDGE)
	scene_context_menu.add_check_item("窗口置顶", CONTEXT_MENU_TOPMOST)
	scene_context_menu.add_item("人物换装", CONTEXT_MENU_OUTFIT)
	scene_context_menu.add_check_item("人物分层动态（试验，可关闭）", CONTEXT_MENU_LAYERED)
	# [DSH] 主动开口的开关。陪伴类功能必须留一个"别烦我"的出口，
	# 否则它从陪伴变成骚扰，而用户没有办法关掉。
	scene_context_menu.add_check_item("空闲时主动开口", CONTEXT_MENU_PROACTIVE)
	scene_context_menu.add_check_item("显示窗口网格", CONTEXT_MENU_WINDOW_GRID)
	scene_context_menu.id_pressed.connect(on_scene_context_menu_pressed)
	add_child(scene_context_menu)

# [DSH] 切换窗口置顶。桌宠主窗口与对话工作区窗一起改：它们是一套界面，
# 只改一个会出现"人物在最前、对话在后面"的割裂感。
# 截图框选遮罩不在这里管——它是临时遮罩，必须浮在最上面。
# [DSH] 贴边停靠/探头期间必须临时置顶：默认不置顶的窗口会被别的程序压在下面，
# 探头就等于白探。离开停靠后立刻严格按用户自己的设置恢复，绝不让临时状态留下来。
# 规则挂在 dock_side 的 setter 上，覆盖所有进出停靠的路径（拖拽、自检、快捷键），
# 以后新增路径也不会漏。
func apply_dock_topmost() -> void:
	var desired := window_topmost or dock_side != 0
	if get_window().always_on_top != desired:
		get_window().always_on_top = desired

func set_window_topmost(value: bool) -> void:
	window_topmost = value
	get_window().always_on_top = value
	if chat_workspace_window:
		chat_workspace_window.always_on_top = value
	# [DSH] 停靠期间用户设置会被临时覆盖，这里立刻重新收敛一次，保证规则唯一。
	apply_dock_topmost()
	if soul_store:
		var settings: Dictionary = soul_store.get_ui_settings()
		settings["window_topmost"] = value
		soul_store.save_ui_settings(settings)
	show_message("窗口已置顶。" if value else "已取消置顶（需要时按 Ctrl+Alt+L 唤起）。", 3.5)

func open_scene_context_menu() -> void:
	if not scene_context_menu:
		return
	var furniture_index := scene_context_menu.get_item_index(CONTEXT_MENU_FURNITURE)
	if furniture_index >= 0:
		scene_context_menu.set_item_text(furniture_index, "收起家具" if scene_furniture_visible else "显示家具")
	var grid_index := scene_context_menu.get_item_index(CONTEXT_MENU_WINDOW_GRID)
	if grid_index >= 0:
		scene_context_menu.set_item_checked(grid_index, window_grid_visible)
	scene_context_menu.position = DisplayServer.mouse_get_position()
	scene_context_menu.set_item_checked(scene_context_menu.get_item_index(CONTEXT_MENU_LAYERED), layer_trial_enabled)
	scene_context_menu.set_item_checked(scene_context_menu.get_item_index(CONTEXT_MENU_PROACTIVE), proactive_enabled)
	scene_context_menu.set_item_checked(scene_context_menu.get_item_index(CONTEXT_MENU_TOPMOST), window_topmost)
	scene_context_menu.popup()

func on_scene_context_menu_pressed(item_id: int) -> void:
	match item_id:
		CONTEXT_MENU_LAYERED:
			toggle_layered_character()
		CONTEXT_MENU_PROACTIVE:
			toggle_proactive_companion()
		CONTEXT_MENU_KNOWLEDGE:
			toggle_knowledge_connection_panel()
		CONTEXT_MENU_TOPMOST:
			set_window_topmost(not window_topmost)
		CONTEXT_MENU_OUTFIT:
			if outfit_center:
				outfit_center.open()
		CONTEXT_MENU_SCREENSHOT:
			start_screenshot_capture()
		CONTEXT_MENU_FURNITURE:
			toggle_furniture_scene()
		CONTEXT_MENU_WINDOW_GRID:
			toggle_window_grid()

# [DSH] 开关"空闲时主动开口"，并持久化到界面配置——用户关掉之后重启不该又被打开。
func toggle_proactive_companion() -> void:
	proactive_enabled = not proactive_enabled
	if not proactive_enabled:
		proactive_idle_clock = 0.0
	if scene_context_menu:
		scene_context_menu.set_item_checked(scene_context_menu.get_item_index(CONTEXT_MENU_PROACTIVE), proactive_enabled)
	if soul_store:
		var settings: Dictionary = soul_store.get_ui_settings()
		settings["proactive_enabled"] = proactive_enabled
		settings["proactive_opt_in"] = true
		soul_store.save_ui_settings(settings)
	show_message("空闲时会主动说话：%s" % ("开启" if proactive_enabled else "关闭"), 3.0)

func toggle_window_grid() -> void:
	window_grid_visible = not window_grid_visible
	if debug_window_grid:
		debug_window_grid.call("set_grid_enabled", window_grid_visible)
	agent_event.emit({"type": "debug.window_grid", "visible": window_grid_visible})

func _exit_tree() -> void:
	if agent_bridge:
		agent_bridge.shutdown()

func open_harness_workspace() -> void:
	if agent_bridge and agent_bridge.core_ready:
		OS.shell_open("http://127.0.0.1:43818/")
		agent_event.emit({"type": "harness.workspace.open", "embedded": false})
	else:
		show_message("Harness 本地核心尚未就绪。", 3.0)

func acquire_single_instance_guard() -> bool:
	# 自检与夹具都以独立进程运行，但都不是"用户又开了一个梁鲸"：
	# 自检用独立数据目录，夹具只做离屏渲染，两者都不该被互斥锁挡住。
	# 否则在用户正开着梁鲸的情况下，验证根本跑不起来。
	# 真机探针同理：无头、不起 Harness、不画任何窗口，跑完立刻退出，
	# 而它偏偏必须在用户开着梁鲸时运行（要读的就是那份真实配置与密钥）。
	if "--selftest" in OS.get_cmdline_user_args() or probe_requested():
		return true
	# 透明桌宠被重复启动时，每个进程都会各画一套人物和家具，看上去像严重残影。
	# 使用仅本机可见的监听端口作为进程互斥锁，第二个实例直接退出。
	single_instance_guard = TCPServer.new()
	var error := single_instance_guard.listen(SINGLE_INSTANCE_PORT, "127.0.0.1")
	if error == OK:
		return true
	print("BLUE_WHALE_ALREADY_RUNNING")
	get_tree().quit()
	return false

func apply_readable_typography(node: Node) -> void:
	if node is RichTextLabel:
		var rich := node as RichTextLabel
		for font_key in ["normal_font_size", "bold_font_size", "italics_font_size", "bold_italics_font_size", "mono_font_size"]:
			var current_size := rich.get_theme_font_size(font_key)
			rich.add_theme_font_size_override(font_key, maxi(15, int(round(float(current_size) * UI_TEXT_SCALE))))
	elif node is Label or node is LineEdit or node is TextEdit:
		var text_control := node as Control
		var current_size := text_control.get_theme_font_size("font_size")
		text_control.add_theme_font_size_override("font_size", maxi(14, int(round(float(current_size) * UI_TEXT_SCALE))))
	elif node is Button or node is OptionButton or node is CheckButton or node is SpinBox:
		var interactive_control := node as Control
		var current_size := interactive_control.get_theme_font_size("font_size")
		interactive_control.add_theme_font_size_override("font_size", maxi(14, int(round(float(current_size) * 1.16))))
	for child in node.get_children():
		apply_readable_typography(child)

func configure_chat_text_fonts(label: RichTextLabel, point_size: int) -> void:
	# The default Latin font's synthetic bold distorts its CJK fallback glyphs.
	# Request native CJK faces and keep all inline styles at the same text size.
	var regular := SystemFont.new()
	regular.font_names = PackedStringArray(["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans CJK SC", "sans-serif"])
	regular.font_weight = 400
	var bold := SystemFont.new()
	bold.font_names = regular.font_names
	bold.font_weight = 700
	for font_key in ["normal_font", "italics_font"]:
		label.add_theme_font_override(font_key, regular)
	for font_key in ["bold_font", "bold_italics_font"]:
		label.add_theme_font_override(font_key, bold)
	for size_key in ["normal_font_size", "bold_font_size", "italics_font_size", "bold_italics_font_size", "mono_font_size"]:
		label.add_theme_font_size_override(size_key, point_size)
	label.add_theme_constant_override("outline_size", 0)
	label.add_theme_constant_override("line_separation", 5)

func initialize_soul_store() -> void:
	soul_store = SoulStore.new()
	var override_root := ""
	if "--selftest" in OS.get_cmdline_user_args():
		# 自检数据目录必须留在工作区内，而且每次运行都应该是干净的。
		# 旧写法用 res://../tmp/... 会解析到工作区之外的上一级目录：在被沙箱或权限
		# 策略限制的机器上那里根本不可写，数据层（含原子写与配置保存）会在自检里
		# 全部静默失败，测试等于没测；而只要它曾经被写进去过数据，后续断言就会
		# 依赖上一次运行留下的脏状态（这一点真的发生过）。
		# tmp/ 前缀的点目录不会进入资产导入，也不会被产品运行使用。
		override_root = ProjectSettings.globalize_path("res://tmp/.selftest_runtime")
	var result: Dictionary = soul_store.initialize(override_root)
	if not bool(result.get("ok", false)):
		push_warning("灵魂仓库初始化失败：%s" % result.get("error", "未知错误"))
	else:
		print("SOUL_STORE_READY=", result.get("root", ""))

func initialize_deepseek_config() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	deepseek_config = DeepSeekConfigStore.new()
	var result: Dictionary = deepseek_config.initialize(soul_store.root_path)
	if not bool(result.get("ok", false)):
		push_warning("DeepSeek 配置初始化失败：%s" % result.get("error", "未知错误"))

# [DSH] 知识库连接：默认仍然是"本机知识库"，没配 WeKnora 时行为与以前完全一致。
# 自检模式不读用户真实配置：走临时目录，避免自检把用户的地址/Key 覆盖掉。
func initialize_weknora() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	weknora_config = WeKnoraConfigStore.new()
	var root: String = soul_store.root_path
	if "--selftest" in OS.get_cmdline_user_args():
		root = ProjectSettings.globalize_path("res://tmp/.selftest_runtime/自检知识库配置")
	var result: Dictionary = weknora_config.initialize(root, deepseek_config)
	if not bool(result.get("ok", false)):
		push_warning("知识库连接配置初始化失败：%s" % result.get("error", "未知错误"))
	weknora_client = WeKnoraClientScript.new()
	weknora_client.name = "WeKnoraClient"
	add_child(weknora_client)
	if weknora_config.uses_weknora():
		weknora_client.initialize(weknora_config.get_api_base_url(), weknora_config.load_api_key())

func initialize_skill_registry() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	skill_registry = SkillRegistry.new()
	var result: Dictionary = skill_registry.initialize(soul_store.root_path)
	if not bool(result.get("ok", false)):
		push_warning("技能库初始化失败：%s" % result.get("error", "未知错误"))

# 规则和工作流使用各自的本机结构化文件，并拥有完全独立的原生窗口。
# 它们不依赖模型或 Harness 启动，因此离线时也可以编辑。
func initialize_rule_and_workflow_centers() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	rule_center = RuleCenter.new()
	add_child(rule_center)
	rule_center.setup(self, soul_store.root_path)
	workflow_center = WorkflowCenter.new()
	add_child(workflow_center)
	workflow_center.setup(self, soul_store.root_path)
	workflow_transport = WorkflowHarness.new()
	add_child(workflow_transport)
	workflow_transport.setup(self)
	workflow_transport.trace_received.connect(on_harness_trace_received)
	workflow_transport.reasoning_received.connect(on_model_reasoning_received)
	workflow_transport.approval_requested.connect(on_harness_approval_requested)
	workflow_transport.approval_resolved.connect(on_harness_approval_resolved)
	workflow_transport.question_requested.connect(on_harness_question_requested)
	workflow_transport.question_resolved.connect(on_harness_question_resolved)
	workflow_transport.interactions_invalidated.connect(on_workflow_interactions_invalidated)
	workflow_runner = WorkflowRunner.new()
	add_child(workflow_runner)
	workflow_runner.setup(soul_store.root_path, workflow_transport)
	workflow_runner.changed.connect(on_workflow_run_changed)
	workflow_center.attach_runner(workflow_runner)

func workflow_run_context() -> Dictionary:
	return workflow_transport.run_context() if workflow_transport else {"ok": false, "error": "工作流执行模块尚未初始化"}

# [DSH] 只在运行记录真的变化时改表情：changed 信号在下载进度等场景会高频触发，
# 每次都重设表情会把"沮丧"保持期一直续上。
var workflow_emotion_key := ""

func on_workflow_run_changed() -> void:
	var active: bool = workflow_runner and workflow_runner.is_active()
	if active and not workflow_owns_chat:
		workflow_owns_chat = true
		chat_busy = true
		reset_model_reasoning()
	elif not active and workflow_owns_chat:
		workflow_owns_chat = false
		chat_busy = false
		on_workflow_interactions_invalidated("工作流本次运行结束")
		dispatch_next_queued_message()
	# [DSH] 工作流同样有"等待核对"和"失败"两个状态，映射规则与对话一致。
	if workflow_runner:
		var state := str(workflow_runner.record.get("state", ""))
		var key := "%s#%d#%d" % [state, int(workflow_runner.record.get("step_index", -1)), int(workflow_runner.record.get("attempt", 0))]
		if key != workflow_emotion_key:
			workflow_emotion_key = key
			if state in ["waiting_input", "waiting_confirmation"] or (active and state in ["pausing", "paused"]):
				set_harness_emotion(EXPRESSION_FOCUS)
			elif state in ["failed", "stop_unconfirmed"]:
				set_harness_emotion(EXPRESSION_DOWN)
			elif not active:
				set_harness_emotion(EXPRESSION_CALM)
	for control in [chat_model_select, chat_reasoning_select, chat_permission_select, chat_project_button]:
		if control:
			control.disabled = active
	update_history_delete_controls()
	if chat_execution_status:
		chat_execution_status.text = "工作流 · " + str(workflow_runner.record.get("message", "运行中")) if active else "工作流记录已更新 · 可继续对话"
		chat_execution_status.tooltip_text = chat_execution_status.text

func on_workflow_interactions_invalidated(_reason: String) -> void:
	if not workflow_transport:
		return
	var workflow_session: String = workflow_transport.session_id
	approval_queue = approval_queue.filter(func(item): return str(item.get("sessionId", "")) != workflow_session)
	question_queue = question_queue.filter(func(item): return str(item.get("sessionId", "")) != workflow_session)
	if str(current_approval.get("sessionId", "")) == workflow_session:
		current_approval.clear()
		if approval_panel:
			approval_panel.hide()
	if str(current_question_request.get("sessionId", "")) == workflow_session:
		current_question_request.clear()
		current_question_drafts.clear()
		current_question_index = 0
		if question_panel:
			question_panel.hide()
	show_next_approval()
	show_next_question_request()

func bridge_for_interaction(request: Dictionary) -> Node:
	if workflow_transport and not workflow_transport.session_id.is_empty() and str(request.get("sessionId", "")) == workflow_transport.session_id:
		return workflow_transport
	return agent_bridge

func workflow_blocks_settings_change() -> bool:
	if workflow_runner and workflow_runner.is_active():
		show_message("工作流尚未结束，请先在工作流中心取消，再修改模型、网络或内核配置。", 4.0)
		return true
	return false

func initialize_execution_framework_config() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	execution_framework_config = ExecutionFrameworkConfig.new()
	var result: Dictionary = execution_framework_config.initialize(soul_store.root_path)
	if not bool(result.get("ok", false)):
		push_warning("执行框架配置初始化失败：%s" % result.get("error", "未知错误"))

func initialize_network_config() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	network_config = NetworkConfigStore.new()
	var result: Dictionary = network_config.initialize(soul_store.root_path)
	if not bool(result.get("ok", false)):
		push_warning("网络配置初始化失败：%s" % result.get("error", "未知错误"))

func runtime_project_directory() -> String:
	var runtime_project_root := ProjectSettings.globalize_path("res://").trim_suffix("/")
	if runtime_project_root.is_empty() or not runtime_project_root.is_absolute_path():
		runtime_project_root = OS.get_executable_path().get_base_dir()
	return runtime_project_root

func resolved_network_settings() -> Dictionary:
	if not network_config:
		return {"enabled": false, "mode": "direct", "source": "直连", "no_proxy": "localhost,127.0.0.1,::1"}
	return network_config.resolve_proxy(network_config.load_config())

func initialize_agent_bridge() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		return
	# 自检不启动 Harness 子进程：自检项都不依赖它，却会每次拉起一个 node，
	# 而进程清理只靠 _exit_tree；一旦外层强制 kill，就会留下孤儿进程与端口占用。
	# 需要真实内核的验证走单独的探针，不混在自检里。
	# 真机探针同理：它只做知识库 HTTP 调用，起第二个 Harness 只会抢端口、拖住启动。
	if "--selftest" in OS.get_cmdline_user_args() or probe_requested():
		print("HARNESS_STATUS=skipped selftest 模式不启动 Harness 子进程")
		return
	agent_bridge = AgentBridgeCore.new()
	agent_bridge.name = "HarnessAgentBridge"
	add_child(agent_bridge)
	agent_bridge.status_changed.connect(on_harness_status_changed)
	agent_bridge.trace_received.connect(on_harness_trace_received)
	agent_bridge.reasoning_received.connect(on_model_reasoning_received)
	agent_bridge.model_configured.connect(on_harness_model_configured)
	agent_bridge.approval_requested.connect(on_harness_approval_requested)
	agent_bridge.approval_resolved.connect(on_harness_approval_resolved)
	agent_bridge.question_requested.connect(on_harness_question_requested)
	agent_bridge.question_resolved.connect(on_harness_question_resolved)
	agent_bridge.session_changed.connect(on_harness_session_changed)
	agent_bridge.metrics_updated.connect(on_harness_metrics_updated)
	agent_bridge.interactions_invalidated.connect(on_harness_interactions_invalidated)
	var framework_settings: Dictionary = execution_framework_config.load_config() if execution_framework_config else {}
	agent_bridge.configure(runtime_project_directory(), soul_store.root_path, framework_settings, resolved_network_settings())
	agent_bridge.start()

func on_harness_status_changed(state: String, detail: String) -> void:
	harness_status_state = state
	harness_status_detail = detail
	print("HARNESS_STATUS=", state, " ", detail)
	if state == "ready":
		sync_chat_profile_to_harness()
	if api_test_status and api_settings_panel and api_settings_panel.visible:
		api_test_status.text = detail
		set_api_status_color(state == "ready")
	if framework_status_label and execution_settings_panel and execution_settings_panel.visible:
		framework_status_label.text = detail
		set_framework_status_color(state == "ready" or state in ["starting", "configured"])

func on_harness_trace_received(title: String, detail: String) -> void:
	if analysis_trace and chat_busy:
		add_analysis_step(title, detail)

func show_analysis_page(reasoning: bool, user_selected := true) -> void:
	if not analysis_reasoning:
		return
	analysis_page_chosen = analysis_page_chosen or user_selected
	analysis_trace.visible = not reasoning
	analysis_reasoning.visible = reasoning
	analysis_steps_button.set_pressed_no_signal(not reasoning)
	analysis_reasoning_button.set_pressed_no_signal(reasoning)

func reset_model_reasoning() -> void:
	model_reasoning_text = ""
	analysis_page_chosen = false
	if analysis_reasoning:
		analysis_reasoning.text = "本次尚未收到模型思考内容。只有模型返回的内容会显示在这里。"
		show_analysis_page(false, false)

func on_model_reasoning_received(detail: String) -> void:
	if not chat_busy or detail.is_empty() or not analysis_reasoning:
		return
	if model_reasoning_text.is_empty():
		analysis_reasoning.clear()
	model_reasoning_text += detail
	analysis_reasoning.add_text(detail)
	if not analysis_page_chosen:
		show_analysis_page(true, false)

func finish_model_reasoning() -> void:
	if analysis_reasoning and model_reasoning_text.is_empty():
		analysis_reasoning.text = "本次模型未返回可展示的思考内容。可检查推理开关与模型支持情况。"

func on_harness_metrics_updated(metrics: Dictionary) -> void:
	if not analysis_metrics:
		return
	analysis_metrics.text = "%d 轮 · %d 步 · LLM %s\n工具 %s · 首字 %s · %.0f tok/s\n缓存 %.0f%% · 输入 %s tokens" % [
		int(metrics.get("turns", 0)),
		int(metrics.get("steps", 0)),
		format_harness_duration(float(metrics.get("llm_ms", 0.0))),
		format_harness_duration(float(metrics.get("tool_ms", 0.0))),
		format_harness_duration(float(metrics.get("ttft_ms", 0.0))),
		float(metrics.get("tokens_per_second", 0.0)),
		float(metrics.get("cache_hit", 0.0)) * 100.0,
		format_harness_token_count(float(metrics.get("input_tokens", 0.0)))
	]

func format_harness_duration(milliseconds: float) -> String:
	var seconds := maxf(0.0, milliseconds / 1000.0)
	if seconds >= 60.0:
		return "%dm%02ds" % [int(seconds / 60.0), int(fmod(seconds, 60.0))]
	return "%.1fs" % seconds

func format_harness_token_count(tokens: float) -> String:
	if tokens >= 1000000.0:
		return "%.1fM" % (tokens / 1000000.0)
	if tokens >= 1000.0:
		return "%.0fK" % (tokens / 1000.0)
	return "%d" % int(tokens)

func on_harness_model_configured(ok: bool, detail: String) -> void:
	if api_test_status and api_settings_panel and api_settings_panel.visible:
		api_test_status.text = detail
		set_api_status_color(ok)

func on_harness_approval_requested(request: Dictionary) -> void:
	for queued in approval_queue:
		if str(queued.get("rpcId", "")) == str(request.get("rpcId", "")):
			return
	if str(current_approval.get("rpcId", "")) == str(request.get("rpcId", "")):
		return
	approval_queue.append(request.duplicate(true))
	# [DSH] 等待授权时她皱眉专注，桌面上就能看出"卡在等你点头"。
	set_harness_emotion(EXPRESSION_FOCUS)
	if chat_execution_status:
		chat_execution_status.text = "等待授权"
		chat_execution_status.add_theme_color_override("font_color", Color("d88727"))
	add_analysis_step("等待你的授权", str(request.get("toolName", "电脑操作")))
	show_next_approval()

func on_harness_approval_resolved(_request: Dictionary, allowed: bool) -> void:
	if str(_request.get("rpcId", "")) != str(current_approval.get("rpcId", "")):
		return
	# [DSH] 用户已作答，不管允许还是拒绝都不再是"等待"状态。
	set_harness_emotion(EXPRESSION_CALM)
	if chat_execution_status:
		chat_execution_status.text = "继续执行" if allowed else "已拒绝"
		chat_execution_status.add_theme_color_override("font_color", Color("2b91ce") if allowed else Color("b25050"))
	add_analysis_step("已允许本次操作" if allowed else "已拒绝操作", "Harness 将按你的选择继续")

func on_harness_question_requested(request: Dictionary) -> void:
	for queued in question_queue:
		if str(queued.get("rpcId", "")) == str(request.get("rpcId", "")):
			return
	if str(current_question_request.get("rpcId", "")) == str(request.get("rpcId", "")):
		return
	question_queue.append(request.duplicate(true))
	# [DSH] 追问也是"卡在等你"，与授权共用专注表情。
	set_harness_emotion(EXPRESSION_FOCUS)
	if chat_execution_status:
		chat_execution_status.text = "等待你的选择"
		chat_execution_status.add_theme_color_override("font_color", Color("d88727"))
	var questions: Array = request.get("questions", []) if request.get("questions", []) is Array else []
	var summary := "Harness 需要你补充信息"
	if not questions.is_empty() and questions[0] is Dictionary:
		summary = str((questions[0] as Dictionary).get("question", summary))
	add_analysis_step("等待你的选择", summary)
	show_next_question_request()

func on_harness_question_resolved(_request: Dictionary, cancelled: bool) -> void:
	if str(_request.get("rpcId", "")) != str(current_question_request.get("rpcId", "")):
		return
	# [DSH] 已回答（或取消），交互结束，表情收回。
	set_harness_emotion(EXPRESSION_CALM)
	if chat_execution_status:
		chat_execution_status.text = "已取消" if cancelled else "继续执行"
		chat_execution_status.add_theme_color_override("font_color", Color("b25050") if cancelled else Color("2b91ce"))
	add_analysis_step("已取消交互" if cancelled else "已提交选择", "Harness 将按你的选择继续")

func on_harness_session_changed(_session_id: String, project_path: String) -> void:
	if chat_project_button:
		var project_name := project_path.get_file() if not project_path.is_empty() else "灵魂"
		if project_name.length() > 6:
			project_name = project_name.left(6) + "…"
		chat_project_button.text = "项目 · %s" % project_name
		chat_project_button.tooltip_text = "当前工作区：%s" % (project_path if not project_path.is_empty() else "本地灵魂仓库")

# 会话切换或内核关闭后，之前排队的授权/追问已经不可能被接受（提交只会得到 409）。
# 这里必须主动清空并告知用户，否则会留下一张永远点不动的授权卡。
func on_harness_interactions_invalidated(reason: String) -> void:
	var had_pending := not approval_queue.is_empty() or not current_approval.is_empty() or not question_queue.is_empty() or not current_question_request.is_empty()
	approval_queue.clear()
	current_approval.clear()
	question_queue.clear()
	current_question_request.clear()
	current_question_index = 0
	current_question_drafts.clear()
	# [DSH] 交互整体失效，等不到任何回答，专注表情也随之作废。
	set_harness_emotion(EXPRESSION_CALM)
	if approval_panel:
		approval_panel.visible = false
	if question_panel:
		question_panel.visible = false
	if had_pending:
		add_analysis_step("授权请求已失效", "%s；请重新发送任务以再次发起操作" % reason)
		show_message("上一条授权请求已失效，请重新发送任务。", 4.0)
	if chat_execution_status:
		chat_execution_status.text = "等待新的任务"
		chat_execution_status.add_theme_color_override("font_color", Color("5b7f9e"))

func show_next_approval() -> void:
	if not current_approval.is_empty() or not current_question_request.is_empty() or approval_queue.is_empty() or not approval_panel:
		return
	# 审批必须可见可点：桌宠可能正停靠侧边、工作区窗口可能没打开、设置页可能开着。
	# 否则授权卡被排进队列却无处显示，任务会静静地卡在等待授权上。
	if dock_side != 0:
		dock_restore_chat_open = true
		restore_from_edge_dock()
	if scene_input_dock and not scene_input_dock.visible:
		hide_all_utility_windows()
		set_chat_workspace_visible(true)
		apply_responsive_chat_layout(true)
	current_approval = approval_queue.pop_front()
	var tool_name := str(current_approval.get("toolName", "电脑操作"))
	var reason := str(current_approval.get("reason", "梁鲸需要执行一项可能改变电脑内容的操作。"))
	approval_tool_label.text = tool_name
	approval_reason_label.text = reason if not reason.is_empty() else "梁鲸需要执行一项可能改变电脑内容的操作。"
	approval_allow_button.disabled = false
	approval_reject_button.disabled = false
	call_deferred("present_current_approval")

func present_current_approval() -> void:
	# 审批必须回到蓝鲸主界面：即使桌宠正停靠侧边、设置页打开或聊天页关闭。
	if dock_side != 0:
		dock_restore_chat_open = true
		restore_from_edge_dock()
	hide_all_utility_windows()
	if scene_input_dock and not scene_input_dock.visible:
		set_chat_workspace_visible(true)
		apply_responsive_chat_layout(true)
	approval_panel.visible = true
	approval_panel.move_to_front()
	position_approval_panel()
	# 立即取消鼠标穿透，避免授权卡出现后的第一次点击落到后面的程序。
	if chat_workspace_window:
		apply_native_window_input_shape(full_window_input_shape())
		chat_workspace_window.mouse_passthrough = false
		chat_workspace_window.grab_focus()

func answer_current_approval(allowed: bool) -> void:
	if current_approval.is_empty() or not agent_bridge:
		return
	approval_allow_button.disabled = true
	approval_reject_button.disabled = true
	var request := current_approval.duplicate(true)
	var result: Dictionary = await bridge_for_interaction(request).respond_approval(request, allowed)
	if str(current_approval.get("rpcId", "")) != str(request.get("rpcId", "")) or str(current_approval.get("sessionId", "")) != str(request.get("sessionId", "")):
		return
	if not bool(result.get("ok", false)):
		approval_allow_button.disabled = false
		approval_reject_button.disabled = false
		approval_reason_label.text = "授权没有送达：%s" % str(result.get("error", "未知错误"))
		return
	current_approval.clear()
	approval_panel.visible = false
	show_next_approval()
	show_next_question_request()

func sync_chat_profile_to_harness() -> void:
	if workflow_owns_chat:
		return
	if chat_profile_syncing:
		chat_profile_sync_pending = true
		return
	if not agent_bridge or not agent_bridge.core_ready or not deepseek_config:
		return
	if not deepseek_config.has_api_key("chat"):
		return
	var profile: Dictionary = deepseek_config.get_profile("chat")
	if str(profile.get("provider", "")) != "deepseek":
		return
	var model := selected_chat_model() if chat_model_select else str(profile.get("model", DeepSeekConfigStore.DEFAULT_MODEL))
	var effort := selected_chat_reasoning_effort() if chat_reasoning_select else str(profile.get("reasoning_effort", "high" if bool(profile.get("thinking", false)) else "off"))
	chat_profile_syncing = true
	await agent_bridge.sync_deepseek(
		deepseek_config.load_api_key("chat"),
		str(profile.get("base_url", DeepSeekConfigStore.DEFAULT_BASE_URL)),
		model,
		effort
	)
	chat_profile_syncing = false
	if chat_profile_sync_pending:
		chat_profile_sync_pending = false
		call_deferred("sync_chat_profile_to_harness")

func build_character() -> void:
	character = Node2D.new()
	character.name = "Character"
	character.position = NORMAL_CHARACTER_POSITION
	add_child(character)
	neutral_texture = load(MODEL_TEXTURE)
	character_sprite = Sprite2D.new()
	character_sprite.name = "CompleteCharacter"
	character_sprite.texture = neutral_texture
	character_sprite.scale = Vector2.ONE * MODEL_SCALE
	var shader := load(CHARACTER_SHADER) as Shader
	if shader:
		character_material = ShaderMaterial.new()
		character_material.shader = shader
		character_material.set_shader_parameter("eye_effect", 0.0)
		character_material.set_shader_parameter("blink", 0.0)
		character_material.set_shader_parameter("gaze", Vector2.ZERO)
		character_sprite.material = character_material
	character.add_child(character_sprite)
	blink_sprite = Sprite2D.new()
	blink_sprite.name = "ClosedEyeExpression"
	blink_sprite.texture = load(BLINK_TEXTURE)
	blink_sprite.position = Vector2(2, -7)
	blink_sprite.scale = Vector2.ONE * MODEL_SCALE
	blink_sprite.visible = false
	var blink_shader := load(BLINK_SHADER) as Shader
	if blink_shader:
		blink_material = ShaderMaterial.new()
		blink_material.shader = blink_shader
		blink_material.set_shader_parameter("blink", 0.0)
		blink_sprite.material = blink_material
	character.add_child(blink_sprite)
	build_layered_character()

func build_layered_character() -> void:
	# Keep both legacy sprites intact for instant rollback, action frames and outfits.
	layered_character = LayeredCharacter.new()
	layered_character.name = "LayeredCharacterTrial"
	character.add_child(layered_character)
	layered_character.hide()
	layered_character.setup(load(MODEL_TEXTURE), load(BLINK_TEXTURE))
	if soul_store:
		var settings := ConfigFile.new()
		if settings.load(soul_store.root_path.path_join("外观/分层试验.cfg")) == OK:
			layer_trial_enabled = bool(settings.get_value("trial", "enabled", true))
	# [DSH] 读回"空闲时主动开口"的用户开关：关掉之后重启不该又被打开。
	if soul_store:
		var proactive_settings: Dictionary = soul_store.get_ui_settings()
		proactive_enabled = bool(proactive_settings.get("proactive_opt_in", false)) and bool(proactive_settings.get("proactive_enabled", false))
		# [DSH] 读回"窗口置顶"：默认关闭，只有用户主动开过才置顶。
		window_topmost = bool(proactive_settings.get("window_topmost", false))
		get_window().always_on_top = window_topmost
	sync_layered_appearance()

func sync_layered_character(delta := 0.0) -> void:
	if not layered_character or layered_frame_capture:
		# 离屏采集期间分层装置被临时挂到 SubViewport 下，这里必须让位，否则会覆盖采集姿势。
		return
	# A rejected appearance must show the new static image, never the previous outfit.
	var enabled: bool = layer_trial_enabled and layered_character.ready_for_use and layered_character.appearance_supported and not action_playing and dock_side == 0
	layered_character.visible = enabled
	character_sprite.visible = not enabled
	if enabled and not layered_expression_pushed:
		# [DSH] 刚被重新启用（换装、动作结束、从侧边缩回）时表情是停在上次的值，
		# 这里按当前状态立即补一次，避免"她切回来时是一张过期表情"。
		layered_expression_pushed = true
		push_harness_emotion()
	elif not enabled:
		layered_expression_pushed = false
	if enabled:
		layered_character.scale = character_sprite.scale
		layered_character.position = character_sprite.position
		var blink_value := float(blink_material.get_shader_parameter("blink")) if blink_material else 0.0
		layered_character.advance(delta, not dragging and character.is_visible_in_tree(), idle_gaze, blink_value)
		blink_sprite.hide()
	else:
		blink_sprite.visible = not custom_outfit_active and not action_playing and dock_side == 0 and not dragging

# 把当前生效的外观纹理交给分层装置。
# 任何可见外观变化的入口都应调用它，否则会出现"人物已经换了、动态还停在上一套"。
func sync_layered_appearance() -> void:
	var texture: Texture2D = neutral_texture if neutral_texture != null else load(MODEL_TEXTURE)
	if character_sprite:
		character_sprite.texture = texture
	if layered_character and layered_character.ready_for_use and not layered_character.set_appearance(texture):
		# 尺寸不符（例如未归一化的生成图）时明确退回旧路径，而不是把错的纹理硬塞进去。
		push_warning("分层动态：外观纹理尺寸不受支持，已退回原有显示方式。")
		add_analysis_step("分层动态已退回", "当前形象尺寸与分层网格不匹配")
	var profile := MotionProfile.defaults()
	if custom_outfit_active and outfit_center:
		profile = outfit_center.active_motion_profile()
	if layered_character:
		layered_character.set_motion_profile(profile)
	sync_layered_character()

func on_outfit_motion_profile_changed(profile: Dictionary) -> void:
	var applied := profile if custom_outfit_active else MotionProfile.defaults()
	if layered_character:
		layered_character.set_motion_profile(applied)
	sync_layered_character()

func toggle_layered_character() -> void:
	layer_trial_enabled = not layer_trial_enabled
	sync_layered_character()
	if scene_context_menu:
		scene_context_menu.set_item_checked(scene_context_menu.get_item_index(CONTEXT_MENU_LAYERED), layer_trial_enabled)
	if soul_store:
		var directory: String = soul_store.root_path.path_join("外观")
		var settings := ConfigFile.new()
		settings.set_value("trial", "enabled", layer_trial_enabled)
		if DirAccess.make_dir_recursive_absolute(directory) == OK:
			var path := directory.path_join("分层试验.cfg")
			if settings.save(path + ".pending") == OK:
				DirAccess.rename_absolute(path + ".pending", path)

# [DSH] 动作清单：把"帧序列"与"实际图片"分开。
# 探头那一组名义上是 60 帧，实际只有两张不同的图（第 29/30/31 帧是闭眼那一拍），
# 以前 60 张 1024×1536 纹理各自占用一份显存（约 377 MB），而屏幕上真正变的只有两张。
# 现在按清单只加载两张图片，再展开成 60 个槽位（同一个 Texture2D 被引用多次）。
# 清单由 tmp\build_action_manifest.mjs 按文件内容哈希生成，不手工维护。
func parse_action_manifest(parsed: Variant) -> Dictionary:
	var fallback := {"fps": DEFAULT_ACTION_FRAME_RATE, "images": {}, "frames": []}
	if not parsed is Dictionary:
		return fallback
	var source: Dictionary = parsed
	var fps := clampf(float(source.get("fps", DEFAULT_ACTION_FRAME_RATE)), 1.0, 60.0)
	var images_value: Variant = source.get("images", {})
	var frames_value: Variant = source.get("frames", [])
	if not images_value is Dictionary or not frames_value is Array:
		return {"fps": fps, "images": {}, "frames": []}
	var images: Dictionary = images_value
	var frame_keys: Array = frames_value
	if images.is_empty() or frame_keys.is_empty():
		return {"fps": fps, "images": {}, "frames": []}
	var file_names: Array = []
	for item in frame_keys:
		var key := str(item)
		if not images.has(key):
			# 清单不完整就整体退回编号帧扫描：宁可多占显存，也不能让探头变成空白。
			return {"fps": fps, "images": {}, "frames": []}
		file_names.append(str(images[key]))
	return {"fps": fps, "images": images.duplicate(true), "frames": file_names}

func load_action_frames(action_name: String, manifest: Dictionary) -> Array[Texture2D]:
	var frames: Array[Texture2D] = []
	var file_names: Array = manifest.get("frames", [])
	if file_names.is_empty():
		for index in range(MAX_ACTION_FRAMES):
			var path := "res://assets/actions/%s/%02d.png" % [action_name, index]
			if not ResourceLoader.exists(path):
				break
			var texture := load(path) as Texture2D
			if texture:
				frames.append(texture)
		return frames
	# 同一张图片只加载一次；60 个槽位里重复的帧共用同一个 Texture2D 实例。
	var cache := {}
	for item in file_names:
		var file_name := str(item)
		if not cache.has(file_name):
			cache[file_name] = load("res://assets/actions/%s/%s" % [action_name, file_name]) as Texture2D
		var texture: Texture2D = cache[file_name]
		if texture == null:
			push_warning("动作 %s 的图片 %s 无法加载，本次不使用该动作。" % [action_name, file_name])
			return []
		frames.append(texture)
	return frames

func load_action_library() -> void:
	var started_usec := Time.get_ticks_usec()
	action_library.clear()
	for action_name in action_assets:
		var manifest := {"fps": DEFAULT_ACTION_FRAME_RATE, "images": {}, "frames": []}
		var config_path := "res://assets/actions/%s/action.json" % action_name
		if FileAccess.file_exists(config_path):
			manifest = parse_action_manifest(JSON.parse_string(FileAccess.get_file_as_string(config_path)))
		var frames := load_action_frames(action_name, manifest)
		if frames.is_empty():
			continue
		var unique_images := {}
		for texture in frames:
			unique_images[texture.get_instance_id()] = true
		action_library[action_name] = {"frames": frames, "fps": float(manifest.get("fps", DEFAULT_ACTION_FRAME_RATE))}
		print("ACTION_LOADED=", action_name, " FRAMES=", frames.size(), " UNIQUE=", unique_images.size(), " FPS=", manifest.get("fps", DEFAULT_ACTION_FRAME_RATE))
	action_library_load_ms = float(Time.get_ticks_usec() - started_usec) / 1000.0

func play_dock_peek() -> void:
	if not action_library.has(DOCK_ACTION):
		return
	var pack: Dictionary = action_library[DOCK_ACTION]
	current_frames = copy_frames(pack.get("frames", []))
	if current_frames.is_empty():
		push_warning("探头动作帧为空，保持当前形象。")
		return
	print("PEEK_PLAY FRAMES=", current_frames.size(), " SIDE=", dock_side)
	current_action = DOCK_ACTION
	current_frame_interval = 1.0 / float(pack["fps"])
	action_playing = true
	frame_index = 0
	frame_clock = 0.0
	dock_peek_holding = false
	dock_hold_clock = 0.0
	character.position = dock_character_position()
	character_sprite.scale = Vector2.ONE * PEEK_MODEL_SCALE
	blink_sprite.visible = false
	# 原画为右侧边缘向左探；停靠左侧时才水平镜像。
	character_sprite.flip_h = dock_side < 0
	character_sprite.texture = current_frames[0]
	if bubble:
		bubble.visible = false
	if agent_panel:
		agent_panel.visible = false
	if agent_scene_background:
		agent_scene_background.visible = false
	if scene_input_dock:
		close_chat_workspace()
	if interaction_hint:
		interaction_hint.visible = false
	# 探头使用专用帧，立即隐藏站立网格；恢复时仍从 neutral_texture 取当前穿着。
	sync_layered_character()

func restore_normal_character() -> void:
	action_playing = false
	frame_index = 0
	frame_clock = 0.0
	current_action = ""
	current_frames = []
	dock_peek_holding = false
	dock_hold_clock = 0.0
	character.position = normal_character_position()
	var restored_scale := normal_character_scale() if agent_panel else MODEL_SCALE
	character_sprite.scale = Vector2.ONE * restored_scale
	blink_sprite.scale = Vector2.ONE * restored_scale
	blink_sprite.visible = false
	character_sprite.flip_h = false
	character_sprite.texture = neutral_texture
	sync_layered_character()
	if agent_panel:
		agent_panel.visible = true
	if agent_scene_background:
		agent_scene_background.visible = scene_furniture_visible

func copy_frames(source: Array) -> Array[Texture2D]:
	# 动作库中的数组是长期缓存；播放时必须复制，避免结束动作时清空缓存。
	var copied: Array[Texture2D] = []
	for item in source:
		var texture := item as Texture2D
		if texture:
			copied.append(texture)
	return copied

func _process(delta: float) -> void:
	screen_check_clock += delta
	if screen_check_clock >= 1.0:
		screen_check_clock = 0.0
		configure_display_sync(false)
	update_action(delta)
	update_edge_dock()
	update_idle_face(delta)
	update_harness_emotion(delta)
	sync_layered_character(delta)
	update_interaction_hint_position()
	# [DSH] 解析窗跟随对话窗显示/隐藏。放在这里做幂等同步，而不是给每个
	# chat_workspace_window.show()/hide() 调用点打补丁：对话窗的显示入口有 7 处
	# （唤起、截图前后、最大化、自检……），漏一处就会出现"对话窗关了、
	# 解析窗还孤零零挂在桌面上"。
	sync_analysis_window_visibility()
	# [DSH] 定时工作流的检查。放在 _process 里而不是新建 Timer：
	# 与其它周期任务共用同一处节拍，避免退出时漏掉定时器的清理。
	update_workflow_schedules(delta)
	update_window_geometry_memory(delta)
	update_window_mouse_passthrough()
	proactive_last_spoken_at = ProactiveCompanion.advance_since_spoken(proactive_last_spoken_at, delta)
	# [DSH] 运行中刷新已等待时长（每秒一次即可，不必每帧改文本）。
	if chat_busy:
		agent_turn_tick_clock += delta
		if agent_turn_tick_clock >= 1.0:
			agent_turn_tick_clock = 0.0
			update_agent_turn_controls()
	else:
		# 空闲计时：用户一有动作就归零（见 note_user_activity）。
		proactive_idle_clock += delta
		update_proactive_companion(delta)

# [DSH] 用户的活动（发消息、点按钮）要重置空闲计时——
# 否则"她主动开口"会变成"在用户刚说完话时插嘴"。
func note_user_activity() -> void:
	proactive_idle_clock = 0.0

# [DSH] 主动开口的触发点。每 5 秒算一次，决策交给纯函数。
func update_proactive_companion(delta: float) -> void:
	if not proactive_enabled:
		return
	proactive_check_clock += delta
	if proactive_check_clock < 5.0:
		return
	proactive_check_clock = 0.0
	if bubble and bubble.visible:
		return
	var span := last_conversation_span()
	var decision := ProactiveCompanion.decide({
		"idle_seconds": proactive_idle_clock,
		"chat_busy": chat_busy,
		"workspace_open": bool(scene_input_dock and scene_input_dock.visible),
		"spoken_count": proactive_spoken_count,
		"seconds_since_last_spoken": proactive_last_spoken_at if proactive_last_spoken_at >= 0.0 else -1.0,
		"last_conversation_seconds": span.get("seconds", -1.0)
	})
	if not bool(decision.get("speak", false)):
		return
	proactive_spoken_count += 1
	proactive_last_spoken_at = 0.0
	show_message(str(decision.get("text", "")), 6.0)
	add_analysis_step("她主动开口", str(decision.get("reason", "")))

# 最近一次非归档、有用户消息的会话距今多久；没有可用记录时返回 seconds = -1。
func last_conversation_span() -> Dictionary:
	if not soul_store:
		return {"seconds": -1.0, "title": ""}
	var newest: Dictionary = {}
	for value in soul_store.list_conversations(80):
		if value is Dictionary and not bool(value.get("archived", false)) and int(value.get("message_count", 0)) > 0:
			newest = value
			break
	if newest.is_empty():
		return {"seconds": -1.0, "title": ""}
	var updated := str(newest.get("updated_at", ""))
	if updated.is_empty():
		return {"seconds": -1.0, "title": ""}
	var zone: Dictionary = Time.get_time_zone_from_system()
	var seconds := ProactiveCompanion.elapsed_since_local_datetime(
		updated, Time.get_unix_time_from_system(), int(zone.get("bias", 0))
	)
	return {"seconds": seconds, "title": ""}

func update_window_mouse_passthrough() -> void:
	if not get_window():
		return
	# 聊天工作区拥有自己的原生窗口和面板命中区；桌宠主窗口不再承担聊天输入。
	# 审批/追问出现时让聊天窗口整块可点，保证所有操作都能收到。
	if chat_workspace_window and chat_workspace_window.visible and scene_input_dock and scene_input_dock.visible:
		var shape := full_window_input_shape() if is_harness_modal_visible() else workspace_input_shape()
		apply_native_window_input_shape(shape)
		get_window().mouse_passthrough_polygon = PackedVector2Array()
		get_window().mouse_passthrough = true
		return
	clear_native_window_input_shape()
	var local_mouse := Vector2(DisplayServer.mouse_get_position() - get_window().position)
	var inside_window := Rect2(Vector2.ZERO, Vector2(get_window().size)).has_point(local_mouse)
	# [DSH] 原来这里还要判 panel_layout_mode（面板正在被拖动时不穿透）。
	# 拆窗后拖动的是独立的原生窗口，桌宠主窗口不再参与，因此该条件已删除。
	var should_pass := inside_window and not window_pointer_held and not visible_content_hit_at(local_mouse)
	if should_pass == mouse_passthrough_active:
		return
	mouse_passthrough_active = should_pass
	# 只切换鼠标输入，不修改窗口形状、透明度或置顶状态。
	get_window().mouse_passthrough = should_pass

func visible_content_hit_at(local_mouse: Vector2) -> bool:
	for control in furniture_controls:
		if control and control.visible and control.get_global_rect().has_point(local_mouse):
			return true
	# [DSH] 气泡可能已被移进聊天窗口（见 position_status_bubble）。那时它的
	# get_global_rect() 是聊天窗口坐标系里的值，和这里的 local_mouse（主窗口坐标系）
	# 不可直接比较，因此只在气泡仍属于本窗口时才参与命中判断。
	if bubble and bubble.visible and bubble.get_parent() == self and bubble.get_global_rect().has_point(local_mouse):
		return true
	if not character or not character.visible:
		return false
	if dock_side != 0:
		var visible_width := minf(float(DOCK_VISIBLE_WIDTH), float(get_window().size.x))
		var visible_x := float(get_window().size.x) - visible_width if dock_side < 0 else 0.0
		return Rect2(visible_x, 82.0, visible_width, minf(390.0, float(get_window().size.y) - 82.0)).has_point(local_mouse)
	return character_hit_at(local_mouse)

func sprite_screen_rect(sprite: Sprite2D) -> Rect2:
	if not sprite or not sprite.texture:
		return Rect2()
	var displayed_size := sprite.texture.get_size() * sprite.scale.abs()
	return Rect2(sprite.global_position - displayed_size * 0.5, displayed_size)

func is_harness_modal_visible() -> bool:
	return bool((approval_panel and approval_panel.visible) or (question_panel and question_panel.visible))

func workspace_input_shape() -> PackedVector2Array:
	if not scene_input_dock or not analysis_panel:
		return full_window_input_shape()
	var chat_rect := Rect2(scene_input_dock.position, scene_input_dock.size)
	var analysis_rect := Rect2(analysis_panel.position, analysis_panel.size)
	var base_left := maxf(0.0, minf(chat_rect.position.x, analysis_rect.position.x) - WORKSPACE_INPUT_MARGIN)
	var base_top := maxf(0.0, minf(chat_rect.position.y, analysis_rect.position.y) - WORKSPACE_INPUT_MARGIN)
	var canvas_size := layout_canvas_size()
	var base_right := minf(canvas_size.x, maxf(chat_rect.end.x, analysis_rect.end.x) + WORKSPACE_INPUT_MARGIN)
	var base_bottom := minf(canvas_size.y, maxf(chat_rect.end.y, analysis_rect.end.y) + WORKSPACE_INPUT_MARGIN)
	# 不再保留人物的顶部命中区，空白处可直接点击后方应用。
	return PackedVector2Array([
		Vector2(base_left, base_top),
		Vector2(base_right, base_top),
		Vector2(base_right, base_bottom),
		Vector2(base_left, base_bottom)
	])

func full_window_input_shape() -> PackedVector2Array:
	var size_value := layout_canvas_size()
	return PackedVector2Array([
		Vector2.ZERO,
		Vector2(size_value.x, 0.0),
		size_value,
		Vector2(0.0, size_value.y)
	])

func apply_native_window_input_shape(shape: PackedVector2Array) -> void:
	if not chat_workspace_window:
		return
	if shape == active_window_input_shape:
		return
	active_window_input_shape = shape
	chat_workspace_window.mouse_passthrough_polygon = PackedVector2Array()
	chat_workspace_window.mouse_passthrough = false

func clear_native_window_input_shape() -> void:
	active_window_input_shape = PackedVector2Array()
	if chat_workspace_window:
		chat_workspace_window.mouse_passthrough_polygon = PackedVector2Array()

# [DSH] 表情层：让桌面上的她知道"现在在发生什么"。
#
# 动机：功能广度已经不是短板，"为什么愿意一直把她放在桌面上"才是。
# 授权卡 / 追问卡 / 失败这三种状态各自会持续数秒到数十秒，此前桌面上完全看不出来，
# 只能从聊天窗口的文字去读。这里把这三种状态映射成面部表情。
#
# 实现是安全的 UV 域变换（见 layered_character.gdshader），不修改几何，
# 因此不可能产生网格撕裂或空洞；关闭分层动态时整套逻辑自动失效。
# 只有当"沮丧"保持期结束、或又被新的沮丧刷新时才允许降级，
# 否则执行中的 chat_busy 会在同一帧把沮丧覆盖成专注。
# [DSH] 工作流「对话自动匹配」的接线。
#
# 数据源与手动运行完全一致（workflow_center.workflows + preview_run_context），
# 因此不存在"自动跑的环境和手动跑的不一样"这种偏差。
# 决策交给纯函数（见 workflow_auto_match.gd），这里只负责收集事实与启动。
func maybe_start_auto_workflow(query: String) -> bool:
	if not workflow_center or not workflow_runner:
		return false
	if workflow_runner.is_active():
		return false
	if not workflow_center.has_method("run_context"):
		return false
	var workflows: Array = []
	var raw = workflow_center.get("workflows")
	if raw is Array:
		workflows = raw
	var decision := WorkflowAutoMatch.decide(query, workflows, workflow_runner.is_active())
	if not bool(decision.get("run", false)):
		# 不命中时把原因留在 trace 里：否则用户会以为"配了自动匹配但没生效"却无从查起。
		var reason := str(decision.get("reason", ""))
		if not reason.is_empty():
			add_analysis_step("未触发自动工作流", reason)
		return false
	var workflow: Dictionary = decision.get("workflow", {})
	var context: Dictionary = workflow_center.call("run_context")
	context["input"] = query
	context["trigger_source"] = "conversation"
	var result = workflow_runner.start(workflow.duplicate(true), context.duplicate(true))
	if result is Dictionary and bool(result.get("ok", false)):
		add_analysis_step("按对话自动触发", str(decision.get("reason", "")))
		show_message("已按你的话自动开始工作流《%s》。" % str(workflow.get("name", "")), 4.5)
		on_workflow_run_changed()
		return true
	var failure := str(result.get("error", "工作流未能启动。")) if result is Dictionary else "执行器没有返回启动结果。"
	add_analysis_step("自动工作流未启动", failure)
	return false

# [DSH] 工作流「定时」触发的接线。
#
# 计划信息**单独存一个文件**，不写进 用户工作流.json：
# workflow_center.save_current_workflow() 保存时会重建字段集合
# （name/trigger/failure/enabled/confirmed/version/updated_at），
# 我若往里加字段会被**静默丢弃**——与界面配置里 proactive_enabled 那次是同一个坑。
const WORKFLOW_SCHEDULE_FILE := "工作流定时.json"
# 可视化图工作流完成时间配置、计划预览和显式授权前，后台调度保持关闭。
# 保留决策模块与旧计划文件只是为了兼容读取，不能静默执行。
const WORKFLOW_SCHEDULER_ENABLED := false

func workflow_schedule_path() -> String:
	if not soul_store or soul_store.root_path.is_empty():
		return ""
	return soul_store.root_path.path_join("配置").path_join(WORKFLOW_SCHEDULE_FILE)

func load_workflow_schedules() -> Array:
	var path := workflow_schedule_path()
	if path.is_empty() or not FileAccess.file_exists(path):
		return []
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not parsed is Dictionary:
		return []
	var items = parsed.get("schedules", [])
	return items if items is Array else []

func save_workflow_schedules(schedules: Array) -> bool:
	var path := workflow_schedule_path()
	if path.is_empty():
		return false
	DirAccess.make_dir_recursive_absolute(path.get_base_dir())
	return AtomicFile.write_text(path, JSON.stringify({"version": 1, "schedules": schedules}, "  "))

# 由 workflow_center 提供的当前工作流列表（与手动运行、自动匹配共用同一份数据）。
func workflow_definitions() -> Array:
	if not workflow_center:
		return []
	var raw = workflow_center.get("workflows")
	return raw if raw is Array else []

# 把配置里的工作流补进调度表：新的加进去（默认每天 09:00，不会立刻跑），
# 已被删除或已改触发方式的清掉。返回是否有变化。
func sync_workflow_schedules() -> bool:
	var definitions := workflow_definitions()
	if definitions.is_empty():
		return false
	var schedules := load_workflow_schedules()
	var by_name := {}
	for schedule in schedules:
		if schedule is Dictionary:
			by_name[str(schedule.get("name", ""))] = schedule
	var changed := false
	var kept: Array = []
	for definition in definitions:
		if not definition is Dictionary:
			continue
		var workflow: Dictionary = definition
		if str(workflow.get("trigger", "")) != WorkflowSchedule.TRIGGER_SCHEDULE:
			continue
		var name := str(workflow.get("name", "")).strip_edges()
		if name.is_empty():
			continue
		if by_name.has(name):
			kept.append(by_name[name])
		else:
			kept.append({
				"name": name,
				"mode": "每天",
				"time": "09:00",
				"every_minutes": 60,
				"last_run": 0.0,
				"last_day_key": ""
			})
			changed = true
	if kept.size() != schedules.size():
		changed = true
	if changed:
		save_workflow_schedules(kept)
	return changed

# 每 5 秒检查一次：到点的定时工作流自动执行。
func update_workflow_schedules(delta: float) -> void:
	if not WORKFLOW_SCHEDULER_ENABLED:
		return
	if not workflow_center or not workflow_runner:
		return
	schedule_check_clock += delta
	if schedule_check_clock < 5.0:
		return
	schedule_check_clock = 0.0
	sync_workflow_schedules()
	var schedules := load_workflow_schedules()
	if schedules.is_empty():
		return
	var definitions := workflow_definitions()
	var by_name := {}
	for definition in definitions:
		if definition is Dictionary:
			by_name[str(definition.get("name", ""))] = definition
	var now := {
		"unix": Time.get_unix_time_from_system(),
		"minute_of_day": WorkflowSchedule.minute_of_day_now(),
		"day_key": WorkflowSchedule.day_key_now()
	}
	var changed := false
	for index in schedules.size():
		var schedule: Dictionary = schedules[index]
		var name := str(schedule.get("name", ""))
		if not by_name.has(name):
			continue
		var probe := schedule.duplicate(true)
		probe["workflow"] = by_name[name]
		var decision := WorkflowSchedule.decide(probe, now)
		if not bool(decision.get("run", false)):
			continue
		# 已有任务在跑时不抢跑：这次不执行、也不记录时间，下一轮再判断。
		if workflow_runner.is_active() or chat_busy:
			continue
		if start_scheduled_workflow(by_name[name], str(decision.get("reason", ""))):
			# 只有真正启动成功才记录运行时刻，避免"启动失败也算跑过"而永远不再尝试。
			schedule["last_run"] = now["unix"]
			schedule["last_day_key"] = now["day_key"]
			schedules[index] = schedule
			changed = true
	if changed:
		save_workflow_schedules(schedules)

func start_scheduled_workflow(workflow: Dictionary, reason: String) -> bool:
	if not workflow_center or not workflow_runner:
		return false
	var context: Dictionary = workflow_center.call("run_context")
	context["input"] = str(workflow.get("name", ""))
	var result = workflow_runner.start(workflow.duplicate(true), context.duplicate(true))
	if result is Dictionary and bool(result.get("ok", false)):
		add_analysis_step("定时触发工作流", reason)
		show_message("定时任务《%s》已开始。" % str(workflow.get("name", "")), 6.0)
		notify_if_workspace_hidden()
		on_workflow_run_changed()
		return true
	var failure := str(result.get("error", "执行器没有返回启动结果。")) if result is Dictionary else "执行器没有返回启动结果。"
	add_analysis_step("定时工作流未启动", failure)
	return false

func is_expression_locked() -> bool:
	return harness_expression == EXPRESSION_DOWN and harness_expression_hold > 0.0

func set_harness_emotion(value: int) -> void:
	var wanted := clampi(value, EXPRESSION_CALM, EXPRESSION_DOWN)
	if wanted == EXPRESSION_DOWN:
		harness_expression_hold = EXPRESSION_DOWN_HOLD
	elif is_expression_locked():
		# 沮丧保持期内只接受同为沮丧的更新；其余请求在她平静下来后再生效。
		return
	if wanted == harness_expression:
		return
	harness_expression = wanted
	if layered_character:
		layered_character.set_emotion(wanted)

func update_harness_emotion(delta: float) -> void:
	if harness_expression == EXPRESSION_DOWN and harness_expression_hold > 0.0:
		harness_expression_hold = maxf(0.0, harness_expression_hold - maxf(0.0, delta))
		if harness_expression_hold <= 0.0:
			harness_expression = EXPRESSION_CALM
			if layered_character:
				layered_character.set_emotion(EXPRESSION_CALM)
	# 注意：这里**不能**每帧补发一次表情。
	# push_harness_emotion() 是"立即生效"路径，它会把 emotion_weight 直接设成目标值，
	# 于是 0.28 秒的淡入永远走不完（表情会变成硬切）。
	# 补发只在"分层装置重新接管显示"时做一次，见 sync_layered_character()。

func push_harness_emotion() -> void:
	if layered_character and layered_character.ready_for_use:
		layered_character.set_emotion(harness_expression, true)

func update_idle_face(delta: float) -> void:
	if not character_material or not blink_material:
		return
	var enabled := not action_playing and dock_side == 0 and not dragging
	character_material.set_shader_parameter("eye_effect", 1.0 if enabled else 0.0)
	blink_sprite.visible = enabled and not custom_outfit_active
	if not enabled:
		idle_gaze = idle_gaze.lerp(Vector2.ZERO, minf(1.0, delta * 10.0))
		blink_clock = 0.0
		blink_elapsed = -1.0
		character_material.set_shader_parameter("gaze", idle_gaze)
		blink_material.set_shader_parameter("blink", 0.0)
		return

	var face_screen := current_face_screen_position()
	var mouse_delta := Vector2(DisplayServer.mouse_get_position()) - face_screen
	var target_gaze := Vector2(
		clampf(mouse_delta.x / 620.0, -1.0, 1.0),
		clampf(mouse_delta.y / 480.0, -1.0, 1.0)
	)
	var gaze_smoothing: float = 1.0 - exp(-delta * 8.0)
	idle_gaze = idle_gaze.lerp(target_gaze, gaze_smoothing)
	character_material.set_shader_parameter("gaze", idle_gaze)

	var blink_value := 0.0
	if blink_elapsed >= 0.0:
		blink_elapsed += delta
		var progress: float = minf(1.0, blink_elapsed / BLINK_DURATION)
		# 快速合眼、极短停留、稍慢睁开；全程连续，避免一帧闪白。
		if progress < 0.38:
			blink_value = smoothstep(0.0, 1.0, progress / 0.38)
		elif progress < 0.48:
			blink_value = 1.0
		else:
			blink_value = 1.0 - smoothstep(0.0, 1.0, (progress - 0.48) / 0.52)
		if progress >= 1.0:
			blink_elapsed = -1.0
			blink_clock = 0.0
			blink_wait = randf_range(2.8, 5.8)
	else:
		blink_clock += delta
		if blink_clock >= blink_wait:
			blink_elapsed = 0.0
	blink_material.set_shader_parameter("blink", blink_value)

func configure_display_sync(force: bool) -> void:
	var screen := DisplayServer.window_get_current_screen()
	if not force and screen == active_screen:
		return
	active_screen = screen
	var detected := DisplayServer.screen_get_refresh_rate(screen)
	if detected <= 1.0:
		detected = 60.0
	display_refresh_rate = detected
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	Engine.max_fps = 0
	print("DISPLAY_REFRESH_RATE=", display_refresh_rate)

func update_action(delta: float) -> void:
	if not action_playing:
		update_dock_hold_breathe(delta)
		return
	if current_frames.is_empty():
		action_playing = false
		current_action = ""
		frame_index = 0
		frame_clock = 0.0
		push_warning("动作播放已安全终止：没有可用帧。")
		return
	frame_clock += delta
	while frame_clock >= current_frame_interval:
		frame_clock -= current_frame_interval
		frame_index += 1
		if frame_index >= current_frames.size():
			var finished_action := current_action
			action_playing = false
			frame_index = 0
			current_action = ""
			current_frames = []
			if finished_action == DOCK_ACTION and dock_side != 0 and action_library.has(DOCK_ACTION):
				var peek_frames: Array = action_library[DOCK_ACTION]["frames"]
				if not peek_frames.is_empty():
					character.position = dock_character_position()
					character_sprite.texture = peek_frames[min(PEEK_HOLD_FRAME, peek_frames.size() - 1)]
					dock_peek_holding = true
					# 保持状态的呼吸从零相位开始，避免接入瞬间跳到半个周期上。
					dock_hold_clock = 0.0
				else:
					push_warning("探头保持帧为空，恢复完整形象。")
					restore_normal_character()
			else:
				character.position = normal_character_position()
				character_sprite.scale = Vector2.ONE * normal_character_scale()
				blink_sprite.scale = Vector2.ONE * normal_character_scale()
				blink_sprite.visible = false
				character_sprite.flip_h = false
				character_sprite.texture = neutral_texture
			return
		if current_action == DOCK_ACTION:
			update_dock_micro_motion()
		character_sprite.texture = current_frames[frame_index]

func update_dock_micro_motion() -> void:
	# 使用整体位移制造 60 帧探身感，不再对五官和手指做像素形变插值。
	var progress := float(frame_index) / float(max(1, current_frames.size() - 1))
	var reach := sin(progress * PI)
	var inward := -1.0 if dock_side > 0 else 1.0
	var base := dock_character_position()
	character.position = base + Vector2(inward * PEEK_REACH_PIXELS * reach, -PEEK_LIFT_PIXELS * reach)

# [DSH] 停靠保持期间她也要活着。
# 帧序列播完后画面是**静止贴图**：探身停在最大幅度上，之后一动不动，
# 而那正是"她扒着屏幕边看你"的常态。这里给一点极轻的呼吸位移，
# 让停靠状态和站立时的分层动态在观感上属于同一个角色。
# 纯函数便于断言：幅度有上限、t=0 回到原点（否则停靠瞬间会跳一下）、相位连续。
func dock_hold_offset(elapsed: float, amplitude := PEEK_HOLD_BREATHE_PIXELS, period := PEEK_HOLD_BREATHE_SECONDS) -> Vector2:
	if period <= 0.0 or amplitude <= 0.0:
		return Vector2.ZERO
	var phase := fmod(maxf(elapsed, 0.0), period) / period
	return Vector2(0.0, -amplitude * sin(phase * TAU))

func update_dock_hold_breathe(delta: float) -> void:
	if not dock_peek_holding or dock_side == 0 or dragging:
		return
	dock_hold_clock += delta
	character.position = dock_character_position() + dock_hold_offset(dock_hold_clock)

func dock_character_position() -> Vector2:
	var compact_x := IDLE_CHARACTER_POSITION.x
	return Vector2(float(get_window().size.x) - compact_x if dock_side < 0 else compact_x, PEEK_COMPACT_POSITION_Y)

func normal_character_position() -> Vector2:
	if host_window_mode == "idle" and not scene_furniture_visible and not (scene_input_dock and scene_input_dock.visible):
		return IDLE_CHARACTER_POSITION
	if host_window_mode == "scene":
		return FURNITURE_CHARACTER_POSITION
	return AGENT_SCENE_POSITION

func normal_character_scale() -> float:
	return IDLE_CHARACTER_SCALE if host_window_mode == "idle" else AGENT_SCENE_SCALE

func _input(event: InputEvent) -> void:
	if (event is InputEventKey and event.pressed and not event.echo) or (event is InputEventMouseButton and event.pressed):
		note_user_activity()
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F8:
		toggle_window_grid()
		return
	# Ctrl+Alt+S 截图提问、Ctrl+Alt+L 唤起工作区（应用内快捷键，见 register_global_hotkeys）。
	if event is InputEventKey and event.pressed and not event.echo and event.ctrl_pressed and event.alt_pressed:
		if event.keycode == HOTKEY_SCREENSHOT:
			start_screenshot_capture()
			return
		if event.keycode == HOTKEY_SUMMON:
			summon_pet_workspace()
			return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		window_pointer_held = event.pressed
	if handle_panel_layout_input(event):
		return
	# 聊天工作台打开后，整个透明宿主窗口不能再响应“任意空白处拖动”。
	# 工作台只允许从标题栏拖动，否则点击按钮或透明区域会把整套窗口带跑。
	if scene_input_dock and scene_input_dock.visible:
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
			close_chat_workspace()
		return
	if agent_panel and agent_panel.visible and event is InputEventMouse:
		# 家具热区交给各自模型；其余区域仍可拖动，人物区域可唤起聊天。
		if not (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT):
			for control in scene_interactive_controls:
				if control.visible and control.get_global_rect().has_point(event.position):
					return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			pointer_down = true
			dragging = false
			press_screen = DisplayServer.mouse_get_position()
			press_window = get_window().position
		else:
			var release_screen := DisplayServer.mouse_get_position()
			if pointer_down and not dragging and Vector2(release_screen - press_screen).length() < DRAG_THRESHOLD:
				if dock_side != 0:
					restore_from_edge_dock()
				elif character_hit_at(event.position):
					open_scene_chat()
			pointer_down = false
			if dragging:
				try_edge_dock()
			dragging = false
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		var closed_overlay := false
		if scene_input_dock and scene_input_dock.visible:
			close_chat_workspace()
			closed_overlay = true
		if not closed_overlay:
			if event.shift_pressed:
				open_scene_context_menu()
			else:
				toggle_furniture_scene()
	elif event is InputEventMouseMotion and pointer_down:
		var now := DisplayServer.mouse_get_position()
		var offset := now - press_screen
		if Vector2(offset).length() >= DRAG_THRESHOLD:
			dragging = true
		if dragging:
			get_window().position = press_window + offset

# 独立聊天窗口拥有自己的 Viewport；这里接管该窗口中的拖动、面板调整和右键关闭，
# 避免事件再落回桌宠主画布。
func on_chat_workspace_window_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		window_pointer_held = event.pressed
	if handle_panel_layout_input(event):
		chat_workspace_window.set_input_as_handled()
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		close_chat_workspace()
		chat_workspace_window.set_input_as_handled()

func character_hit_at(local_position: Vector2) -> bool:
	if dock_side != 0:
		return true
	if host_window_mode == "idle":
		return Rect2(1, 6, 269, 510).has_point(local_position)
	if host_window_mode == "scene":
		return Rect2(360, 8, 280, 502).has_point(local_position)
	return Rect2(360, 190, 280, 545).has_point(local_position)

func build_bubble() -> void:
	bubble = PanelContainer.new()
	bubble.position = Vector2(284, 14)
	bubble.size = Vector2(432, 72)
	bubble.z_index = 38
	bubble.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.965, 0.985, 1.0, 0.97)
	style.border_color = Color("75bdf2")
	style.set_border_width_all(2)
	style.set_corner_radius_all(22)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	bubble.add_theme_stylebox_override("panel", style)
	add_child(bubble)
	# 文字放进一个不参与容器最小尺寸计算的内容层。否则首次显示时，
	# 自动换行标签可能在宽度尚未稳定前把 PanelContainer 撑成大面板。
	var bubble_content := Control.new()
	bubble_content.name = "BubbleContent"
	bubble_content.custom_minimum_size = Vector2.ZERO
	bubble_content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bubble.add_child(bubble_content)
	bubble_text = Label.new()
	bubble_text.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bubble_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bubble_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bubble_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	bubble_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bubble_text.add_theme_color_override("font_color", Color("163f67"))
	bubble_text.add_theme_font_size_override("font_size", 17)
	bubble_content.add_child(bubble_text)
	bubble.visible = false

func build_agent_panel() -> void:
	# 场景中的家具是独立 Sprite2D 模型，不再由代码绘制或伪装成按钮。
	agent_scene_background = Node2D.new()
	agent_scene_background.name = "AgentSceneBackgroundModels"
	agent_scene_background.visible = false
	add_child(agent_scene_background)
	move_child(agent_scene_background, character.get_index())
	cabinet_model = Sprite2D.new()
	cabinet_model.name = "MemoryCabinetModel"
	cabinet_model.texture = load(CABINET_MODEL_TEXTURE)
	cabinet_model.position = CABINET_MODEL_POSITION
	cabinet_model.scale = Vector2.ONE * CABINET_MODEL_SCALE
	agent_scene_background.add_child(cabinet_model)

	agent_panel = SoulAgentScene.new()
	agent_panel.position = Vector2.ZERO
	agent_panel.size = Vector2(WORKSPACE_WINDOW_SIZE)
	agent_panel.visible = true
	add_child(agent_panel)
	desk_model = Sprite2D.new()
	desk_model.name = "StudyDeskModel"
	desk_model.texture = load(DESK_MODEL_TEXTURE)
	desk_model.position = DESK_MODEL_POSITION
	desk_model.scale = Vector2.ONE * DESK_MODEL_SCALE
	desk_model.visible = false
	agent_panel.add_child(desk_model)

	# 隐形热区只负责命中；用户看到和操作的是书桌、书本、抽屉与柜子模型本身。
	agent_panel.add_child(make_scene_hotspot(
		DESK_NETWORK_HOTSPOT,
		"鲸羽笔 · 网络与代理配置",
		toggle_network_settings,
		desk_model,
		DESK_MODEL_SCALE
	))
	# 书桌右上方的书本/设备组合直接进入规则中心。
	agent_panel.add_child(make_scene_hotspot(
		DESK_RULE_CENTER_HOTSPOT,
		"打开规则中心",
		open_rule_center_from_workbench,
		desk_model,
		DESK_MODEL_SCALE,
		"DeskRuleCenterHotspot"
	))
	# 柜子左右门分别承担“记忆”和“技能”。两个区域共享同一个柜体模型，
	# 但悬停提示和点击行为独立，用户不必进入二级菜单。
	agent_panel.add_child(make_scene_hotspot(
		Rect2(749, 50, 112, 300),
		"记忆柜左门 · 打开本地记忆",
		open_memory_folder,
		cabinet_model,
		CABINET_MODEL_SCALE
	))
	agent_panel.add_child(make_scene_hotspot(
		Rect2(861, 50, 117, 300),
		"记忆柜右门 · 打开技能库",
		toggle_skill_library,
		cabinet_model,
		CABINET_MODEL_SCALE
	))
	agent_panel.add_child(make_scene_hotspot(
		CABINET_OUTFIT_HOTSPOT,
		"衣柜下层 · 人物换装",
		open_outfit_from_cabinet,
		cabinet_model,
		CABINET_MODEL_SCALE,
		"CabinetOutfitHotspot"
	))
	agent_panel.add_child(make_scene_hotspot(
		DESK_EXECUTION_HOTSPOT,
		"执行框架中心 · 配置 Harness",
		toggle_execution_framework_settings,
		desk_model,
		DESK_MODEL_SCALE
	))
	agent_panel.add_child(make_scene_hotspot(
		DESK_LAMP_HOTSPOT,
		"鲸鱼台灯 · 模型配置",
		toggle_api_settings,
		desk_model,
		DESK_MODEL_SCALE
	))
	agent_panel.add_child(make_scene_hotspot(
		DESK_KNOWLEDGE_HOTSPOT,
		"竖排资料书 · 导入本地知识资料",
		toggle_knowledge_import_panel,
		desk_model,
		DESK_MODEL_SCALE
	))
	# 书桌中央摊开的书本直接进入工作流中心；与左侧知识导入区完全分离。
	agent_panel.add_child(make_scene_hotspot(
		DESK_WORKFLOW_HOTSPOT,
		"打开工作流中心",
		open_workflow_center_from_workbench,
		desk_model,
		DESK_MODEL_SCALE,
		"DeskWorkflowCenterHotspot"
	))
	agent_panel.add_child(make_scene_hotspot(
		DESK_INBOX_HOTSPOT,
		"资料抽屉 · 点击打开投喂箱",
		open_soul_inbox,
		desk_model,
		DESK_MODEL_SCALE
	))
	agent_panel.add_child(make_scene_hotspot(
		DESK_SOUL_ROOT_HOTSPOT,
		"本地档案门 · 点击打开灵魂仓库",
		open_soul_root,
		desk_model,
		DESK_MODEL_SCALE
	))

	agent_status = Label.new()
	agent_status.position = Vector2(92, 254)
	agent_status.size = Vector2(197, 27)
	agent_status.text = "本地灵魂仓库"
	agent_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	agent_status.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	agent_status.add_theme_color_override("font_color", Color("bdeeff"))
	agent_status.add_theme_font_size_override("font_size", 9)
	agent_status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	agent_status.visible = false
	agent_panel.add_child(agent_status)
	agent_hint = Label.new()
	agent_hint.visible = false
	agent_hint.text = "聊天保存在本地 · 可以说“记住：……”"
	agent_panel.add_child(agent_hint)

	build_chat_workspace()
	build_knowledge_import_panel()
	build_api_settings_panel()
	build_execution_framework_settings_panel()
	build_network_settings_panel()
	build_skill_library_panel()
	# Local folders open in Windows Explorer.
	initialize_rule_and_workflow_centers()
	build_interaction_hint()
	set_furniture_visible(false)
	update_soul_status()

func build_history_sidebar(parent: HBoxContainer) -> void:
	chat_history_panel = PanelContainer.new()
	chat_history_panel.name = "LocalConversationHistory"
	chat_history_panel.custom_minimum_size = Vector2(172, 0)
	chat_history_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var history_style := StyleBoxFlat.new()
	history_style.bg_color = Color(0.90, 0.96, 1.0, 0.82)
	history_style.border_color = Color("b8daef")
	history_style.set_border_width_all(1)
	history_style.set_corner_radius_all(14)
	history_style.content_margin_left = 9
	history_style.content_margin_right = 9
	history_style.content_margin_top = 10
	history_style.content_margin_bottom = 10
	chat_history_panel.add_theme_stylebox_override("panel", history_style)
	parent.add_child(chat_history_panel)
	var history_content := VBoxContainer.new()
	history_content.add_theme_constant_override("separation", 8)
	chat_history_panel.add_child(history_content)
	var history_title := Label.new()
	history_title.text = "历史会话"
	history_title.add_theme_color_override("font_color", Color("173f63"))
	history_title.add_theme_font_size_override("font_size", 15)
	history_content.add_child(history_title)
	chat_history_search = LineEdit.new()
	chat_history_search.placeholder_text = "搜索本机记录"
	chat_history_search.clear_button_enabled = true
	chat_history_search.custom_minimum_size = Vector2(0, 34)
	apply_settings_field_style(chat_history_search)
	chat_history_search.text_changed.connect(refresh_history_sidebar)
	history_content.add_child(chat_history_search)
	history_undo_row = HBoxContainer.new()
	history_undo_row.add_theme_constant_override("separation", 4)
	history_undo_row.hide()
	history_content.add_child(history_undo_row)
	history_undo_label = Label.new()
	history_undo_label.text = "已删除"
	history_undo_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	history_undo_label.add_theme_color_override("font_color", Color("6887a1"))
	history_undo_label.add_theme_font_size_override("font_size", 12)
	history_undo_row.add_child(history_undo_label)
	history_undo_button = Button.new()
	history_undo_button.text = "撤销"
	apply_settings_button_style(history_undo_button, false)
	history_undo_button.pressed.connect(undo_history_delete)
	history_undo_row.add_child(history_undo_button)
	# [DSH] 回收站清理入口：与"隐藏/归档/彻底删除"放在一起，用户不必去找文件目录。
	# 只清"已被彻底删除"的标记，隐藏标记保留（清掉会让隐藏的会话重新出现）。
	var recycle_row := HBoxContainer.new()
	recycle_row.add_theme_constant_override("separation", 4)
	history_content.add_child(recycle_row)
	history_recycle_label = Label.new()
	history_recycle_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	history_recycle_label.add_theme_color_override("font_color", Color("6887a1"))
	history_recycle_label.add_theme_font_size_override("font_size", 11)
	recycle_row.add_child(history_recycle_label)
	history_recycle_button = Button.new()
	history_recycle_button.text = "清理标记"
	history_recycle_button.tooltip_text = "删除“彻底删除”留下的回收标记；不会删除任何聊天内容。被“隐藏”的会话会因此重新出现。"
	apply_settings_button_style(history_recycle_button, false)
	history_recycle_button.add_theme_font_size_override("font_size", 11)
	history_recycle_button.pressed.connect(purge_recycle_markers_with_feedback)
	recycle_row.add_child(history_recycle_button)
	refresh_recycle_usage()
	build_erase_confirm_dialog(history_content)
	var history_scroll := ScrollContainer.new()
	history_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	history_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	history_content.add_child(history_scroll)
	chat_history_list = VBoxContainer.new()
	chat_history_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_history_list.add_theme_constant_override("separation", 5)
	history_scroll.add_child(chat_history_list)
	chat_history_empty = Label.new()
	chat_history_empty.text = "暂无本机会话"
	chat_history_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	chat_history_empty.add_theme_color_override("font_color", Color("7692aa"))
	chat_history_empty.add_theme_font_size_override("font_size", 12)
	chat_history_list.add_child(chat_history_empty)

func initialize_local_conversation_history() -> void:
	if not soul_store or not chat_transcript:
		return
	var conversations: Array = soul_store.list_conversations(80)
	if conversations.is_empty():
		soul_store.begin_conversation("新对话", current_workspace_path(), "")
		refresh_history_sidebar()
		return
	var latest: Dictionary = conversations[0] if conversations[0] is Dictionary else {}
	var latest_id := str(latest.get("id", ""))
	if latest_id.is_empty():
		return
	soul_store.select_conversation(latest_id)
	render_local_conversation(latest_id)
	refresh_history_sidebar()

func refresh_history_sidebar(search_text := "") -> void:
	if not chat_history_list or not soul_store:
		return
	history_delete_buttons.clear()
	for child in chat_history_list.get_children():
		chat_history_list.remove_child(child)
		child.queue_free()
	var conversations: Array = soul_store.list_conversations(200, search_text)
	if conversations.is_empty():
		chat_history_empty = Label.new()
		chat_history_empty.text = "没有匹配的本机会话" if not search_text.strip_edges().is_empty() else "暂无本机会话"
		chat_history_empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		chat_history_empty.add_theme_color_override("font_color", Color("7692aa"))
		chat_history_empty.add_theme_font_size_override("font_size", 12)
		chat_history_list.add_child(chat_history_empty)
		return
	# 归档会话单独成组排在最后：它们仍在磁盘上、仍可打开，只是不占据日常视野。
	var today := Time.get_date_string_from_system()
	var active_conversations: Array = []
	var archived_conversations: Array = []
	for conversation_value in conversations:
		if not conversation_value is Dictionary:
			continue
		if bool((conversation_value as Dictionary).get("archived", false)):
			archived_conversations.append(conversation_value)
		else:
			active_conversations.append(conversation_value)
	render_history_group("", active_conversations, today)
	if not archived_conversations.is_empty():
		render_history_group("已归档", archived_conversations, today, true)

func render_history_group(group_override: String, conversations: Array, today: String, archived := false) -> void:
	var last_group := "\u0000"
	for conversation_value in conversations:
		var conversation: Dictionary = conversation_value
		var updated_at := str(conversation.get("updated_at", ""))
		var date_key := updated_at.left(10)
		var group_name := group_override
		if group_name.is_empty():
			group_name = "今天" if date_key == today else (date_key if not date_key.is_empty() else "更早")
		if group_name != last_group:
			var group_label := Label.new()
			group_label.text = group_name
			group_label.add_theme_color_override("font_color", Color("6887a1"))
			group_label.add_theme_font_size_override("font_size", 11)
			chat_history_list.add_child(group_label)
			last_group = group_name
			# [DSH] 归档分组第一次出现时给一句说明：用户看到"已归档"但不知道意味着什么，
			# 容易误以为会话被删掉了。说明必须写清"没有被删、可以移出"。
			if archived and group_override == "已归档":
				var archived_hint := Label.new()
				archived_hint.text = "归档只是不在日常列表里显示；会话仍在磁盘上，可随时打开或移出归档。"
				archived_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
				archived_hint.add_theme_color_override("font_color", Color("8aa2b8"))
				archived_hint.add_theme_font_size_override("font_size", 10)
				chat_history_list.add_child(archived_hint)
		var conversation_id := str(conversation.get("id", ""))
		var history_row := HBoxContainer.new()
		history_row.add_theme_constant_override("separation", 4)
		history_row.set_meta("conversation_id", conversation_id)
		chat_history_list.add_child(history_row)
		var history_button := Button.new()
		history_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var title := str(conversation.get("title", "新对话"))
		history_button.text = ("〔归档〕%s" % title) if archived else title
		history_button.tooltip_text = "%s\n%s%s" % [
			title,
			str(conversation.get("workspace", "本地灵魂仓库")),
			"\n已归档：仍在磁盘上，可随时打开或移出归档。" if archived else ""
		]
		history_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		history_button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		history_button.custom_minimum_size = Vector2(0, 38)
		apply_settings_button_style(history_button, conversation_id == soul_store.session_id)
		history_button.pressed.connect(open_local_conversation.bind(conversation_id))
		history_row.add_child(history_button)
		# 逐个操作放进下拉菜单，避免"隐藏/归档/彻底删除"三个按钮挤占侧栏宽度。
		var menu_button := MenuButton.new()
		menu_button.text = "⋯"
		menu_button.flat = false
		menu_button.tooltip_text = "会话操作：隐藏、归档、彻底删除"
		menu_button.custom_minimum_size = Vector2(38, 38)
		apply_settings_button_style(menu_button, false)
		menu_button.add_theme_font_size_override("font_size", 13)
		var popup := menu_button.get_popup()
		popup.add_item("隐藏（可撤销）", 1)
		popup.add_item("移出归档" if archived else "归档", 2)
		popup.add_separator()
		popup.add_item("彻底删除（不可撤销）", 3)
		popup.id_pressed.connect(on_history_menu_selected.bind(conversation_id))
		menu_button.disabled = chat_busy
		history_row.add_child(menu_button)
		history_delete_buttons.append(menu_button)

func on_history_menu_selected(item_id: int, conversation_id: String) -> void:
	match item_id:
		1:
			delete_history_conversation(conversation_id)
		2:
			toggle_history_archive(conversation_id)
		3:
			request_erase_history_conversation(conversation_id)

# 彻底删除不可撤销，因此必须二次确认，并且把"与本机记录的关系"说清楚。
func build_erase_confirm_dialog(parent: Node) -> void:
	erase_confirm_dialog = ConfirmationDialog.new()
	erase_confirm_dialog.title = "彻底删除本机会话"
	erase_confirm_dialog.ok_button_text = "彻底删除"
	erase_confirm_dialog.cancel_button_text = "取消"
	erase_confirm_dialog.dialog_text = ""
	erase_confirm_dialog.min_size = Vector2i(460, 200)
	erase_confirm_dialog.confirmed.connect(confirm_erase_history_conversation)
	parent.add_child(erase_confirm_dialog)

func request_erase_history_conversation(conversation_id: String) -> void:
	if chat_busy or not soul_store or conversation_id.is_empty():
		return
	pending_erase_conversation_id = conversation_id
	var title := conversation_id
	for conversation_value in soul_store.list_conversations(200):
		if conversation_value is Dictionary and str(conversation_value.get("id", "")) == conversation_id:
			title = str(conversation_value.get("title", conversation_id))
			break
	erase_confirm_dialog.dialog_text = (
		"将把《%s》的聊天记录从这台电脑上真正删除，且无法撤销。\n\n"
		+ "会删除：本机聊天记录文件里的该会话内容。\n"
		+ "不会删除：长期记忆、已导入的知识库资料、已收藏的换装形象。\n\n"
		+ "如果只是想让它不出现在列表里，请改用“归档”或“隐藏”。"
	) % title
	NativeFilePicker.confirm(erase_confirm_dialog)

func confirm_erase_history_conversation() -> void:
	var conversation_id := pending_erase_conversation_id
	pending_erase_conversation_id = ""
	if conversation_id.is_empty() or not soul_store:
		return
	var was_current: bool = conversation_id == soul_store.session_id
	var result: Dictionary = soul_store.erase_conversation(conversation_id)
	if not bool(result.get("ok", false)):
		history_undo_label.text = "彻底删除失败"
		history_undo_label.tooltip_text = str(result.get("error", "无法彻底删除会话"))
		history_undo_row.show()
		history_undo_button.hide()
		return
	# 已彻底删除，不可能撤销：清掉撤销入口，避免给出错误承诺。
	last_deleted_conversation_id = ""
	history_undo_button.hide()
	history_undo_row.show()
	history_undo_label.text = "已彻底删除（不可撤销）"
	history_undo_label.tooltip_text = "已删除 %d 条记录，涉及 %d 个文件。" % [
		int(result.get("removed_records", 0)), int(result.get("erased_files", 0))
	]
	if was_current:
		if agent_bridge:
			agent_bridge.session_id = ""
			agent_bridge.last_event_seq = -1
			agent_bridge.announced_approvals.clear()
			agent_bridge.announced_questions.clear()
			agent_bridge.interactions_invalidated.emit("本机会话已彻底删除")
		soul_store.begin_conversation("新对话", current_workspace_path(), "")
		agent_input.clear()
		reset_chat_for_new_session("该会话已彻底删除，无法恢复。可以开始新对话。")
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")
	update_history_delete_controls()

# [DSH] 回收站用量与清理。
# 展示"回收标记"数量与占用，让用户知道这些文件的存在；清理只删标记，不动聊天内容。
func refresh_recycle_usage() -> void:
	if not history_recycle_label or not soul_store:
		return
	var usage: Dictionary = soul_store.recycle_usage()
	var markers := int(usage.get("markers", 0))
	var bytes := int(usage.get("bytes", 0))
	if markers == 0:
		history_recycle_label.text = "回收标记：无"
		history_recycle_button.disabled = true
		return
	history_recycle_label.text = "回收标记 %d 个 · %d KB" % [markers, maxi(1, int(bytes / 1024))]
	history_recycle_button.disabled = chat_busy

func purge_recycle_markers_with_feedback() -> void:
	if chat_busy or not soul_store:
		return
	var result: Dictionary = soul_store.purge_recycle_markers(true)
	history_undo_row.show()
	history_undo_button.hide()
	if bool(result.get("ok", false)):
		history_undo_label.text = str(result.get("message", "已清理回收标记。"))
		history_undo_label.tooltip_text = "只删除了标记文件；聊天内容没有任何改变。"
	else:
		history_undo_label.text = "清理失败"
		history_undo_label.tooltip_text = str(result.get("error", "无法清理回收标记"))
	refresh_recycle_usage()
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")

func toggle_history_archive(conversation_id: String) -> void:
	if chat_busy or not soul_store or conversation_id.is_empty():
		return
	var result: Dictionary
	if soul_store.is_conversation_archived(conversation_id):
		result = soul_store.unarchive_conversation(conversation_id)
	else:
		result = soul_store.archive_conversation(conversation_id)
	if bool(result.get("ok", false)):
		history_undo_row.hide()
	else:
		history_undo_label.text = "归档操作失败"
		history_undo_label.tooltip_text = str(result.get("error", "无法完成归档操作"))
		history_undo_button.hide()
		history_undo_row.show()
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")

func update_history_delete_controls() -> void:
	for button in history_delete_buttons:
		if is_instance_valid(button):
			button.disabled = chat_busy
	if history_undo_button:
		history_undo_button.disabled = chat_busy

func delete_history_conversation(conversation_id: String) -> void:
	if chat_busy or not soul_store or conversation_id.is_empty():
		return
	var was_current: bool = conversation_id == soul_store.session_id
	var result: Dictionary = soul_store.delete_conversation(conversation_id)
	if not bool(result.get("ok", false)):
		history_undo_label.text = "删除失败"
		history_undo_label.tooltip_text = str(result.get("error", "无法删除本机会话"))
		history_undo_row.show()
		history_undo_button.visible = not last_deleted_conversation_id.is_empty()
		return
	last_deleted_conversation_id = conversation_id
	# 明确区分"隐藏"与"彻底删除"：这条路径不碰磁盘上的记录，只说它从列表里消失，
	# 否则用户会以为数据已经销毁（真正销毁是菜单里的"彻底删除"）。
	history_undo_label.text = "已隐藏"
	history_undo_label.tooltip_text = "已从列表隐藏，本机记录仍然保留；点击撤销可恢复。若要真正删除请用菜单里的“彻底删除”。"
	history_undo_row.show()
	history_undo_button.show()
	if was_current:
		# Detach locally. A future task creates a fresh Harness session on demand.
		if agent_bridge:
			agent_bridge.session_id = ""
			agent_bridge.last_event_seq = -1
			agent_bridge.announced_approvals.clear()
			agent_bridge.announced_questions.clear()
			agent_bridge.interactions_invalidated.emit("本机会话已删除")
		soul_store.begin_conversation("新对话", current_workspace_path(), "")
		agent_input.clear()
		reset_chat_for_new_session("该会话已删除。可以开始新对话，也可以点击左侧“撤销”恢复。")
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")
	update_history_delete_controls()

func undo_history_delete() -> void:
	if chat_busy or not soul_store or last_deleted_conversation_id.is_empty():
		return
	var result: Dictionary = soul_store.restore_conversation(last_deleted_conversation_id)
	if not bool(result.get("ok", false)):
		history_undo_label.text = "恢复失败"
		history_undo_label.tooltip_text = str(result.get("error", "无法恢复会话"))
		return
	last_deleted_conversation_id = ""
	history_undo_row.hide()
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")

func open_local_conversation(conversation_id: String) -> void:
	if chat_busy or not soul_store or conversation_id.is_empty():
		return
	if not soul_store.select_conversation(conversation_id):
		return
	clear_chat_attachment()
	reset_chat_skill_selection()
	reset_analysis_trace()
	render_local_conversation(conversation_id)
	refresh_history_sidebar(chat_history_search.text if chat_history_search else "")
	if chat_execution_status:
		chat_execution_status.text = "已打开本机会话 · 执行时重新连接 Harness"
		chat_execution_status.add_theme_color_override("font_color", Color("5b7f9e"))
	if agent_input:
		agent_input.grab_focus()

func render_local_conversation(conversation_id: String) -> void:
	if not chat_transcript or not soul_store:
		return
	chat_transcript.clear()
	reset_model_reasoning()
	var records: Array = soul_store.load_conversation(conversation_id, 500)
	if records.is_empty():
		append_chat_message("assistant", "这是一个新的本机会话。你可以直接提问或交代任务。")
		return
	for record_value in records:
		if not record_value is Dictionary:
			continue
		var record: Dictionary = record_value
		append_chat_message(str(record.get("role", "assistant")), str(record.get("content", "")))
		if str(record.get("role", "")) == "assistant":
			var metadata: Dictionary = record.get("metadata", {}) if record.get("metadata", {}) is Dictionary else {}
			model_reasoning_text = str(metadata.get("reasoning", ""))
	if not model_reasoning_text.is_empty():
		analysis_reasoning.text = model_reasoning_text
	else:
		finish_model_reasoning()

func current_workspace_path() -> String:
	if agent_bridge and not agent_bridge.workspace_path.is_empty():
		return agent_bridge.workspace_path
	return soul_store.root_path if soul_store else ""

# 创建聊天专用原生窗口；只显示双栏面板，透明留白不拦截桌面输入。
func create_chat_workspace_window() -> void:
	if chat_workspace_window:
		return
	chat_workspace_window = Window.new()
	chat_workspace_window.name = "ChatWorkspaceWindow"
	chat_workspace_window.title = "梁鲸 · 对话"
	chat_workspace_window.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	chat_workspace_window.content_scale_size = Vector2i.ZERO
	chat_workspace_window.wrap_controls = false
	chat_workspace_window.borderless = true
	chat_workspace_window.transparent = true
	chat_workspace_window.always_on_top = window_topmost
	chat_workspace_window.unresizable = false
	chat_workspace_window.transient = false
	chat_workspace_window.exclusive = false
	chat_workspace_window.visible = false
	NativeWindows.configure(chat_workspace_window)
	# [DSH] 聊天窗也跟随全局界面缩放（configure() 之后收口，见 UI_SCALE_BASELINE）。
	apply_canvas_scale(chat_workspace_window)
	add_child(chat_workspace_window)
	chat_workspace_window.close_requested.connect(close_chat_from_titlebar)
	chat_workspace_window.size_changed.connect(on_chat_workspace_window_size_changed)
	chat_workspace_window.files_dropped.connect(on_chat_files_dropped)
	chat_workspace_window.window_input.connect(on_chat_workspace_window_input)

	var screen := get_window().current_screen
	var usable := DisplayServer.screen_get_usable_rect(screen)
	var safe_minimum := Vector2i(
		mini(320, usable.size.x),
		mini(240, usable.size.y)
	)
	var restored_size := Vector2i(
		mini(WORKSPACE_WINDOW_SIZE.x, usable.size.x),
		mini(WORKSPACE_WINDOW_SIZE.y, usable.size.y)
	)
	var restored_position := usable.position + (usable.size - restored_size) / 2
	if soul_store:
		var settings: Dictionary = soul_store.get_ui_settings()
		var saved_chat: Dictionary = settings.get("chat_window", {})
		var saved_size: Array = saved_chat.get("size", [])
		var saved_position: Array = saved_chat.get("position", [])
		if saved_size.size() >= 2:
			restored_size = Vector2i(
				clampi(int(saved_size[0]), safe_minimum.x, usable.size.x),
				clampi(int(saved_size[1]), safe_minimum.y, usable.size.y)
			)
		if saved_position.size() >= 2:
			restored_position = Vector2i(int(saved_position[0]), int(saved_position[1]))
	restored_position.x = clampi(restored_position.x, usable.position.x, usable.end.x - restored_size.x)
	restored_position.y = clampi(restored_position.y, usable.position.y, usable.end.y - restored_size.y)
	var restored_rect := safe_chat_windowed_rect(Rect2i(restored_position, restored_size), usable)
	restored_size = restored_rect.size
	restored_position = restored_rect.position
	# [DSH] 以上全部按逻辑像素算（配置里存的也是逻辑尺寸），只有写进窗口时才换算成
	# 物理尺寸；位置夹取要按物理尺寸做，否则窗口可能右侧/下侧探出可用区。
	var physical_size := scaled_size(restored_size)
	restored_position.x = clampi(restored_position.x, usable.position.x, maxi(usable.position.x, usable.end.x - physical_size.x))
	restored_position.y = clampi(restored_position.y, usable.position.y, maxi(usable.position.y, usable.end.y - physical_size.y))
	chat_workspace_window.min_size = scaled_size(safe_minimum)
	chat_workspace_window.size = physical_size
	chat_workspace_window.position = restored_position
	chat_windowed_size = physical_size
	chat_windowed_position = restored_position
	chat_last_observed_size = physical_size
	chat_last_observed_position = restored_position

	chat_workspace_root = Control.new()
	chat_workspace_root.name = "ChatWorkspaceRoot"
	chat_workspace_root.position = Vector2.ZERO
	chat_workspace_root.size = Vector2(restored_size)
	chat_workspace_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chat_workspace_window.add_child(chat_workspace_root)

func build_chat_workspace() -> void:
	create_chat_workspace_window()
	scene_input_dock = PanelContainer.new()
	scene_input_dock.name = "ChatWorkspace"
	scene_input_dock.position = Vector2(10, 220)
	scene_input_dock.size = Vector2(620, 510)
	scene_input_dock.visible = false
	scene_input_dock.z_index = 30
	var dock_style := StyleBoxFlat.new()
	dock_style.bg_color = Color(0.955, 0.982, 1.0, 0.985)
	dock_style.border_color = Color("62bdf2")
	dock_style.set_border_width_all(2)
	dock_style.set_corner_radius_all(22)
	dock_style.content_margin_left = 20
	dock_style.content_margin_right = 20
	dock_style.content_margin_top = 17
	dock_style.content_margin_bottom = 18
	dock_style.shadow_color = Color(0.03, 0.16, 0.34, 0.30)
	dock_style.shadow_size = 14
	scene_input_dock.add_theme_stylebox_override("panel", dock_style)
	chat_workspace_root.add_child(scene_input_dock)
	scene_interactive_controls.append(scene_input_dock)

	var workspace_row := HBoxContainer.new()
	workspace_row.add_theme_constant_override("separation", 14)
	scene_input_dock.add_child(workspace_row)
	build_history_sidebar(workspace_row)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	workspace_row.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "拖动对话窗口"
	header.gui_input.connect(on_main_titlebar_input)
	content.add_child(header)
	var title := Label.new()
	title.text = "梁鲸"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("173f63"))
	title.add_theme_font_size_override("font_size", 19)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var privacy := Label.new()
	privacy.text = "本地会话"
	privacy.add_theme_color_override("font_color", Color("5b7f9e"))
	privacy.add_theme_font_size_override("font_size", 11)
	privacy.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	privacy.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(privacy)
	var minimize_button := Button.new()
	minimize_button.text = "—"
	minimize_button.tooltip_text = "缩小到最近的屏幕侧边"
	minimize_button.custom_minimum_size = Vector2(38, 34)
	apply_settings_button_style(minimize_button, false)
	minimize_button.pressed.connect(minimize_chat_to_screen_edge)
	header.add_child(minimize_button)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(38, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_chat_from_titlebar)
	header.add_child(close_button)

	var session_bar := HBoxContainer.new()
	session_bar.add_theme_constant_override("separation", 8)
	content.add_child(session_bar)
	var new_conversation_button := Button.new()
	new_conversation_button.text = "＋ 新对话"
	new_conversation_button.tooltip_text = "新建一段独立会话"
	new_conversation_button.custom_minimum_size = Vector2(96, 34)
	apply_settings_button_style(new_conversation_button, false)
	new_conversation_button.pressed.connect(new_agent_conversation)
	session_bar.add_child(new_conversation_button)
	var harness_workspace_button := Button.new()
	harness_workspace_button.text = "Harness 工作区"
	harness_workspace_button.tooltip_text = "直接打开当前执行框架的高级工作区"
	harness_workspace_button.custom_minimum_size = Vector2(126, 34)
	harness_workspace_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_button_style(harness_workspace_button, false)
	harness_workspace_button.pressed.connect(open_harness_console)
	session_bar.add_child(harness_workspace_button)

	# 所有消息统一进入执行框架。用户在这里直接选择执行模型、推理等级，
	# 并决定图片先走独立视觉模型，还是把原图直接交给 Harness 当前模型。
	var execution_bar := HBoxContainer.new()
	execution_bar.add_theme_constant_override("separation", 8)
	content.add_child(execution_bar)
	chat_model_select = OptionButton.new()
	chat_model_select.tooltip_text = "选择本轮使用的执行模型；模型来源于台灯里的模型中心"
	chat_model_select.custom_minimum_size = Vector2(190, 34)
	apply_settings_field_style(chat_model_select)
	chat_model_select.item_selected.connect(on_chat_model_selected)
	execution_bar.add_child(chat_model_select)
	chat_reasoning_select = OptionButton.new()
	chat_reasoning_select.tooltip_text = "设置 DeepSeek Harness 的推理等级"
	chat_reasoning_select.custom_minimum_size = Vector2(112, 34)
	chat_reasoning_select.add_item("不推理", 0)
	chat_reasoning_select.set_item_metadata(0, "off")
	chat_reasoning_select.add_item("低推理", 1)
	chat_reasoning_select.set_item_metadata(1, "low")
	chat_reasoning_select.add_item("高推理", 2)
	chat_reasoning_select.set_item_metadata(2, "high")
	chat_reasoning_select.add_item("最高推理", 3)
	chat_reasoning_select.set_item_metadata(3, "max")
	apply_settings_field_style(chat_reasoning_select)
	chat_reasoning_select.item_selected.connect(on_chat_reasoning_selected)
	execution_bar.add_child(chat_reasoning_select)
	chat_external_vision_check = CheckButton.new()
	chat_external_vision_check.text = "外挂视觉"
	chat_external_vision_check.tooltip_text = "开启：先用模型中心配置的视觉模型识别，再交给 Harness\n关闭：原图直接交给 Harness 当前模型"
	chat_external_vision_check.custom_minimum_size = Vector2(108, 34)
	chat_external_vision_check.button_pressed = deepseek_config.is_external_vision_enabled() if deepseek_config else true
	for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
		chat_external_vision_check.add_theme_color_override(color_name, Color("274d70"))
	chat_external_vision_check.add_theme_color_override("font_disabled_color", Color("7b91a5"))
	chat_external_vision_check.add_theme_font_size_override("font_size", 12)
	chat_external_vision_check.toggled.connect(on_external_vision_toggled)
	execution_bar.add_child(chat_external_vision_check)
	chat_execution_status = Label.new()
	chat_execution_status.text = "统一处理 · 修改前仍需授权"
	chat_execution_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_execution_status.clip_text = true
	chat_execution_status.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	chat_execution_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	chat_execution_status.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	chat_execution_status.add_theme_font_size_override("font_size", 12)
	chat_execution_status.add_theme_color_override("font_color", Color("5b7f9e"))
	execution_bar.add_child(chat_execution_status)
	populate_chat_model_controls()

	chat_transcript = RichTextLabel.new()
	chat_transcript.custom_minimum_size = Vector2(0, 200)
	chat_transcript.size_flags_vertical = Control.SIZE_EXPAND_FILL
	chat_transcript.bbcode_enabled = true
	chat_transcript.fit_content = false
	chat_transcript.scroll_active = true
	chat_transcript.selection_enabled = true
	chat_transcript.context_menu_enabled = true
	chat_transcript.shortcut_keys_enabled = true
	chat_transcript.deselect_on_focus_loss_enabled = false
	chat_transcript.tooltip_text = "可拖动选择任意文字，Ctrl + C 复制"
	chat_transcript.add_theme_color_override("default_color", Color("274d70"))
	chat_transcript.add_theme_font_size_override("normal_font_size", 14)
	configure_chat_text_fonts(chat_transcript, 14)
	var transcript_style := StyleBoxFlat.new()
	transcript_style.bg_color = Color(1, 1, 1, 0.72)
	transcript_style.border_color = Color("c8deed")
	transcript_style.set_border_width_all(1)
	transcript_style.set_corner_radius_all(14)
	transcript_style.content_margin_left = 14
	transcript_style.content_margin_right = 14
	transcript_style.content_margin_top = 12
	transcript_style.content_margin_bottom = 12
	chat_transcript.add_theme_stylebox_override("normal", transcript_style)
	content.add_child(chat_transcript)
	append_chat_message("assistant", "我在呢。你可以直接提问，也可以带一份文件一起问我。")

	var attachment_bar := HBoxContainer.new()
	attachment_bar.add_theme_constant_override("separation", 7)
	content.add_child(attachment_bar)
	chat_attachment_preview = TextureRect.new()
	chat_attachment_preview.custom_minimum_size = Vector2(48, 38)
	chat_attachment_preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	chat_attachment_preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	chat_attachment_preview.visible = false
	attachment_bar.add_child(chat_attachment_preview)
	chat_attachment_label = Label.new()
	chat_attachment_label.text = "未添加附件"
	chat_attachment_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_attachment_label.clip_text = true
	chat_attachment_label.add_theme_color_override("font_color", Color("67849d"))
	chat_attachment_label.add_theme_font_size_override("font_size", 12)
	chat_attachment_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	attachment_bar.add_child(chat_attachment_label)
	chat_archive_button = Button.new()
	chat_archive_button.text = "归档到知识库"
	chat_archive_button.visible = false
	chat_archive_button.custom_minimum_size = Vector2(110, 32)
	apply_settings_button_style(chat_archive_button, true)
	chat_archive_button.pressed.connect(archive_chat_attachment)
	attachment_bar.add_child(chat_archive_button)
	chat_remove_attachment_button = Button.new()
	chat_remove_attachment_button.text = "移除"
	chat_remove_attachment_button.visible = false
	chat_remove_attachment_button.custom_minimum_size = Vector2(58, 32)
	apply_settings_button_style(chat_remove_attachment_button, false)
	chat_remove_attachment_button.pressed.connect(clear_chat_attachment)
	attachment_bar.add_child(chat_remove_attachment_button)

	agent_input = TextEdit.new()
	agent_input.placeholder_text = "输入问题……  Enter 发送 · Shift + Enter 换行 · 文件可直接拖到这里"
	agent_input.custom_minimum_size = Vector2(0, 70)
	agent_input.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	agent_input.add_theme_font_size_override("font_size", 14)
	apply_settings_field_style(agent_input)
	agent_input.gui_input.connect(on_chat_input_gui)
	content.add_child(agent_input)
	# [DSH] 待发送队列状态条：执行期间你还能继续输入，这里显示已排了几条。
	# 它必须显眼且能撤销——排队最容易手滑多发一条，而排错的那条会在当前任务结束后
	# 真的发出去（花的是你的模型费用），所以"撤销最后一条"是一等公民。
	pending_queue_bar = HBoxContainer.new()
	pending_queue_bar.add_theme_constant_override("separation", 8)
	pending_queue_bar.visible = false
	content.add_child(pending_queue_bar)
	pending_queue_label = Label.new()
	pending_queue_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pending_queue_label.clip_text = true
	pending_queue_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	pending_queue_label.add_theme_color_override("font_color", Color("d88727"))
	pending_queue_label.add_theme_font_size_override("font_size", 12)
	pending_queue_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	pending_queue_bar.add_child(pending_queue_label)
	pending_queue_undo_button = Button.new()
	pending_queue_undo_button.text = "撤销排队"
	pending_queue_undo_button.custom_minimum_size = Vector2(92, 30)
	pending_queue_undo_button.tooltip_text = "把最后一条排队的消息撤回来（不会发给模型）"
	apply_settings_button_style(pending_queue_undo_button, false)
	pending_queue_undo_button.pressed.connect(undo_last_queued_message)
	pending_queue_bar.add_child(pending_queue_undo_button)
	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 8)
	content.add_child(action_row)
	var attach := Button.new()
	attach.text = "＋ 文件"
	attach.tooltip_text = "选择文件，或把文件直接拖到输入框"
	attach.custom_minimum_size = Vector2(82, 40)
	apply_settings_button_style(attach, false)
	attach.pressed.connect(choose_chat_attachment)
	action_row.add_child(attach)
	# 技能是本轮对话的上下文选择，入口紧邻附件；完整管理仍打开独立原生窗口，
	# 不把技能库面板塞进人物主体画布。
	chat_skill_menu = MenuButton.new()
	chat_skill_menu.text = "技能 · 自动"
	chat_skill_menu.tooltip_text = "选择本轮技能；完整管理会打开独立技能库窗口"
	chat_skill_menu.custom_minimum_size = Vector2(104, 40)
	# MenuButton 默认是 flat，会把 normal/hover/pressed 背景全部吃掉；关闭 flat
	# 后复用“添加文件”的白底、蓝边和圆角样式。
	chat_skill_menu.flat = false
	apply_settings_button_style(chat_skill_menu, false)
	chat_skill_menu.get_popup().about_to_popup.connect(refresh_chat_skill_menu)
	chat_skill_menu.get_popup().id_pressed.connect(on_chat_skill_menu_selected)
	action_row.add_child(chat_skill_menu)
	# 项目入口从顶部移到技能旁，缩短文字但保留完整路径提示，减少误触面积。
	chat_project_button = Button.new()
	chat_project_button.text = "项目 · 灵魂"
	chat_project_button.tooltip_text = "选择项目文件夹；当前为本地灵魂仓库"
	chat_project_button.custom_minimum_size = Vector2(98, 40)
	apply_settings_button_style(chat_project_button, false)
	chat_project_button.pressed.connect(choose_agent_project)
	action_row.add_child(chat_project_button)
	# 这是 Harness 原生 /permission 控制，不是仅改变界面文字。
	chat_permission_select = OptionButton.new()
	chat_permission_select.tooltip_text = "自动判断：只是问答就直接回答，需要操作电脑才交给 Harness\n受控写入：工作区外操作会请求审批\n完全访问：不再请求审批，请谨慎使用"
	chat_permission_select.custom_minimum_size = Vector2(106, 40)
	chat_permission_select.add_item("自动判断", 0)
	chat_permission_select.set_item_metadata(0, "auto")
	chat_permission_select.add_item("受控写入", 1)
	chat_permission_select.set_item_metadata(1, "workspace-write")
	chat_permission_select.add_item("完全访问", 2)
	chat_permission_select.set_item_metadata(2, "danger-full-access")
	apply_settings_field_style(chat_permission_select)
	chat_permission_select.item_selected.connect(on_chat_permission_selected)
	action_row.add_child(chat_permission_select)
	chat_plugin_button = Button.new()
	chat_plugin_button.text = "插件"
	chat_plugin_button.tooltip_text = "打开 Harness 插件配置与已加载插件清单"
	chat_plugin_button.custom_minimum_size = Vector2(68, 40)
	apply_settings_button_style(chat_plugin_button, false)
	chat_plugin_button.pressed.connect(open_harness_plugins)
	action_row.add_child(chat_plugin_button)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	action_row.add_child(spacer)
	# [DSH] 停止按钮：任务运行中才出现。这是"不设等待上限"的前提——
	# 任务可以跑任意久，但中止权必须在用户手里，语义与 Harness 自己的停止一致。
	chat_stop_button = Button.new()
	chat_stop_button.text = "停止"
	chat_stop_button.custom_minimum_size = Vector2(90, 40)
	chat_stop_button.tooltip_text = "中止当前正在执行的这一轮（已生成的内容会保留）"
	apply_settings_button_style(chat_stop_button, false)
	chat_stop_button.visible = false
	chat_stop_button.pressed.connect(stop_current_agent_turn)
	action_row.add_child(chat_stop_button)
	var send := Button.new()
	send.text = "发送"
	send.custom_minimum_size = Vector2(90, 40)
	apply_settings_button_style(send, true)
	send.pressed.connect(func(): submit_agent(agent_input.text))
	action_row.add_child(send)
	chat_resize_grip = Button.new()
	chat_resize_grip.text = "↘"
	chat_resize_grip.tooltip_text = "拖动调整整个软件窗口大小"
	chat_resize_grip.custom_minimum_size = Vector2(38, 40)
	chat_resize_grip.mouse_default_cursor_shape = Control.CURSOR_FDIAGSIZE
	apply_settings_button_style(chat_resize_grip, false)
	chat_resize_grip.gui_input.connect(on_native_resize_grip_input)
	action_row.add_child(chat_resize_grip)
	chat_resize_grip.hide()

	chat_attachment_dialog = FileDialog.new()
	chat_attachment_dialog.access = FileDialog.ACCESS_FILESYSTEM
	chat_attachment_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	# The independent Windows picker process never blocks the Godot event loop.
	chat_attachment_dialog.use_native_dialog = true
	chat_attachment_dialog.transient = false
	chat_attachment_dialog.exclusive = false
	chat_attachment_dialog.unresizable = false
	chat_attachment_dialog.min_size = Vector2i(720, 500)
	chat_attachment_dialog.filters = PackedStringArray(["*.* ; 所有文件"])
	chat_attachment_dialog.file_selected.connect(on_chat_attachment_selected)
	chat_attachment_dialog.canceled.connect(finish_native_file_dialog)
	# 原生文件框由主进程窗口托管，不能挂在独立聊天子窗口下；否则 Windows
	# 可能把选择框放到置顶聊天窗后面并锁住父窗，看起来像程序卡死。
	add_child(chat_attachment_dialog)
	# 项目目录不再使用 FileDialog。Windows 在多置顶窗口环境下关闭 FileDialog 后，
	# 偶尔会残留父窗口禁用状态，表现为“弹窗关了但主程序完全点不动”。这里改成
	# 梁鲸自己的非模态原生工具窗口，和模型中心一样与聊天窗彻底独立。
	# Project selection is handled by the Windows folder picker.
	build_analysis_panel()
	build_approval_panel()
	build_question_panel()

func build_approval_panel() -> void:
	approval_panel = PanelContainer.new()
	approval_panel.name = "HarnessApproval"
	approval_panel.size = Vector2(500, 280)
	approval_panel.visible = false
	approval_panel.z_index = 90
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.965, 0.985, 1.0, 0.995)
	style.border_color = Color("42aef0")
	style.set_border_width_all(2)
	style.set_corner_radius_all(20)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 20
	style.content_margin_bottom = 20
	style.shadow_color = Color(0.02, 0.12, 0.28, 0.38)
	style.shadow_size = 18
	approval_panel.add_theme_stylebox_override("panel", style)
	# 授权卡挂到聊天窗口根层，保证审批始终出现在用户当前操作的窗口中。
	chat_workspace_root.add_child(approval_panel)
	scene_interactive_controls.append(approval_panel)
	var content := VBoxContainer.new()
	# 先给自动换行文字一个确定宽度，否则 Godot 会按极窄宽度计算高度，
	# 把整张授权卡撑到窗口底部并将操作按钮挤出屏幕。
	content.custom_minimum_size = Vector2(452, 0)
	content.add_theme_constant_override("separation", 11)
	approval_panel.add_child(content)
	var title := Label.new()
	title.text = "需要你的授权"
	title.add_theme_font_size_override("font_size", 19)
	title.add_theme_color_override("font_color", Color("173f63"))
	content.add_child(title)
	var intro := Label.new()
	intro.text = "Harness 准备执行下面的操作。确认前不会继续。"
	intro.add_theme_font_size_override("font_size", 13)
	intro.add_theme_color_override("font_color", Color("5b7892"))
	content.add_child(intro)
	approval_tool_label = Label.new()
	approval_tool_label.add_theme_font_size_override("font_size", 17)
	approval_tool_label.add_theme_color_override("font_color", Color("155684"))
	content.add_child(approval_tool_label)
	approval_reason_label = Label.new()
	approval_reason_label.custom_minimum_size = Vector2(452, 84)
	approval_reason_label.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	approval_reason_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	approval_reason_label.add_theme_font_size_override("font_size", 14)
	approval_reason_label.add_theme_color_override("font_color", Color("274d70"))
	content.add_child(approval_reason_label)
	var actions := HBoxContainer.new()
	actions.custom_minimum_size = Vector2(452, 42)
	actions.alignment = BoxContainer.ALIGNMENT_END
	actions.add_theme_constant_override("separation", 10)
	content.add_child(actions)
	approval_reject_button = Button.new()
	approval_reject_button.text = "拒绝"
	approval_reject_button.custom_minimum_size = Vector2(96, 40)
	apply_settings_button_style(approval_reject_button, false)
	approval_reject_button.pressed.connect(func(): answer_current_approval(false))
	actions.add_child(approval_reject_button)
	approval_allow_button = Button.new()
	approval_allow_button.text = "仅本次允许"
	approval_allow_button.custom_minimum_size = Vector2(132, 40)
	apply_settings_button_style(approval_allow_button, true)
	approval_allow_button.pressed.connect(func(): answer_current_approval(true))
	actions.add_child(approval_allow_button)
	position_approval_panel()

func populate_chat_model_controls() -> void:
	if not chat_model_select or not deepseek_config:
		return
	var profile: Dictionary = deepseek_config.get_profile("chat")
	var configured := str(profile.get("model", DeepSeekConfigStore.DEFAULT_MODEL)).strip_edges()
	var model_ids: Array[String] = deepseek_config.get_model_candidates("chat")
	chat_model_select.clear()
	for model_id in model_ids:
		chat_model_select.add_item(model_id)
		chat_model_select.set_item_metadata(chat_model_select.item_count - 1, model_id)
	if chat_model_select.item_count == 0:
		chat_model_select.add_item(configured if not configured.is_empty() else "未配置模型")
		chat_model_select.set_item_metadata(0, configured)
	select_option_by_metadata(chat_model_select, configured)
	var effort := str(profile.get("reasoning_effort", "high" if bool(profile.get("thinking", false)) else "off"))
	select_option_by_metadata(chat_reasoning_select, effort)
	update_chat_model_status()

func selected_chat_model() -> String:
	if not chat_model_select or chat_model_select.selected < 0:
		return DeepSeekConfigStore.DEFAULT_MODEL
	return str(chat_model_select.get_item_metadata(chat_model_select.selected)).strip_edges()

func selected_chat_reasoning_effort() -> String:
	if not chat_reasoning_select or chat_reasoning_select.selected < 0:
		return "off"
	var effort := str(chat_reasoning_select.get_item_metadata(chat_reasoning_select.selected))
	return effort if effort in ["off", "low", "high", "max"] else "off"

func on_chat_model_selected(_index: int) -> void:
	persist_chat_runtime_selection()
	update_chat_model_status()
	sync_chat_profile_to_harness()
	add_analysis_step("执行模型已切换", selected_chat_model())

func on_chat_reasoning_selected(_index: int) -> void:
	persist_chat_runtime_selection()
	update_chat_model_status()
	sync_chat_profile_to_harness()
	add_analysis_step("推理等级已更新", chat_reasoning_label(selected_chat_reasoning_effort()))

func on_external_vision_toggled(enabled: bool) -> void:
	# 选择保存在本机模型配置中，重启程序后继续沿用；这里只改变媒体路由，
	# 不会绕过 Harness 的工具授权与审批流程。
	if deepseek_config:
		deepseek_config.save_external_vision_enabled(enabled)
	update_chat_model_status()
	add_analysis_step(
		"外挂视觉已%s" % ("开启" if enabled else "关闭"),
		"图片先交给已配置的视觉模型" if enabled else "原图将直接交给 Harness 当前模型"
	)

func persist_chat_runtime_selection() -> void:
	if deepseek_config:
		deepseek_config.save_chat_runtime_selection(selected_chat_model(), selected_chat_reasoning_effort())

func update_chat_model_status() -> void:
	if not chat_execution_status:
		return
	var vision_route := "外挂视觉" if is_external_vision_enabled() else "原生视觉"
	chat_execution_status.text = "%s · %s · 修改前需授权" % [
		chat_reasoning_label(selected_chat_reasoning_effort()),
		vision_route
	]
	chat_execution_status.add_theme_color_override("font_color", Color("2388c7"))

func is_external_vision_enabled() -> bool:
	if chat_external_vision_check:
		return chat_external_vision_check.button_pressed
	return deepseek_config.is_external_vision_enabled() if deepseek_config else true

func chat_reasoning_label(effort: String) -> String:
	match effort:
		"max":
			return "最高推理"
		"high":
			return "高推理"
		"low":
			return "低推理"
		_:
			return "不推理"

# 输入区只保留轻量选择器；“管理技能库”始终打开独立原生窗口。
func refresh_chat_skill_menu() -> void:
	if not chat_skill_menu:
		return
	var popup := chat_skill_menu.get_popup()
	popup.clear()
	popup.add_radio_check_item("自动匹配", 0)
	popup.set_item_checked(popup.item_count - 1, chat_skill_mode == "auto")
	popup.add_radio_check_item("本轮不使用技能", 1)
	popup.set_item_checked(popup.item_count - 1, chat_skill_mode == "none")
	popup.add_separator("手动指定")
	var available_count := 0
	if skill_registry:
		skill_registry.refresh()
		for skill in skill_registry.enabled_skills():
			if not bool(skill.get("allow_model_context", false)):
				continue
			var item_id := 100 + available_count
			popup.add_radio_check_item(str(skill.get("name", skill.get("id", "未命名技能"))), item_id)
			var item_index := popup.item_count - 1
			popup.set_item_metadata(item_index, str(skill.get("id", "")))
			popup.set_item_checked(item_index, chat_skill_mode == "manual" and chat_manual_skill_id == str(skill.get("id", "")))
			available_count += 1
	if available_count == 0:
		popup.add_item("没有已启用且已授权的技能", 50)
		popup.set_item_disabled(popup.item_count - 1, true)
	popup.add_separator()
	popup.add_item("管理技能库…", 9000)

func on_chat_skill_menu_selected(item_id: int) -> void:
	if item_id == 9000:
		toggle_skill_library()
		return
	if item_id == 0:
		chat_skill_mode = "auto"
		chat_manual_skill_id = ""
	elif item_id == 1:
		chat_skill_mode = "none"
		chat_manual_skill_id = ""
	elif item_id >= 100 and chat_skill_menu:
		var popup := chat_skill_menu.get_popup()
		var item_index := popup.get_item_index(item_id)
		if item_index >= 0:
			chat_skill_mode = "manual"
			chat_manual_skill_id = str(popup.get_item_metadata(item_index))
	update_chat_skill_button()
	add_analysis_step("技能调用方式已更新", chat_skill_menu.text if chat_skill_menu else "")

func update_chat_skill_button() -> void:
	if not chat_skill_menu:
		return
	match chat_skill_mode:
		"none":
			chat_skill_menu.text = "技能 · 关闭"
		"manual":
			var skill: Dictionary = skill_registry.get_skill(chat_manual_skill_id) if skill_registry else {}
			chat_skill_menu.text = "技能 · %s" % str(skill.get("name", "不可用"))
		_:
			chat_skill_menu.text = "技能 · 自动"

func reset_chat_skill_selection() -> void:
	chat_skill_mode = "auto"
	chat_manual_skill_id = ""
	update_chat_skill_button()

func resolve_chat_skill_context(query: String) -> Dictionary:
	if not skill_registry or chat_skill_mode == "none":
		return {"text": "", "count": 0, "names": [], "ids": [], "mode": chat_skill_mode}
	var result: Dictionary
	if chat_skill_mode == "manual":
		var selected_ids: Array[String] = [chat_manual_skill_id]
		result = skill_registry.build_task_context_for_ids(selected_ids)
	else:
		result = skill_registry.build_task_context(query)
	result["mode"] = chat_skill_mode
	return result

func selected_chat_permission_mode() -> String:
	if chat_permission_select and chat_permission_select.selected >= 0:
		return str(chat_permission_select.get_item_metadata(chat_permission_select.selected))
	return "auto"

func on_chat_permission_selected(_index: int) -> void:
	var preset := selected_chat_permission_mode()
	# 「自动判断」不是 Harness 的权限预设：它只决定本轮走哪条通道，
	# 真正的权限始终按受控写入应用，因此这里不需要下发 /permission。
	if preset == "auto":
		add_analysis_step("已切换为自动判断", "需要操作电脑时交给 Harness（受控写入）；只是问答就直接回答")
		return
	if preset == "danger-full-access":
		show_message("已选择完全访问：Harness 将不再弹出审批，请只在可信任务中使用。", 5.0)
	if not agent_bridge or not agent_bridge.core_ready:
		add_analysis_step("权限模式待同步", "Harness 就绪后会在发送任务前应用")
		return
	chat_permission_select.disabled = true
	var result: Dictionary = await agent_bridge.set_permission_preset(preset)
	chat_permission_select.disabled = false
	if bool(result.get("ok", false)):
		add_analysis_step("审批方式已更新", "受控写入 · 越界操作需要审批" if preset == "workspace-write" else "完全访问 · 不再弹出审批")
	else:
		add_analysis_step("审批方式更新失败", str(result.get("error", "未知错误")))

func open_harness_plugins() -> void:
	if not agent_bridge or not agent_bridge.core_ready:
		show_message("Harness 本地核心尚未就绪。", 3.0)
		return
	open_harness_workspace()
	show_message("已打开 Harness；点击左下角设置，进入“插件”即可管理。", 5.0)
	add_analysis_step("打开插件入口", "Harness 设置 · 插件")

func open_rule_center_from_workbench() -> void:
	# 规则编辑器拥有自己的非模态原生窗口；这里只负责从家具工作台跳转。
	if rule_center:
		rule_center.open()
	agent_event.emit({"type": "governance.open", "section": "rules", "source": "furniture_workbench"})

func open_workflow_center_from_workbench() -> void:
	# 工作流编辑器与工作台、桌宠和聊天窗口彼此独立，关闭不会锁住其他窗口。
	if workflow_center:
		workflow_center.open()
	agent_event.emit({"type": "governance.open", "section": "workflows", "source": "furniture_workbench"})

func decide_message_route(query: String) -> String:
	# 真正的分流判定在 task_router.gd 中，并且是可单独自检的纯函数。
	# 附件要求读取/识别时一律按“需要操作电脑”处理，因为解析结果还要继续交给 Harness。
	var actionable_attachment := TaskRouter.attachment_requires_action(chat_attachment_info)
	return TaskRouter.decide(query, actionable_attachment)

func position_approval_panel() -> void:
	if not approval_panel:
		return
	var canvas := layout_canvas_size()
	var safe_width := minf(500.0, maxf(360.0, canvas.x - 40.0))
	var safe_height := minf(320.0, maxf(280.0, canvas.y - 40.0))
	approval_panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	approval_panel.size = Vector2(safe_width, safe_height)
	approval_panel.position = Vector2(
		floor((canvas.x - safe_width) * 0.5),
		floor((canvas.y - safe_height) * 0.5)
	)

func build_question_panel() -> void:
	question_panel = PanelContainer.new()
	question_panel.name = "HarnessQuestion"
	question_panel.size = Vector2(560, 650)
	question_panel.visible = false
	question_panel.z_index = 91
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.965, 0.985, 1.0, 0.998)
	style.border_color = Color("42aef0")
	style.set_border_width_all(2)
	style.set_corner_radius_all(20)
	style.content_margin_left = 22
	style.content_margin_right = 22
	style.content_margin_top = 18
	style.content_margin_bottom = 18
	style.shadow_color = Color(0.02, 0.12, 0.28, 0.40)
	style.shadow_size = 18
	question_panel.add_theme_stylebox_override("panel", style)
	chat_workspace_root.add_child(question_panel)
	scene_interactive_controls.append(question_panel)
	var content := VBoxContainer.new()
	content.custom_minimum_size = Vector2(512, 0)
	content.add_theme_constant_override("separation", 9)
	question_panel.add_child(content)
	var title_row := HBoxContainer.new()
	content.add_child(title_row)
	var title := Label.new()
	title.text = "Harness 需要你确认"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_font_size_override("font_size", 19)
	title.add_theme_color_override("font_color", Color("173f63"))
	title_row.add_child(title)
	question_progress_label = Label.new()
	question_progress_label.add_theme_font_size_override("font_size", 13)
	question_progress_label.add_theme_color_override("font_color", Color("5b7892"))
	title_row.add_child(question_progress_label)
	var intro := Label.new()
	intro.text = "任务正在等待你的选择；提交后 Harness 才会继续。"
	intro.add_theme_font_size_override("font_size", 13)
	intro.add_theme_color_override("font_color", Color("5b7892"))
	content.add_child(intro)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 390)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(scroll)
	var question_body := VBoxContainer.new()
	question_body.custom_minimum_size = Vector2(500, 0)
	question_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	question_body.add_theme_constant_override("separation", 10)
	scroll.add_child(question_body)
	question_header_label = Label.new()
	question_header_label.add_theme_font_size_override("font_size", 14)
	question_header_label.add_theme_color_override("font_color", Color("2b91ce"))
	question_body.add_child(question_header_label)
	question_text_label = Label.new()
	question_text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	question_text_label.add_theme_font_size_override("font_size", 17)
	question_text_label.add_theme_color_override("font_color", Color("155684"))
	question_body.add_child(question_text_label)
	question_detail_label = Label.new()
	question_detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	question_detail_label.add_theme_font_size_override("font_size", 14)
	question_detail_label.add_theme_color_override("font_color", Color("365c7c"))
	question_body.add_child(question_detail_label)
	question_options_box = VBoxContainer.new()
	question_options_box.add_theme_constant_override("separation", 7)
	question_body.add_child(question_options_box)
	var custom_caption := Label.new()
	custom_caption.text = "补充说明 / 其他答案"
	custom_caption.add_theme_font_size_override("font_size", 13)
	custom_caption.add_theme_color_override("font_color", Color("5b7892"))
	question_body.add_child(custom_caption)
	question_custom_input = TextEdit.new()
	question_custom_input.custom_minimum_size = Vector2(0, 86)
	question_custom_input.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	question_custom_input.placeholder_text = "没有合适选项时可以直接输入；有选项时也可补充说明"
	question_custom_input.text_changed.connect(on_question_custom_text_changed)
	apply_settings_field_style(question_custom_input)
	question_body.add_child(question_custom_input)
	question_error_label = Label.new()
	question_error_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	question_error_label.add_theme_font_size_override("font_size", 12)
	question_error_label.add_theme_color_override("font_color", Color("b25050"))
	content.add_child(question_error_label)
	var actions := HBoxContainer.new()
	actions.custom_minimum_size = Vector2(512, 42)
	actions.add_theme_constant_override("separation", 9)
	content.add_child(actions)
	question_cancel_button = Button.new()
	question_cancel_button.text = "取消任务"
	question_cancel_button.custom_minimum_size = Vector2(108, 40)
	apply_settings_button_style(question_cancel_button, false)
	question_cancel_button.pressed.connect(cancel_current_question_request)
	actions.add_child(question_cancel_button)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(spacer)
	question_back_button = Button.new()
	question_back_button.text = "上一步"
	question_back_button.custom_minimum_size = Vector2(96, 40)
	apply_settings_button_style(question_back_button, false)
	question_back_button.pressed.connect(show_previous_question)
	actions.add_child(question_back_button)
	question_submit_button = Button.new()
	question_submit_button.text = "下一步"
	question_submit_button.custom_minimum_size = Vector2(112, 40)
	apply_settings_button_style(question_submit_button, true)
	question_submit_button.pressed.connect(continue_question_request)
	actions.add_child(question_submit_button)
	position_question_panel()

func show_next_question_request() -> void:
	if not current_question_request.is_empty() or not current_approval.is_empty() or not approval_queue.is_empty() or question_queue.is_empty() or not question_panel:
		return
	current_question_request = question_queue.pop_front()
	var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
	if questions.is_empty():
		current_question_request.clear()
		show_next_question_request()
		return
	current_question_drafts.clear()
	for _question in questions:
		current_question_drafts.append({"selected": [], "custom": ""})
	current_question_index = 0
	render_current_question()
	call_deferred("present_current_question")

func present_current_question() -> void:
	if dock_side != 0:
		dock_restore_chat_open = true
		restore_from_edge_dock()
	hide_all_utility_windows()
	if scene_input_dock and not scene_input_dock.visible:
		set_chat_workspace_visible(true)
		apply_responsive_chat_layout(true)
	question_panel.visible = true
	question_panel.move_to_front()
	position_question_panel()
	if chat_workspace_window:
		apply_native_window_input_shape(full_window_input_shape())
		chat_workspace_window.mouse_passthrough = false
		chat_workspace_window.grab_focus()

func render_current_question() -> void:
	if current_question_request.is_empty() or current_question_index < 0:
		return
	var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
	if current_question_index >= questions.size() or not questions[current_question_index] is Dictionary:
		return
	var question: Dictionary = questions[current_question_index]
	var draft: Dictionary = current_question_drafts[current_question_index]
	question_progress_label.text = "%d / %d" % [current_question_index + 1, questions.size()]
	question_header_label.text = str(question.get("header", "需要你的选择"))
	question_text_label.text = str(question.get("question", "请补充任务需要的信息"))
	question_detail_label.text = str(question.get("detail", ""))
	question_detail_label.visible = not question_detail_label.text.is_empty()
	for child in question_options_box.get_children():
		question_options_box.remove_child(child)
		child.queue_free()
	question_option_buttons.clear()
	var options: Array = question.get("options", []) if question.get("options", []) is Array else []
	var selected: Array = draft.get("selected", []) if draft.get("selected", []) is Array else []
	for option_value in options:
		if not option_value is Dictionary:
			continue
		var option: Dictionary = option_value
		var label := str(option.get("label", ""))
		if label.is_empty():
			continue
		var description := str(option.get("description", ""))
		var button := Button.new()
		button.text = label if description.is_empty() else "%s\n%s" % [label, description]
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.toggle_mode = true
		button.custom_minimum_size = Vector2(0, 52 if not description.is_empty() else 42)
		button.set_meta("option_label", label)
		button.set_pressed_no_signal(label in selected)
		apply_settings_button_style(button, label in selected)
		button.toggled.connect(on_question_option_toggled.bind(label))
		question_options_box.add_child(button)
		question_option_buttons.append(button)
	question_custom_input.set_block_signals(true)
	question_custom_input.text = str(draft.get("custom", ""))
	question_custom_input.set_block_signals(false)
	question_custom_input.placeholder_text = "输入回答" if options.is_empty() else "没有合适选项时，可以输入其他答案"
	question_error_label.text = ""
	question_back_button.visible = current_question_index > 0
	question_submit_button.text = "提交" if current_question_index == questions.size() - 1 else "下一步"
	question_submit_button.disabled = false
	question_cancel_button.disabled = false

func on_question_option_toggled(pressed: bool, label: String) -> void:
	if current_question_request.is_empty():
		return
	var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
	if current_question_index >= questions.size() or not questions[current_question_index] is Dictionary:
		return
	var question: Dictionary = questions[current_question_index]
	var draft: Dictionary = current_question_drafts[current_question_index]
	var selected: Array = (draft.get("selected", []) as Array).duplicate()
	if bool(question.get("multiSelect", false)):
		if pressed and label not in selected:
			selected.append(label)
		elif not pressed:
			selected.erase(label)
	else:
		selected = [label] if pressed else []
		if pressed:
			draft["custom"] = ""
			question_custom_input.set_block_signals(true)
			question_custom_input.text = ""
			question_custom_input.set_block_signals(false)
	for button in question_option_buttons:
		var is_selected := str(button.get_meta("option_label", "")) in selected
		button.set_pressed_no_signal(is_selected)
		apply_settings_button_style(button, is_selected)
	draft["selected"] = selected
	current_question_drafts[current_question_index] = draft
	question_error_label.text = ""

func on_question_custom_text_changed() -> void:
	if current_question_request.is_empty() or current_question_index >= current_question_drafts.size():
		return
	var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
	var draft: Dictionary = current_question_drafts[current_question_index]
	draft["custom"] = question_custom_input.text
	if current_question_index < questions.size() and questions[current_question_index] is Dictionary:
		var question: Dictionary = questions[current_question_index]
		if not bool(question.get("multiSelect", false)) and not question_custom_input.text.strip_edges().is_empty():
			draft["selected"] = []
			for button in question_option_buttons:
				button.set_pressed_no_signal(false)
				apply_settings_button_style(button, false)
	current_question_drafts[current_question_index] = draft
	question_error_label.text = ""

func show_previous_question() -> void:
	if current_question_index <= 0:
		return
	current_question_index -= 1
	render_current_question()

func continue_question_request() -> void:
	if current_question_request.is_empty() or current_question_index >= current_question_drafts.size():
		return
	var draft: Dictionary = current_question_drafts[current_question_index]
	var selected: Array = draft.get("selected", []) if draft.get("selected", []) is Array else []
	if selected.is_empty() and str(draft.get("custom", "")).strip_edges().is_empty():
		question_error_label.text = "请先选择一个选项或填写回答。"
		return
	var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
	if current_question_index < questions.size() - 1:
		current_question_index += 1
		render_current_question()
		return
	await submit_current_question_request(false)

func cancel_current_question_request() -> void:
	if current_question_request.is_empty():
		return
	await submit_current_question_request(true)

func submit_current_question_request(cancelled: bool) -> void:
	if current_question_request.is_empty() or not agent_bridge:
		return
	question_submit_button.disabled = true
	question_cancel_button.disabled = true
	question_back_button.disabled = true
	var answers: Array = []
	if not cancelled:
		var questions: Array = current_question_request.get("questions", []) if current_question_request.get("questions", []) is Array else []
		for index in range(questions.size()):
			if not questions[index] is Dictionary:
				continue
			var question: Dictionary = questions[index]
			var draft: Dictionary = current_question_drafts[index]
			var answer := {
				"id": str(question.get("id", "")),
				"selected": (draft.get("selected", []) as Array).duplicate()
			}
			var custom := str(draft.get("custom", "")).strip_edges()
			if not custom.is_empty():
				answer["custom"] = custom
			answers.append(answer)
	var request := current_question_request.duplicate(true)
	var result: Dictionary = await bridge_for_interaction(request).respond_question(request, answers, cancelled)
	if str(current_question_request.get("rpcId", "")) != str(request.get("rpcId", "")) or str(current_question_request.get("sessionId", "")) != str(request.get("sessionId", "")):
		return
	if not bool(result.get("ok", false)):
		question_submit_button.disabled = false
		question_cancel_button.disabled = false
		question_back_button.disabled = false
		question_error_label.text = "提交没有送达：%s" % str(result.get("error", "未知错误"))
		return
	current_question_request.clear()
	current_question_drafts.clear()
	question_panel.visible = false
	show_next_approval()
	show_next_question_request()

func position_question_panel() -> void:
	if not question_panel:
		return
	var canvas := layout_canvas_size()
	var safe_width := minf(560.0, maxf(390.0, canvas.x - 36.0))
	var safe_height := minf(650.0, maxf(520.0, canvas.y - 36.0))
	question_panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
	question_panel.size = Vector2(safe_width, safe_height)
	question_panel.position = Vector2(
		floor((canvas.x - safe_width) * 0.5),
		floor((canvas.y - safe_height) * 0.5)
	)

func build_analysis_panel() -> void:
	# [DSH] 2026-09-16 用户先要求合并成一个窗口，随后又要求改回独立窗口，这里还原。
	# 顶层拖动条不再重建：窗口有系统标题栏（NativeWindows.configure 会打开边框），
	# 自绘拖动条是重复的，用户也明确要求去掉那条。
	analysis_window = create_analysis_window()
	analysis_panel = PanelContainer.new()
	analysis_panel.name = "AnalysisTrace"
	analysis_panel.visible = false
	analysis_panel.z_index = 31
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.13, 0.29, 0.965)
	style.border_color = Color("54c7ff")
	style.set_border_width_all(2)
	style.set_corner_radius_all(22)
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 17
	style.content_margin_bottom = 18
	style.shadow_color = Color(0.05, 0.48, 0.92, 0.30)
	style.shadow_size = 15
	analysis_panel.add_theme_stylebox_override("panel", style)
	analysis_window.add_child(analysis_panel)
	scene_interactive_controls.append(analysis_panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 7)
	analysis_panel.add_child(content)
	# [DSH] 合并后这里原来有一条"解析过程 · 与对话同窗 + 复位"的顶栏，用户要求去掉：
	# 它正下方就是"解析过程"大标题，属于重复信息。改回独立窗口后同样不再重建——
	# 窗口有系统标题栏，拖动与缩放进出都由系统负责。
	var icon_center := CenterContainer.new()
	icon_center.custom_minimum_size = Vector2(0, 68)
	content.add_child(icon_center)
	analysis_orb = AnalysisOrb.new()
	icon_center.add_child(analysis_orb)
	var title := Label.new()
	title.text = "解析过程"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color("d6f5ff"))
	title.add_theme_font_size_override("font_size", 18)
	content.add_child(title)
	analysis_status = Label.new()
	analysis_status.text = "等待问题"
	analysis_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	analysis_status.add_theme_color_override("font_color", Color("79d6ff"))
	analysis_status.add_theme_font_size_override("font_size", 12)
	content.add_child(analysis_status)
	var line := HSeparator.new()
	line.add_theme_color_override("separator", Color(0.25, 0.70, 0.95, 0.35))
	content.add_child(line)
	var analysis_pages := HBoxContainer.new()
	var analysis_group := ButtonGroup.new()
	content.add_child(analysis_pages)
	analysis_steps_button = Button.new()
	analysis_steps_button.text = "处理步骤"
	analysis_reasoning_button = Button.new()
	analysis_reasoning_button.text = "模型思考"
	for page_button in [analysis_steps_button, analysis_reasoning_button]:
		page_button.toggle_mode = true
		page_button.button_group = analysis_group
		page_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		page_button.custom_minimum_size.y = 32
		apply_dark_panel_button_style(page_button)
		analysis_pages.add_child(page_button)
	analysis_steps_button.pressed.connect(show_analysis_page.bind(false))
	analysis_reasoning_button.pressed.connect(show_analysis_page.bind(true))
	analysis_trace = RichTextLabel.new()
	analysis_trace.custom_minimum_size = Vector2(0, 180)
	analysis_trace.size_flags_vertical = Control.SIZE_EXPAND_FILL
	analysis_trace.bbcode_enabled = false
	analysis_trace.scroll_active = true
	analysis_trace.add_theme_color_override("default_color", Color("b9d9eb"))
	analysis_trace.add_theme_font_size_override("normal_font_size", 13)
	configure_chat_text_fonts(analysis_trace, 13)
	var trace_style := StyleBoxFlat.new()
	trace_style.bg_color = Color(0.055, 0.19, 0.35, 0.58)
	trace_style.border_color = Color(0.25, 0.68, 0.92, 0.22)
	trace_style.set_border_width_all(1)
	trace_style.set_corner_radius_all(13)
	trace_style.content_margin_left = 13
	trace_style.content_margin_right = 13
	trace_style.content_margin_top = 12
	trace_style.content_margin_bottom = 12
	analysis_trace.add_theme_stylebox_override("normal", trace_style)
	content.add_child(analysis_trace)
	analysis_reasoning = RichTextLabel.new()
	analysis_reasoning.custom_minimum_size = Vector2(0, 180)
	analysis_reasoning.size_flags_vertical = Control.SIZE_EXPAND_FILL
	analysis_reasoning.bbcode_enabled = false
	analysis_reasoning.selection_enabled = true
	analysis_reasoning.context_menu_enabled = true
	analysis_reasoning.scroll_active = true
	analysis_reasoning.scroll_following = true
	analysis_reasoning.add_theme_color_override("default_color", Color("b9d9eb"))
	configure_chat_text_fonts(analysis_reasoning, 13)
	analysis_reasoning.add_theme_stylebox_override("normal", trace_style.duplicate())
	content.add_child(analysis_reasoning)
	# 对齐 Harness 浏览器底边的会话统计；使用真实会话事件计算，不改变原窗体尺寸。
	analysis_metrics = Label.new()
	analysis_metrics.text = "0 轮 · 0 步 · 等待会话统计"
	analysis_metrics.custom_minimum_size = Vector2(0, 40)
	analysis_metrics.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	analysis_metrics.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	analysis_metrics.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	analysis_metrics.add_theme_color_override("font_color", Color("86c9ec"))
	analysis_metrics.add_theme_font_size_override("font_size", 10)
	analysis_metrics.tooltip_text = "Harness 会话的轮次、步骤、模型/工具耗时、首字延迟、速度、缓存和输入量"
	content.add_child(analysis_metrics)
	var analysis_resize_row := HBoxContainer.new()
	content.add_child(analysis_resize_row)
	var analysis_resize_spacer := Control.new()
	analysis_resize_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	analysis_resize_row.add_child(analysis_resize_spacer)
	analysis_resize_grip = Button.new()
	analysis_resize_grip.text = "复位"
	analysis_resize_grip.tooltip_text = "把解析窗恢复默认大小并重新贴到对话窗右侧"
	analysis_resize_grip.custom_minimum_size = Vector2(64, 32)
	apply_dark_panel_button_style(analysis_resize_grip)
	# [DSH] 改回独立窗口后，复位重新作用于**窗口**（大小 + 贴回对话窗右侧）。
	analysis_resize_grip.pressed.connect(reset_analysis_window_layout)
	analysis_resize_row.add_child(analysis_resize_grip)
	reset_analysis_trace()
	# 面板内容建完之后才知道真实最小尺寸，此时把窗口最小尺寸与初始尺寸收敛到位，
	# 否则窗口可能比面板内容还小（实测面板最小高度 787 > 原本写死的 260）。
	analysis_window.size = scaled_size(DEFAULT_ANALYSIS_WINDOW_SIZE)
	sync_analysis_window_minimum()

func current_face_screen_position() -> Vector2:
	var profile := MotionProfile.defaults()
	if custom_outfit_active and layered_character:
		profile = layered_character.profile
	var face_uv := Vector2(0.5, float(profile["head_y"]))
	if bool(profile["eyes_enabled"]):
		face_uv = Vector2((float(profile["eye_left_x"]) + float(profile["eye_right_x"])) * 0.5, (float(profile["eye_left_y"]) + float(profile["eye_right_y"])) * 0.5)
	if character and character_sprite and neutral_texture:
		# [DSH] 窗口坐标是物理像素，角色坐标是逻辑像素：逻辑部分整体乘 ui_scale 才是屏幕位移。
		return Vector2(get_window().position) + (character.position + (face_uv - Vector2(0.5,0.5)) * neutral_texture.get_size() * character_sprite.scale) * ui_scale
	return Vector2(get_window().position) + FACE_SCREEN_OFFSET * ui_scale

# [DSH] 全局界面缩放的三个基础件。见 UI_SCALE_BASELINE 处的说明。
func compute_ui_scale() -> float:
	var usable := DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen())
	if usable.size.x <= 0 or usable.size.y <= 0:
		return 1.0
	var raw := minf(float(usable.size.x) / UI_SCALE_BASELINE.x, float(usable.size.y) / UI_SCALE_BASELINE.y)
	return clampf(raw, UI_SCALE_MIN, 1.0)

# 逻辑尺寸 → 物理窗口尺寸。ui_scale 为 1.0 时原样返回（不影响开发机行为）。
func scaled_size(logical: Vector2i) -> Vector2i:
	if is_equal_approx(ui_scale, 1.0):
		return logical
	return Vector2i(
		maxi(1, int(round(float(logical.x) * ui_scale))),
		maxi(1, int(round(float(logical.y) * ui_scale)))
	)

# 物理窗口尺寸 → 逻辑尺寸。存档一律按逻辑像素写盘，避免不同分辨率的机器
# 互相把对方的窗口尺寸读成"物理像素"，也避免同一台机器重启后反复缩小。
func logical_size(physical: Vector2i) -> Vector2i:
	if is_equal_approx(ui_scale, 1.0):
		return physical
	return Vector2i(
		maxi(1, int(round(float(physical.x) / ui_scale))),
		maxi(1, int(round(float(physical.y) / ui_scale)))
	)

func apply_canvas_scale(window: Window) -> void:
	if is_equal_approx(ui_scale, 1.0):
		return
	window.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	window.content_scale_factor = ui_scale

# 创建真正的原生工具窗口。它们与桌宠主窗口拥有各自的尺寸、位置和输入区域，
# 家具场景不会因为打开配置页而消失、缩放或被配置面板替换。
func create_utility_window(window_name: String, requested_size: Vector2i) -> Window:
	var utility_window := Window.new()
	utility_window.name = window_name
	utility_window.title = window_name
	# [DSH] 工具窗是固定尺寸窗：窗口本身按物理尺寸建，画布再按 ui_scale 反算回
	# 逻辑尺寸，所以下面所有面板的 position/size 依然写逻辑像素。
	var physical_size := scaled_size(requested_size)
	utility_window.size = physical_size
	utility_window.min_size = physical_size
	utility_window.max_size = physical_size
	# 工具窗口使用自己的 1:1 画布，避免继承桌宠主窗口在待机/家具/工作区
	# 三种尺寸之间切换时产生的 CanvasItems 拉伸。
	utility_window.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	utility_window.wrap_controls = false
	utility_window.borderless = true
	utility_window.transparent = true
	utility_window.always_on_top = true
	utility_window.unresizable = true
	utility_window.transient = false
	utility_window.exclusive = false
	utility_window.visible = false
	NativeWindows.configure(utility_window)
	# [DSH] configure() 会把 content_scale_mode 复位成 DISABLED、min_size 复位成
	# 320×240，所以缩放和固定尺寸必须在它之后收口。
	utility_window.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	apply_canvas_scale(utility_window)
	utility_window.min_size = physical_size
	utility_window.max_size = physical_size
	utility_window.size = physical_size
	add_child(utility_window)
	return utility_window

# 梁鲸自己的项目目录浏览器。它是独立、非 transient、非 exclusive 的 Window，
# 所以打开、放着不操作、直接关闭，都不会改变聊天窗口的可交互状态。
func build_project_picker_window() -> void:
	project_picker_window = create_utility_window("梁鲸 · 选择项目文件夹", PROJECT_PICKER_WINDOW_SIZE)
	# 项目浏览器单独保持不透明但无系统标题栏的稳定外壳；其他功能窗口维持原样。
	project_picker_window.transparent = false
	project_picker_window.borderless = true
	project_picker_window.unresizable = true
	project_picker_window.mode = Window.MODE_WINDOWED
	project_picker_window.always_on_top = true
	project_picker_window.close_requested.connect(close_project_picker)
	# 不透明窗口的默认清屏色是黑色。先铺满浅蓝底，避免圆角面板四周露出黑边。
	var window_background := ColorRect.new()
	window_background.name = "ProjectPickerBackground"
	window_background.position = Vector2.ZERO
	window_background.size = Vector2(PROJECT_PICKER_WINDOW_SIZE)
	window_background.color = Color(0.955, 0.982, 1.0, 1.0)
	window_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	project_picker_window.add_child(window_background)

	project_picker_panel = PanelContainer.new()
	project_picker_panel.name = "ProjectFolderPicker"
	project_picker_panel.position = Vector2.ZERO
	project_picker_panel.size = Vector2(PROJECT_PICKER_WINDOW_SIZE)
	project_picker_panel.visible = true
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.99)
	panel_style.border_color = Color("62bdf2")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(20)
	panel_style.content_margin_left = 22
	panel_style.content_margin_right = 22
	panel_style.content_margin_top = 18
	panel_style.content_margin_bottom = 18
	# 独立窗口自身已有清晰轮廓，不再绘制会被窗口边缘裁成黑边的外投影。
	panel_style.shadow_size = 0
	project_picker_panel.add_theme_stylebox_override("panel", panel_style)
	project_picker_window.add_child(project_picker_panel)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	project_picker_panel.add_child(content)

	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动项目窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(project_picker_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "●  选择项目文件夹"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title.add_theme_color_override("font_color", Color("173f63"))
	title.add_theme_font_size_override("font_size", 20)
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.tooltip_text = "关闭；不会影响主程序"
	close_button.custom_minimum_size = Vector2(40, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_project_picker)
	header.add_child(close_button)

	var hint := Label.new()
	hint.text = "选择一个文件夹作为 Harness 工作区。这个窗口完全独立，关闭后梁鲸仍可继续操作。"
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_color_override("font_color", Color("5b7f9e"))
	hint.add_theme_font_size_override("font_size", 13)
	content.add_child(hint)

	var quick_row := HBoxContainer.new()
	quick_row.add_theme_constant_override("separation", 8)
	content.add_child(quick_row)
	for quick_item in [
		["灵魂仓库", "soul"],
		["桌面", "desktop"],
		["文档", "documents"]
	]:
		var quick_button := Button.new()
		quick_button.text = str(quick_item[0])
		quick_button.custom_minimum_size = Vector2(108, 34)
		apply_settings_button_style(quick_button, false)
		quick_button.pressed.connect(open_project_picker_quick_path.bind(str(quick_item[1])))
		quick_row.add_child(quick_button)

	var path_row := HBoxContainer.new()
	path_row.add_theme_constant_override("separation", 8)
	content.add_child(path_row)
	var up_button := Button.new()
	up_button.text = "↑ 上级"
	up_button.custom_minimum_size = Vector2(82, 38)
	apply_settings_button_style(up_button, false)
	up_button.pressed.connect(project_picker_go_up)
	path_row.add_child(up_button)
	project_picker_path_input = LineEdit.new()
	project_picker_path_input.placeholder_text = "输入文件夹路径，例如 D:/项目"
	project_picker_path_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_picker_path_input.custom_minimum_size = Vector2(0, 38)
	apply_settings_field_style(project_picker_path_input)
	project_picker_path_input.text_submitted.connect(func(_text: String) -> void: project_picker_navigate(project_picker_path_input.text))
	path_row.add_child(project_picker_path_input)
	var go_button := Button.new()
	go_button.text = "前往"
	go_button.custom_minimum_size = Vector2(72, 38)
	apply_settings_button_style(go_button, false)
	go_button.pressed.connect(func() -> void: project_picker_navigate(project_picker_path_input.text))
	path_row.add_child(go_button)

	project_picker_folder_list = ItemList.new()
	project_picker_folder_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	# 为标题、路径、新建和确认区预留足够空间，低分辨率也不裁切底部按钮。
	project_picker_folder_list.custom_minimum_size = Vector2(0, 230)
	project_picker_folder_list.allow_reselect = true
	project_picker_folder_list.tooltip_text = "双击文件夹进入；底部按钮使用当前显示的文件夹"
	project_picker_folder_list.add_theme_font_size_override("font_size", 14)
	var list_style := StyleBoxFlat.new()
	list_style.bg_color = Color(1, 1, 1, 0.74)
	list_style.border_color = Color("c8deed")
	list_style.set_border_width_all(1)
	list_style.set_corner_radius_all(12)
	list_style.content_margin_left = 8
	list_style.content_margin_right = 8
	list_style.content_margin_top = 8
	list_style.content_margin_bottom = 8
	project_picker_folder_list.add_theme_stylebox_override("panel", list_style)
	project_picker_folder_list.item_activated.connect(on_project_picker_folder_activated)
	content.add_child(project_picker_folder_list)

	var create_row := HBoxContainer.new()
	create_row.add_theme_constant_override("separation", 8)
	content.add_child(create_row)
	project_picker_new_folder_input = LineEdit.new()
	project_picker_new_folder_input.placeholder_text = "新文件夹名称（可选）"
	project_picker_new_folder_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_picker_new_folder_input.custom_minimum_size = Vector2(0, 36)
	apply_settings_field_style(project_picker_new_folder_input)
	project_picker_new_folder_input.text_submitted.connect(func(_text: String) -> void: project_picker_create_folder())
	create_row.add_child(project_picker_new_folder_input)
	var create_button := Button.new()
	create_button.text = "新建文件夹"
	create_button.custom_minimum_size = Vector2(112, 36)
	apply_settings_button_style(create_button, false)
	create_button.pressed.connect(project_picker_create_folder)
	create_row.add_child(create_button)

	project_picker_status = Label.new()
	project_picker_status.text = "请选择项目文件夹"
	project_picker_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_picker_status.clip_text = true
	project_picker_status.add_theme_color_override("font_color", Color("397397"))
	project_picker_status.add_theme_font_size_override("font_size", 12)
	content.add_child(project_picker_status)

	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 8)
	content.add_child(action_row)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	action_row.add_child(spacer)
	var cancel_button := Button.new()
	cancel_button.text = "取消"
	cancel_button.custom_minimum_size = Vector2(92, 40)
	apply_settings_button_style(cancel_button, false)
	cancel_button.pressed.connect(close_project_picker)
	action_row.add_child(cancel_button)
	var confirm_button := Button.new()
	confirm_button.text = "使用当前文件夹"
	confirm_button.custom_minimum_size = Vector2(152, 40)
	apply_settings_button_style(confirm_button, true)
	confirm_button.pressed.connect(confirm_project_picker)
	action_row.add_child(confirm_button)
	apply_readable_typography(project_picker_panel)

func normalize_project_picker_path(path: String) -> String:
	var normalized := path.strip_edges().replace("\\", "/")
	if normalized.length() == 2 and normalized.substr(1, 1) == ":":
		normalized += "/"
	while normalized.length() > 3 and normalized.ends_with("/"):
		normalized = normalized.left(normalized.length() - 1)
	return normalized

func project_picker_default_path() -> String:
	if agent_bridge:
		var workspace := normalize_project_picker_path(str(agent_bridge.workspace_path))
		if not workspace.is_empty() and DirAccess.dir_exists_absolute(workspace):
			return workspace
	if soul_store:
		var soul_path := normalize_project_picker_path(str(soul_store.root_path))
		if not soul_path.is_empty() and DirAccess.dir_exists_absolute(soul_path):
			return soul_path
	var documents := normalize_project_picker_path(OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS))
	if DirAccess.dir_exists_absolute(documents):
		return documents
	return normalize_project_picker_path(OS.get_environment("USERPROFILE"))

func open_project_picker() -> void:
	if not agent_project_dialog:
		agent_project_dialog = FileDialog.new()
		agent_project_dialog.title = "选择项目文件夹"
		agent_project_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
		agent_project_dialog.access = FileDialog.ACCESS_FILESYSTEM
		add_child(agent_project_dialog)
		agent_project_dialog.dir_selected.connect(func(path: String):
			finish_native_file_dialog()
			on_agent_project_selected(path))
		agent_project_dialog.canceled.connect(finish_native_file_dialog)
	agent_project_dialog.current_dir = project_picker_default_path()
	popup_native_file_dialog(agent_project_dialog, 0.8)


func finalize_project_picker_show() -> void:
	if not project_picker_window or not project_picker_window.visible:
		return
	position_utility_window(project_picker_window)
	project_picker_window.grab_focus()
	DisplayServer.window_move_to_foreground(project_picker_window.get_window_id())
	print("PROJECT_PICKER_READY visible=", project_picker_window.visible, " position=", project_picker_window.position, " size=", project_picker_window.size)

func close_project_picker() -> void:
	if project_picker_window:
		project_picker_window.hide()
		print("PROJECT_PICKER_CLOSED")
	if chat_workspace_window and chat_workspace_window.visible:
		chat_workspace_window.grab_focus()
		DisplayServer.window_move_to_foreground(chat_workspace_window.get_window_id())

func open_project_picker_quick_path(kind: String) -> void:
	var target := ""
	match kind:
		"soul":
			if soul_store:
				target = str(soul_store.root_path)
		"desktop":
			target = OS.get_system_dir(OS.SYSTEM_DIR_DESKTOP)
		"documents":
			target = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	if not target.is_empty():
		project_picker_navigate(target)

func project_picker_navigate(path: String) -> void:
	var normalized := normalize_project_picker_path(path)
	if normalized.is_empty() or not DirAccess.dir_exists_absolute(normalized):
		if project_picker_status:
			project_picker_status.text = "找不到这个文件夹，请检查路径。"
			project_picker_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	project_picker_current_path = normalized
	project_picker_path_input.text = normalized
	project_picker_folder_list.clear()
	var folders := DirAccess.get_directories_at(normalized)
	folders.sort()
	for folder_name in folders:
		project_picker_folder_list.add_item("▸  %s" % str(folder_name))
		var index := project_picker_folder_list.item_count - 1
		project_picker_folder_list.set_item_metadata(index, normalize_project_picker_path(normalized.path_join(str(folder_name))))
	project_picker_status.text = "%d 个子文件夹 · 将使用：%s" % [folders.size(), normalized]
	project_picker_status.add_theme_color_override("font_color", Color("397397"))

func on_project_picker_folder_activated(index: int) -> void:
	if not project_picker_folder_list or index < 0 or index >= project_picker_folder_list.item_count:
		return
	project_picker_navigate(str(project_picker_folder_list.get_item_metadata(index)))

func project_picker_go_up() -> void:
	if project_picker_current_path.is_empty():
		return
	var parent := normalize_project_picker_path(project_picker_current_path.get_base_dir())
	if parent.is_empty() or parent == project_picker_current_path:
		return
	project_picker_navigate(parent)

func project_picker_create_folder() -> void:
	if not project_picker_new_folder_input or project_picker_current_path.is_empty():
		return
	var folder_name := project_picker_new_folder_input.text.strip_edges()
	if folder_name.is_empty():
		project_picker_status.text = "请先输入新文件夹名称。"
		project_picker_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	for invalid_character in ["<", ">", ":", "\"", "/", "\\", "|", "?", "*"]:
		if folder_name.contains(invalid_character):
			project_picker_status.text = "文件夹名称包含 Windows 不允许的字符。"
			project_picker_status.add_theme_color_override("font_color", Color("c64e59"))
			return
	var new_path := normalize_project_picker_path(project_picker_current_path.path_join(folder_name))
	var result := DirAccess.make_dir_absolute(new_path)
	if result != OK and result != ERR_ALREADY_EXISTS:
		project_picker_status.text = "新建失败：没有权限或路径不可用。"
		project_picker_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	project_picker_new_folder_input.clear()
	project_picker_navigate(new_path)

func confirm_project_picker() -> void:
	if project_picker_current_path.is_empty() or not DirAccess.dir_exists_absolute(project_picker_current_path):
		project_picker_status.text = "请先进入一个有效文件夹。"
		project_picker_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	var selected_path := project_picker_current_path
	close_project_picker()
	on_agent_project_selected(selected_path)

# 工作台的灵魂仓库、投喂箱、记忆与技能目录共用这一个梁鲸自建浏览器。
# 浏览文件夹始终在同一个窗口内完成，只有双击具体文件时才交给系统关联程序。
func build_local_file_browser_window() -> void:
	local_file_browser_window = create_utility_window("梁鲸 · 本地文件库", LOCAL_FILE_BROWSER_WINDOW_SIZE)
	local_file_browser_window.transparent = false
	local_file_browser_window.borderless = true
	local_file_browser_window.unresizable = true
	local_file_browser_window.mode = Window.MODE_WINDOWED
	local_file_browser_window.always_on_top = true
	local_file_browser_window.close_requested.connect(close_local_file_browser)

	var window_background := ColorRect.new()
	window_background.name = "LocalFileBrowserBackground"
	window_background.position = Vector2.ZERO
	window_background.size = Vector2(LOCAL_FILE_BROWSER_WINDOW_SIZE)
	window_background.color = Color(0.955, 0.982, 1.0, 1.0)
	window_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	local_file_browser_window.add_child(window_background)

	local_file_browser_panel = PanelContainer.new()
	local_file_browser_panel.name = "LocalFileBrowser"
	local_file_browser_panel.position = Vector2.ZERO
	local_file_browser_panel.size = Vector2(LOCAL_FILE_BROWSER_WINDOW_SIZE)
	local_file_browser_panel.visible = true
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.995)
	panel_style.border_color = Color("62bdf2")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(20)
	panel_style.content_margin_left = 22
	panel_style.content_margin_right = 22
	panel_style.content_margin_top = 18
	panel_style.content_margin_bottom = 18
	local_file_browser_panel.add_theme_stylebox_override("panel", panel_style)
	local_file_browser_window.add_child(local_file_browser_panel)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 10)
	local_file_browser_panel.add_child(content)

	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动本地文件库窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(local_file_browser_window))
	content.add_child(header)
	local_file_browser_title = Label.new()
	local_file_browser_title.text = "●  梁鲸本地文件库"
	local_file_browser_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	local_file_browser_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	local_file_browser_title.add_theme_color_override("font_color", Color("173f63"))
	local_file_browser_title.add_theme_font_size_override("font_size", 20)
	header.add_child(local_file_browser_title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.tooltip_text = "关闭"
	close_button.custom_minimum_size = Vector2(40, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_local_file_browser)
	header.add_child(close_button)

	var navigation_row := HBoxContainer.new()
	navigation_row.add_theme_constant_override("separation", 8)
	content.add_child(navigation_row)
	var back_button := Button.new()
	back_button.text = "←"
	back_button.tooltip_text = "后退"
	back_button.custom_minimum_size = Vector2(44, 38)
	apply_settings_button_style(back_button, false)
	back_button.pressed.connect(local_file_browser_go_back)
	navigation_row.add_child(back_button)
	var up_button := Button.new()
	up_button.text = "↑ 上级"
	up_button.custom_minimum_size = Vector2(82, 38)
	apply_settings_button_style(up_button, false)
	up_button.pressed.connect(local_file_browser_go_up)
	navigation_row.add_child(up_button)
	local_file_browser_path_input = LineEdit.new()
	local_file_browser_path_input.placeholder_text = "本地文件夹路径"
	local_file_browser_path_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	local_file_browser_path_input.custom_minimum_size = Vector2(0, 38)
	apply_settings_field_style(local_file_browser_path_input)
	local_file_browser_path_input.text_submitted.connect(func(_text: String) -> void: local_file_browser_navigate(local_file_browser_path_input.text))
	navigation_row.add_child(local_file_browser_path_input)
	var go_button := Button.new()
	go_button.text = "前往"
	go_button.custom_minimum_size = Vector2(72, 38)
	apply_settings_button_style(go_button, false)
	go_button.pressed.connect(func() -> void: local_file_browser_navigate(local_file_browser_path_input.text))
	navigation_row.add_child(go_button)
	var refresh_button := Button.new()
	refresh_button.text = "刷新"
	refresh_button.custom_minimum_size = Vector2(72, 38)
	apply_settings_button_style(refresh_button, false)
	refresh_button.pressed.connect(func() -> void: local_file_browser_navigate(local_file_browser_current_path, false))
	navigation_row.add_child(refresh_button)

	local_file_browser_list = ItemList.new()
	local_file_browser_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	# 给路径栏、底部状态和按钮留足空间，确保 680px 高度下完整显示。
	local_file_browser_list.custom_minimum_size = Vector2(0, 430)
	local_file_browser_list.allow_reselect = true
	local_file_browser_list.tooltip_text = "双击文件夹进入；双击文件用对应程序打开"
	local_file_browser_list.add_theme_font_size_override("font_size", 14)
	var list_style := StyleBoxFlat.new()
	list_style.bg_color = Color(1, 1, 1, 0.78)
	list_style.border_color = Color("c8deed")
	list_style.set_border_width_all(1)
	list_style.set_corner_radius_all(12)
	list_style.content_margin_left = 8
	list_style.content_margin_right = 8
	list_style.content_margin_top = 8
	list_style.content_margin_bottom = 8
	local_file_browser_list.add_theme_stylebox_override("panel", list_style)
	local_file_browser_list.item_selected.connect(on_local_file_browser_item_selected)
	local_file_browser_list.item_activated.connect(on_local_file_browser_item_activated)
	content.add_child(local_file_browser_list)

	var bottom_row := HBoxContainer.new()
	bottom_row.add_theme_constant_override("separation", 8)
	content.add_child(bottom_row)
	local_file_browser_status = Label.new()
	local_file_browser_status.text = "双击文件夹进入，双击文件打开"
	local_file_browser_status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	local_file_browser_status.clip_text = true
	local_file_browser_status.add_theme_color_override("font_color", Color("397397"))
	local_file_browser_status.add_theme_font_size_override("font_size", 12)
	bottom_row.add_child(local_file_browser_status)
	local_file_browser_open_button = Button.new()
	local_file_browser_open_button.text = "打开选中项"
	local_file_browser_open_button.custom_minimum_size = Vector2(126, 40)
	apply_settings_button_style(local_file_browser_open_button, true)
	local_file_browser_open_button.pressed.connect(open_local_file_browser_selection)
	bottom_row.add_child(local_file_browser_open_button)
	var close_bottom_button := Button.new()
	close_bottom_button.text = "关闭"
	close_bottom_button.custom_minimum_size = Vector2(82, 40)
	apply_settings_button_style(close_bottom_button, false)
	close_bottom_button.pressed.connect(close_local_file_browser)
	bottom_row.add_child(close_bottom_button)
	apply_readable_typography(local_file_browser_panel)

func open_local_file_browser(path: String, _section_title := "本地文件库") -> void:
	var normalized := normalize_project_picker_path(path)
	if DirAccess.dir_exists_absolute(normalized):
		OS.shell_open(normalized)
	else:
		show_message("本地目录不存在。", 3.0)


func select_local_file_with_browser(path: String, section_title: String, extensions: Array[String], callback: Callable) -> void:
	var dialog := FileDialog.new()
	dialog.title = section_title
	dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	dialog.access = FileDialog.ACCESS_FILESYSTEM
	add_child(dialog)
	if DirAccess.dir_exists_absolute(path):
		dialog.current_dir = path
	var patterns := PackedStringArray()
	for extension in extensions:
		patterns.append("*." + extension.trim_prefix("."))
	if not patterns.is_empty():
		dialog.filters = PackedStringArray([",".join(patterns) + " ; 文件"])
	dialog.file_selected.connect(func(selected: String):
		finish_native_file_dialog()
		callback.call(selected)
		dialog.queue_free())
	dialog.canceled.connect(func():
		finish_native_file_dialog()
		dialog.queue_free())
	popup_native_file_dialog(dialog, 0.8)


func finalize_local_file_browser_show() -> void:
	if not local_file_browser_window or not local_file_browser_window.visible:
		return
	position_utility_window(local_file_browser_window)
	local_file_browser_window.grab_focus()
	DisplayServer.window_move_to_foreground(local_file_browser_window.get_window_id())

func close_local_file_browser() -> void:
	if local_file_browser_window:
		local_file_browser_window.hide()
	if api_settings_window and api_settings_window.visible:
		api_settings_window.grab_focus()
		DisplayServer.window_move_to_foreground(api_settings_window.get_window_id())
	elif chat_workspace_window and chat_workspace_window.visible:
		chat_workspace_window.grab_focus()
		DisplayServer.window_move_to_foreground(chat_workspace_window.get_window_id())
	else:
		get_window().grab_focus()

func local_file_browser_navigate(path: String, record_history := true) -> void:
	var normalized := normalize_project_picker_path(path)
	if normalized.is_empty() or not DirAccess.dir_exists_absolute(normalized):
		local_file_browser_status.text = "找不到这个本地文件夹。"
		local_file_browser_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	local_file_browser_current_path = normalized
	local_file_browser_path_input.text = normalized
	if record_history:
		if local_file_browser_history_index < local_file_browser_history.size() - 1:
			local_file_browser_history = local_file_browser_history.slice(0, local_file_browser_history_index + 1)
		if local_file_browser_history.is_empty() or local_file_browser_history.back() != normalized:
			local_file_browser_history.append(normalized)
			local_file_browser_history_index = local_file_browser_history.size() - 1
	local_file_browser_list.clear()
	var folders := DirAccess.get_directories_at(normalized)
	var files := DirAccess.get_files_at(normalized)
	folders.sort()
	files.sort()
	for folder_name in folders:
		local_file_browser_list.add_item("📁  %s" % str(folder_name))
		var folder_index := local_file_browser_list.item_count - 1
		local_file_browser_list.set_item_metadata(folder_index, {
			"path": normalize_project_picker_path(normalized.path_join(str(folder_name))),
			"is_dir": true
		})
	for file_name in files:
		if local_file_browser_mode == "select_file" and not local_file_browser_extensions.is_empty():
			var file_extension := str(file_name).get_extension().to_lower()
			if file_extension not in local_file_browser_extensions:
				continue
		local_file_browser_list.add_item("📄  %s" % str(file_name))
		var file_index := local_file_browser_list.item_count - 1
		local_file_browser_list.set_item_metadata(file_index, {
			"path": normalize_project_picker_path(normalized.path_join(str(file_name))),
			"is_dir": false
		})
	local_file_browser_status.text = "%d 个文件夹 · %d 个文件" % [folders.size(), files.size()]
	local_file_browser_status.add_theme_color_override("font_color", Color("397397"))

func local_file_browser_go_back() -> void:
	if local_file_browser_history_index <= 0:
		return
	local_file_browser_history_index -= 1
	local_file_browser_navigate(local_file_browser_history[local_file_browser_history_index], false)

func local_file_browser_go_up() -> void:
	if local_file_browser_current_path.is_empty():
		return
	var parent := normalize_project_picker_path(local_file_browser_current_path.get_base_dir())
	if parent.is_empty() or parent == local_file_browser_current_path:
		return
	local_file_browser_navigate(parent)

func on_local_file_browser_item_selected(index: int) -> void:
	if not local_file_browser_list or index < 0 or index >= local_file_browser_list.item_count:
		return
	var metadata: Dictionary = local_file_browser_list.get_item_metadata(index)
	var kind := "文件夹" if bool(metadata.get("is_dir", false)) else "文件"
	local_file_browser_status.text = "%s · %s" % [kind, str(metadata.get("path", ""))]

func on_local_file_browser_item_activated(index: int) -> void:
	if not local_file_browser_list or index < 0 or index >= local_file_browser_list.item_count:
		return
	var metadata: Dictionary = local_file_browser_list.get_item_metadata(index)
	var path := str(metadata.get("path", ""))
	if bool(metadata.get("is_dir", false)):
		local_file_browser_navigate(path)
		return
	if not FileAccess.file_exists(path):
		local_file_browser_status.text = "文件已经不存在，请刷新列表。"
		local_file_browser_status.add_theme_color_override("font_color", Color("c64e59"))
		return
	if local_file_browser_mode == "select_file":
		var callback := local_file_browser_select_callback
		close_local_file_browser()
		if callback.is_valid():
			callback.call(path)
		return
	var open_error := OS.shell_open(path)
	if open_error != OK:
		local_file_browser_status.text = "没有找到可打开这个文件的本机程序。"
		local_file_browser_status.add_theme_color_override("font_color", Color("c64e59"))

func open_local_file_browser_selection() -> void:
	if not local_file_browser_list:
		return
	var selected := local_file_browser_list.get_selected_items()
	if selected.is_empty():
		local_file_browser_status.text = "请先选择一个文件夹或文件。"
		return
	on_local_file_browser_item_activated(int(selected[0]))

func utility_window_for_panel(panel: Control) -> Window:
	if panel == api_settings_panel:
		return api_settings_window
	if panel == execution_settings_panel:
		return execution_settings_window
	if panel == network_settings_panel:
		return network_settings_window
	if panel == knowledge_import_panel:
		return knowledge_import_window
	if panel == knowledge_settings_panel:
		return knowledge_settings_window
	if panel == knowledge_connection_panel:
		return knowledge_connection_window
	if panel == skill_library_panel:
		return skill_library_window
	return null

func open_utility_panel(panel: Control, requested_window_size: Vector2i, requested_panel_size: Vector2) -> void:
	if not panel:
		return
	var utility_window := utility_window_for_panel(panel)
	if not utility_window:
		return
	var usable := DisplayServer.screen_get_usable_rect(get_window().current_screen)
	var safe_size := scaled_size(Vector2i(
		mini(requested_window_size.x, usable.size.x),
		mini(requested_window_size.y, usable.size.y)
	))
	NativeWindows.fit(utility_window, safe_size)
	panel.visible = true
	position_utility_panel(panel, requested_panel_size)
	# 原生子窗口在首次 show() 前设置位置，Windows 可能再按父窗口偏移一次，
	# 导致窗口跑到屏幕右下方。先显示，再通过 DisplayServer 写入绝对屏幕坐标。
	utility_window.show()
	position_utility_window(utility_window)
	utility_window.grab_focus()
	# 复杂容器首次显示前可能保留一份过大的最小尺寸缓存。下一帧再收敛一次，
	# 否则技能详情的可伸缩文本区会把面板高度错误地撑到窗口之外。
	call_deferred("finalize_utility_panel_layout", panel, requested_panel_size, utility_window)

func finalize_utility_panel_layout(panel: Control, preferred_size: Vector2, utility_window: Window) -> void:
	if not panel or not utility_window or not utility_window.visible:
		return
	position_utility_panel(panel, preferred_size)
	position_utility_window(utility_window)

func position_utility_panel(panel: Control, _preferred_size: Vector2) -> void:
	var utility_window := utility_window_for_panel(panel)
	if panel and utility_window:
		NativeWindows.mount(utility_window, panel)


func position_utility_window(utility_window: Window) -> void:
	if not utility_window:
		return
	var screen := get_window().current_screen
	var usable := DisplayServer.screen_get_usable_rect(screen)
	var target := usable.position + (usable.size - utility_window.size) / 2
	target.x = clampi(target.x, usable.position.x, usable.end.x - utility_window.size.x)
	target.y = clampi(target.y, usable.position.y, usable.end.y - utility_window.size.y)
	DisplayServer.window_set_current_screen(screen, utility_window.get_window_id())
	# show() 之后写入绝对屏幕坐标，避免 Windows 首次创建原生窗口时
	# 根据桌宠待机窗口的位置再做一次自动偏移。
	utility_window.position = target

func position_visible_utility_panels() -> void:
	if api_settings_panel and api_settings_panel.visible:
		position_utility_panel(api_settings_panel, Vector2(460, 610))
	if execution_settings_panel and execution_settings_panel.visible:
		position_utility_panel(execution_settings_panel, Vector2(520, 690))
	if network_settings_panel and network_settings_panel.visible:
		position_utility_panel(network_settings_panel, Vector2(490, 560))
	if knowledge_import_panel and knowledge_import_panel.visible:
		position_utility_panel(knowledge_import_panel, Vector2(286, 235))
	if knowledge_settings_panel and knowledge_settings_panel.visible:
		position_utility_panel(knowledge_settings_panel, Vector2(390, 420))
	if skill_library_panel and skill_library_panel.visible:
		position_utility_panel(skill_library_panel, Vector2(812, 698))

func set_furniture_scene_rendering(visible: bool) -> void:
	if agent_scene_background:
		agent_scene_background.visible = visible
	if desk_model:
		desk_model.visible = visible
	if cabinet_model:
		cabinet_model.visible = visible
	set_furniture_controls_enabled(visible)

func close_utility_panel(panel: Control = null, restore_host := true) -> void:
	if panel:
		panel.visible = false
		var utility_window := utility_window_for_panel(panel)
		if utility_window:
			utility_window.hide()
	else:
		for utility_panel in [api_settings_panel, execution_settings_panel, network_settings_panel, knowledge_import_panel, knowledge_settings_panel, knowledge_connection_panel, skill_library_panel]:
			if utility_panel:
				utility_panel.visible = false
		for utility_window in [api_settings_window, execution_settings_window, network_settings_window, knowledge_import_window, knowledge_settings_window, knowledge_connection_window, skill_library_window]:
			if utility_window:
				utility_window.hide()
	# 参数为兼容旧调用保留；原生工具窗口关闭时永远不改变桌宠主窗口。
	if restore_host:
		pass

func hide_all_utility_windows() -> void:
	close_utility_panel(null, false)
	close_project_picker()
	close_local_file_browser()
	if rule_center:
		rule_center.close()
	if workflow_center:
		workflow_center.close()

func on_utility_titlebar_input(event: InputEvent, utility_window: Window) -> void:
	if not event is InputEventMouseButton:
		return
	if event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
		return
	DisplayServer.window_start_drag(utility_window.get_window_id())
	utility_window.get_viewport().set_input_as_handled()

# [DSH] 解析窗的原生窗口。
#
# 与其它工具窗的区别：它**可缩放**（其它工具窗是固定尺寸），因为解析过程面板的
# 内容多少差异很大；内部面板始终铺满窗口，因此不存在"面板和窗口尺寸不一致"
# 这类需要额外同步的状态。
func create_analysis_window() -> Window:
	var window := Window.new()
	window.name = "AnalysisWindow"
	window.title = "梁鲸 · 解析过程"
	window.content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	window.wrap_controls = false
	window.borderless = true
	window.transparent = true
	window.always_on_top = true
	window.unresizable = false
	window.transient = false
	window.exclusive = false
	window.visible = false
	# [DSH] 窗口最小尺寸必须覆盖**面板自身的真实最小尺寸**。
	# 实测面板的 combined minimum 高度是 787（内部两个滚动区各占 180 起），
	# 而窗口若只给 260，面板就会从窗口里溢出去——切到独立窗口后这类
	# "面板比窗口大"的问题必须在这一层挡掉，不能再靠分栏算法兜。
	window.add_child(window_bootstrap_margin())
	NativeWindows.configure(window)
	# [DSH] 解析窗跟随全局界面缩放（它可自由缩放，画布同样按 ui_scale 反算逻辑尺寸）。
	apply_canvas_scale(window)
	add_child(window)
	window.close_requested.connect(close_analysis_window)
	window.size_changed.connect(on_analysis_window_size_changed)
	return window

# 窗口内容落地时才拿得到面板最小尺寸（面板是后建的），因此用一个占位节点占住
# 尺寸来源：真正的收敛在 sync_analysis_window_minimum() 里做。
func window_bootstrap_margin() -> Control:
	var margin := Control.new()
	margin.name = "BootstrapMargin"
	margin.custom_minimum_size = Vector2.ONE
	return margin

# 把窗口最小尺寸收敛到面板真实最小尺寸。
# 窗口 min_size 小于内容最小尺寸时，Godot 不会自动放大窗口，面板会溢出；
# 内容比窗口小则留着空白。两种都由这里对齐。
func sync_analysis_window_minimum() -> void:
	if analysis_window and analysis_panel:
		NativeWindows.mount(analysis_window, analysis_panel)
		NativeWindows.fit(analysis_window)


func on_analysis_window_size_changed() -> void:
	layout_analysis_panel_in_window()

func layout_analysis_panel_in_window() -> void:
	if analysis_window and analysis_panel:
		NativeWindows.mount(analysis_window, analysis_panel)


func sync_analysis_window_visibility() -> void:
	if not analysis_window:
		return
	var should_show := bool(
		chat_workspace_window
		and chat_workspace_window.visible
		and analysis_panel
		and analysis_panel.visible
	)
	if should_show == analysis_window.visible:
		return
	if should_show:
		layout_analysis_panel_in_window()
		analysis_window.show()
		position_analysis_window()
	else:
		analysis_window.hide()

# [DSH] 2026-09-16：合并同窗的分栏实现（ensure_workspace_split / mount_workspace_pane /
# attach_analysis_pane）已按用户要求撤销，解析面板改回独立窗口。以下是撤销记录，
# 便于以后要再合并时直接捡回来（当时的三个坑都记在这里）：
#
#  1. `reparent()` 要求节点**本来就有父节点**，对孤儿节点会失败并打印
#     "Node needs a parent to be reparented."，不抛异常、只留一行日志，
#     表现为"面板怎么都挂不上"，还会每帧重复新建 ScrollContainer。
#  2. `get_parent() != pane` 在两边都是 null 时为假，挂载分支会被静默跳过。
#  3. 容器不给隐藏子节点排版；祖先不可见时量到的是退化矩形，几何断言会误报。
#     所以合并版的几何断言只能在"工作区真的可见"时做，否则必须报 SKIP。

# 默认停在对话窗右侧并贴齐；右侧放不下就翻到左侧；都放不下则夹进屏幕内。
func position_analysis_window() -> void:
	if not analysis_window or not chat_workspace_window:
		return
	var usable := DisplayServer.screen_get_usable_rect(chat_workspace_window.current_screen)
	var target_size := analysis_window.size
	var gap := int(WorkspaceLayout.safe_gap_for_width(float(chat_workspace_window.size.x)))
	var chat_rect := Rect2i(chat_workspace_window.position, chat_workspace_window.size)
	var right_x := chat_rect.end.x + gap
	var left_x := chat_rect.position.x - gap - target_size.x
	var desired_x := right_x
	if right_x + target_size.x > usable.end.x:
		desired_x = left_x
	var desired := Vector2i(
		clampi(desired_x, usable.position.x, maxi(usable.position.x, usable.end.x - target_size.x)),
		clampi(chat_rect.position.y, usable.position.y, maxi(usable.position.y, usable.end.y - target_size.y))
	)
	DisplayServer.window_set_current_screen(chat_workspace_window.current_screen, analysis_window.get_window_id())
	analysis_window.position = desired

func close_analysis_window() -> void:
	if analysis_panel:
		analysis_panel.visible = false
	if analysis_window:
		analysis_window.hide()

# 复位键：把解析窗按默认尺寸重新停到对话窗右侧。
func reset_analysis_window_layout() -> void:
	if not analysis_window:
		return
	analysis_window.size = scaled_size(DEFAULT_ANALYSIS_WINDOW_SIZE)
	on_analysis_window_size_changed()
	if analysis_window.visible:
		position_analysis_window()
	show_message("解析窗口已复位。", 2.5)

func build_knowledge_import_panel() -> void:
	knowledge_import_window = create_utility_window("梁鲸 · 投喂本地知识", KNOWLEDGE_IMPORT_WINDOW_SIZE)
	knowledge_import_window.close_requested.connect(close_knowledge_import_panel)
	knowledge_import_panel = PanelContainer.new()
	knowledge_import_panel.name = "KnowledgeImport"
	knowledge_import_panel.position = Vector2(34, 292)
	knowledge_import_panel.size = Vector2(286, 235)
	knowledge_import_panel.visible = false
	knowledge_import_panel.z_index = 20
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.955, 0.982, 1.0, 0.985)
	style.border_color = Color("65b9ed")
	style.set_border_width_all(2)
	style.set_corner_radius_all(18)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 15
	style.content_margin_bottom = 16
	style.shadow_color = Color(0.03, 0.16, 0.34, 0.25)
	style.shadow_size = 12
	knowledge_import_panel.add_theme_stylebox_override("panel", style)
	knowledge_import_window.add_child(knowledge_import_panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 8)
	knowledge_import_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(knowledge_import_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "📖  投喂本地知识"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("173f63"))
	title.add_theme_font_size_override("font_size", 17)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.tooltip_text = "关闭"
	close_button.custom_minimum_size = Vector2(34, 32)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_knowledge_import_panel)
	header.add_child(close_button)
	var file_button := Button.new()
	file_button.text = "选择单个文件"
	file_button.custom_minimum_size = Vector2(0, 38)
	apply_settings_button_style(file_button, true)
	file_button.pressed.connect(choose_knowledge_file)
	content.add_child(file_button)
	var folder_button := Button.new()
	folder_button.text = "选择整个文件夹"
	folder_button.custom_minimum_size = Vector2(0, 38)
	apply_settings_button_style(folder_button, false)
	folder_button.pressed.connect(choose_knowledge_folder)
	content.add_child(folder_button)
	var inbox_button := Button.new()
	inbox_button.text = "打开本地投喂箱"
	inbox_button.custom_minimum_size = Vector2(0, 34)
	apply_settings_button_style(inbox_button, false)
	inbox_button.pressed.connect(open_soul_inbox)
	content.add_child(inbox_button)
	var settings_button := Button.new()
	settings_button.text = "导入与索引设置"
	settings_button.custom_minimum_size = Vector2(0, 34)
	apply_settings_button_style(settings_button, false)
	settings_button.pressed.connect(toggle_knowledge_settings)
	content.add_child(settings_button)
	# [DSH] 知识库来源（本机 / WeKnora）与 API Key 的入口。放在投喂面板里，
	# 因为"往哪儿投喂"和"从哪儿检索"是同一件事的两面。
	var connection_button := Button.new()
	connection_button.text = "知识库连接（WeKnora）"
	connection_button.custom_minimum_size = Vector2(0, 34)
	apply_settings_button_style(connection_button, false)
	connection_button.pressed.connect(toggle_knowledge_connection_panel)
	content.add_child(connection_button)

	knowledge_file_dialog = FileDialog.new()
	knowledge_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	knowledge_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	knowledge_file_dialog.use_native_dialog = true
	knowledge_file_dialog.filters = PackedStringArray(["*.* ; 所有资料"])
	knowledge_file_dialog.file_selected.connect(on_knowledge_path_selected)
	knowledge_file_dialog.canceled.connect(finish_native_file_dialog)
	add_child(knowledge_file_dialog)
	knowledge_folder_dialog = FileDialog.new()
	knowledge_folder_dialog.access = FileDialog.ACCESS_FILESYSTEM
	knowledge_folder_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	knowledge_folder_dialog.use_native_dialog = true
	knowledge_folder_dialog.dir_selected.connect(on_knowledge_path_selected)
	knowledge_folder_dialog.canceled.connect(finish_native_file_dialog)
	add_child(knowledge_folder_dialog)
	build_knowledge_settings_panel()
	build_knowledge_connection_panel()

func build_knowledge_settings_panel() -> void:
	knowledge_settings_window = create_utility_window("梁鲸 · 知识导入设置", KNOWLEDGE_SETTINGS_WINDOW_SIZE)
	knowledge_settings_window.close_requested.connect(close_knowledge_settings_panel)
	knowledge_settings_panel = PanelContainer.new()
	knowledge_settings_panel.name = "KnowledgeSettings"
	knowledge_settings_panel.position = Vector2(28, 205)
	knowledge_settings_panel.size = Vector2(390, 420)
	knowledge_settings_panel.visible = false
	knowledge_settings_panel.z_index = 25
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.955, 0.982, 1.0, 0.99)
	style.border_color = Color("65b9ed")
	style.set_border_width_all(2)
	style.set_corner_radius_all(20)
	style.content_margin_left = 22
	style.content_margin_right = 22
	style.content_margin_top = 17
	style.content_margin_bottom = 18
	style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	style.shadow_size = 14
	knowledge_settings_panel.add_theme_stylebox_override("panel", style)
	knowledge_settings_window.add_child(knowledge_settings_panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 9)
	knowledge_settings_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(knowledge_settings_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "知识导入设置"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("173f63"))
	title.add_theme_font_size_override("font_size", 18)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(38, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_knowledge_settings_panel)
	header.add_child(close_button)
	var explain := Label.new()
	explain.text = "原文件保留在本地，转换后的 Markdown 用于检索。"
	explain.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	explain.custom_minimum_size = Vector2(330, 36)
	explain.add_theme_color_override("font_color", Color("527493"))
	explain.add_theme_font_size_override("font_size", 12)
	content.add_child(explain)
	knowledge_docx_check = CheckButton.new()
	knowledge_docx_check.text = "Word（DOCX）自动转 Markdown"
	style_knowledge_check(knowledge_docx_check)
	content.add_child(knowledge_docx_check)
	knowledge_xlsx_check = CheckButton.new()
	knowledge_xlsx_check.text = "Excel（XLSX）自动转 Markdown 表格"
	style_knowledge_check(knowledge_xlsx_check)
	content.add_child(knowledge_xlsx_check)
	var pending := Label.new()
	pending.text = "PDF、老式 DOC：保留原件，等待解析组件"
	pending.add_theme_color_override("font_color", Color("7b6a55"))
	pending.add_theme_font_size_override("font_size", 12)
	content.add_child(pending)
	var chunk_row := HBoxContainer.new()
	chunk_row.add_theme_constant_override("separation", 8)
	content.add_child(chunk_row)
	var chunk_label := make_settings_label("分段长度")
	chunk_label.custom_minimum_size = Vector2(88, 40)
	chunk_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	chunk_row.add_child(chunk_label)
	knowledge_chunk_size = SpinBox.new()
	knowledge_chunk_size.min_value = 300
	knowledge_chunk_size.max_value = 4000
	knowledge_chunk_size.step = 100
	knowledge_chunk_size.custom_minimum_size = Vector2(110, 40)
	apply_settings_field_style(knowledge_chunk_size.get_line_edit())
	chunk_row.add_child(knowledge_chunk_size)
	var overlap_label := make_settings_label("重叠")
	overlap_label.custom_minimum_size = Vector2(48, 40)
	overlap_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	chunk_row.add_child(overlap_label)
	knowledge_chunk_overlap = SpinBox.new()
	knowledge_chunk_overlap.min_value = 0
	knowledge_chunk_overlap.max_value = 1000
	knowledge_chunk_overlap.step = 20
	knowledge_chunk_overlap.custom_minimum_size = Vector2(90, 40)
	apply_settings_field_style(knowledge_chunk_overlap.get_line_edit())
	chunk_row.add_child(knowledge_chunk_overlap)
	var hint := Label.new()
	hint.text = "推荐：900 字 / 重叠 140 字。数值越小，检索越细。"
	hint.add_theme_color_override("font_color", Color("607c94"))
	hint.add_theme_font_size_override("font_size", 12)
	content.add_child(hint)
	var save_button := Button.new()
	save_button.text = "保存导入设置"
	save_button.custom_minimum_size = Vector2(0, 42)
	apply_settings_button_style(save_button, true)
	save_button.pressed.connect(save_knowledge_settings)
	content.add_child(save_button)

func style_knowledge_check(check: CheckButton) -> void:
	for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
		check.add_theme_color_override(color_name, Color("274d70"))

# [DSH] 知识库连接面板：填 WeKnora 地址与 API Key、测试连接、勾选参与检索的知识库。
#
# 为什么必须有这个面板：API Key 走的是**设备绑定加密**（和模型中心同一套），
# 手工编辑 配置\知识库连接.json 只能写地址，写不进 Key——没有界面就等于没法配。
func build_knowledge_connection_panel() -> void:
	knowledge_connection_window = create_utility_window("梁鲸 · 知识库连接", KNOWLEDGE_CONNECTION_WINDOW_SIZE)
	knowledge_connection_window.close_requested.connect(close_knowledge_connection_panel)
	knowledge_connection_panel = PanelContainer.new()
	knowledge_connection_panel.name = "KnowledgeConnection"
	knowledge_connection_panel.visible = false
	knowledge_connection_panel.z_index = 26
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.955, 0.982, 1.0, 0.99)
	style.border_color = Color("65b9ed")
	style.set_border_width_all(2)
	style.set_corner_radius_all(20)
	style.content_margin_left = 22
	style.content_margin_right = 22
	style.content_margin_top = 17
	style.content_margin_bottom = 18
	style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	style.shadow_size = 14
	knowledge_connection_panel.add_theme_stylebox_override("panel", style)
	knowledge_connection_window.add_child(knowledge_connection_panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 9)
	knowledge_connection_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(knowledge_connection_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "知识库连接"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("173f63"))
	title.add_theme_font_size_override("font_size", 18)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(38, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_knowledge_connection_panel)
	header.add_child(close_button)
	var explain := Label.new()
	explain.text = "梁鲸负责投喂与提问，WeKnora 负责解析、索引与检索。地址要填服务根地址，不用带 /api/v1。"
	explain.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	explain.custom_minimum_size = Vector2(430, 34)
	explain.add_theme_color_override("font_color", Color("527493"))
	explain.add_theme_font_size_override("font_size", 12)
	content.add_child(explain)
	var source_row := HBoxContainer.new()
	source_row.add_theme_constant_override("separation", 8)
	content.add_child(source_row)
	var source_label := make_settings_label("知识库来源")
	source_label.custom_minimum_size = Vector2(96, 40)
	source_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	source_row.add_child(source_label)
	knowledge_source_option = OptionButton.new()
	knowledge_source_option.custom_minimum_size = Vector2(230, 40)
	knowledge_source_option.add_item("本机知识库", 0)
	knowledge_source_option.add_item("WeKnora", 1)
	apply_settings_field_style(knowledge_source_option)
	source_row.add_child(knowledge_source_option)
	var host_row := HBoxContainer.new()
	host_row.add_theme_constant_override("separation", 8)
	content.add_child(host_row)
	var host_label := make_settings_label("服务地址")
	host_label.custom_minimum_size = Vector2(96, 40)
	host_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	host_row.add_child(host_label)
	knowledge_host_edit = LineEdit.new()
	knowledge_host_edit.placeholder_text = "https://kb.你的域名 或 http://127.0.0.1:8080"
	knowledge_host_edit.custom_minimum_size = Vector2(320, 40)
	apply_settings_field_style(knowledge_host_edit)
	host_row.add_child(knowledge_host_edit)
	# [DSH] 明文放行开关。默认关闭；只有用户明确勾选才放行非回环的 http 地址，
	# 否则公网明文会把 API Key 与资料正文暴露给路径上的每一跳。
	knowledge_insecure_check = CheckButton.new()
	knowledge_insecure_check.text = "允许明文 HTTP（不推荐：Key 与资料会明文过网）"
	knowledge_insecure_check.tooltip_text = "只有你自己的私有部署、且暂时没有证书时才勾选。能用 https 就不要勾。"
	style_knowledge_check(knowledge_insecure_check)
	content.add_child(knowledge_insecure_check)
	var key_row := HBoxContainer.new()
	key_row.add_theme_constant_override("separation", 8)
	content.add_child(key_row)
	var key_label := make_settings_label("API Key")
	key_label.custom_minimum_size = Vector2(96, 40)
	key_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	key_row.add_child(key_label)
	knowledge_key_edit = LineEdit.new()
	knowledge_key_edit.secret = true
	knowledge_key_edit.placeholder_text = "在 WeKnora 的账号页生成；留空表示不修改已保存的 Key"
	knowledge_key_edit.custom_minimum_size = Vector2(320, 40)
	apply_settings_field_style(knowledge_key_edit)
	key_row.add_child(knowledge_key_edit)
	var button_row := HBoxContainer.new()
	button_row.add_theme_constant_override("separation", 8)
	content.add_child(button_row)
	knowledge_connection_test_button = Button.new()
	knowledge_connection_test_button.text = "保存并测试连接"
	knowledge_connection_test_button.custom_minimum_size = Vector2(200, 42)
	knowledge_connection_test_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_button_style(knowledge_connection_test_button, true)
	knowledge_connection_test_button.pressed.connect(save_and_test_knowledge_connection)
	button_row.add_child(knowledge_connection_test_button)
	var clear_button := Button.new()
	clear_button.text = "清空 Key"
	clear_button.custom_minimum_size = Vector2(110, 42)
	apply_settings_button_style(clear_button, false)
	clear_button.pressed.connect(clear_knowledge_connection_key)
	button_row.add_child(clear_button)
	knowledge_connection_status = Label.new()
	knowledge_connection_status.text = "尚未测试。"
	knowledge_connection_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	knowledge_connection_status.custom_minimum_size = Vector2(430, 52)
	knowledge_connection_status.add_theme_color_override("font_color", Color("3d6488"))
	knowledge_connection_status.add_theme_font_size_override("font_size", 12)
	content.add_child(knowledge_connection_status)
	var list_title := Label.new()
	list_title.text = "参与检索的知识库（勾选后保存）"
	list_title.add_theme_color_override("font_color", Color("173f63"))
	list_title.add_theme_font_size_override("font_size", 14)
	content.add_child(list_title)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(430, 150)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	knowledge_base_list = VBoxContainer.new()
	knowledge_base_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	knowledge_base_list.add_theme_constant_override("separation", 4)
	scroll.add_child(knowledge_base_list)
	var save_selection := Button.new()
	save_selection.text = "保存知识库选择"
	save_selection.custom_minimum_size = Vector2(0, 40)
	apply_settings_button_style(save_selection, false)
	save_selection.pressed.connect(save_knowledge_base_selection)
	content.add_child(save_selection)

func toggle_knowledge_connection_panel() -> void:
	if knowledge_connection_panel.visible:
		close_knowledge_connection_panel()
		return
	# 先关掉所有工具窗：这个面板要展示一列知识库，叠加在别的设置窗上既看不清也点不准。
	close_utility_panel(null)
	open_utility_panel(knowledge_connection_panel, KNOWLEDGE_CONNECTION_WINDOW_SIZE, Vector2(480, 560))
	refresh_knowledge_connection_fields()

func close_knowledge_connection_panel() -> void:
	close_utility_panel(knowledge_connection_panel)

func refresh_knowledge_connection_fields() -> void:
	if not knowledge_connection_panel or not weknora_config:
		return
	knowledge_source_option.select(1 if weknora_config.get_mode() == WeKnoraConfigStore.MODE_WEKNORA else 0)
	knowledge_host_edit.text = weknora_config.get_host()
	knowledge_insecure_check.button_pressed = weknora_config.get_allow_insecure_http()
	knowledge_key_edit.text = ""
	knowledge_key_edit.placeholder_text = (
		"已保存（留空表示不修改）" if weknora_config.has_api_key()
		else "在 WeKnora 的账号页生成"
	)
	knowledge_connection_status.text = "当前：%s" % weknora_config.status_line()
	render_knowledge_base_list([], weknora_config.get_knowledge_base_ids())

func render_knowledge_base_list(items: Array, selected_ids: Array) -> void:
	if not knowledge_base_list:
		return
	for child in knowledge_base_list.get_children():
		child.queue_free()
	if items.is_empty():
		var empty := Label.new()
		empty.text = "还没有读到知识库。填好地址与 Key 后点「保存并测试连接」。"
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		empty.add_theme_color_override("font_color", Color("7b8fa3"))
		empty.add_theme_font_size_override("font_size", 12)
		knowledge_base_list.add_child(empty)
		return
	for item in items:
		if not item is Dictionary:
			continue
		var row: Dictionary = item
		var check := CheckButton.new()
		# 片段数只在服务端真的给了才显示：真机上 list 接口返回 chunk_count=0（版本差异），
		# 直接写"0 个片段"会让用户以为库里是空的。
		var chunks := int(row.get("chunk_count", 0))
		check.text = "%s（%d 份资料%s）" % [
			str(row.get("name", row.get("id", "未命名"))),
			int(row.get("knowledge_count", 0)),
			"，%d 个片段" % chunks if chunks > 0 else "",
		]
		if bool(row.get("graph_enabled", false)):
			check.text += " · 图谱"
		check.set_meta("knowledge_base_id", str(row.get("id", "")))
		check.button_pressed = selected_ids.has(str(row.get("id", "")))
		style_knowledge_check(check)
		knowledge_base_list.add_child(check)

func collect_selected_knowledge_base_ids() -> Array:
	var ids: Array = []
	if not knowledge_base_list:
		return ids
	for child in knowledge_base_list.get_children():
		if child is CheckButton and child.button_pressed and child.has_meta("knowledge_base_id"):
			ids.append(str(child.get_meta("knowledge_base_id")))
	return ids

func save_knowledge_base_selection() -> void:
	if not weknora_config:
		return
	var ids := collect_selected_knowledge_base_ids()
	if ids.is_empty():
		show_message("至少要勾选一个知识库，否则检索没有范围。", 4.0)
		return
	weknora_config.set_knowledge_base_ids(ids)
	show_message("已选择 %d 个知识库参与检索。" % ids.size(), 3.5)

func clear_knowledge_connection_key() -> void:
	if not weknora_config:
		return
	weknora_config.clear_api_key()
	weknora_config.set_mode(WeKnoraConfigStore.MODE_LOCAL)
	refresh_knowledge_connection_fields()
	show_message("已清空 WeKnora 的 API Key，并切回本机知识库。", 4.0)

# 保存 → 测试。测试顺序是刻意的：
#   1) 列知识库（证明地址、Key、权限都对）；
#   2) 读 /system 的图谱引擎（告诉用户知识图谱到底能不能用）；
#   3) 只有前两步都通过，才把来源切到 WeKnora——否则会留下一个"看起来配好了、每次提问都失败"的状态。
func save_and_test_knowledge_connection() -> void:
	if not weknora_config or not weknora_client:
		show_message("知识库连接还没初始化完成。", 4.0)
		return
	var wants_weknora := knowledge_source_option.get_selected_id() == 1
	var host := knowledge_host_edit.text.strip_edges()
	var key := knowledge_key_edit.text.strip_edges()
	# 放行开关要在校验地址之前落盘：check_host() 读的就是它。
	weknora_config.set_allow_insecure_http(knowledge_insecure_check.button_pressed)
	if wants_weknora:
		if host.is_empty():
			knowledge_connection_status.text = "请先填写 WeKnora 的服务地址。"
			return
		var verdict: Dictionary = weknora_config.check_host(host)
		if not bool(verdict.get("ok", false)):
			knowledge_connection_status.text = str(verdict.get("error", "地址不可用。"))
			return
		if key.is_empty() and not weknora_config.has_api_key():
			knowledge_connection_status.text = "请填写 API Key（WeKnora 账号页可以生成）。"
			return
	var host_result: Dictionary = weknora_config.set_host(host)
	if not bool(host_result.get("ok", false)):
		knowledge_connection_status.text = str(host_result.get("error", "地址保存失败。"))
		return
	if not key.is_empty():
		if not weknora_config.save_api_key(key):
			knowledge_connection_status.text = "API Key 保存失败（加密写入没有通过回读校验）。"
			return
		knowledge_key_edit.text = ""
	weknora_client.initialize(weknora_config.get_api_base_url(), weknora_config.load_api_key())
	if not wants_weknora:
		weknora_config.set_mode(WeKnoraConfigStore.MODE_LOCAL)
		knowledge_connection_status.text = "已保存，当前使用本机知识库。"
		refresh_knowledge_connection_fields()
		return
	knowledge_connection_test_button.disabled = true
	knowledge_connection_status.text = "正在连接 %s ……" % weknora_config.get_api_base_url()
	var probed: Dictionary = await weknora_client.list_knowledge_bases()
	if not bool(probed.get("ok", false)):
		# 失败时保持本机模式：宁可让用户继续用本机库，也不要留下一个坏掉的来源。
		weknora_config.set_mode(WeKnoraConfigStore.MODE_LOCAL)
		knowledge_connection_test_button.disabled = false
		knowledge_connection_status.text = "连接失败：%s\n已保持「本机知识库」，不会影响你现在使用。" % str(probed.get("error", "未知错误"))
		return
	var items: Array = probed.get("items", [])
	var selected: Array = weknora_config.get_knowledge_base_ids()
	var auto_selected: bool = selected.is_empty()
	if auto_selected:
		# 第一次连接：默认全选，用户不用先勾一遍才能用。
		for item in items:
			selected.append(str(Dictionary(item).get("id", "")))
	render_knowledge_base_list(items, selected)
	if auto_selected and not selected.is_empty():
		weknora_config.set_knowledge_base_ids(selected)
	var graph_line := "知识图谱：未启用（可以在 WeKnora 里给知识库打开，之后需要重新解析才会补图）"
	var graph_kbs := 0
	for item in items:
		if item is Dictionary and bool(Dictionary(item).get("graph_enabled", false)):
			graph_kbs += 1
	if graph_kbs > 0:
		graph_line = "知识图谱：已启用（%d 个知识库）" % graph_kbs
	# /system 只是补充信息：用户的部署上它可能就是 404，所以不能拿它当唯一来源。
	var info: Dictionary = await weknora_client.system_info()
	if bool(info.get("ok", false)) and str(info.get("graph_engine", "")) != "":
		graph_line += "；服务端图谱引擎：%s" % str(info.get("graph_engine", ""))
	var mode_result: Dictionary = weknora_config.set_mode(WeKnoraConfigStore.MODE_WEKNORA)
	knowledge_connection_test_button.disabled = false
	if not bool(mode_result.get("ok", false)):
		knowledge_connection_status.text = str(mode_result.get("error", "切换失败。"))
		return
	knowledge_key_edit.placeholder_text = "已保存（留空表示不修改）"
	var insecure_note := ""
	if weknora_config.get_allow_insecure_http() and not WeKnoraConfigStore.is_safe_host(weknora_config.get_host()):
		insecure_note = "\n⚠ 当前走明文 HTTP：API Key 与资料正文会以明文经过网络，请尽快改用 https。"
	knowledge_connection_status.text = "连接成功：读到 %d 个知识库，已参与检索 %d 个。\n%s\n当前来源：WeKnora%s" % [
		items.size(), selected.size(), graph_line, insecure_note
	]
	show_message("已连接到 WeKnora，知识库检索改由它负责。", 4.5)

func toggle_knowledge_settings() -> void:
	if knowledge_settings_panel.visible:
		close_knowledge_settings_panel()
		return
	open_utility_panel(knowledge_settings_panel, KNOWLEDGE_SETTINGS_WINDOW_SIZE, Vector2(390, 420))
	if not soul_store:
		return
	var settings: Dictionary = soul_store.get_import_settings()
	knowledge_docx_check.button_pressed = bool(settings.get("convert_docx", true))
	knowledge_xlsx_check.button_pressed = bool(settings.get("convert_xlsx", true))
	knowledge_chunk_size.value = int(settings.get("chunk_size", 900))
	knowledge_chunk_overlap.value = int(settings.get("chunk_overlap", 140))

func save_knowledge_settings() -> void:
	if not soul_store:
		return
	var saved: bool = soul_store.save_import_settings({
		"convert_docx": knowledge_docx_check.button_pressed,
		"convert_xlsx": knowledge_xlsx_check.button_pressed,
		"chunk_size": int(knowledge_chunk_size.value),
		"chunk_overlap": int(knowledge_chunk_overlap.value)
	})
	close_knowledge_settings_panel()
	show_message("知识导入设置已保存在本机。" if saved else "知识导入设置保存失败。", 3.5)

func toggle_knowledge_import_panel() -> void:
	if knowledge_import_panel.visible:
		close_knowledge_import_panel()
		return
	hide_interaction_hint()
	open_utility_panel(knowledge_import_panel, KNOWLEDGE_IMPORT_WINDOW_SIZE, Vector2(286, 235))

func close_knowledge_import_panel() -> void:
	close_utility_panel(knowledge_import_panel)

func close_knowledge_settings_panel() -> void:
	close_utility_panel(knowledge_settings_panel)

func choose_knowledge_file() -> void:
	close_knowledge_import_panel()
	popup_native_file_dialog(knowledge_file_dialog, 0.78)

func choose_knowledge_folder() -> void:
	close_knowledge_import_panel()
	popup_native_file_dialog(knowledge_folder_dialog, 0.78)

func on_knowledge_path_selected(path: String) -> void:
	finish_native_file_dialog()
	if not soul_store:
		show_message("本地知识库还没有准备好。", 3.0)
		return
	show_message("正在把资料复制到本地知识库……", 3.0)
	var imported: Dictionary = soul_store.import_path(path)
	if not bool(imported.get("ok", false)):
		show_message(str(imported.get("message", "资料导入失败。")), 4.0)
		return
	var learned: Dictionary = soul_store.learn_inbox()
	var message := "已导入 %d 个文件；直接学会 %d 份，等待解析 %d 份。" % [
		int(imported.get("copied", 0)),
		int(learned.get("learned", 0)),
		int(learned.get("pending", 0))
	]
	if int(imported.get("skipped_links", 0)) > 0:
		message += " 已跳过链接目录。"
	show_message(message, 6.0)
	if agent_hint:
		agent_hint.text = message
	update_soul_status()
	agent_event.emit({"type": "knowledge.imported", "files": imported.get("copied", 0), "source": path})

func build_api_settings_panel() -> void:
	api_settings_window = create_utility_window("梁鲸 · 模型中心", MODEL_SETTINGS_WINDOW_SIZE)
	api_settings_window.close_requested.connect(close_api_settings)
	api_settings_panel = PanelContainer.new()
	api_settings_panel.name = "ModelSettings"
	api_settings_panel.position = Vector2(270, 75)
	api_settings_panel.size = Vector2(460, 610)
	api_settings_panel.visible = false
	api_settings_panel.z_index = 20
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.985)
	panel_style.border_color = Color("65b9ed")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(22)
	panel_style.content_margin_left = 24
	panel_style.content_margin_right = 24
	panel_style.content_margin_top = 19
	panel_style.content_margin_bottom = 20
	panel_style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	panel_style.shadow_size = 18
	api_settings_panel.add_theme_stylebox_override("panel", panel_style)
	api_settings_window.add_child(api_settings_panel)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 7)
	api_settings_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(api_settings_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "●  模型中心"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("163f67"))
	title.add_theme_font_size_override("font_size", 20)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.tooltip_text = "关闭"
	close_button.custom_minimum_size = Vector2(38, 34)
	close_button.add_theme_font_size_override("font_size", 22)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_api_settings)
	header.add_child(close_button)

	model_center_tabs = TabContainer.new()
	model_center_tabs.custom_minimum_size.y = 540
	model_center_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(model_center_tabs)
	style_model_center_tabs()
	var chat_scroll := ScrollContainer.new()
	chat_scroll.name = "对话与视觉"
	chat_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	model_center_tabs.add_child(chat_scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 7)
	chat_scroll.add_child(content)
	var image_scroll := ScrollContainer.new()
	image_scroll.name = "图像与换装"
	image_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	model_center_tabs.add_child(image_scroll)
	image_model_settings_box = VBoxContainer.new()
	image_model_settings_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	image_scroll.add_child(image_model_settings_box)
	var privacy := Label.new()
	privacy.text = "Key 只保存在这台电脑的加密文件中"
	privacy.add_theme_color_override("font_color", Color("527493"))
	privacy.add_theme_font_size_override("font_size", 13)
	content.add_child(privacy)

	var selectors := HBoxContainer.new()
	selectors.add_theme_constant_override("separation", 10)
	content.add_child(selectors)
	var role_box := VBoxContainer.new()
	role_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	role_box.add_theme_constant_override("separation", 4)
	role_box.add_child(make_settings_label("能力位置"))
	api_role_select = OptionButton.new()
	api_role_select.custom_minimum_size = Vector2(0, 40)
	api_role_select.add_item("对话模型", 0)
	api_role_select.set_item_metadata(0, "chat")
	api_role_select.add_item("视觉模型", 1)
	api_role_select.set_item_metadata(1, "vision")
	apply_settings_field_style(api_role_select)
	api_role_select.item_selected.connect(on_api_role_selected)
	role_box.add_child(api_role_select)
	selectors.add_child(role_box)
	var provider_box := VBoxContainer.new()
	provider_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	provider_box.add_theme_constant_override("separation", 4)
	provider_box.add_child(make_settings_label("接口类型"))
	api_provider_select = OptionButton.new()
	api_provider_select.custom_minimum_size = Vector2(0, 40)
	api_provider_select.add_item("DeepSeek", 0)
	api_provider_select.set_item_metadata(0, "deepseek")
	api_provider_select.add_item("兼容接口", 1)
	api_provider_select.set_item_metadata(1, "openai_compatible")
	apply_settings_field_style(api_provider_select)
	api_provider_select.item_selected.connect(on_api_provider_selected)
	provider_box.add_child(api_provider_select)
	selectors.add_child(provider_box)

	var collaboration_row := HBoxContainer.new()
	collaboration_row.add_theme_constant_override("separation", 10)
	content.add_child(collaboration_row)
	var collaboration_label := make_settings_label("模型协作")
	collaboration_label.custom_minimum_size = Vector2(82, 40)
	collaboration_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	collaboration_row.add_child(collaboration_label)
	api_collaboration_select = OptionButton.new()
	api_collaboration_select.custom_minimum_size = Vector2(0, 40)
	api_collaboration_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	api_collaboration_select.add_item("视觉识别 → Harness 处理", 0)
	api_collaboration_select.set_item_metadata(0, "vision_then_chat")
	api_collaboration_select.add_item("视觉模型详细描述 → Harness", 1)
	api_collaboration_select.set_item_metadata(1, "vision_direct")
	api_collaboration_select.add_item("自动选择可用模型", 2)
	api_collaboration_select.set_item_metadata(2, "auto")
	apply_settings_field_style(api_collaboration_select)
	collaboration_row.add_child(api_collaboration_select)

	content.add_child(make_settings_label("接口地址"))
	api_base_url_input = LineEdit.new()
	api_base_url_input.placeholder_text = "https://api.deepseek.com"
	api_base_url_input.custom_minimum_size = Vector2(0, 40)
	apply_settings_field_style(api_base_url_input)
	content.add_child(api_base_url_input)

	content.add_child(make_settings_label("API Key"))
	var key_row := HBoxContainer.new()
	key_row.add_theme_constant_override("separation", 8)
	content.add_child(key_row)
	api_key_input = LineEdit.new()
	api_key_input.secret = true
	api_key_input.placeholder_text = "粘贴以 sk- 开头的 Key"
	api_key_input.custom_minimum_size = Vector2(0, 40)
	api_key_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_field_style(api_key_input)
	key_row.add_child(api_key_input)
	var import_key_button := Button.new()
	import_key_button.text = "导入 Key"
	import_key_button.tooltip_text = "导入纯文本、.env、JSON，或本机梁鲸加密 Key 配置"
	import_key_button.custom_minimum_size = Vector2(96, 40)
	apply_settings_button_style(import_key_button, false)
	import_key_button.pressed.connect(open_api_key_import)
	key_row.add_child(import_key_button)

	content.add_child(make_settings_label("模型 ID"))
	var model_row := HBoxContainer.new()
	model_row.add_theme_constant_override("separation", 8)
	content.add_child(model_row)
	api_model_input = LineEdit.new()
	api_model_input.placeholder_text = "可手填，或从接口读取"
	api_model_input.custom_minimum_size = Vector2(0, 40)
	api_model_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_field_style(api_model_input)
	model_row.add_child(api_model_input)
	api_read_models_button = Button.new()
	api_read_models_button.text = "读取模型"
	api_read_models_button.custom_minimum_size = Vector2(104, 40)
	apply_settings_button_style(api_read_models_button, false)
	api_read_models_button.pressed.connect(read_api_models)
	model_row.add_child(api_read_models_button)
	# 可编辑组合框：模型 ID 仍能手填，下拉入口嵌在同一个输入框右侧。
	# “读取模型”只刷新候选项，不再在下方生成第二个重复输入框。
	api_model_dropdown = MenuButton.new()
	api_model_dropdown.name = "ModelDropdown"
	api_model_dropdown.text = ""
	api_model_dropdown.tooltip_text = "选择已读取的模型"
	api_model_dropdown.flat = true
	api_model_dropdown.visible = false
	api_model_dropdown.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
	api_model_dropdown.offset_left = -38
	api_model_dropdown.offset_right = -2
	api_model_dropdown.offset_top = 2
	api_model_dropdown.offset_bottom = -2
	api_model_dropdown.get_popup().max_size = Vector2i(420, 320)
	api_model_dropdown.get_popup().add_theme_font_size_override("font_size", 15)
	api_model_dropdown.get_popup().id_pressed.connect(on_api_model_selected)
	api_model_dropdown.get_popup().visibility_changed.connect(on_api_model_popup_visibility_changed)
	api_model_dropdown.about_to_popup.connect(align_api_model_popup)
	api_model_input.add_child(api_model_dropdown)

	api_thinking_check = CheckButton.new()
	api_thinking_check.text = "思考模式（复杂问题时使用）"
	for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
		api_thinking_check.add_theme_color_override(color_name, Color("274d70"))
	api_thinking_check.add_theme_color_override("font_disabled_color", Color("7b91a5"))
	content.add_child(api_thinking_check)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	content.add_child(actions)
	var save_button := Button.new()
	save_button.text = "保存在本机"
	save_button.custom_minimum_size = Vector2(0, 42)
	save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_button_style(save_button, true)
	save_button.pressed.connect(save_api_settings)
	actions.add_child(save_button)
	api_test_button = Button.new()
	api_test_button.text = "测试连接"
	api_test_button.custom_minimum_size = Vector2(0, 42)
	api_test_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_button_style(api_test_button, false)
	api_test_button.pressed.connect(test_api_connection)
	actions.add_child(api_test_button)

	api_test_status = Label.new()
	api_test_status.text = "对话与视觉模型可以分别配置。"
	api_test_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	api_test_status.custom_minimum_size = Vector2(360, 38)
	api_test_status.add_theme_color_override("font_color", Color("58738c"))
	api_test_status.add_theme_font_size_override("font_size", 12)
	content.add_child(api_test_status)

	api_http_request = HTTPRequest.new()
	# 国内模型接口在首次建连、DNS 或 TLS 握手时可能超过 15 秒。
	# 旧时限会把已经正确保存的新 Key 误报为网络故障。
	api_http_request.timeout = 60.0
	api_http_request.request_completed.connect(on_api_test_completed)
	add_child(api_http_request)
	configure_http_request_proxy(api_http_request)

	# 导入 Key 复用梁鲸自建文件库的“选择文件”模式，不再创建会锁住模型中心的 FileDialog。

# 羽毛笔打开的网络页是独立原生窗口，不占用人物、家具或聊天工作区的画布。
# 一份设置同时交给 Godot 模型请求和内置 Harness，避免两条网络通道行为不一致。
func build_network_settings_panel() -> void:
	network_settings_window = create_utility_window("梁鲸 · 网络配置", NETWORK_SETTINGS_WINDOW_SIZE)
	network_settings_window.close_requested.connect(close_network_settings)
	network_settings_panel = PanelContainer.new()
	network_settings_panel.name = "NetworkSettings"
	network_settings_panel.size = Vector2(490, 560)
	network_settings_panel.visible = false
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.985)
	panel_style.border_color = Color("65b9ed")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(22)
	panel_style.content_margin_left = 24
	panel_style.content_margin_right = 24
	panel_style.content_margin_top = 19
	panel_style.content_margin_bottom = 20
	panel_style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	panel_style.shadow_size = 18
	network_settings_panel.add_theme_stylebox_override("panel", panel_style)
	network_settings_window.add_child(network_settings_panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 9)
	network_settings_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(network_settings_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "●  网络配置"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("163f67"))
	title.add_theme_font_size_override("font_size", 20)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var refresh_button := Button.new()
	refresh_button.text = "重新检测"
	refresh_button.tooltip_text = "重新读取 Windows 当前代理"
	refresh_button.custom_minimum_size = Vector2(94, 34)
	apply_settings_button_style(refresh_button, false)
	refresh_button.pressed.connect(refresh_network_detection)
	header.add_child(refresh_button)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(38, 34)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_network_settings)
	header.add_child(close_button)
	var intro := Label.new()
	intro.text = "这里控制模型接口与内置 Harness 的联网方式；不会修改 v2rayN 或 Windows 设置。"
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.custom_minimum_size = Vector2(410, 44)
	intro.add_theme_color_override("font_color", Color("527493"))
	intro.add_theme_font_size_override("font_size", 13)
	content.add_child(intro)
	content.add_child(make_settings_label("联网方式"))
	network_mode_select = OptionButton.new()
	network_mode_select.custom_minimum_size = Vector2(0, 42)
	network_mode_select.add_item("跟随 Windows 系统代理", 0)
	network_mode_select.set_item_metadata(0, "system")
	network_mode_select.add_item("直连（不使用代理）", 1)
	network_mode_select.set_item_metadata(1, "direct")
	network_mode_select.add_item("自定义 HTTP / HTTPS 代理", 2)
	network_mode_select.set_item_metadata(2, "custom")
	apply_settings_field_style(network_mode_select)
	network_mode_select.item_selected.connect(on_network_mode_selected)
	content.add_child(network_mode_select)
	network_detected_label = Label.new()
	network_detected_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_detected_label.custom_minimum_size = Vector2(410, 40)
	network_detected_label.add_theme_color_override("font_color", Color("35698f"))
	network_detected_label.add_theme_font_size_override("font_size", 12)
	content.add_child(network_detected_label)
	content.add_child(make_settings_label("自定义代理服务器"))
	var proxy_row := HBoxContainer.new()
	proxy_row.add_theme_constant_override("separation", 8)
	content.add_child(proxy_row)
	network_proxy_scheme_select = OptionButton.new()
	network_proxy_scheme_select.custom_minimum_size = Vector2(98, 42)
	network_proxy_scheme_select.add_item("HTTP", 0)
	network_proxy_scheme_select.set_item_metadata(0, "http")
	network_proxy_scheme_select.add_item("HTTPS", 1)
	network_proxy_scheme_select.set_item_metadata(1, "https")
	apply_settings_field_style(network_proxy_scheme_select)
	proxy_row.add_child(network_proxy_scheme_select)
	network_proxy_input = LineEdit.new()
	network_proxy_input.placeholder_text = "服务器地址，如 127.0.0.1"
	network_proxy_input.custom_minimum_size = Vector2(0, 42)
	network_proxy_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_field_style(network_proxy_input)
	proxy_row.add_child(network_proxy_input)
	network_proxy_port_input = SpinBox.new()
	network_proxy_port_input.min_value = 1
	network_proxy_port_input.max_value = 65535
	network_proxy_port_input.step = 1
	network_proxy_port_input.value = 10808
	network_proxy_port_input.suffix = "端口"
	network_proxy_port_input.custom_minimum_size = Vector2(112, 42)
	apply_settings_field_style(network_proxy_port_input.get_line_edit())
	network_proxy_port_input.tooltip_text = "代理端口，例如 v2rayN 常用的 10808"
	proxy_row.add_child(network_proxy_port_input)
	content.add_child(make_settings_label("不走代理的本机地址"))
	network_no_proxy_input = LineEdit.new()
	network_no_proxy_input.placeholder_text = "localhost,127.0.0.1,::1"
	network_no_proxy_input.custom_minimum_size = Vector2(0, 42)
	apply_settings_field_style(network_no_proxy_input)
	content.add_child(network_no_proxy_input)
	var note := Label.new()
	note.text = "Harness 的核心与审批通道始终绕过代理。代理服务器需支持普通 HTTP/HTTPS 代理协议。"
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(410, 44)
	note.add_theme_color_override("font_color", Color("607c94"))
	note.add_theme_font_size_override("font_size", 12)
	content.add_child(note)
	var save_button := Button.new()
	save_button.text = "保存并重启联网通道"
	save_button.custom_minimum_size = Vector2(0, 44)
	apply_settings_button_style(save_button, true)
	save_button.pressed.connect(save_network_settings)
	content.add_child(save_button)
	network_status_label = Label.new()
	network_status_label.text = "网络设置保存在本机。"
	network_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status_label.custom_minimum_size = Vector2(410, 38)
	network_status_label.add_theme_color_override("font_color", Color("58738c"))
	network_status_label.add_theme_font_size_override("font_size", 12)
	content.add_child(network_status_label)

func build_execution_framework_settings_panel() -> void:
	execution_settings_window = create_utility_window("梁鲸 · 执行框架中心", EXECUTION_SETTINGS_WINDOW_SIZE)
	execution_settings_window.close_requested.connect(close_execution_framework_settings)
	execution_settings_panel = PanelContainer.new()
	execution_settings_panel.name = "ExecutionFrameworkSettings"
	execution_settings_panel.size = Vector2(520, 690)
	execution_settings_panel.visible = false
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.985)
	panel_style.border_color = Color("65b9ed")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(22)
	panel_style.content_margin_left = 22
	panel_style.content_margin_right = 22
	panel_style.content_margin_top = 18
	panel_style.content_margin_bottom = 18
	panel_style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	panel_style.shadow_size = 18
	execution_settings_panel.add_theme_stylebox_override("panel", panel_style)
	execution_settings_window.add_child(execution_settings_panel)

	# 执行框架选项较多，放进独立滚动区；系统字体或 DPI 放大时仍保持原生窗口边界完整。
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	execution_settings_panel.add_child(scroll)
	var content := VBoxContainer.new()
	content.custom_minimum_size = Vector2(450, 0)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 7)
	scroll.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动工具窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(execution_settings_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "●  执行框架中心"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("163f67"))
	title.add_theme_font_size_override("font_size", 20)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.tooltip_text = "关闭"
	close_button.custom_minimum_size = Vector2(38, 34)
	close_button.add_theme_font_size_override("font_size", 22)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_execution_framework_settings)
	header.add_child(close_button)

	var intro := Label.new()
	intro.text = "模型负责思考，执行框架负责操作电脑。这里更换 Harness 本身，不会改动 API Key。"
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_theme_color_override("font_color", Color("527493"))
	intro.add_theme_font_size_override("font_size", 13)
	content.add_child(intro)

	var identity_row := HBoxContainer.new()
	identity_row.add_theme_constant_override("separation", 10)
	content.add_child(identity_row)
	var mode_box := VBoxContainer.new()
	mode_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mode_box.add_child(make_settings_label("框架来源"))
	framework_mode_select = OptionButton.new()
	framework_mode_select.custom_minimum_size = Vector2(0, 40)
	framework_mode_select.add_item("内置 DeepSeek Harness", 0)
	framework_mode_select.set_item_metadata(0, "bundled")
	framework_mode_select.add_item("本地兼容框架", 1)
	framework_mode_select.set_item_metadata(1, "custom")
	framework_mode_select.add_item("已运行的兼容服务", 2)
	framework_mode_select.set_item_metadata(2, "external")
	apply_settings_field_style(framework_mode_select)
	framework_mode_select.item_selected.connect(on_framework_mode_selected)
	mode_box.add_child(framework_mode_select)
	identity_row.add_child(mode_box)
	var name_box := VBoxContainer.new()
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.add_child(make_settings_label("显示名称"))
	framework_name_input = LineEdit.new()
	framework_name_input.custom_minimum_size = Vector2(0, 40)
	framework_name_input.placeholder_text = "例如 DeepSeek Harness"
	apply_settings_field_style(framework_name_input)
	name_box.add_child(framework_name_input)
	identity_row.add_child(name_box)

	var protocol_row := HBoxContainer.new()
	protocol_row.add_child(make_settings_label("适配协议"))
	var protocol_value := Label.new()
	protocol_value.text = "梁鲸 Harness RPC v1（聊天、工具、审批、追问）"
	protocol_value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	protocol_value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	protocol_value.add_theme_color_override("font_color", Color("1f70a7"))
	protocol_value.add_theme_font_size_override("font_size", 13)
	protocol_row.add_child(protocol_value)
	content.add_child(protocol_row)

	# 内置框架升级区：更新只替换随程序携带的 Harness，用户配置、会话和知识库均位于独立数据目录。
	var update_row := HBoxContainer.new()
	update_row.add_theme_constant_override("separation", 8)
	content.add_child(update_row)
	framework_update_version_label = Label.new()
	framework_update_version_label.text = "内置版本：正在读取"
	framework_update_version_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	framework_update_version_label.add_theme_color_override("font_color", Color("315f85"))
	framework_update_version_label.add_theme_font_size_override("font_size", 13)
	update_row.add_child(framework_update_version_label)
	framework_update_button = Button.new()
	framework_update_button.text = "检查并升级"
	framework_update_button.tooltip_text = "从官方软件源检查最新版；升级前自动备份，异常时自动恢复旧版"
	framework_update_button.custom_minimum_size = Vector2(122, 38)
	apply_settings_button_style(framework_update_button, false)
	framework_update_button.pressed.connect(check_and_update_bundled_harness)
	update_row.add_child(framework_update_button)

	framework_auto_start_check = CheckButton.new()
	framework_auto_start_check.text = "随桌宠自动启动执行框架"
	for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
		framework_auto_start_check.add_theme_color_override(color_name, Color("274d70"))
	content.add_child(framework_auto_start_check)

	content.add_child(make_settings_label("核心服务地址"))
	framework_core_url_input = LineEdit.new()
	framework_core_url_input.custom_minimum_size = Vector2(0, 38)
	framework_core_url_input.placeholder_text = ExecutionFrameworkConfig.DEFAULT_CORE_URL
	apply_settings_field_style(framework_core_url_input)
	content.add_child(framework_core_url_input)
	content.add_child(make_settings_label("审批与交互地址"))
	framework_interaction_url_input = LineEdit.new()
	framework_interaction_url_input.custom_minimum_size = Vector2(0, 38)
	framework_interaction_url_input.placeholder_text = ExecutionFrameworkConfig.DEFAULT_INTERACTION_URL
	apply_settings_field_style(framework_interaction_url_input)
	content.add_child(framework_interaction_url_input)

	content.add_child(make_settings_label("运行程序（留空使用免安装版自带 node.exe）"))
	var executable_row := HBoxContainer.new()
	executable_row.add_theme_constant_override("separation", 8)
	content.add_child(executable_row)
	framework_executable_input = LineEdit.new()
	framework_executable_input.custom_minimum_size = Vector2(0, 38)
	framework_executable_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	framework_executable_input.placeholder_text = "可选：选择新框架的运行程序"
	apply_settings_field_style(framework_executable_input)
	executable_row.add_child(framework_executable_input)
	var choose_executable := Button.new()
	choose_executable.text = "选择"
	choose_executable.custom_minimum_size = Vector2(76, 38)
	apply_settings_button_style(choose_executable, false)
	choose_executable.pressed.connect(choose_framework_executable)
	executable_row.add_child(choose_executable)

	content.add_child(make_settings_label("入口文件（留空使用自带 blue-whale-harness.mjs）"))
	var launcher_row := HBoxContainer.new()
	launcher_row.add_theme_constant_override("separation", 8)
	content.add_child(launcher_row)
	framework_launcher_input = LineEdit.new()
	framework_launcher_input.custom_minimum_size = Vector2(0, 38)
	framework_launcher_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	framework_launcher_input.placeholder_text = "可选：选择更新后的 Harness 入口"
	apply_settings_field_style(framework_launcher_input)
	launcher_row.add_child(framework_launcher_input)
	var choose_launcher := Button.new()
	choose_launcher.text = "选择"
	choose_launcher.custom_minimum_size = Vector2(76, 38)
	apply_settings_button_style(choose_launcher, false)
	choose_launcher.pressed.connect(choose_framework_launcher)
	launcher_row.add_child(choose_launcher)

	content.add_child(make_settings_label("附加启动参数（每行一个，通常留空）"))
	framework_arguments_input = TextEdit.new()
	framework_arguments_input.custom_minimum_size = Vector2(0, 76)
	framework_arguments_input.placeholder_text = "支持 {data_dir}、{core_url}、{interaction_url} 等占位符"
	framework_arguments_input.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	apply_settings_field_style(framework_arguments_input)
	content.add_child(framework_arguments_input)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	content.add_child(actions)
	var save_button := Button.new()
	save_button.text = "保存并重启"
	save_button.custom_minimum_size = Vector2(0, 42)
	save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_button_style(save_button, true)
	save_button.pressed.connect(save_and_restart_execution_framework)
	actions.add_child(save_button)
	var test_button := Button.new()
	test_button.text = "测试连接"
	test_button.custom_minimum_size = Vector2(104, 42)
	apply_settings_button_style(test_button, false)
	test_button.pressed.connect(test_execution_framework_connection)
	actions.add_child(test_button)
	var reset_button := Button.new()
	reset_button.text = "恢复默认"
	reset_button.custom_minimum_size = Vector2(94, 42)
	apply_settings_button_style(reset_button, false)
	reset_button.pressed.connect(reset_execution_framework_form)
	actions.add_child(reset_button)

	framework_status_label = Label.new()
	framework_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	framework_status_label.custom_minimum_size = Vector2(0, 44)
	framework_status_label.add_theme_color_override("font_color", Color("58738c"))
	framework_status_label.add_theme_font_size_override("font_size", 12)
	content.add_child(framework_status_label)

	framework_executable_dialog = FileDialog.new()
	framework_executable_dialog.access = FileDialog.ACCESS_FILESYSTEM
	framework_executable_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	framework_executable_dialog.use_native_dialog = true
	framework_executable_dialog.filters = PackedStringArray(["*.exe ; Windows 运行程序", "*.* ; 所有文件"])
	framework_executable_dialog.file_selected.connect(on_framework_executable_selected)
	framework_executable_dialog.canceled.connect(finish_native_file_dialog)
	add_child(framework_executable_dialog)
	framework_launcher_dialog = FileDialog.new()
	framework_launcher_dialog.access = FileDialog.ACCESS_FILESYSTEM
	framework_launcher_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	framework_launcher_dialog.use_native_dialog = true
	framework_launcher_dialog.filters = PackedStringArray(["*.mjs,*.js,*.cjs ; JavaScript 入口", "*.* ; 所有文件"])
	framework_launcher_dialog.file_selected.connect(on_framework_launcher_selected)
	framework_launcher_dialog.canceled.connect(finish_native_file_dialog)
	add_child(framework_launcher_dialog)

func make_settings_label(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_color_override("font_color", Color("274d70"))
	label.add_theme_font_size_override("font_size", 13)
	return label

func apply_settings_field_style(control: Control) -> void:
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(1.0, 1.0, 1.0, 0.92)
	normal.border_color = Color("b8d8ec")
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(9)
	normal.content_margin_left = 12
	normal.content_margin_right = 12
	var focus := normal.duplicate() as StyleBoxFlat
	focus.border_color = Color("56b8ef")
	focus.set_border_width_all(2)
	control.add_theme_stylebox_override("normal", normal)
	control.add_theme_stylebox_override("focus", focus)
	control.add_theme_color_override("font_color", Color("173f63"))
	control.add_theme_color_override("font_placeholder_color", Color(0.36, 0.49, 0.60, 0.82))
	control.add_theme_font_size_override("font_size", 14)

func apply_settings_button_style(button: Button, primary: bool) -> void:
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("2f91d5") if primary else Color(1.0, 1.0, 1.0, 0.90)
	normal.border_color = Color("2f91d5") if primary else Color("a8cfe7")
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(10)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color("48a8e7") if primary else Color("e5f5ff")
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color("247db9") if primary else Color("cdeafb")
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	button.add_theme_color_override("font_color", Color.WHITE if primary else Color("214e72"))
	button.add_theme_color_override("font_hover_color", Color.WHITE if primary else Color("173f63"))
	button.add_theme_font_size_override("font_size", 14)

func apply_dark_panel_button_style(button: Button) -> void:
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.12, 0.37, 0.60, 0.72)
	normal.border_color = Color(0.34, 0.78, 1.0, 0.62)
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(8)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.18, 0.52, 0.78, 0.9)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.08, 0.28, 0.48, 0.95)
	for state in ["normal", "disabled"]:
		button.add_theme_stylebox_override(state, normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("focus", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		button.add_theme_color_override(color_name, Color("d9f5ff"))
	button.add_theme_font_size_override("font_size", 11)

func on_main_titlebar_input(event: InputEvent) -> void:
	if not event is InputEventMouseButton:
		return
	if event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
		return
	if event.double_click:
		scene_input_dock.accept_event()
		return
	if chat_window_transitioning or is_chat_window_maximized():
		return
	if chat_workspace_window:
		DisplayServer.window_start_drag(chat_workspace_window.get_window_id())
	scene_input_dock.accept_event()

func on_native_resize_grip_input(event: InputEvent) -> void:
	if not event is InputEventMouseButton:
		return
	if event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
		return
	if chat_window_transitioning or is_chat_window_maximized():
		return
	if not chat_workspace_window:
		return
	chat_windowed_position = chat_workspace_window.position
	chat_windowed_size = chat_workspace_window.size
	DisplayServer.window_start_resize(DisplayServer.WINDOW_EDGE_BOTTOM_RIGHT, chat_workspace_window.get_window_id())
	scene_input_dock.accept_event()

func is_chat_window_maximized() -> bool:
	return bool(chat_workspace_window and chat_workspace_window.mode == Window.MODE_MAXIMIZED)


func chat_rect_fills_work_area(rect: Rect2i, usable: Rect2i) -> bool:
	return (
		usable.size.x > 0 and usable.size.y > 0
		and absi(rect.position.x - usable.position.x) <= 4
		and absi(rect.position.y - usable.position.y) <= 4
		and absi(rect.size.x - usable.size.x) <= 4
		and absi(rect.size.y - usable.size.y) <= 4
	)

func safe_chat_windowed_rect(saved: Rect2i, usable: Rect2i) -> Rect2i:
	var minimum := Vector2i(mini(320, usable.size.x), mini(240, usable.size.y))
	var size_value := Vector2i(clampi(saved.size.x, minimum.x, usable.size.x), clampi(saved.size.y, minimum.y, usable.size.y))
	var position_value := saved.position
	# Recover a full-screen snapshot left by an earlier interrupted restore.
	if size_value.x >= usable.size.x - 4 and size_value.y >= usable.size.y - 4:
		size_value = Vector2i(mini(WORKSPACE_WINDOW_SIZE.x, usable.size.x), mini(WORKSPACE_WINDOW_SIZE.y, usable.size.y))
		position_value = usable.position + (usable.size - size_value) / 2
	position_value.x = clampi(position_value.x, usable.position.x, usable.end.x - size_value.x)
	position_value.y = clampi(position_value.y, usable.position.y, usable.end.y - size_value.y)
	return Rect2i(position_value, size_value)

func toggle_chat_window_maximize() -> void:
	if chat_workspace_window:
		chat_workspace_window.mode = Window.MODE_WINDOWED if is_chat_window_maximized() else Window.MODE_MAXIMIZED


func restore_chat_windowed_mode() -> void:
	if chat_workspace_window:
		chat_workspace_window.mode = Window.MODE_WINDOWED
		chat_window_custom_maximized = false
		chat_window_transitioning = false


func begin_chat_window_transition() -> void:
	chat_window_transition_revision += 1
	chat_window_transitioning = true
	# Resizing a transparent native window can leave its previous Win32 hit-test
	# region active until the next message pump. Keep the whole target clickable
	# during that one-frame transition, then install the precise workspace shape.
	refresh_chat_workspace_input_shape(false)

func finish_chat_window_transition(revision: int, maximized: bool, target: Rect2i) -> void:
	if revision != chat_window_transition_revision or not chat_workspace_window:
		return
	chat_workspace_window.mode = Window.MODE_WINDOWED
	chat_workspace_window.position = target.position
	chat_workspace_window.size = target.size
	chat_window_custom_maximized = maximized
	apply_responsive_chat_layout(not maximized)
	refresh_chat_workspace_input_shape(true)
	if not maximized:
		chat_last_observed_size = target.size
		chat_last_observed_position = target.position
		save_app_window_geometry()

func refresh_chat_workspace_input_shape(precise: bool) -> void:
	if not chat_workspace_window:
		return
	active_window_input_shape = PackedVector2Array()
	var shape := workspace_input_shape() if precise and not is_harness_modal_visible() else full_window_input_shape()
	apply_native_window_input_shape(shape)
	chat_workspace_window.mouse_passthrough = false

func close_chat_from_titlebar() -> void:
	await close_chat_workspace()
	save_app_window_geometry()

func minimize_chat_to_screen_edge() -> void:
	dock_restore_chat_open = bool(scene_input_dock and scene_input_dock.visible)
	dock_restore_scene_open = scene_furniture_visible
	await close_chat_workspace()
	dock_screen = DisplayServer.window_get_current_screen()
	var rect := DisplayServer.screen_get_usable_rect(dock_screen)
	var window_size := get_window().size
	var current_center := get_window().position.x + int(window_size.x / 2)
	var screen_center := rect.position.x + int(rect.size.x / 2)
	var y := clampi(get_window().position.y, rect.position.y, rect.end.y - window_size.y)
	if current_center <= screen_center:
		dock_side = -1
		dock_full = Vector2i(rect.position.x, y)
		dock_hidden = Vector2i(rect.position.x - (window_size.x - DOCK_VISIBLE_WIDTH), y)
	else:
		dock_side = 1
		dock_full = Vector2i(rect.end.x - window_size.x, y)
		dock_hidden = Vector2i(rect.end.x - DOCK_VISIBLE_WIDTH, y)
	dock_hover_armed = false
	play_dock_peek()
	slide_window(dock_hidden)
	save_app_window_geometry()

func restore_saved_app_window(usable: Rect2i) -> void:
	# [DSH] 这里全程按逻辑像素算（配置里存的是逻辑尺寸），最后一步才换算成物理窗口尺寸。
	var default_size := adaptive_default_window_size(usable)
	var default_physical := scaled_size(default_size)
	var default_position := Vector2i(usable.end.x - default_physical.x - 15, usable.end.y - default_physical.y - 10)
	if not soul_store:
		get_window().size = default_physical
		get_window().position = default_position
		return
	var settings: Dictionary = soul_store.get_ui_settings()
	var window_settings: Dictionary = settings.get("app_window", {})
	var size_value: Array = window_settings.get("size", [IDLE_WINDOW_SIZE.x, IDLE_WINDOW_SIZE.y])
	var position_value: Array = window_settings.get("position", [])
	var restored_size := default_size
	var repaired_window_geometry := false
	if size_value.size() >= 2:
		var minimum_width := mini(WINDOW_MIN_WIDTH, usable.size.x)
		var minimum_height := mini(WINDOW_MIN_HEIGHT, usable.size.y)
		var saved_size := Vector2i(int(size_value[0]), int(size_value[1]))
		restored_size = Vector2i(
			clampi(saved_size.x, minimum_width, usable.size.x),
			clampi(saved_size.y, minimum_height, usable.size.y)
		)
		repaired_window_geometry = restored_size != saved_size
	# 旧版本在“还原”时可能把最大化尺寸写进配置。检测到这种泄漏时，
	# 自动回到正常窗口，避免桌宠场景占着整块屏幕、左右探头方向错乱。
	# [DSH] 泄漏判定必须用物理尺寸：0.8 缩放下"占满屏幕"的旧存档，逻辑值只有屏幕的 80%，
	# 用逻辑值判定会漏判。
	var restored_physical := scaled_size(restored_size)
	var leaked_maximized_geometry := (
		restored_physical.x >= int(float(usable.size.x) * 0.90)
		and restored_physical.y >= int(float(usable.size.y) * 0.90)
	)
	if leaked_maximized_geometry:
		restored_size = default_size
		restored_physical = default_physical
		repaired_window_geometry = true
	var restored_position := default_position
	if position_value.size() >= 2:
		restored_position = Vector2i(int(position_value[0]), int(position_value[1]))
		restored_position.x = clampi(restored_position.x, usable.position.x, usable.end.x - restored_physical.x)
		restored_position.y = clampi(restored_position.y, usable.position.y, usable.end.y - restored_physical.y)
	if leaked_maximized_geometry:
		restored_position = default_position
	get_window().size = restored_physical
	get_window().position = restored_position
	chat_windowed_size = restored_physical
	chat_windowed_position = restored_position
	pet_window_size = restored_physical
	pet_window_position = restored_position
	pet_window_geometry_valid = true
	if repaired_window_geometry:
		call_deferred("save_app_window_geometry")

func adaptive_default_window_size(usable: Rect2i) -> Vector2i:
	# 桌面待机只保留人物投影范围；家具和正式工作台按需扩展到完整场景。
	var safe_width := maxi(1, usable.size.x - 24)
	var safe_height := maxi(1, usable.size.y - 24)
	return Vector2i(mini(IDLE_WINDOW_SIZE.x, safe_width), mini(IDLE_WINDOW_SIZE.y, safe_height))

func set_workspace_resize_handles_visible(_visible: bool) -> void:
	if chat_resize_grip:
		chat_resize_grip.visible = false
	if analysis_resize_grip:
		analysis_resize_grip.visible = false

func on_app_window_size_changed() -> void:
	if agent_panel:
		# [DSH] 面板活在逻辑画布里，窗口尺寸是物理像素，必须换算回逻辑尺寸。
		agent_panel.size = Vector2(logical_size(get_window().size))
	position_status_bubble()
	position_visible_utility_panels()

# 聊天窗口只调整自己的控件树。主桌宠尺寸变化不再牵动聊天布局。
func on_chat_workspace_window_size_changed() -> void:
	if not chat_workspace_window or not chat_workspace_root:
		return
	chat_workspace_root.size = Vector2(logical_size(chat_workspace_window.size))
	position_approval_panel()
	position_question_panel()
	if scene_input_dock and scene_input_dock.visible:
		apply_responsive_chat_layout(false)
	if (
		chat_window_constraint_deferred
		or chat_window_transitioning
		or is_chat_window_maximized()
		or chat_workspace_window.mode != Window.MODE_WINDOWED
	):
		return
	chat_window_constraint_deferred = true
	call_deferred("constrain_chat_window_to_screen")

func constrain_chat_window_to_screen() -> void:
	chat_window_constraint_deferred = false
	if not chat_workspace_window or chat_window_transitioning or is_chat_window_maximized() or chat_workspace_window.mode != Window.MODE_WINDOWED:
		return
	var usable := DisplayServer.screen_get_usable_rect(chat_workspace_window.current_screen)
	var minimum := Vector2i(
		mini(320, usable.size.x),
		mini(240, usable.size.y)
	)
	var safe_size := Vector2i(
		clampi(chat_workspace_window.size.x, minimum.x, usable.size.x),
		clampi(chat_workspace_window.size.y, minimum.y, usable.size.y)
	)
	chat_workspace_window.min_size = minimum
	var safe_position := chat_workspace_window.position
	safe_position.x = clampi(safe_position.x, usable.position.x, usable.end.x - safe_size.x)
	safe_position.y = clampi(safe_position.y, usable.position.y, usable.end.y - safe_size.y)
	if chat_workspace_window.size != safe_size:
		chat_workspace_window.size = safe_size
	if chat_workspace_window.position != safe_position:
		chat_workspace_window.position = safe_position

func constrain_resized_window_to_screen() -> void:
	window_constraint_deferred = false
	if (
		constraining_window_geometry
		or restoring_pet_window_geometry
		or chat_window_custom_maximized
		or dock_side != 0
		or get_window().mode != Window.MODE_WINDOWED
	):
		return
	var screen := DisplayServer.window_get_current_screen()
	var usable := DisplayServer.screen_get_usable_rect(screen)
	var mode_minimum := (
		WORKSPACE_WINDOW_SIZE if host_window_mode == "workspace"
		else FURNITURE_WINDOW_SIZE if host_window_mode == "scene"
		else IDLE_WINDOW_SIZE
	)
	var minimum := Vector2i(mini(mode_minimum.x, usable.size.x), mini(mode_minimum.y, usable.size.y))
	var current_position := get_window().position
	var current_size := get_window().size
	var safe_position := current_position
	# 只有左上角确实越出当前屏幕时才纠正位置；合法的右下角拉伸绝不重写 position。
	safe_position.x = clampi(safe_position.x, usable.position.x, usable.end.x - minimum.x)
	safe_position.y = clampi(safe_position.y, usable.position.y, usable.end.y - minimum.y)
	var position_changed := safe_position != current_position
	var size_anchor := safe_position if position_changed else current_position
	var maximum_from_here := Vector2i(
		maxi(minimum.x, usable.end.x - size_anchor.x),
		maxi(minimum.y, usable.end.y - size_anchor.y)
	)
	var safe_size := Vector2i(
		clampi(current_size.x, minimum.x, maximum_from_here.x),
		clampi(current_size.y, minimum.y, maximum_from_here.y)
	)
	var size_changed := safe_size != current_size
	if size_changed or position_changed:
		constraining_window_geometry = true
		if position_changed:
			get_window().position = safe_position
		if size_changed:
			get_window().size = safe_size
		constraining_window_geometry = false
	if agent_panel:
		agent_panel.size = layout_canvas_size()
	apply_responsive_chat_layout(false)

# [DSH] 对话面板现在**独占**工作区画布：解析面板已经搬到自己的原生窗口里。
#
# 这里原本是"两栏响应式分栏"，也是"解析窗压住对话窗"的来源：
# 两个面板必须在一个画布里同时满足各自最小尺寸，一旦
#   对话最小 911 + 间隙 32 + 解析最小 340 + 边距 57 > 窗口 1300
# 就必然重叠（实测间隙 -105px）。拆窗后这类冲突从根上不存在，
# 因此整块分栏计算、验收、自愈、旧坐标修复都可以删掉。
func apply_responsive_chat_layout(_allow_saved_layout := false) -> void:
	if not scene_input_dock or not scene_input_dock.visible:
		return
	load_chat_layout()
	NativeWindows.mount(chat_workspace_window, scene_input_dock)
	position_status_bubble()
	# 对话窗尺寸变化后，解析窗仍应贴在其右侧。
	if analysis_window and analysis_window.visible:
		position_analysis_window()

func position_status_bubble() -> void:
	if not bubble:
		return
	# [DSH] 气泡是**跨窗口**的：它必须出现在用户正在看的那个窗口里。
	#
	# 原先只有一个主窗口：工作区可见时把气泡贴在对话面板左边 18px 处——
	# 但那时主窗口只有 271 宽（贴在屏幕右下角的待机尺寸），气泡被算成 390 宽，
	# 右侧直接被裁掉。真机现象就是"聊天气泡没对齐"。
	#
	# 现在的做法是按场景选择父窗口，并在该窗口的坐标系里定位：
	#   · 对话面板开着 → 把气泡移进聊天窗口，与对话面板中线对齐；
	#   · 待机/家具场景 → 移回主窗口，在窗口内水平居中。
	# 每次显示都按需 reparent，两侧的坐标空间不会混用。
	var workspace_open := bool(
		scene_input_dock
		and scene_input_dock.visible
		and chat_workspace_window
		and chat_workspace_window.visible
		and scene_input_dock.size.x >= 200.0
	)
	var target_parent: Node = chat_workspace_root if workspace_open else self
	if bubble.get_parent() != target_parent:
		bubble.reparent(target_parent, false)
	# [DSH] 气泡的父窗口可能是聊天窗或主窗。两个窗口的 size 都是**物理像素**，
	# 而气泡的 position/size 活在父窗口的逻辑画布里，所以这里统一换算回逻辑尺寸；
	# 否则界面缩放后气泡会按物理宽度居中，在待机窗口上偏左几个像素。
	var canvas := Vector2(logical_size(chat_workspace_window.size)) if workspace_open else Vector2(logical_size(get_window().size))
	# 边距随显示的字号一起放大（UI_TEXT_SCALE），避免文字贴着圆角。
	var edge := 12.0 * UI_TEXT_SCALE
	var minimum_width := 200.0
	if workspace_open:
		# 与对话面板中线对齐，宽度不超过面板可用宽度。
		var panel_rect := Rect2(scene_input_dock.position, scene_input_dock.size)
		var width := clampf(panel_rect.size.x * 0.5, minimum_width, 390.0)
		width = minf(width, maxf(minimum_width, panel_rect.size.x - edge * 2.0))
		bubble.size = Vector2(width, 66)
		bubble.position = Vector2(
			clampf(panel_rect.position.x + (panel_rect.size.x - width) * 0.5, edge, maxf(edge, canvas.x - width - edge)),
			maxf(edge, panel_rect.position.y - 74.0)
		)
	else:
		# 待机/家具场景：宽度必须跟着主窗口走，写死宽度在 271 宽的待机窗口上会被裁。
		var compact_width := clampf(canvas.x - edge * 2.0, minimum_width, 432.0)
		bubble.size = Vector2(compact_width, 72)
		bubble.position = Vector2(
			floor((canvas.x - compact_width) * 0.5),
			edge
		)

func is_normal_workspace_window() -> bool:
	return (
		chat_workspace_window
		and chat_workspace_window.mode == Window.MODE_WINDOWED
		and not chat_window_custom_maximized
		and chat_workspace_window.size == scaled_size(WORKSPACE_WINDOW_SIZE)
	)

func layout_canvas_size() -> Vector2:
	var canvas_size := Vector2(chat_workspace_window.size) if chat_workspace_window and scene_input_dock and scene_input_dock.visible else Vector2(get_window().size)
	if canvas_size.x < 100.0 or canvas_size.y < 100.0:
		return Vector2(WORKSPACE_WINDOW_SIZE)
	return canvas_size

func update_window_geometry_memory(delta: float) -> void:
	# 聊天原生窗口独立记忆自己的位置和尺寸，不再污染桌宠的待机几何。
	if chat_workspace_window and chat_workspace_window.visible and chat_workspace_window.mode == Window.MODE_WINDOWED and not chat_window_transitioning and not is_chat_window_maximized():
		var current_chat_position := chat_workspace_window.position
		var current_chat_size := chat_workspace_window.size
		if current_chat_position != chat_last_observed_position or current_chat_size != chat_last_observed_size:
			chat_last_observed_position = current_chat_position
			chat_last_observed_size = current_chat_size
			chat_windowed_position = current_chat_position
			chat_windowed_size = current_chat_size
			window_geometry_dirty = true
			window_geometry_quiet_clock = 0.0
	if get_window().mode != Window.MODE_WINDOWED or chat_window_transitioning or chat_window_custom_maximized or dock_side != 0 or restoring_pet_window_geometry:
		return
	var current_position := get_window().position
	var current_size := get_window().size
	if current_position != last_observed_window_position or current_size != last_observed_window_size:
		last_observed_window_position = current_position
		last_observed_window_size = current_size
		if host_window_mode == "idle" and not (scene_input_dock and scene_input_dock.visible):
			pet_window_position = current_position
			pet_window_size = current_size
			pet_window_geometry_valid = true
		window_geometry_dirty = true
		window_geometry_quiet_clock = 0.0
		return
	if window_geometry_dirty:
		window_geometry_quiet_clock += delta
		if window_geometry_quiet_clock >= 0.8:
			window_geometry_dirty = false
			save_app_window_geometry()

func save_app_window_geometry() -> void:
	if not soul_store:
		return
	var settings: Dictionary = soul_store.get_ui_settings()
	var saved_position := pet_window_position if pet_window_geometry_valid else chat_windowed_position
	var saved_size := pet_window_size if pet_window_geometry_valid else chat_windowed_size
	# [DSH] 尺寸按逻辑像素写盘：换到别的分辨率/缩放档后读回来仍然表示"同样大的界面"，
	# 也不会因为反复保存-恢复而每次再乘一次 ui_scale。位置是绝对屏幕坐标，按物理像素存。
	var saved_logical_size := logical_size(saved_size)
	var chat_logical_size := logical_size(chat_windowed_size)
	settings["app_window"] = {
		"position": [saved_position.x, saved_position.y],
		"size": [saved_logical_size.x, saved_logical_size.y]
	}
	settings["chat_window"] = {
		"position": [chat_windowed_position.x, chat_windowed_position.y],
		"size": [chat_logical_size.x, chat_logical_size.y]
	}
	soul_store.save_ui_settings(settings)

# [DSH] 拆窗后，面板自由拖动/缩放整块不再需要：
#   · 解析面板在自己的原生窗口里，拖动=拖窗口（DisplayServer.window_start_drag），
#     缩放=拖窗口边框（原生行为）；
#   · 对话面板铺满整个工作区画布，没有"摆在哪"这回事。
# 因此这里只保留一个空实现，供仍在连接的信号调用，避免留下会移动面板的旧路径。
func begin_panel_layout(_event: InputEvent, _target: Control, _mode: String) -> void:
	pass

func handle_panel_layout_input(_event: InputEvent) -> bool:
	return false

# [DSH] 拆窗后不再从存档恢复面板坐标：
#   · 对话面板铺满画布，位置/尺寸由窗口决定；
#   · 解析面板的尺寸由解析窗决定。
# 旧存档里的 chat_workspace / analysis_panel 字段因此不再被读取（留着不读即可，
# 不必迁移磁盘格式——它们已经是无害的历史数据）。
func load_chat_layout() -> void:
	pass

# [DSH] 同理不再写面板坐标。保留函数体为空实现，避免旧调用点报错。
func save_chat_layout() -> void:
	pass

func reset_chat_layout() -> void:
	apply_responsive_chat_layout()
	reset_analysis_window_layout()
	show_message("对话窗口布局已复位。", 2.5)

# 复位按钮的真实入口：重建对话区几何并重新停靠解析窗。
func reset_workspace_layout() -> void:
	apply_responsive_chat_layout()
	reset_analysis_window_layout()

func toggle_execution_framework_settings() -> void:
	if not execution_settings_panel:
		return
	if execution_settings_panel.visible:
		close_execution_framework_settings()
		return
	hide_interaction_hint()
	open_utility_panel(execution_settings_panel, EXECUTION_SETTINGS_WINDOW_SIZE, Vector2(520, 690))
	populate_execution_framework_settings()
	position_utility_panel(execution_settings_panel, Vector2(520, 690))
	framework_name_input.grab_focus()
	agent_event.emit({"type": "settings.open", "section": "execution_framework"})

func close_execution_framework_settings() -> void:
	close_utility_panel(execution_settings_panel)

func selected_framework_mode() -> String:
	if not framework_mode_select or framework_mode_select.selected < 0:
		return "bundled"
	return str(framework_mode_select.get_item_metadata(framework_mode_select.selected))

func on_framework_mode_selected(_index: int) -> void:
	var mode := selected_framework_mode()
	framework_auto_start_check.disabled = mode == "external"
	refresh_framework_update_ui()
	if mode == "external":
		framework_auto_start_check.button_pressed = false
		framework_status_label.text = "外部服务由你单独启动；桌宠只连接核心和审批地址。"
	elif mode == "custom":
		framework_status_label.text = "本地兼容框架须实现梁鲸 Harness RPC v1；请选择运行程序，入口文件可留空。"
	else:
		framework_status_label.text = "使用免安装版自带运行核心；也可以选择更新后的 node.exe 和 Harness 入口文件。"

func populate_execution_framework_settings() -> void:
	if not execution_framework_config:
		framework_status_label.text = "执行框架配置目录还没有准备好。"
		return
	var settings: Dictionary = execution_framework_config.load_config()
	select_option_by_metadata(framework_mode_select, str(settings.get("mode", "bundled")))
	framework_name_input.text = str(settings.get("name", "DeepSeek Harness"))
	framework_auto_start_check.button_pressed = bool(settings.get("auto_start", true))
	framework_core_url_input.text = str(settings.get("core_url", ExecutionFrameworkConfig.DEFAULT_CORE_URL))
	framework_interaction_url_input.text = str(settings.get("interaction_url", ExecutionFrameworkConfig.DEFAULT_INTERACTION_URL))
	framework_executable_input.text = str(settings.get("executable_path", ""))
	framework_launcher_input.text = str(settings.get("launcher_path", ""))
	var arguments: Array = settings.get("launch_arguments", []) if settings.get("launch_arguments", []) is Array else []
	framework_arguments_input.text = "\n".join(arguments)
	on_framework_mode_selected(framework_mode_select.selected)
	var version := bundled_framework_version()
	var version_text := " · 内置版本 %s" % version if not version.is_empty() else ""
	refresh_framework_update_ui()
	framework_status_label.text = "%s：%s%s" % [framework_name_input.text, harness_status_detail, version_text]
	set_framework_status_color(harness_status_state == "ready" or harness_status_state in ["starting", "configured"])

func execution_framework_form_value() -> Dictionary:
	var arguments: Array[String] = []
	for raw_line in framework_arguments_input.text.replace("\r", "").split("\n"):
		var argument := str(raw_line).strip_edges()
		if not argument.is_empty():
			arguments.append(argument)
	return {
		"name": framework_name_input.text,
		"mode": selected_framework_mode(),
		"adapter": "blue_whale_v1",
		"auto_start": framework_auto_start_check.button_pressed,
		"core_url": framework_core_url_input.text,
		"interaction_url": framework_interaction_url_input.text,
		"executable_path": framework_executable_input.text,
		"launcher_path": framework_launcher_input.text,
		"launch_arguments": arguments
	}

func save_execution_framework_form() -> Dictionary:
	if not execution_framework_config:
		return {"ok": false, "message": "执行框架配置目录还没有准备好。"}
	var result: Dictionary = execution_framework_config.save_config(execution_framework_form_value())
	framework_status_label.text = str(result.get("message", "配置保存完成。"))
	set_framework_status_color(bool(result.get("ok", false)))
	return result

func save_and_restart_execution_framework() -> void:
	if workflow_blocks_settings_change():
		return
	var result := save_execution_framework_form()
	if not bool(result.get("ok", false)):
		return
	if not agent_bridge:
		framework_status_label.text = "配置已保存，但执行框架通信桥尚未加载。"
		set_framework_status_color(false)
		return
	framework_status_label.text = "正在按新配置重启执行框架……"
	set_framework_status_color(true)
	agent_bridge.shutdown()
	await get_tree().process_frame
	var settings: Dictionary = execution_framework_config.load_config()
	agent_bridge.configure(runtime_project_directory(), soul_store.root_path, settings, resolved_network_settings())
	await agent_bridge.start()
	framework_status_label.text = harness_status_detail
	set_framework_status_color(harness_status_state == "ready" or harness_status_state == "configured")
	show_message("执行框架配置已应用。", 3.0)
	agent_event.emit({"type": "settings.saved", "section": "execution_framework", "mode": selected_framework_mode()})

func test_execution_framework_connection() -> void:
	if not agent_bridge:
		framework_status_label.text = "执行框架通信桥尚未加载。"
		set_framework_status_color(false)
		return
	framework_status_label.text = "正在测试核心与审批交互通道……"
	set_framework_status_color(true)
	var result: Dictionary = await agent_bridge.test_connection()
	framework_status_label.text = str(result.get("message", "测试完成。"))
	set_framework_status_color(bool(result.get("ok", false)))

func reset_execution_framework_form() -> void:
	if not execution_framework_config:
		return
	var defaults: Dictionary = execution_framework_config.default_config()
	select_option_by_metadata(framework_mode_select, str(defaults["mode"]))
	framework_name_input.text = str(defaults["name"])
	framework_auto_start_check.button_pressed = bool(defaults["auto_start"])
	framework_core_url_input.text = str(defaults["core_url"])
	framework_interaction_url_input.text = str(defaults["interaction_url"])
	framework_executable_input.clear()
	framework_launcher_input.clear()
	framework_arguments_input.clear()
	on_framework_mode_selected(framework_mode_select.selected)
	framework_status_label.text = "已恢复表单默认值；点击“保存并重启”后生效。"
	set_framework_status_color(true)

func choose_framework_executable() -> void:
	if framework_executable_dialog:
		popup_native_file_dialog(framework_executable_dialog, 0.72)

func choose_framework_launcher() -> void:
	if framework_launcher_dialog:
		popup_native_file_dialog(framework_launcher_dialog, 0.72)

func on_framework_executable_selected(path: String) -> void:
	finish_native_file_dialog()
	framework_executable_input.text = path.replace("\\", "/")

func on_framework_launcher_selected(path: String) -> void:
	finish_native_file_dialog()
	framework_launcher_input.text = path.replace("\\", "/")

func set_framework_status_color(ok: bool) -> void:
	if framework_status_label:
		framework_status_label.add_theme_color_override("font_color", Color("16836b") if ok else Color("c44d5b"))

func bundled_framework_version() -> String:
	var path := ProjectSettings.globalize_path("res://runtime/harness/app/runtime-version.json")
	if not FileAccess.file_exists(path):
		return ""
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return ""
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	return str(parsed.get("version", "")) if parsed is Dictionary else ""

# 技能库是独立的原生窗口。这里仅提供技能包管理界面；技能内容由用户决定，
# 默认不附带任何业务技能，也不会在导入后自动启用或执行脚本。
func build_skill_library_panel() -> void:
	skill_library_window = create_utility_window("梁鲸 · 本地技能库", SKILL_LIBRARY_WINDOW_SIZE)
	skill_library_window.close_requested.connect(close_skill_library)
	skill_library_panel = PanelContainer.new()
	skill_library_panel.name = "LocalSkillLibrary"
	skill_library_panel.size = Vector2(812, 698)
	skill_library_panel.visible = false
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.955, 0.982, 1.0, 0.99)
	panel_style.border_color = Color("65b9ed")
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(22)
	panel_style.content_margin_left = 20
	panel_style.content_margin_right = 20
	panel_style.content_margin_top = 17
	panel_style.content_margin_bottom = 18
	panel_style.shadow_color = Color(0.03, 0.16, 0.34, 0.28)
	panel_style.shadow_size = 18
	skill_library_panel.add_theme_stylebox_override("panel", panel_style)
	skill_library_window.add_child(skill_library_panel)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 9)
	skill_library_panel.add_child(content)
	var header := HBoxContainer.new()
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.tooltip_text = "按住拖动技能库窗口"
	header.gui_input.connect(on_utility_titlebar_input.bind(skill_library_window))
	content.add_child(header)
	var title := Label.new()
	title.text = "●  本地技能库"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("163f67"))
	title.add_theme_font_size_override("font_size", 20)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	header.add_child(title)
	var close_button := Button.new()
	close_button.text = "×"
	close_button.custom_minimum_size = Vector2(38, 34)
	close_button.add_theme_font_size_override("font_size", 22)
	apply_settings_button_style(close_button, false)
	close_button.pressed.connect(close_skill_library)
	header.add_child(close_button)

	var intro := Label.new()
	intro.text = "技能由当前电脑的用户自己创建和导入；Harness 升级不会修改这里。导入后默认停用。"
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	intro.add_theme_color_override("font_color", Color("527493"))
	intro.add_theme_font_size_override("font_size", 13)
	content.add_child(intro)

	var toolbar := HBoxContainer.new()
	toolbar.add_theme_constant_override("separation", 7)
	content.add_child(toolbar)
	skill_search_input = LineEdit.new()
	skill_search_input.placeholder_text = "搜索本机技能"
	skill_search_input.custom_minimum_size = Vector2(210, 38)
	skill_search_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	apply_settings_field_style(skill_search_input)
	skill_search_input.text_changed.connect(func(_text: String) -> void: refresh_skill_library_list())
	toolbar.add_child(skill_search_input)
	for definition in [
		{"text": "刷新", "tip": "重新扫描技能库目录", "action": refresh_skill_library},
		{"text": "打开目录", "tip": "打开本机技能库文件夹", "action": open_skill_library_folder},
		{"text": "导入文件夹", "tip": "选择一个包含 SKILL.md 的技能文件夹", "action": choose_skill_folder}
	]:
		var button := Button.new()
		button.text = str(definition["text"])
		button.tooltip_text = str(definition["tip"])
		button.custom_minimum_size = Vector2(86, 38)
		apply_settings_button_style(button, false)
		var toolbar_action: Callable = definition["action"]
		button.pressed.connect(toolbar_action)
		toolbar.add_child(button)

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	content.add_child(body)
	var list_panel := PanelContainer.new()
	list_panel.custom_minimum_size = Vector2(248, 0)
	list_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var list_style := StyleBoxFlat.new()
	list_style.bg_color = Color(0.91, 0.965, 0.995, 0.72)
	list_style.border_color = Color(0.32, 0.68, 0.90, 0.35)
	list_style.set_border_width_all(1)
	list_style.set_corner_radius_all(14)
	list_style.content_margin_left = 8
	list_style.content_margin_right = 8
	list_style.content_margin_top = 8
	list_style.content_margin_bottom = 8
	list_panel.add_theme_stylebox_override("panel", list_style)
	body.add_child(list_panel)
	var skill_scroll := ScrollContainer.new()
	skill_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	skill_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	skill_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	# ScrollContainer 的最小尺寸会跟着内容一起长大。技能很多时，左侧列表会把整套
	# 面板的最小高度顶到窗口之外（实测达到 1748px），标题栏和工具栏被挤出屏幕，
	# 用户再也点不到关闭和导入。显式把最小高度归零，列表改为在可用高度内滚动。
	skill_scroll.custom_minimum_size = Vector2(0, 0)
	list_panel.add_child(skill_scroll)
	skill_list_box = VBoxContainer.new()
	skill_list_box.custom_minimum_size = Vector2(220, 0)
	skill_list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	skill_list_box.add_theme_constant_override("separation", 6)
	skill_scroll.add_child(skill_list_box)

	var detail_panel := PanelContainer.new()
	detail_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var detail_style := StyleBoxFlat.new()
	detail_style.bg_color = Color(1, 1, 1, 0.72)
	detail_style.border_color = Color(0.32, 0.68, 0.90, 0.35)
	detail_style.set_border_width_all(1)
	detail_style.set_corner_radius_all(14)
	detail_style.content_margin_left = 16
	detail_style.content_margin_right = 16
	detail_style.content_margin_top = 14
	detail_style.content_margin_bottom = 14
	detail_panel.add_theme_stylebox_override("panel", detail_style)
	body.add_child(detail_panel)
	var detail_box := VBoxContainer.new()
	detail_box.add_theme_constant_override("separation", 8)
	detail_panel.add_child(detail_box)
	skill_detail_title = Label.new()
	skill_detail_title.text = "选择一项技能"
	skill_detail_title.add_theme_color_override("font_color", Color("17496f"))
	skill_detail_title.add_theme_font_size_override("font_size", 19)
	detail_box.add_child(skill_detail_title)
	skill_detail_meta = Label.new()
	skill_detail_meta.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	skill_detail_meta.add_theme_color_override("font_color", Color("557792"))
	skill_detail_meta.add_theme_font_size_override("font_size", 12)
	detail_box.add_child(skill_detail_meta)
	var switches := HBoxContainer.new()
	switches.add_theme_constant_override("separation", 16)
	detail_box.add_child(switches)
	skill_enable_check = CheckButton.new()
	skill_enable_check.text = "启用技能"
	style_knowledge_check(skill_enable_check)
	skill_enable_check.disabled = true
	skill_enable_check.toggled.connect(on_skill_enabled_toggled)
	switches.add_child(skill_enable_check)
	skill_auto_check = CheckButton.new()
	skill_auto_check.text = "允许自动匹配"
	style_knowledge_check(skill_auto_check)
	skill_auto_check.disabled = true
	skill_auto_check.toggled.connect(on_skill_auto_toggled)
	switches.add_child(skill_auto_check)
	skill_model_context_check = CheckButton.new()
	skill_model_context_check.text = "允许交给模型"
	skill_model_context_check.tooltip_text = "开启后，命中此技能时会把 SKILL.md 说明发送给当前配置的模型；默认关闭"
	style_knowledge_check(skill_model_context_check)
	skill_model_context_check.disabled = true
	skill_model_context_check.toggled.connect(on_skill_model_context_toggled)
	switches.add_child(skill_model_context_check)
	skill_detail_text = RichTextLabel.new()
	skill_detail_text.bbcode_enabled = false
	skill_detail_text.scroll_active = true
	skill_detail_text.custom_minimum_size = Vector2(0, 330)
	skill_detail_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	skill_detail_text.add_theme_color_override("default_color", Color("244f70"))
	skill_detail_text.add_theme_font_size_override("normal_font_size", 13)
	var text_style := StyleBoxFlat.new()
	text_style.bg_color = Color(0.94, 0.978, 1.0, 0.65)
	text_style.set_corner_radius_all(11)
	text_style.content_margin_left = 12
	text_style.content_margin_right = 12
	text_style.content_margin_top = 10
	text_style.content_margin_bottom = 10
	skill_detail_text.add_theme_stylebox_override("normal", text_style)
	detail_box.add_child(skill_detail_text)
	var detail_actions := HBoxContainer.new()
	detail_actions.add_theme_constant_override("separation", 8)
	detail_box.add_child(detail_actions)
	var template_button := Button.new()
	template_button.text = "新建空白模板"
	template_button.tooltip_text = "创建一份可编辑的 skill.json 和 SKILL.md，不包含任何预设业务内容"
	template_button.custom_minimum_size = Vector2(132, 38)
	apply_settings_button_style(template_button, false)
	template_button.pressed.connect(create_blank_skill_template)
	detail_actions.add_child(template_button)
	var selected_folder_button := Button.new()
	selected_folder_button.text = "打开所选目录"
	selected_folder_button.custom_minimum_size = Vector2(126, 38)
	apply_settings_button_style(selected_folder_button, false)
	selected_folder_button.pressed.connect(open_selected_skill_folder)
	detail_actions.add_child(selected_folder_button)

	skill_status_label = Label.new()
	skill_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	skill_status_label.add_theme_color_override("font_color", Color("3a718e"))
	skill_status_label.add_theme_font_size_override("font_size", 12)
	content.add_child(skill_status_label)

	skill_import_dialog = FileDialog.new()
	skill_import_dialog.access = FileDialog.ACCESS_FILESYSTEM
	skill_import_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	skill_import_dialog.use_native_dialog = true
	skill_import_dialog.dir_selected.connect(on_skill_folder_selected)
	skill_import_dialog.canceled.connect(finish_native_file_dialog)
	add_child(skill_import_dialog)

func toggle_skill_library() -> void:
	if not skill_library_panel:
		return
	if skill_library_panel.visible:
		close_skill_library()
		return
	hide_interaction_hint()
	open_utility_panel(skill_library_panel, SKILL_LIBRARY_WINDOW_SIZE, Vector2(812, 698))
	refresh_skill_library()
	skill_search_input.grab_focus()
	agent_event.emit({"type": "skills.open", "source": "cabinet.right_door"})

func close_skill_library() -> void:
	close_utility_panel(skill_library_panel)

func refresh_skill_library() -> void:
	if not skill_registry:
		skill_status_label.text = "本地技能库尚未准备好。"
		return
	skill_registry.refresh()
	refresh_skill_library_list()

func refresh_skill_library_list() -> void:
	if not skill_list_box or not skill_registry:
		return
	for child in skill_list_box.get_children():
		child.queue_free()
	var skills: Array = skill_registry.list_skills(skill_search_input.text if skill_search_input else "")
	if skills.is_empty():
		var empty := Label.new()
		empty.text = "还没有技能。\n\n可以导入文件夹，或者新建一份空白模板。"
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		empty.add_theme_color_override("font_color", Color("6b8aa3"))
		empty.add_theme_font_size_override("font_size", 13)
		skill_list_box.add_child(empty)
		selected_skill_id = ""
		render_skill_detail({})
	else:
		var selected_still_exists := false
		for skill_value in skills:
			var skill: Dictionary = skill_value
			var skill_id := str(skill.get("id", ""))
			if skill_id == selected_skill_id:
				selected_still_exists = true
			var button := Button.new()
			var state_mark := "●" if bool(skill.get("enabled", false)) else "○"
			var invalid_mark := "  ⚠" if not bool(skill.get("valid", false)) else ""
			button.text = "%s  %s%s\n%s" % [state_mark, str(skill.get("name", "未命名技能")), invalid_mark, str(skill.get("description", "")).left(28)]
			button.alignment = HORIZONTAL_ALIGNMENT_LEFT
			button.custom_minimum_size = Vector2(0, 60)
			button.add_theme_font_size_override("font_size", 12)
			apply_settings_button_style(button, skill_id == selected_skill_id)
			button.pressed.connect(select_skill.bind(skill_id))
			skill_list_box.add_child(button)
		if not selected_still_exists:
			selected_skill_id = str((skills[0] as Dictionary).get("id", ""))
		render_skill_detail(skill_registry.get_skill(selected_skill_id))
	var enabled_count: int = int(skill_registry.enabled_skills().size())
	skill_status_label.text = "本机共 %d 项技能，已启用 %d 项。只会把本轮命中的启用技能交给 Harness。" % [skill_registry.cached_skills.size(), enabled_count]

func select_skill(skill_id: String) -> void:
	selected_skill_id = skill_id
	refresh_skill_library_list()

func render_skill_detail(skill: Dictionary) -> void:
	if skill.is_empty():
		skill_detail_title.text = "技能库是空的"
		skill_detail_meta.text = "用户可以自己决定安装哪些技能。"
		skill_detail_text.text = "每个技能文件夹至少包含 SKILL.md；可选 skill.json 用来声明名称、版本、触发词和权限。\n\n导入后的技能默认停用，启用后也不能绕过 Harness 的工具授权。"
		skill_enable_check.set_pressed_no_signal(false)
		skill_auto_check.set_pressed_no_signal(false)
		skill_model_context_check.set_pressed_no_signal(false)
		skill_enable_check.disabled = true
		skill_auto_check.disabled = true
		skill_model_context_check.disabled = true
		return
	var valid := bool(skill.get("valid", false))
	skill_detail_title.text = str(skill.get("name", "未命名技能"))
	skill_detail_meta.text = "ID：%s  ·  版本：%s\n触发词：%s\n声明权限：%s%s" % [
		str(skill.get("id", "")), str(skill.get("version", "0.1.0")),
		"、".join(skill.get("triggers", [])) if not (skill.get("triggers", []) as Array).is_empty() else "未设置",
		"、".join(skill.get("permissions", [])) if not (skill.get("permissions", []) as Array).is_empty() else "未声明",
		"\n格式错误：%s" % str(skill.get("error", "")) if not valid else ""
	]
	skill_detail_text.text = str(skill.get("instructions", "")) if valid else "技能包未通过格式检查，无法启用。"
	skill_enable_check.set_pressed_no_signal(bool(skill.get("enabled", false)))
	skill_auto_check.set_pressed_no_signal(bool(skill.get("auto_invoke", false)))
	skill_model_context_check.set_pressed_no_signal(bool(skill.get("allow_model_context", false)))
	skill_enable_check.disabled = not valid
	skill_auto_check.disabled = not valid or not bool(skill.get("enabled", false))
	skill_model_context_check.disabled = not valid or not bool(skill.get("enabled", false))

func on_skill_enabled_toggled(enabled: bool) -> void:
	if selected_skill_id.is_empty() or not skill_registry:
		return
	skill_registry.set_enabled(selected_skill_id, enabled)
	if not enabled:
		skill_registry.set_auto_invoke(selected_skill_id, false)
		skill_registry.set_model_context_allowed(selected_skill_id, false)
	refresh_skill_library_list()
	skill_status_label.text = "技能已%s；设置只保存在当前电脑。" % ("启用" if enabled else "停用")

func on_skill_auto_toggled(enabled: bool) -> void:
	if selected_skill_id.is_empty() or not skill_registry:
		return
	skill_registry.set_auto_invoke(selected_skill_id, enabled)
	refresh_skill_library_list()
	skill_status_label.text = "自动匹配已%s。也可以在对话中使用 @技能名 明确调用。" % ("开启" if enabled else "关闭")

func on_skill_model_context_toggled(allowed: bool) -> void:
	if selected_skill_id.is_empty() or not skill_registry:
		return
	skill_registry.set_model_context_allowed(selected_skill_id, allowed)
	refresh_skill_library_list()
	skill_status_label.text = (
		"已允许：命中该技能时会把 SKILL.md 发送给当前配置的模型；Harness 审批仍然有效。"
		if allowed else "已关闭：该技能内容只保存在本机，不会进入模型任务。"
	)
	set_skill_status_color(true)

func open_skill_library_folder() -> void:
	if skill_registry:
		open_local_file_browser(skill_registry.skills_path, "技能库")

func open_selected_skill_folder() -> void:
	if selected_skill_id.is_empty() or not skill_registry:
		return
	var skill: Dictionary = skill_registry.get_skill(selected_skill_id)
	var path := str(skill.get("path", ""))
	if not path.is_empty():
		open_local_file_browser(path, str(skill.get("name", selected_skill_id)))

func choose_skill_folder() -> void:
	if skill_import_dialog:
		popup_native_file_dialog(skill_import_dialog, 0.78)

func on_skill_folder_selected(path: String) -> void:
	finish_native_file_dialog()
	if not skill_registry:
		return
	var result: Dictionary = skill_registry.import_skill_folder(path)
	skill_status_label.text = str(result.get("message", result.get("error", "导入完成")))
	set_skill_status_color(bool(result.get("ok", false)))
	refresh_skill_library_list()

func create_blank_skill_template() -> void:
	if not skill_registry:
		return
	var result: Dictionary = skill_registry.create_blank_template()
	if bool(result.get("ok", false)):
		selected_skill_id = str(result.get("id", ""))
		refresh_skill_library_list()
		open_local_file_browser(str(result.get("path", skill_registry.skills_path)), "新技能模板")
		skill_status_label.text = "已创建空白技能模板；填写完成后回到这里点击“刷新”。"
	else:
		skill_status_label.text = str(result.get("error", "模板创建失败"))
	set_skill_status_color(bool(result.get("ok", false)))

func set_skill_status_color(ok: bool) -> void:
	if skill_status_label:
		skill_status_label.add_theme_color_override("font_color", Color("16836b") if ok else Color("c44d5b"))

func refresh_framework_update_ui() -> void:
	if framework_update_version_label:
		var version := bundled_framework_version()
		framework_update_version_label.text = "内置版本：%s" % (version if not version.is_empty() else "未知")
	if framework_update_button:
		framework_update_button.disabled = framework_update_busy or selected_framework_mode() != "bundled"
		framework_update_button.text = "升级中…" if framework_update_busy else "检查并升级"

func check_and_update_bundled_harness() -> void:
	if workflow_blocks_settings_change():
		return
	if framework_update_busy:
		return
	if selected_framework_mode() != "bundled":
		framework_status_label.text = "一键升级只用于免安装版内置 Harness；自定义框架请使用其自己的升级方式。"
		set_framework_status_color(false)
		return
	if OS.get_name() != "Windows":
		framework_status_label.text = "当前一键升级器仅支持 Windows 免安装版。"
		set_framework_status_color(false)
		return
	var updater_path := ProjectSettings.globalize_path("res://runtime/harness/updater/update_harness.ps1")
	if not FileAccess.file_exists(updater_path):
		framework_status_label.text = "升级组件不完整，请重新取得免安装版。"
		set_framework_status_color(false)
		return
	var system_root := OS.get_environment("SystemRoot")
	var powershell := system_root.path_join("System32/WindowsPowerShell/v1.0/powershell.exe")
	if not FileAccess.file_exists(powershell):
		framework_status_label.text = "Windows 升级服务不可用。"
		set_framework_status_color(false)
		return
	framework_update_run_id = "%s-%s" % [str(Time.get_unix_time_from_system()), str(randi_range(1000, 9999))]
	var project_root := ProjectSettings.globalize_path("res://").trim_suffix("/").trim_suffix("\\")
	var arguments := PackedStringArray([
		"-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
		"-File", updater_path, "-ProjectRoot", project_root, "-RunId", framework_update_run_id
	])
	framework_update_process_id = OS.create_process(powershell, arguments, false)
	if framework_update_process_id <= 0:
		framework_status_label.text = "升级服务启动失败。"
		set_framework_status_color(false)
		return
	framework_update_busy = true
	refresh_framework_update_ui()
	framework_status_label.text = "正在连接官方软件源检查新版本……"
	set_framework_status_color(true)
	monitor_harness_update(framework_update_run_id)

func monitor_harness_update(run_id: String) -> void:
	var last_message := ""
	while framework_update_process_id > 0 and OS.is_process_running(framework_update_process_id):
		await get_tree().create_timer(0.75).timeout
		var live_status := read_harness_update_status(run_id)
		var message := str(live_status.get("message", ""))
		if not message.is_empty() and message != last_message:
			last_message = message
			framework_status_label.text = message
			set_framework_status_color(str(live_status.get("phase", "")) != "failed")
	var final_status := read_harness_update_status(run_id)
	framework_update_process_id = -1
	var ok := bool(final_status.get("ok", false)) and bool(final_status.get("done", false))
	var touched_runtime := bool(final_status.get("touched_runtime", false))
	if touched_runtime and agent_bridge:
		framework_status_label.text = "升级文件已就位，正在重新连接执行框架……"
		set_framework_status_color(true)
		agent_bridge.shutdown()
		await get_tree().create_timer(0.35).timeout
		var settings: Dictionary = execution_framework_config.load_config()
		agent_bridge.configure(runtime_project_directory(), soul_store.root_path, settings, resolved_network_settings())
		await agent_bridge.start()
	framework_update_busy = false
	refresh_framework_update_ui()
	if ok:
		var version := str(final_status.get("version", bundled_framework_version()))
		var updated := bool(final_status.get("updated", false))
		framework_status_label.text = "Harness 已升级到 %s，并通过安全检查。" % version if updated else "Harness %s 已是最新版。" % version
		set_framework_status_color(true)
		show_message("执行框架升级完成。" if updated else "执行框架已是最新版。", 3.0)
	else:
		framework_status_label.text = str(final_status.get("message", "升级没有完成，原版本保持不变。"))
		set_framework_status_color(false)
		show_message("升级失败，已保留或恢复原版本。", 4.0)
	framework_update_run_id = ""

func read_harness_update_status(run_id: String) -> Dictionary:
	var path := ProjectSettings.globalize_path("res://runtime/harness/update-status.json")
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {}
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary and str(parsed.get("run_id", "")) == run_id:
		return parsed
	return {}

func selected_network_mode() -> String:
	if not network_mode_select or network_mode_select.selected < 0:
		return "system"
	return str(network_mode_select.get_item_metadata(network_mode_select.selected))

func toggle_network_settings() -> void:
	if not network_settings_panel:
		return
	if network_settings_panel.visible:
		close_network_settings()
		return
	hide_interaction_hint()
	open_utility_panel(network_settings_panel, NETWORK_SETTINGS_WINDOW_SIZE, Vector2(490, 560))
	populate_network_settings()
	position_utility_panel(network_settings_panel, Vector2(490, 560))
	agent_event.emit({"type": "settings.open", "section": "network"})

func close_network_settings() -> void:
	close_utility_panel(network_settings_panel)

func populate_network_settings() -> void:
	if not network_config:
		network_status_label.text = "网络配置目录还没有准备好。"
		return
	var settings: Dictionary = network_config.load_config()
	select_option_by_metadata(network_mode_select, str(settings.get("mode", "system")))
	var saved_proxy_url := str(settings.get("proxy_url", ""))
	var saved_proxy_parts: Dictionary = network_config.proxy_host_port(saved_proxy_url)
	select_option_by_metadata(network_proxy_scheme_select, "https" if saved_proxy_url.begins_with("https://") else "http")
	network_proxy_input.text = str(saved_proxy_parts.get("host", ""))
	var saved_proxy_port := int(saved_proxy_parts.get("port", -1))
	network_proxy_port_input.value = saved_proxy_port if saved_proxy_port > 0 else 10808
	network_no_proxy_input.text = str(settings.get("no_proxy", "localhost,127.0.0.1,::1"))
	refresh_network_detection()
	on_network_mode_selected(network_mode_select.selected)

func on_network_mode_selected(_index: int) -> void:
	if not network_proxy_input:
		return
	var custom_mode := selected_network_mode() == "custom"
	network_proxy_scheme_select.disabled = not custom_mode
	network_proxy_input.editable = custom_mode
	network_proxy_port_input.editable = custom_mode
	network_proxy_input.modulate = Color.WHITE if custom_mode else Color(0.82, 0.87, 0.91, 1.0)
	network_proxy_port_input.modulate = Color.WHITE if custom_mode else Color(0.82, 0.87, 0.91, 1.0)

func refresh_network_detection() -> void:
	if not network_config or not network_detected_label:
		return
	var detected: Dictionary = network_config.detect_system_proxy()
	network_detected_label.text = str(detected.get("detail", "没有检测到系统代理。"))
	network_detected_label.add_theme_color_override(
		"font_color",
		Color("287e69") if bool(detected.get("enabled", false)) else Color("8a6470")
	)

func save_network_settings() -> void:
	if workflow_blocks_settings_change():
		return
	if not network_config:
		network_status_label.text = "网络配置目录还没有准备好。"
		return
	var proxy_scheme := "http"
	if network_proxy_scheme_select.selected >= 0:
		proxy_scheme = str(network_proxy_scheme_select.get_item_metadata(network_proxy_scheme_select.selected))
	var proxy_host := network_proxy_input.text.strip_edges().trim_prefix("http://").trim_prefix("https://").trim_suffix("/")
	var custom_proxy_url := "%s://%s:%d" % [proxy_scheme, proxy_host, int(network_proxy_port_input.value)]
	var result: Dictionary = network_config.save_config({
		"mode": selected_network_mode(),
		"proxy_url": custom_proxy_url,
		"no_proxy": network_no_proxy_input.text
	})
	network_status_label.text = str(result.get("message", "网络配置保存完成。"))
	network_status_label.add_theme_color_override("font_color", Color("287e69") if bool(result.get("ok", false)) else Color("c04b57"))
	if not bool(result.get("ok", false)):
		return
	configure_http_request_proxy(api_http_request)
	await restart_agent_bridge_with_current_settings()
	var resolved: Dictionary = result.get("resolved", {}) if result.get("resolved", {}) is Dictionary else {}
	var bridge_detail := harness_status_detail if not harness_status_detail.is_empty() else "Harness 已重启"
	network_status_label.text = "%s %s" % [str(resolved.get("detail", "网络配置已应用。")), bridge_detail]
	show_message("网络配置已应用到模型与 Harness。", 4.0)
	agent_event.emit({"type": "settings.saved", "section": "network", "mode": selected_network_mode()})

func restart_agent_bridge_with_current_settings() -> void:
	if workflow_blocks_settings_change():
		return
	if not agent_bridge or not soul_store:
		return
	agent_bridge.shutdown()
	await get_tree().process_frame
	var framework_settings: Dictionary = execution_framework_config.load_config() if execution_framework_config else {}
	agent_bridge.configure(runtime_project_directory(), soul_store.root_path, framework_settings, resolved_network_settings())
	await agent_bridge.start()

func configure_http_request_proxy(request: HTTPRequest) -> void:
	# [DSH] 实现移到 network_config.apply_to_request 一处，换装生成也走它。
	NetworkConfigStore.apply_to_request(request, resolved_network_settings())

func toggle_api_settings() -> void:
	if not api_settings_panel:
		return
	if api_settings_panel.visible:
		close_api_settings()
		return
	hide_interaction_hint()
	open_utility_panel(api_settings_panel, MODEL_SETTINGS_WINDOW_SIZE, Vector2(460, 610))
	populate_api_settings()
	position_utility_panel(api_settings_panel, Vector2(460, 610))
	if deepseek_config and deepseek_config.has_api_key(current_api_role()):
		api_base_url_input.grab_focus()
	else:
		api_key_input.grab_focus()
	agent_event.emit({"type": "settings.open", "section": "models"})

func close_api_settings() -> void:
	close_utility_panel(api_settings_panel)

func open_api_key_import() -> void:
	# 只读取本机文件；真正写入加密存储仍需用户在模型中心点击“保存在本机”。
	hide_interaction_hint()
	var start_directory := OS.get_environment("USERPROFILE")
	if start_directory.is_empty():
		start_directory = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	select_local_file_with_browser(
		start_directory,
		"选择 API Key 文件",
		["txt", "env", "json", "key"],
		on_api_key_file_selected
	)

func on_api_key_file_selected(path: String) -> void:
	if not FileAccess.file_exists(path):
		show_message("没有找到所选 Key 文件。", 3.5)
		return
	var imported_key := ""
	var import_description := path.get_file()
	# 用户可以直接选择梁鲸保存的 chat_model.key / vision_model.key。
	# 也可以选择“模型配置.json”，程序会按当前能力位置读取同目录的加密 Key。
	if deepseek_config and path.get_extension().to_lower() == "key":
		imported_key = normalize_imported_api_key(deepseek_config.load_api_key_from_path(path))
	if imported_key.is_empty() and path.get_extension().to_lower() == "json":
		var json_text := FileAccess.get_file_as_string(path)
		var parsed = JSON.parse_string(json_text)
		if parsed is Dictionary and (parsed.has("profiles") or str(parsed.get("key_protection", "")).begins_with("device-bound")):
			var sibling_key_path := path.get_base_dir().path_join("%s_model.key" % current_api_role())
			if deepseek_config and FileAccess.file_exists(sibling_key_path):
				imported_key = normalize_imported_api_key(deepseek_config.load_api_key_from_path(sibling_key_path))
				import_description = "%s + %s" % [path.get_file(), sibling_key_path.get_file()]
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		show_message("无法读取所选 Key 文件。", 3.5)
		return
	var file_length := int(file.get_length())
	if file_length <= 0 or file_length > 1024 * 1024:
		file.close()
		show_message("Key 文件为空或超过 1 MB。", 4.0)
		return
	var source_text := file.get_as_text() if imported_key.is_empty() else ""
	file.close()
	if imported_key.is_empty():
		imported_key = extract_api_key_from_text(source_text)
	if imported_key.is_empty():
		show_message("没有识别到有效的 API Key。支持纯文本、.env、JSON，以及本机生成的梁鲸加密 Key 文件。", 6.0)
		return
	if not api_settings_panel.visible:
		toggle_api_settings()
	api_key_input.text = imported_key
	api_key_input.caret_column = imported_key.length()
	api_key_input.grab_focus()
	var role_name := "视觉模型" if current_api_role() == "vision" else "对话模型"
	api_test_status.text = "已从 %s 读取 Key，目标为%s；核对后请点击“保存在本机”。" % [import_description, role_name]
	set_api_status_color(true)
	show_message("Key 已载入模型中心，请确认后保存。", 4.0)
	agent_event.emit({"type": "settings.key_imported", "role": current_api_role(), "source": path.get_file()})

func extract_api_key_from_text(source_text: String) -> String:
	# JSON 支持 api_key/key 以及 chat、vision 等嵌套配置；不执行文件中的任何内容。
	var parsed = null
	if source_text.strip_edges().begins_with("{"):
		parsed = JSON.parse_string(source_text)
	if parsed is Dictionary:
		var json_key := find_api_key_in_dictionary(parsed, current_api_role(), 0)
		if not json_key.is_empty():
			return json_key
	var accepted_names := [
		"api_key", "apikey", "api-key", "key",
		"deepseek_api_key", "ark_api_key", "volcengine_api_key", "openai_api_key"
	]
	var plain_candidates: Array[String] = []
	for raw_line in source_text.replace("\r", "").split("\n"):
		var line := str(raw_line).strip_edges()
		if line.is_empty() or line.begins_with("#") or line.begins_with(";"):
			continue
		var separator := line.find("=")
		if separator < 0:
			separator = line.find(":")
		if separator > 0:
			var field_name := line.substr(0, separator).strip_edges().to_lower().trim_prefix("\"").trim_suffix("\"")
			if field_name in accepted_names:
				var named_key := normalize_imported_api_key(line.substr(separator + 1))
				if not named_key.is_empty():
					return named_key
		else:
			plain_candidates.append(line)
	if plain_candidates.size() == 1:
		return normalize_imported_api_key(plain_candidates[0])
	return ""

func find_api_key_in_dictionary(data: Dictionary, preferred_role: String, depth: int) -> String:
	if depth > 4:
		return ""
	if data.has(preferred_role) and data[preferred_role] is Dictionary:
		var role_key := find_api_key_in_dictionary(data[preferred_role], preferred_role, depth + 1)
		if not role_key.is_empty():
			return role_key
	for field_name in ["api_key", "apikey", "apiKey", "key", "DEEPSEEK_API_KEY", "ARK_API_KEY", "VOLCENGINE_API_KEY", "OPENAI_API_KEY"]:
		if data.has(field_name):
			var direct_key := normalize_imported_api_key(str(data[field_name]))
			if not direct_key.is_empty():
				return direct_key
	for child in data.values():
		if child is Dictionary:
			var nested_key := find_api_key_in_dictionary(child, preferred_role, depth + 1)
			if not nested_key.is_empty():
				return nested_key
	return ""

func normalize_imported_api_key(raw_value: String) -> String:
	var candidate := raw_value.strip_edges().trim_prefix("\"").trim_suffix("\"").trim_prefix("'").trim_suffix("'").strip_edges()
	var comment_position := candidate.find(" #")
	if comment_position > 0:
		candidate = candidate.substr(0, comment_position).strip_edges()
	if candidate.length() < 12 or candidate.length() > 512:
		return ""
	for whitespace in [" ", "\t", "\n", "\r"]:
		if candidate.contains(whitespace):
			return ""
	return candidate

func open_harness_console() -> void:
	open_harness_workspace()

func populate_api_settings() -> void:
	if not deepseek_config:
		api_test_status.text = "本地配置目录还没有准备好。"
		return
	var role := current_api_role()
	var settings: Dictionary = deepseek_config.get_profile(role)
	api_base_url_input.text = str(settings.get("base_url", ""))
	api_model_input.text = str(settings.get("model", ""))
	select_option_by_metadata(api_provider_select, str(settings.get("provider", "openai_compatible")))
	api_thinking_check.button_pressed = bool(settings.get("thinking", false))
	api_thinking_check.disabled = role == "vision"
	var orchestration: Dictionary = deepseek_config.get_orchestration()
	select_option_by_metadata(api_collaboration_select, str(orchestration.get("mode", "vision_then_chat")))
	api_key_input.clear()
	api_key_input.placeholder_text = "已加密保存 · 留空保持不变" if deepseek_config.has_api_key(role) else "粘贴该接口的 API Key"
	# 打开模型中心时直接恢复上次从接口读取并保存在本机的候选项。
	# “读取模型”只负责联网刷新，不再是展开下拉框的前置步骤。
	set_api_model_candidates(deepseek_config.get_model_candidates(role))
	var role_name := "视觉模型" if role == "vision" else "对话模型"
	if role == "chat" and harness_status_state == "ready":
		api_test_status.text = "本地核心已连接；已恢复 %d 个本地模型，读取模型可联网刷新。" % api_model_ids.size()
		set_api_status_color(true)
	elif role == "chat" and harness_status_state in ["starting", "offline"]:
		api_test_status.text = harness_status_detail
		set_api_status_color(true)
	else:
		api_test_status.text = "%s已载入；已恢复 %d 个本地模型，读取模型可联网刷新。" % [role_name, api_model_ids.size()]
		set_api_status_color(true)

func current_api_role() -> String:
	if not api_role_select or api_role_select.selected < 0:
		return "chat"
	return str(api_role_select.get_item_metadata(api_role_select.selected))

func selected_api_provider() -> String:
	if not api_provider_select or api_provider_select.selected < 0:
		return "openai_compatible"
	return str(api_provider_select.get_item_metadata(api_provider_select.selected))

func selected_api_collaboration() -> String:
	if not api_collaboration_select or api_collaboration_select.selected < 0:
		return "vision_then_chat"
	return str(api_collaboration_select.get_item_metadata(api_collaboration_select.selected))

func selected_api_model() -> String:
	return api_model_input.text.strip_edges()

func select_option_by_metadata(option: OptionButton, value: String) -> void:
	for index in range(option.item_count):
		if str(option.get_item_metadata(index)) == value:
			option.select(index)
			return

func on_api_role_selected(_index: int) -> void:
	populate_api_settings()

func on_api_provider_selected(_index: int) -> void:
	if selected_api_provider() == "deepseek":
		if api_base_url_input.text.strip_edges().is_empty():
			api_base_url_input.text = DeepSeekConfigStore.DEFAULT_BASE_URL
		if api_model_input.text.strip_edges().is_empty() and current_api_role() == "chat":
			api_model_input.text = DeepSeekConfigStore.DEFAULT_MODEL

func on_api_model_selected(index: int) -> void:
	if index >= 0 and index < api_model_ids.size():
		api_model_input.text = api_model_ids[index]
		update_api_model_popup_checks(index)
		api_test_status.text = "已选择模型：%s" % api_model_input.text
		set_api_status_color(true)

func set_api_model_candidates(model_ids: Array[String]) -> void:
	api_model_ids.clear()
	for value in model_ids:
		var model_id := str(value).strip_edges()
		if not model_id.is_empty() and not api_model_ids.has(model_id):
			api_model_ids.append(model_id)
	api_model_ids.sort()
	var model_popup := api_model_dropdown.get_popup()
	model_popup.clear()
	for index in range(api_model_ids.size()):
		model_popup.add_item(api_model_ids[index], index)
	api_model_dropdown.visible = not api_model_ids.is_empty()
	update_api_model_popup_checks(api_model_ids.find(api_model_input.text.strip_edges()))

func update_api_model_popup_checks(selected_index: int) -> void:
	var model_popup := api_model_dropdown.get_popup()
	for index in range(model_popup.item_count):
		model_popup.set_item_checked(index, index == selected_index)

func align_api_model_popup() -> void:
	# MenuButton 会在 about_to_popup 信号返回后再次使用箭头按钮定位弹层，
	# 因此等它完成默认定位，再覆盖为“模型 ID”输入框的最终屏幕坐标。
	call_deferred("align_api_model_popup_after_open")

func on_api_model_popup_visibility_changed() -> void:
	if api_model_dropdown and api_model_dropdown.get_popup().visible:
		call_deferred("align_api_model_popup_after_open")

func align_api_model_popup_after_open() -> void:
	# MenuButton 只是输入框右侧的箭头；弹层本身必须按完整输入框定位和定宽。
	if not api_model_input or not api_model_dropdown:
		return
	var model_popup := api_model_dropdown.get_popup()
	var input_rect := api_model_input.get_global_rect()
	var popup_width := maxi(180, roundi(input_rect.size.x))
	var popup_height := mini(320, maxi(44, api_model_ids.size() * 30 + 12))
	model_popup.min_size = Vector2i(popup_width, 0)
	model_popup.max_size = Vector2i(popup_width, 320)
	model_popup.size = Vector2i(popup_width, popup_height)
	# 模型中心是独立原生 Window，必须使用输入框所属窗口，不能使用桌宠主窗口。
	var host_window := api_model_input.get_window()
	var target := Vector2i(
		host_window.position.x + roundi(input_rect.position.x),
		host_window.position.y + roundi(input_rect.end.y)
	)
	var usable := DisplayServer.screen_get_usable_rect(host_window.current_screen)
	target.x = clampi(target.x, usable.position.x, usable.end.x - popup_width)
	if target.y + popup_height > usable.end.y:
		target.y = host_window.position.y + roundi(input_rect.position.y) - popup_height
	model_popup.position = target
	print("MODEL_POPUP_ALIGNED=", model_popup.position.x == target.x and model_popup.size.x == popup_width, " target=", target, " size=", model_popup.size)

func save_api_settings() -> bool:
	if workflow_blocks_settings_change():
		return false
	if not deepseek_config:
		api_test_status.text = "本地配置目录还没有准备好。"
		set_api_status_color(false)
		return false
	var role := current_api_role()
	var previous_profile: Dictionary = deepseek_config.get_profile(role)
	var saved_effort := "off"
	if role == "chat" and api_thinking_check.button_pressed:
		saved_effort = str(previous_profile.get("reasoning_effort", "high"))
		if saved_effort == "off":
			saved_effort = "high"
	var result: Dictionary = deepseek_config.save_profile(
		role,
		api_key_input.text,
		api_base_url_input.text,
		selected_api_model(),
		selected_api_provider(),
		api_thinking_check.button_pressed,
		saved_effort
	)
	var ok := bool(result.get("ok", false))
	if ok:
		ok = deepseek_config.save_orchestration(selected_api_collaboration())
		if not ok:
			result["message"] = "模型协作配置保存失败。"
	api_test_status.text = str(result.get("message", "配置保存完成。"))
	set_api_status_color(ok)
	if ok:
		api_key_input.clear()
		api_key_input.placeholder_text = "已加密保存 · 留空保持不变"
		agent_event.emit({"type": "settings.saved", "role": role, "provider": selected_api_provider(), "model": selected_api_model()})
		if role == "chat" and selected_api_provider() == "deepseek":
			populate_chat_model_controls()
			sync_chat_profile_to_harness()
	return ok

func test_api_connection() -> void:
	if not save_api_settings():
		return
	start_api_models_request("test")

func read_api_models() -> void:
	start_api_models_request("models")

func start_api_models_request(mode: String) -> void:
	if api_request_in_progress or api_http_request.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		return
	var role := current_api_role()
	var api_key := api_key_input.text.strip_edges()
	if api_key.is_empty():
		api_key = deepseek_config.load_api_key(role)
	if api_key.is_empty():
		api_test_status.text = "请先填写 API Key。"
		set_api_status_color(false)
		return
	var base_url := api_base_url_input.text.strip_edges().trim_suffix("/")
	if base_url.is_empty() or not deepseek_config.is_safe_base_url(base_url):
		api_test_status.text = "请填写有效的 HTTPS 接口地址。"
		set_api_status_color(false)
		return
	var endpoint := base_url + "/models"
	var headers := PackedStringArray([
		"Accept: application/json",
		"Authorization: Bearer %s" % api_key
	])
	api_request_mode = mode
	api_request_role = role
	api_request_in_progress = true
	api_test_button.disabled = true
	api_read_models_button.disabled = true
	api_test_status.text = "正在通过 Harness 读取模型……" if agent_bridge and agent_bridge.core_ready and mode == "models" else ("正在通过 Harness 测试接口……" if agent_bridge and agent_bridge.core_ready else ("正在读取模型列表……" if mode == "models" else "正在测试当前接口……"))
	set_api_status_color(true)
	# 优先使用 Harness 的 Node 网络通道。它与执行模型共用网络栈，避免
	# Godot HTTPS 在部分 Windows 网络环境中等待到超时。
	if agent_bridge and agent_bridge.core_ready:
		var bridge_result: Dictionary = await agent_bridge.fetch_model_list(base_url, api_key)
		api_request_in_progress = false
		api_test_button.disabled = false
		api_read_models_button.disabled = false
		if not bool(bridge_result.get("ok", false)):
			api_test_status.text = "连接失败：%s" % str(bridge_result.get("error", "Harness 网络通道没有返回结果"))
			set_api_status_color(false)
			return
		var bridge_value: Dictionary = bridge_result.get("value", {}) if bridge_result.get("value", {}) is Dictionary else {}
		var model_payload = bridge_value.get("data", {})
		if mode == "models":
			populate_models_from_payload(model_payload)
		else:
			api_test_status.text = "连接成功，当前模型服务已经准备好。"
			set_api_status_color(true)
			agent_event.emit({"type": "settings.connection_ok", "role": api_request_role, "provider": selected_api_provider()})
		return
	var request_error := api_http_request.request(endpoint, headers, HTTPClient.METHOD_GET)
	if request_error != OK:
		api_request_in_progress = false
		api_test_button.disabled = false
		api_read_models_button.disabled = false
		api_test_status.text = "连接未发出，请检查网络或接口地址。"
		set_api_status_color(false)

func on_api_test_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	api_request_in_progress = false
	api_test_button.disabled = false
	api_read_models_button.disabled = false
	print("MODEL_CONNECTION_RESULT=", result, " HTTP=", response_code)
	if result == HTTPRequest.RESULT_SUCCESS and response_code >= 200 and response_code < 300:
		if api_request_mode == "models":
			populate_models_from_response(body)
			return
		api_test_status.text = "连接成功，当前模型服务已经准备好。"
		set_api_status_color(true)
		agent_event.emit({"type": "settings.connection_ok", "role": api_request_role, "provider": selected_api_provider()})
		return
	if response_code == 401 or response_code == 403:
		api_test_status.text = "连接失败：API Key 无效或没有权限。"
	elif response_code > 0:
		api_test_status.text = "连接失败：服务返回 %d。" % response_code
	elif result == HTTPRequest.RESULT_TIMEOUT:
		api_test_status.text = "连接超时：接口 60 秒内没有响应，请稍后重试或检查代理。"
	elif result == HTTPRequest.RESULT_CANT_RESOLVE:
		api_test_status.text = "连接失败：无法解析接口域名，请检查 DNS。"
	elif result == HTTPRequest.RESULT_TLS_HANDSHAKE_ERROR:
		api_test_status.text = "连接失败：HTTPS 安全握手失败，请检查系统时间或代理。"
	elif result == HTTPRequest.RESULT_CANT_CONNECT:
		api_test_status.text = "连接失败：无法连接模型服务器，请检查网络或代理。"
	else:
		api_test_status.text = "连接失败：传输错误 %d，请检查网络和接口地址。" % result
	set_api_status_color(false)

func populate_models_from_response(body: PackedByteArray) -> void:
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	populate_models_from_payload(parsed)

func populate_models_from_payload(parsed) -> void:
	var raw_models: Array = []
	if parsed is Dictionary:
		if parsed.get("data", null) is Array:
			raw_models = parsed.get("data", [])
		elif parsed.get("models", null) is Array:
			raw_models = parsed.get("models", [])
	var model_ids: Array[String] = []
	for item in raw_models:
		var model_id := ""
		if item is Dictionary:
			model_id = str(item.get("id", item.get("name", ""))).strip_edges()
		else:
			model_id = str(item).strip_edges()
		if not model_id.is_empty() and not model_ids.has(model_id):
			model_ids.append(model_id)
	model_ids.sort()
	if model_ids.is_empty():
		api_test_status.text = "接口已连接，但没有返回可选择的模型；可以手填模型 ID。"
		set_api_status_color(false)
		return
	if deepseek_config:
		deepseek_config.save_model_candidates(api_request_role, model_ids)
		if api_request_role == "chat":
			populate_chat_model_controls()
	set_api_model_candidates(model_ids)
	var configured := api_model_input.text.strip_edges()
	if configured.is_empty():
		api_model_input.text = model_ids[0]
	update_api_model_popup_checks(api_model_ids.find(api_model_input.text.strip_edges()))
	api_test_status.text = "已读取 %d 个模型；可手填，或点击模型 ID 右侧箭头选择。" % model_ids.size()
	set_api_status_color(true)

func set_api_status_color(ok: bool) -> void:
	api_test_status.add_theme_color_override("font_color", Color("297a68") if ok else Color("b64755"))

func build_interaction_hint() -> void:
	interaction_hint = PanelContainer.new()
	interaction_hint.name = "InteractionHint"
	interaction_hint.size = Vector2(220, 38)
	interaction_hint.visible = false
	interaction_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	interaction_hint.z_index = 50
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.16, 0.31, 0.94)
	style.border_color = Color("70d6ff")
	style.set_border_width_all(1)
	style.set_corner_radius_all(12)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 7
	style.content_margin_bottom = 7
	style.shadow_color = Color(0.02, 0.10, 0.24, 0.30)
	style.shadow_size = 6
	interaction_hint.add_theme_stylebox_override("panel", style)
	agent_panel.add_child(interaction_hint)
	interaction_hint_label = Label.new()
	interaction_hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	interaction_hint_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	interaction_hint_label.add_theme_color_override("font_color", Color("e9f9ff"))
	interaction_hint_label.add_theme_font_size_override("font_size", 13)
	interaction_hint.add_child(interaction_hint_label)

func show_interaction_hint(text: String) -> void:
	if not interaction_hint or (api_settings_panel and api_settings_panel.visible):
		return
	interaction_hint_label.text = text
	interaction_hint.visible = true
	update_interaction_hint_position()

func hide_interaction_hint() -> void:
	if interaction_hint:
		interaction_hint.visible = false

func update_interaction_hint_position() -> void:
	if not interaction_hint or not interaction_hint.visible:
		return
	var mouse := get_viewport().get_mouse_position()
	var desired := mouse + Vector2(16, -48)
	var canvas_size := layout_canvas_size()
	desired.x = clampf(desired.x, 8.0, canvas_size.x - interaction_hint.size.x - 8.0)
	desired.y = clampf(desired.y, 8.0, canvas_size.y - interaction_hint.size.y - 8.0)
	interaction_hint.position = desired

func set_furniture_visible(visible: bool, animate: bool = false) -> void:
	if scene_transition_tween and scene_transition_tween.is_valid():
		scene_transition_tween.kill()
	scene_furniture_visible = visible
	set_furniture_controls_enabled(false)
	hide_interaction_hint()
	if not visible and api_settings_panel:
		api_settings_panel.visible = false
	if not visible and knowledge_import_panel:
		knowledge_import_panel.visible = false
	if not visible and knowledge_settings_panel:
		knowledge_settings_panel.visible = false
	if not visible and scene_input_dock:
		close_chat_workspace()
	if visible:
		enter_expanded_host_window("scene")
		agent_scene_background.visible = true
		cabinet_model.visible = true
		desk_model.visible = true
		if not animate:
			reset_furniture_transform()
			set_furniture_controls_enabled(true)
			return
		desk_model.position = DESK_MODEL_POSITION - Vector2(115, 0)
		cabinet_model.position = CABINET_MODEL_POSITION + Vector2(115, 0)
		desk_model.scale = Vector2.ONE * DESK_MODEL_SCALE * 0.90
		cabinet_model.scale = Vector2.ONE * CABINET_MODEL_SCALE * 0.90
		scene_transition_tween = create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		scene_transition_tween.set_parallel(true)
		scene_transition_tween.tween_property(desk_model, "position", DESK_MODEL_POSITION, 0.46)
		scene_transition_tween.tween_property(cabinet_model, "position", CABINET_MODEL_POSITION, 0.46)
		scene_transition_tween.tween_property(desk_model, "scale", Vector2.ONE * DESK_MODEL_SCALE, 0.46)
		scene_transition_tween.tween_property(cabinet_model, "scale", Vector2.ONE * CABINET_MODEL_SCALE, 0.46)
		scene_transition_tween.finished.connect(func() -> void:
			if scene_furniture_visible:
				set_furniture_controls_enabled(true)
		)
		return
	if not animate:
		finish_furniture_hide()
		return
	scene_transition_tween = create_tween().set_trans(Tween.TRANS_QUINT).set_ease(Tween.EASE_IN)
	scene_transition_tween.set_parallel(true)
	scene_transition_tween.tween_property(desk_model, "position", DESK_MODEL_POSITION - Vector2(125, 0), 0.28)
	scene_transition_tween.tween_property(cabinet_model, "position", CABINET_MODEL_POSITION + Vector2(125, 0), 0.28)
	scene_transition_tween.tween_property(desk_model, "scale", Vector2.ONE * DESK_MODEL_SCALE * 0.92, 0.28)
	scene_transition_tween.tween_property(cabinet_model, "scale", Vector2.ONE * CABINET_MODEL_SCALE * 0.92, 0.28)
	scene_transition_tween.finished.connect(func() -> void:
		if not scene_furniture_visible:
			finish_furniture_hide()
	)

func set_furniture_controls_enabled(enabled: bool) -> void:
	if agent_status:
		agent_status.visible = enabled
	for control in furniture_controls:
		control.visible = enabled

func reset_furniture_transform() -> void:
	desk_model.position = DESK_MODEL_POSITION
	cabinet_model.position = CABINET_MODEL_POSITION
	desk_model.scale = Vector2.ONE * DESK_MODEL_SCALE
	cabinet_model.scale = Vector2.ONE * CABINET_MODEL_SCALE

func finish_furniture_hide() -> void:
	agent_scene_background.visible = false
	cabinet_model.visible = false
	desk_model.visible = false
	reset_furniture_transform()
	if not (scene_input_dock and scene_input_dock.visible):
		enter_compact_idle_window(true)

func toggle_furniture_scene() -> void:
	set_furniture_visible(not scene_furniture_visible, true)
	agent_event.emit({"type": "scene.furniture", "visible": scene_furniture_visible})

func make_scene_hotspot(rect: Rect2, tip: String, callback: Callable, model: Sprite2D, base_scale: float, hotspot_name := "") -> Button:
	var hotspot := Button.new()
	if not hotspot_name.is_empty():
		hotspot.name = hotspot_name
	hotspot.position = rect.position
	hotspot.size = rect.size
	hotspot.text = ""
	hotspot.tooltip_text = ""
	hotspot.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var empty := StyleBoxEmpty.new()
	for state in ["normal", "hover", "pressed", "focus", "disabled"]:
		hotspot.add_theme_stylebox_override(state, empty)
	hotspot.mouse_entered.connect(func() -> void:
		hover_scene_model(model, base_scale, true)
		show_interaction_hint(tip)
	)
	hotspot.mouse_exited.connect(func() -> void:
		hover_scene_model(model, base_scale, false)
		hide_interaction_hint()
	)
	hotspot.pressed.connect(func() -> void:
		pulse_scene_model(model, base_scale)
		callback.call()
	)
	scene_interactive_controls.append(hotspot)
	furniture_controls.append(hotspot)
	return hotspot

func hover_scene_model(model: Sprite2D, base_scale: float, hovering: bool) -> void:
	var tween := create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	var factor := 1.018 if hovering else 1.0
	tween.tween_property(model, "scale", Vector2.ONE * base_scale * factor, 0.14)

func pulse_scene_model(model: Sprite2D, base_scale: float) -> void:
	var tween := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(model, "scale", Vector2.ONE * base_scale * 0.975, 0.07)
	tween.tween_property(model, "scale", Vector2.ONE * base_scale, 0.18)

func open_scene_chat() -> void:
	hide_interaction_hint()
	if knowledge_import_panel:
		knowledge_import_panel.visible = false
	if knowledge_settings_panel:
		knowledge_settings_panel.visible = false
	if api_settings_panel:
		api_settings_panel.visible = false
	var opening := not scene_input_dock.visible
	if opening:
		capture_pet_window_geometry()
		set_chat_workspace_visible(true)
		apply_responsive_chat_layout(true)
		agent_input.grab_focus()
		agent_event.emit({"type": "agent.open", "source": "pet.character_click"})
	else:
		if chat_workspace_window:
			chat_workspace_window.grab_focus()
		agent_input.grab_focus()

func close_chat_workspace() -> void:
	set_chat_workspace_visible(false)

func enter_compact_idle_window(preserve_character_anchor := true) -> void:
	if not dynamic_host_ready or dock_side != 0:
		return
	set_dynamic_host_geometry("idle", IDLE_WINDOW_SIZE, IDLE_CHARACTER_POSITION, preserve_character_anchor)

func enter_expanded_host_window(mode := "scene") -> void:
	if not dynamic_host_ready or dock_side != 0:
		return
	var requested_size := FURNITURE_WINDOW_SIZE if mode == "scene" else WORKSPACE_WINDOW_SIZE
	var character_position := FURNITURE_CHARACTER_POSITION if mode == "scene" else AGENT_SCENE_POSITION
	set_dynamic_host_geometry(mode, requested_size, character_position, true)

func set_dynamic_host_geometry(mode: String, requested_size: Vector2i, target_character_position: Vector2, preserve_character_anchor: bool) -> void:
	var screen := DisplayServer.window_get_current_screen()
	var usable := DisplayServer.screen_get_usable_rect(screen)
	# [DSH] requested_size 和角色坐标都是逻辑像素，窗口尺寸是物理像素，两者之间
	# 隔着 content_scale_factor。凡是要和 window.position（物理）相加的位移量都必须
	# 乘 ui_scale，否则待机↔工作区切换时人物会按 20% 的比例往左上漂。
	var logical_usable := logical_size(usable.size)
	var target_logical := Vector2i(
		mini(requested_size.x, logical_usable.x),
		mini(requested_size.y, logical_usable.y)
	)
	var target_size := scaled_size(target_logical)
	var logical_anchor := character.position if character else target_character_position
	var character_screen_anchor := Vector2(get_window().position) + logical_anchor * ui_scale
	var target_position := get_window().position
	if preserve_character_anchor:
		target_position = Vector2i(character_screen_anchor - target_character_position * ui_scale)
	target_position.x = clampi(target_position.x, usable.position.x, usable.end.x - target_size.x)
	target_position.y = clampi(target_position.y, usable.position.y, usable.end.y - target_size.y)
	var requested_minimum := (
		IDLE_WINDOW_SIZE if mode == "idle"
		else FURNITURE_WINDOW_SIZE if mode == "scene"
		else WORKSPACE_WINDOW_SIZE
	)
	# 先切换模式再写尺寸，保证同步触发的 size_changed 使用当前模式的最小尺寸。
	host_window_mode = mode
	get_window().min_size = scaled_size(Vector2i(
		mini(requested_minimum.x, logical_usable.x),
		mini(requested_minimum.y, logical_usable.y)
	))
	get_window().size = target_size
	get_window().position = target_position
	if character:
		character.position = target_character_position
	var target_scale := IDLE_CHARACTER_SCALE if mode == "idle" else AGENT_SCENE_SCALE
	if character_sprite and not action_playing:
		character_sprite.scale = Vector2.ONE * target_scale
	if blink_sprite and not action_playing:
		blink_sprite.scale = Vector2.ONE * target_scale
	if agent_panel:
		agent_panel.size = Vector2(target_logical)
	last_observed_window_position = target_position
	last_observed_window_size = target_size
	if mode == "idle":
		pet_window_position = target_position
		pet_window_size = target_size
		pet_window_geometry_valid = true
	call_deferred("reassert_dynamic_window_geometry", target_position, target_size, mode)

func reassert_dynamic_window_geometry(target_position: Vector2i, target_size: Vector2i, mode: String) -> void:
	if host_window_mode != mode or dock_side != 0:
		return
	get_window().size = target_size
	get_window().position = target_position

func capture_pet_window_geometry() -> void:
	if dock_side != 0 or chat_window_custom_maximized:
		return
	pet_window_position = get_window().position
	pet_window_size = get_window().size
	pet_window_geometry_valid = true
	last_observed_window_position = pet_window_position
	last_observed_window_size = pet_window_size

func restore_pet_window_geometry() -> void:
	if not pet_window_geometry_valid or restoring_pet_window_geometry:
		return
	restoring_pet_window_geometry = true
	if dock_tween and dock_tween.is_running():
		dock_tween.kill()
	host_window_mode = "scene" if scene_furniture_visible else "idle"
	var usable := DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen())
	var restored_minimum := FURNITURE_WINDOW_SIZE if scene_furniture_visible else IDLE_WINDOW_SIZE
	get_window().min_size = Vector2i(mini(restored_minimum.x, usable.size.x), mini(restored_minimum.y, usable.size.y))
	get_window().mode = Window.MODE_WINDOWED
	await get_tree().process_frame
	get_window().size = pet_window_size
	await get_tree().process_frame
	get_window().position = pet_window_position
	await get_tree().process_frame
	# 再写一次位置，抵消 Windows 对透明无边框窗口的自动重定位。
	get_window().position = pet_window_position
	if character:
		character.position = FURNITURE_CHARACTER_POSITION if scene_furniture_visible else IDLE_CHARACTER_POSITION
	var restored_scale := AGENT_SCENE_SCALE if scene_furniture_visible else IDLE_CHARACTER_SCALE
	if character_sprite and not action_playing:
		character_sprite.scale = Vector2.ONE * restored_scale
	if blink_sprite and not action_playing:
		blink_sprite.scale = Vector2.ONE * restored_scale
	chat_window_custom_maximized = false
	set_workspace_resize_handles_visible(true)
	last_observed_window_position = pet_window_position
	last_observed_window_size = pet_window_size
	if chat_maximize_button:
		chat_maximize_button.text = "□"
		chat_maximize_button.tooltip_text = "最大化"
	restoring_pet_window_geometry = false

func set_chat_workspace_visible(visible: bool) -> void:
	if scene_input_dock:
		scene_input_dock.visible = visible
	if analysis_panel:
		analysis_panel.visible = visible
	if character:
		character.visible = not visible
	if visible and bubble:
		bubble.visible = false
	position_status_bubble()
	if visible:
		chat_workspace_reveal_revision += 1
		var reveal_revision := chat_workspace_reveal_revision
		# 原生窗口首次创建时，Windows 可能先呈现控件的构建期默认坐标。
		# 整棵工作区先透明，待窗口真实尺寸生效并完成第二次布局后再一起显示。
		if chat_workspace_root:
			chat_workspace_root.modulate.a = 0.0
		if agent_scene_background:
			agent_scene_background.visible = false
		if desk_model:
			desk_model.visible = false
		if cabinet_model:
			cabinet_model.visible = false
		set_furniture_controls_enabled(false)
		# Godot 主窗口本身不能隐藏；因此将其内容清空并设为完全穿透，
		# 再显示独立聊天窗口。透明桌宠画布不会再拦截任何鼠标操作。
		get_window().mouse_passthrough_polygon = PackedVector2Array()
		get_window().mouse_passthrough = true
		if chat_workspace_window:
			prepare_chat_workspace_before_show()
			chat_workspace_window.show()
			chat_workspace_window.grab_focus()
			call_deferred("finalize_chat_workspace_window_show", reveal_revision)
	elif scene_furniture_visible:
		chat_workspace_reveal_revision += 1
		if chat_workspace_root:
			chat_workspace_root.modulate.a = 1.0
		if agent_scene_background:
			agent_scene_background.visible = true
		if desk_model:
			desk_model.visible = true
		if cabinet_model:
			cabinet_model.visible = true
		set_furniture_controls_enabled(true)
		if chat_workspace_window:
			chat_workspace_window.hide()
		clear_native_window_input_shape()
		get_window().mouse_passthrough = false
		get_window().grab_focus()
	else:
		chat_workspace_reveal_revision += 1
		if chat_workspace_root:
			chat_workspace_root.modulate.a = 1.0
		if chat_workspace_window:
			chat_workspace_window.hide()
		clear_native_window_input_shape()
		get_window().mouse_passthrough = false
		get_window().grab_focus()

func prepare_chat_workspace_before_show() -> void:
	if not chat_workspace_window:
		return
	if not chat_window_custom_maximized:
		chat_workspace_window.size = chat_windowed_size
		chat_workspace_window.position = chat_windowed_position
	constrain_chat_window_to_screen()
	# 对话面板铺满画布，因此这一步不可能产生"相交的构建期默认坐标"；
	# 解析面板在自己的窗口里，显示前也不需要任何分栏计算。
	apply_responsive_chat_layout(true)
	refresh_chat_workspace_input_shape(true)

func finalize_chat_workspace_window_show(reveal_revision: int) -> void:
	# 等原生窗口报告一次真实尺寸；透明期间不会让用户看到默认重叠坐标。
	await get_tree().process_frame
	if reveal_revision != chat_workspace_reveal_revision or not chat_workspace_window or not chat_workspace_window.visible:
		return
	# Windows 首次创建无边框窗口时可能按父窗口再偏移一次；显示后复写绝对坐标。
	if not chat_window_custom_maximized:
		chat_workspace_window.size = chat_windowed_size
		chat_workspace_window.position = chat_windowed_position
	constrain_chat_window_to_screen()
	apply_responsive_chat_layout(true)
	# 解析窗必须在对话窗几何确定之后再停靠，否则会贴到旧位置上。
	sync_analysis_window_visibility()
	position_analysis_window()
	refresh_chat_workspace_input_shape(true)
	if chat_workspace_root:
		chat_workspace_root.modulate.a = 1.0
	chat_workspace_window.grab_focus()

func on_chat_input_gui(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.ctrl_pressed and event.keycode == KEY_V and DisplayServer.clipboard_has_image():
		paste_clipboard_image()
		agent_input.accept_event()
		return
	if event.keycode in [KEY_ENTER, KEY_KP_ENTER] and not event.shift_pressed:
		submit_agent(agent_input.text)
		agent_input.accept_event()

func append_chat_message(role: String, text: String) -> void:
	if not chat_transcript:
		return
	var display_name := "你" if role == "user" else "梁鲸"
	var title_color := Color("267fbd") if role == "user" else Color("155684")
	chat_transcript.push_color(title_color)
	chat_transcript.add_text("●  %s" % display_name)
	chat_transcript.pop()
	chat_transcript.add_text("\n")
	if role == "assistant":
		chat_transcript.append_text(markdown_to_chat_bbcode(text))
	else:
		chat_transcript.add_text(text)
	chat_transcript.add_text("\n\n")
	chat_transcript.scroll_to_line(maxi(0, chat_transcript.get_line_count() - 1))

# RichTextLabel 不会自动理解模型返回的 Markdown。转换实现已移到
# markdown_to_bbcode.gd，这里保留同名入口，避免改动所有调用点。
func markdown_to_chat_bbcode(markdown: String) -> String:
	return MarkdownFormatter.to_bbcode(markdown)

func reset_analysis_trace() -> void:
	if not analysis_trace:
		return
	reset_model_reasoning()
	analysis_trace.clear()
	analysis_trace.add_text("准备就绪\n\n发送问题后，这里会展示可核对的处理步骤。")
	if analysis_status:
		analysis_status.text = "等待问题"
	if analysis_orb:
		analysis_orb.set_active(false)
	if analysis_metrics:
		analysis_metrics.text = "0 轮 · 0 步 · 等待会话统计"

func add_analysis_step(title: String, detail := "") -> void:
	if not analysis_trace:
		return
	if analysis_trace.get_parsed_text().begins_with("准备就绪"):
		analysis_trace.clear()
	analysis_trace.push_color(Color("79d6ff"))
	analysis_trace.add_text("●  %s" % title)
	analysis_trace.pop()
	if not detail.is_empty():
		analysis_trace.push_color(Color("b9d9eb"))
		analysis_trace.add_text("\n   %s" % detail)
		analysis_trace.pop()
	analysis_trace.add_text("\n\n")
	analysis_trace.scroll_to_line(maxi(0, analysis_trace.get_line_count() - 1))
	analysis_status.text = title

# 原生文件框显示期间撤下桌宠和工具页的置顶状态，防止人物压在 Windows
# 文件选择器上。选择或取消后再恢复原来的置顶窗口，不改变任何窗口尺寸。
func popup_native_file_dialog(dialog: FileDialog, _ratio: float) -> void:
	if not dialog or native_dialog_open:
		return
	native_dialog_open = true
	active_native_dialog = dialog
	NativeFilePicker.open(dialog)


func focus_native_file_dialog(dialog: FileDialog) -> void:
	if native_dialog_open and dialog and is_instance_valid(dialog):
		if not dialog.use_native_dialog:
			var screen := chat_workspace_window.current_screen if chat_workspace_window and chat_workspace_window.visible else get_window().current_screen
			var usable := DisplayServer.screen_get_usable_rect(screen)
			var safe_size := Vector2i(
				mini(920, usable.size.x),
				mini(680, usable.size.y)
			)
			dialog.size = safe_size
			dialog.position = usable.position + (usable.size - safe_size) / 2
		dialog.grab_focus()

func finish_native_file_dialog() -> void:
	native_dialog_open = false
	active_native_dialog = null


func restore_native_dialog_topmost() -> void:
	await get_tree().process_frame
	get_window().always_on_top = native_dialog_restore_topmost
	for window in native_dialog_topmost_windows:
		if is_instance_valid(window) and window.visible:
			window.always_on_top = true
	native_dialog_topmost_windows.clear()

# Windows Explorer 拖放不依赖“添加文件”按钮。桌宠聊天打开时，第一份有效
# 文件直接进入现有附件解析流程；多文件会明确提示当前只使用第一份。
func on_chat_files_dropped(files: PackedStringArray) -> void:
	if not scene_input_dock or not scene_input_dock.visible or files.is_empty():
		return
	if chat_busy:
		show_message("当前任务还在处理，请完成后再拖入附件。", 3.0)
		return
	var selected_path := ""
	for file_path in files:
		var normalized := str(file_path).replace("\\", "/")
		if FileAccess.file_exists(normalized):
			selected_path = normalized
			break
	if selected_path.is_empty():
		show_message("请拖入一个文件；文件夹请使用项目按钮选择。", 3.5)
		return
	on_chat_attachment_selected(selected_path)
	if files.size() > 1:
		show_message("已添加第一份文件；当前每轮支持一个附件。", 3.5)
	if agent_input:
		agent_input.grab_focus()

func choose_chat_attachment() -> void:
	popup_native_file_dialog(chat_attachment_dialog, 0.78)

func choose_agent_project() -> void:
	if chat_busy:
		show_message("当前任务仍在执行，请完成后再切换项目。", 3.0)
		return
	open_project_picker()

func on_agent_project_selected(path: String) -> void:
	if chat_busy or chat_session_changing or not agent_bridge:
		return
	chat_session_changing = true
	chat_project_button.disabled = true
	chat_project_button.text = "正在打开…"
	if chat_execution_status:
		chat_execution_status.text = "正在切换工作区"
	add_analysis_step("切换项目", "正在连接所选文件夹，请稍候")
	var result: Dictionary = await agent_bridge.open_project(path)
	chat_session_changing = false
	chat_project_button.disabled = false
	if not bool(result.get("ok", false)):
		append_chat_message("assistant", "项目没有打开：%s" % str(result.get("error", "未知错误")))
		on_harness_session_changed("", agent_bridge.workspace_path)
		if chat_execution_status:
			chat_execution_status.text = "项目打开失败"
		return
	on_harness_session_changed(str(result.get("session_id", "")), str(result.get("workspace_path", path)))
	if chat_execution_status:
		chat_execution_status.text = "项目已切换"
	if soul_store:
		soul_store.begin_conversation(
			"项目 · %s" % path.replace("\\", "/").get_file(),
			path,
			str(result.get("session_id", ""))
		)
	reset_chat_for_new_session("已进入项目《%s》。这是一个新的独立对话。" % path.replace("\\", "/").get_file())
	refresh_history_sidebar()

func new_agent_conversation() -> void:
	if chat_busy or chat_session_changing:
		return
	chat_session_changing = true
	var harness_session_id := ""
	if agent_bridge and agent_bridge.core_ready:
		var result: Dictionary = await agent_bridge.new_conversation()
		if bool(result.get("ok", false)):
			harness_session_id = str(result.get("session_id", ""))
	chat_session_changing = false
	if soul_store:
		soul_store.begin_conversation("新对话", current_workspace_path(), harness_session_id)
	reset_chat_for_new_session("新对话已经建立。你可以从一个全新的问题开始。")
	refresh_history_sidebar()

func reset_chat_for_new_session(greeting: String) -> void:
	chat_transcript.clear()
	clear_chat_attachment()
	reset_chat_skill_selection()
	reset_analysis_trace()
	append_chat_message("assistant", greeting)
	agent_input.grab_focus()

func paste_clipboard_image() -> void:
	var image := DisplayServer.clipboard_get_image()
	if image == null or image.is_empty():
		show_message("剪贴板里没有可用图片。", 2.5)
		return
	var max_side := maxi(image.get_width(), image.get_height())
	if max_side > 2048:
		var ratio := 2048.0 / float(max_side)
		image.resize(maxi(1, int(image.get_width() * ratio)), maxi(1, int(image.get_height() * ratio)), Image.INTERPOLATE_LANCZOS)
	var bytes := image.save_png_to_buffer()
	if bytes.is_empty() or bytes.size() > 5 * 1024 * 1024:
		show_message("图片过大，请压缩到 5 MB 以内再粘贴。", 3.0)
		return
	chat_attachment_path = ""
	chat_image_bytes = bytes
	chat_image_media_type = "image/png"
	chat_image_name = "剪贴板图片.png"
	chat_attachment_info = {
		"ok": true,
		"name": chat_image_name,
		"parser": "图片 · 已准备发送",
		"requires_vision": true,
		"recognized": false
	}
	chat_attachment_preview.texture = ImageTexture.create_from_image(image)
	chat_attachment_preview.visible = true
	chat_attachment_label.text = "%s · 已粘贴" % chat_image_name
	chat_attachment_label.add_theme_color_override("font_color", Color("286d9b"))
	chat_archive_button.visible = false
	chat_remove_attachment_button.visible = true
	reset_analysis_trace()
	add_analysis_step("图片已粘贴", "发送时先由视觉模型识别，再把结果交给 Harness")

func on_chat_attachment_selected(path: String) -> void:
	finish_native_file_dialog()
	if not soul_store:
		show_message("本地资料模块还没有准备好。", 3.0)
		return
	chat_attachment_path = path.replace("\\", "/")
	chat_attachment_info = soul_store.inspect_attachment(chat_attachment_path)
	load_selected_image_attachment(chat_attachment_path)
	chat_archive_button.text = "归档到知识库"
	chat_archive_button.disabled = false
	if not bool(chat_attachment_info.get("ok", false)):
		chat_attachment_label.text = "解析失败 · %s" % chat_attachment_path.get_file()
		chat_attachment_label.add_theme_color_override("font_color", Color("b75c55"))
		chat_archive_button.visible = false
		chat_remove_attachment_button.visible = true
		append_chat_message("assistant", str(chat_attachment_info.get("message", "这个附件暂时无法读取。")))
		return
	var name := str(chat_attachment_info.get("name", chat_attachment_path.get_file()))
	var parser := str(chat_attachment_info.get("parser", "本地解析"))
	chat_attachment_label.text = "%s · %s" % [name, parser]
	chat_attachment_label.add_theme_color_override("font_color", Color("286d9b"))
	chat_archive_button.visible = true
	chat_remove_attachment_button.visible = true
	append_chat_message("assistant", "%s 文件只用于本次提问；确认有长期价值后，可以点“归档到知识库”。" % str(chat_attachment_info.get("message", "已读取。")))
	reset_analysis_trace()
	add_analysis_step("附件已识别", "%s · %s" % [name, parser])

func clear_chat_attachment() -> void:
	chat_attachment_path = ""
	chat_attachment_info.clear()
	chat_image_bytes.clear()
	chat_image_media_type = ""
	chat_image_name = ""
	if chat_attachment_preview:
		chat_attachment_preview.texture = null
		chat_attachment_preview.visible = false
	chat_attachment_label.text = "未添加附件"
	chat_attachment_label.add_theme_color_override("font_color", Color("67849d"))
	chat_archive_button.visible = false
	chat_remove_attachment_button.visible = false

func load_selected_image_attachment(path: String) -> void:
	chat_image_bytes.clear()
	chat_image_media_type = ""
	chat_image_name = ""
	if chat_attachment_preview:
		chat_attachment_preview.texture = null
		chat_attachment_preview.visible = false
	var extension := path.get_extension().to_lower()
	var media_types := {
		"png": "image/png",
		"jpg": "image/jpeg",
		"jpeg": "image/jpeg",
		"webp": "image/webp",
		"gif": "image/gif"
	}
	if not media_types.has(extension):
		return
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty() or bytes.size() > 5 * 1024 * 1024:
		return
	chat_image_bytes = bytes
	chat_image_media_type = str(media_types[extension])
	chat_image_name = path.get_file()
	if extension != "gif":
		var image := Image.new()
		if image.load(path) == OK:
			chat_attachment_preview.texture = ImageTexture.create_from_image(image)
			chat_attachment_preview.visible = true

func archive_chat_attachment() -> void:
	if chat_attachment_path.is_empty() or not soul_store:
		return
	chat_archive_button.disabled = true
	add_analysis_step("正在归档", "复制原件并建立本地索引")
	var imported: Dictionary = soul_store.import_path(chat_attachment_path)
	if not bool(imported.get("ok", false)):
		chat_archive_button.disabled = false
		append_chat_message("assistant", str(imported.get("message", "归档失败。")))
		return
	var learned: Dictionary = soul_store.learn_inbox()
	var message := "已归档《%s》；建立索引 %d 份，待解析 %d 份。" % [
		chat_attachment_path.get_file(),
		int(learned.get("learned", 0)),
		int(learned.get("pending", 0))
	]
	append_chat_message("assistant", message)
	add_analysis_step("归档完成", "原件已保留在本地灵魂仓库")
	chat_archive_button.text = "已归档"
	chat_archive_button.disabled = true
	update_soul_status()
	agent_event.emit({"type": "knowledge.attachment_archived", "source": chat_attachment_path})

func set_agent_scene_pose(enabled: bool) -> void:
	if character_pose_tween and character_pose_tween.is_valid():
		character_pose_tween.kill()
	character_pose_tween = create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	var target_position := normal_character_position() if enabled else NORMAL_CHARACTER_POSITION
	var target_scale := Vector2.ONE * (normal_character_scale() if enabled else MODEL_SCALE)
	character_pose_tween.parallel().tween_property(character, "position", target_position, 0.28)
	character_pose_tween.parallel().tween_property(character_sprite, "scale", target_scale, 0.28)
	character_pose_tween.parallel().tween_property(blink_sprite, "scale", target_scale, 0.28)

func submit_agent(text: String) -> void:
	# [DSH] 用户一说话就重置空闲计时：主动开口绝不能在用户刚说完话时插嘴。
	note_user_activity()
	# [DSH] 执行期间不再丢弃输入，改为入队（见 chat_pending_queue 的注释）。
	# 附件与图片随消息一起入队：原来它们挂在全局状态上，排队时必须一并快照，
	# 否则第二条消息会顶着第一条的附件发出去。
	if chat_busy:
		enqueue_chat_message(text)
		return
	var query := text.strip_edges()
	if query.is_empty() and chat_attachment_path.is_empty() and chat_image_bytes.is_empty():
		return
	if query.is_empty():
		query = "请分析这份文件，概括重点并告诉我应该如何归档。"
	chat_busy = true
	agent_turn_started_at = Time.get_ticks_msec()
	update_agent_turn_controls()
	# [DSH] 任务执行期间她保持"专注"；失败会在下面的结果分支里覆盖成沮丧。
	set_harness_emotion(EXPRESSION_FOCUS)
	update_history_delete_controls()
	reset_model_reasoning()
	agent_input.clear()
	var attachment_name := str(chat_attachment_info.get("name", ""))
	var display_query := query
	if not attachment_name.is_empty():
		display_query += "\n附件：%s" % attachment_name
	# [DSH] 工作流「对话自动匹配」：这一步是此前缺失的接线。
	# 以前这个触发方式只存配置、从不触发（下拉框有选项、tooltip 也承认了）。
	# 位置刻意放在**开始分析之前**：命中工作流时这一轮整个交给工作流执行，
	# 不再走对话通道（否则同一个请求会被"工作流 + 模型"各做一遍），
	# 也不会先刷出一串与工作流无关的分析步骤。
	# 带附件的请求继续走普通对话；工作流启动后保持 chat_busy，直到运行器真正结束。
	var has_attachment := not chat_attachment_path.is_empty() or not chat_image_bytes.is_empty()
	if not has_attachment and maybe_start_auto_workflow(query):
		append_chat_message("user", display_query)
		append_chat_message("assistant", "已按你的明确指令启动匹配的工作流，可在工作流中心查看进度。")
		chat_busy = bool(workflow_runner and workflow_runner.is_active())
		update_agent_turn_controls()
		update_history_delete_controls()
		return
	append_chat_message("user", display_query)
	analysis_trace.clear()
	analysis_orb.set_active(true)
	add_analysis_step("理解问题", "已读取本次提问")
	await get_tree().create_timer(0.12).timeout
	if not chat_attachment_info.is_empty():
		var attachment_detail := str(chat_attachment_info.get("parser", "等待解析"))
		if int(chat_attachment_info.get("characters", 0)) > 0:
			attachment_detail += " · %d 字符" % int(chat_attachment_info.get("characters", 0))
		add_analysis_step("解析附件", attachment_detail)
		await get_tree().create_timer(0.12).timeout
	var local_context_result := collect_local_knowledge_context(query)
	var local_context := str(local_context_result.get("text", ""))
	var local_source_count := int(local_context_result.get("count", 0))
	# 技能匹配在本机完成。注册表只会返回“已启用 + 用户明确允许交给模型”
	# 且本轮明确/自动命中的技能；其他技能的内容不会离开本机。
	var skill_context_result: Dictionary = resolve_chat_skill_context(query)
	var skill_context := str(skill_context_result.get("text", ""))
	var matched_skill_names: Array = skill_context_result.get("names", []) if skill_context_result.get("names", []) is Array else []
	var matched_skill_ids: Array = skill_context_result.get("ids", []) if skill_context_result.get("ids", []) is Array else []
	var conversation_context: String = soul_store.conversation_context(soul_store.session_id, 12) if soul_store else ""
	add_analysis_step(
		"检索本地资料",
		"已找到 %d 条相关资料" % local_source_count if local_source_count > 0 else "没有匹配到相关资料"
	)
	await get_tree().create_timer(0.12).timeout
	if int(skill_context_result.get("count", 0)) > 0:
		add_analysis_step(
			"手动指定技能" if str(skill_context_result.get("mode", "auto")) == "manual" else "匹配本地技能",
			"本轮使用：%s" % "、".join(matched_skill_names)
		)
		await get_tree().create_timer(0.12).timeout
	elif chat_skill_mode == "none":
		add_analysis_step("本轮不使用技能", "由用户在输入区关闭")
	var model_name := "本地检索核心"
	var permission_mode := selected_chat_permission_mode()
	var route := decide_message_route(query)
	# 「自动判断」只决定这一轮走哪条通道，不改变 Harness 的审批语义：
	# 需要操作电脑时按受控写入执行，越界操作仍会逐次请求授权。
	var route_decision := TaskRouter.classify(query, TaskRouter.attachment_requires_action(chat_attachment_info))
	if permission_mode == "auto":
		add_analysis_step("智能判断处理方式", str(route_decision.get("explain", "")))
	var use_harness := false
	var use_direct_model := false
	if deepseek_config:
		var profile: Dictionary = deepseek_config.get_profile("chat")
		if deepseek_config.has_api_key("chat"):
			model_name = selected_chat_model()
			use_direct_model = true
			use_harness = (
				(permission_mode != "auto" or route == TaskRouter.ROUTE_HARNESS)
				and agent_bridge != null
				and agent_bridge.core_ready
				and str(profile.get("provider", "")) == "deepseek"
			)
			if use_harness:
				model_name += " · Harness"
			else:
				model_name += " · 直接回答"
	elif route == TaskRouter.ROUTE_HARNESS:
		# 没有可用的对话模型时，需要操作电脑的请求仍然只交给 Harness。
		use_harness = agent_bridge != null and agent_bridge.core_ready
	add_analysis_step("准备处理通道", model_name)
	await get_tree().create_timer(0.12).timeout
	if soul_store:
		soul_store.append_message("user", query, {
			"source": "pet.panel",
			"attachment": attachment_name,
			"permission_mode": permission_mode,
			"route": route,
			"skills": matched_skill_ids,
			"workspace": current_workspace_path(),
			"harness_session_id": agent_bridge.session_id if agent_bridge else ""
		})
		refresh_history_sidebar(chat_history_search.text if chat_history_search else "")
	var response := ""
	if use_harness:
		if chat_execution_status:
			chat_execution_status.text = "正在执行"
			chat_execution_status.add_theme_color_override("font_color", Color("2388c7"))
		add_analysis_step("启动梁鲸任务", "准备规划；改变电脑内容前必须获得你的授权")
		var context_parts: Array[String] = []
		if not conversation_context.is_empty():
			context_parts.append("以下是当前本机会话最近的上下文：\n" + conversation_context)
		if not local_context.is_empty():
			context_parts.append(local_context)
		if not skill_context.is_empty():
			context_parts.append(skill_context)
		var vision_error := ""
		var harness_images: Array = []
		if not chat_image_bytes.is_empty():
			if is_external_vision_enabled():
				add_analysis_step("调用外挂视觉", "正在读取《%s》" % chat_image_name)
				var vision_result: Dictionary = await analyze_current_image(query)
				if bool(vision_result.get("ok", false)):
					context_parts.append(
						"以下是外挂视觉模型对用户图片《%s》的识别结果。请把它视为图片内容，结合用户任务继续回答或操作：\n%s" % [
							chat_image_name,
							str(vision_result.get("text", ""))
						]
					)
					add_analysis_step("外挂视觉完成", "识别结果已交给 Harness")
				else:
					vision_error = str(vision_result.get("error", "视觉模型没有返回结果"))
					add_analysis_step("外挂视觉失败", vision_error)
			else:
				harness_images.append({
					"bytes": chat_image_bytes.duplicate(),
					"media_type": chat_image_media_type if not chat_image_media_type.is_empty() else "image/png",
					"name": chat_image_name if not chat_image_name.is_empty() else "粘贴图片.png"
				})
				add_analysis_step("使用 Harness 原生视觉", "原图将交给当前执行模型")
		else:
			var attachment_context := harness_attachment_context(query)
			if not attachment_context.is_empty():
				context_parts.append(attachment_context)
		if not vision_error.is_empty():
			response = "视觉模型没有完成图片识别：%s" % vision_error
		else:
			var context := "\n\n".join(context_parts)
			# 每轮发送前把底边审批选择同步到当前 Harness 会话。新建对话会
			# 产生新会话，因此不能只在按钮切换时写一次。
			var effective_preset := "workspace-write" if permission_mode == "auto" else permission_mode
			var permission_result: Dictionary = await agent_bridge.set_permission_preset(effective_preset)
			if bool(permission_result.get("ok", false)):
				add_analysis_step("应用审批方式", "受控写入 · 越界时审批（自动判断）" if permission_mode == "auto" else ("受控写入 · 越界时审批" if permission_mode == "workspace-write" else "完全访问 · 不审批"))
			else:
				add_analysis_step("沿用 Harness 默认审批", str(permission_result.get("error", "权限模式未同步")))
			# 开启外挂视觉时 Harness 只接收识别文字；关闭时传入原图，因此当前
			# 执行模型必须支持图像输入（例如 deepseek-v4-flash-vision-exp）。
			var harness_result: Dictionary = await agent_bridge.send_query(query, context, harness_images)
			if bool(harness_result.get("ok", false)):
				response = str(harness_result.get("text", ""))
				if bool(harness_result.get("partial", false)):
					# 任务中途失败但已生成部分内容：保留下来，并如实说明是被中断的。
					add_analysis_step("任务中途中断", "已保留生成到一半的内容")
			else:
				var harness_error := str(harness_result.get("error", "未知错误"))
				if not harness_images.is_empty() and ("image" in harness_error.to_lower() or "图片" in harness_error):
					harness_error += "。当前模型可能不支持原生图片，请开启“外挂视觉”或切换到视觉模型。"
				# [DSH] 区分"用户主动停止"、"核心掉线"与真正的执行失败。
				# 原来三者都写成"梁鲸没有完成这次任务"，而超时那种情况任务其实还在跑，
				# 这句话是不准确的（真机上已经误导过用户）。
				if bool(harness_result.get("cancelled", false)):
					response = harness_error
					add_analysis_step("已停止本轮", "按你的要求中止，已生成的内容仍保留在会话记录里")
				elif bool(harness_result.get("interrupted", false)):
					response = harness_error
					add_analysis_step("本地核心断开", "本轮无法继续")
				else:
					response = "梁鲸没有完成这次任务：%s" % harness_error
					add_analysis_step("任务未完成", str(harness_result.get("error", "未知错误")))
		if chat_execution_status:
			var failed := response.begins_with("梁鲸没有完成") or response.begins_with("本地核心已断开")
			chat_execution_status.text = "Harness · 就绪" if vision_error.is_empty() and not failed else "执行失败"
			chat_execution_status.add_theme_color_override("font_color", Color("3b8f6c") if chat_execution_status.text == "Harness · 就绪" else Color("b25050"))
	elif route == "harness":
		response = "这项请求需要操作电脑，但 Harness 尚未就绪。请先在台灯的模型中心检查模型配置和本地核心状态。"
		add_analysis_step("执行通道不可用", "没有向电脑发送任何操作")
		if chat_execution_status:
			chat_execution_status.text = "Harness 尚未就绪"
			chat_execution_status.add_theme_color_override("font_color", Color("b25050"))
	elif use_direct_model:
		if selected_chat_reasoning_effort() != "off":
			analysis_reasoning.text = "正在连接模型思考流……"
			if not analysis_page_chosen:
				show_analysis_page(true, false)
		var direct_result: Dictionary = await send_direct_model_query(query, local_context, conversation_context)
		# SSE 分片已经逐段写入界面时不能再追加完整结果，否则思考会重复一遍。
		if not bool(direct_result.get("reasoning_streamed", false)):
			on_model_reasoning_received(str(direct_result.get("reasoning", "")))
		if bool(direct_result.get("ok", false)):
			response = str(direct_result.get("text", ""))
			# [DSH] 流式拿不到正文时会降级为非流式重发一次（同一次提问内的通道降级）。
			# 这条 trace 让"为什么这次没有实时思考"有据可查，而不是看起来像没生效。
			if str(direct_result.get("transport", "")) == "非流式回退":
				add_analysis_step("改用非流式通道", "本次思考流没有返回正文，已自动用非流式重新获取")
			# [DSH] 中途静默保住的那半截回答必须带标记：不能让用户以为它答完了。
			if bool(direct_result.get("truncated", false)):
				response += "\n\n（本次回答在传输中途中断，以上内容可能不完整：%s）" % str(direct_result.get("error", "模型流中断"))
				add_analysis_step("回答中断", str(direct_result.get("error", "模型流中断")))
		else:
			response = "模型没有完成这次回答：%s" % str(direct_result.get("error", "未知错误"))
			add_analysis_step("模型调用失败", str(direct_result.get("error", "未知错误")))
	else:
		response = local_soul_response(query, chat_attachment_info)
	# [DSH] 失败就直说：把"没做完"这件事放到脸上，而不是只写在一行状态栏里。
	# 只认这两个开头，避免把正常回答里出现的"没有完成"字样误判成失败。
	if response.begins_with("梁鲸没有完成") or response.begins_with("模型没有完成"):
		set_harness_emotion(EXPRESSION_DOWN)
	finish_model_reasoning()
	if soul_store:
		soul_store.append_message("assistant", response, {
			"reasoning": model_reasoning_text,
			"mode": "harness.v1" if use_harness else "local.soul.v1",
			"route": route,
			"workspace": current_workspace_path(),
			"harness_session_id": agent_bridge.session_id if agent_bridge else ""
		})
		refresh_history_sidebar(chat_history_search.text if chat_history_search else "")
	append_chat_message("assistant", response)
	add_analysis_step("生成答复", "已完成，可继续追问")
	analysis_status.text = "解析完成"
	analysis_orb.mark_complete()
	chat_busy = false
	update_agent_turn_controls()
	update_history_delete_controls()
	clear_chat_attachment()
	show_message("处理完成啦，结果已经放在当前会话里。", 3.5)
	if agent_hint:
		agent_hint.text = response
	update_soul_status()
	agent_event.emit({
		"type": "agent.query",
		"source": "pet.panel",
		"text": query,
		"local_response": response
	})
	# [DSH] 本轮结束：先告诉用户结果，再决定是否接着发下一条排队的消息。
	notify_turn_finished(response)
	dispatch_next_queued_message()

# [DSH] 把消息放进待发送队列（执行中调用）。
func enqueue_chat_message(text: String) -> void:
	var query := text.strip_edges()
	# 与直接发送时的兜底保持一致：只有附件没有文字时也要能发。
	if query.is_empty() and chat_attachment_path.is_empty() and chat_image_bytes.is_empty():
		return
	if query.is_empty():
		query = "请分析这份文件，概括重点并告诉我应该如何归档。"
	# [DSH] 反向验证入口：置 BLUE_WHALE_QUEUE_NO_SNAPSHOT=1 时故意不存附件快照，
	# 用来确认下面的自检断言真的能抓住"快照退化成实时读取"这个缺陷。
	# 之所以留一个显式开关而不是靠临时改代码：字典项里塞注释会让 GDScript 解析失败，
	# 而删掉快照又要同时改两处，手改容易改出语法错误（已经踩过两次）。
	var snapshot_attachments := OS.get_environment("BLUE_WHALE_QUEUE_NO_SNAPSHOT").is_empty()
	chat_pending_queue.append({
		"text": query,
		"attachment_path": chat_attachment_path if snapshot_attachments else "",
		"image_bytes": chat_image_bytes.duplicate() if not chat_image_bytes.is_empty() else PackedByteArray(),
		"image_name": chat_image_name,
		"image_media_type": chat_image_media_type,
		"side_note": chat_attachment_info.duplicate(true)
	})
	# 入队即清空输入区：让用户看到"这条已经被接收"，而不是留在框里以为没发出去。
	agent_input.clear()
	clear_chat_attachment()
	update_pending_queue_bar()
	add_analysis_step("已加入待发送队列", "当前任务结束后会自动发出（共 %d 条）" % chat_pending_queue.size())

# [DSH] 当前轮结束后，把队列里的下一条发出去。
#
# 用 call_deferred 而不是直接递归调用：submit_agent 是 async 函数，且此刻仍在
# 自己这一轮的执行栈里；延迟一帧再发，避免"上一轮还没完全收尾就开下一轮"造成的状态交叉。
static func can_dispatch_queued_message(has_messages: bool, busy: bool, session_changing: bool, workflow_active: bool) -> bool:
	return has_messages and not busy and not session_changing and not workflow_active


func dispatch_next_queued_message() -> void:
	var workflow_active := bool(workflow_runner and workflow_runner.is_active())
	if not can_dispatch_queued_message(not chat_pending_queue.is_empty(), chat_busy, chat_session_changing, workflow_active):
		update_pending_queue_bar()
		return
	call_deferred("_send_next_queued_message")

func _send_next_queued_message() -> void:
	var workflow_active := bool(workflow_runner and workflow_runner.is_active())
	if not can_dispatch_queued_message(not chat_pending_queue.is_empty(), chat_busy, chat_session_changing, workflow_active):
		return
	var item: Dictionary = chat_pending_queue.pop_front()
	update_pending_queue_bar()
	# 把队列项里的附件恢复到当前状态：submit_agent 读的是这几个字段。
	# 同一个反向验证开关也决定这里是否恢复快照（见 enqueue_chat_message）。
	if OS.get_environment("BLUE_WHALE_QUEUE_NO_SNAPSHOT").is_empty():
		chat_attachment_path = str(item.get("attachment_path", ""))
		chat_image_bytes = item.get("image_bytes", PackedByteArray())
		chat_image_name = str(item.get("image_name", ""))
		chat_image_media_type = str(item.get("image_media_type", "image/png"))
		chat_attachment_info = item.get("side_note", {}) if item.get("side_note", {}) is Dictionary else {}
	submit_agent(str(item.get("text", "")))

# [DSH] 撤销最后一条排队（排队很容易手滑多发一条）。
func undo_last_queued_message() -> void:
	if chat_pending_queue.is_empty():
		return
	var dropped: Dictionary = chat_pending_queue.pop_back()
	update_pending_queue_bar()
	show_message("已撤销排队：%s" % str(dropped.get("text", "")).left(20), 3.0)

func update_pending_queue_bar() -> void:
	if not pending_queue_bar:
		return
	var count := chat_pending_queue.size()
	pending_queue_bar.visible = count > 0
	if count == 0:
		return
	if pending_queue_label:
		pending_queue_label.text = "已排队 %d 条 · 当前任务结束后自动发送" % count
	if pending_queue_undo_button:
		pending_queue_undo_button.disabled = count == 0

# [DSH] 本轮结束的桌面提醒。
#
# 取消等待上限之后，"任务要跑很久"成了常态；如果完成时没有任何提示，用户必须一直盯着
# 聊天窗口——那就等于又把等待上限还回来了。所以完成时让桌宠自己说一句。
func notify_turn_finished(response: String) -> void:
	var failed := response.begins_with("梁鲸没有完成") or response.begins_with("本地核心已断开") or response.begins_with("模型没有完成")
	var cancelled := response.begins_with("已按你的要求停止")
	var summary := response.replace("\n", " ").strip_edges()
	if summary.length() > 42:
		summary = summary.left(42) + "…"
	if cancelled:
		show_message("已停止这一轮。", 4.0)
		return
	if failed:
		show_message("这一轮没做成：%s" % summary, 6.0)
		return
	var queued := chat_pending_queue.size()
	if queued > 0:
		show_message("完成了，接着处理你排队的 %d 条。" % queued, 4.5)
	else:
		show_message("做好了：%s" % summary, 5.0)
	# 工作区没开着的时候也要能看见：把气泡留在桌面上，而不是只在聊天窗里。
	notify_if_workspace_hidden()

# 工作区不可见（在待机/家具场景、或已隐藏）时，用桌宠气泡提示，避免"跑完了没人知道"。
func notify_if_workspace_hidden() -> void:
	if scene_input_dock and scene_input_dock.visible:
		return
	if bubble:
		bubble.visible = true
		position_status_bubble()

# [DSH] 停止当前轮次。与 Harness 自己的停止同语义：中止执行、保留已生成内容。
func stop_current_agent_turn() -> void:
	if not chat_busy:
		return
	if chat_stop_button:
		chat_stop_button.disabled = true
		chat_stop_button.text = "停止中…"
	add_analysis_step("已请求停止", "正在中止这一轮")
	if agent_bridge:
		var result: Dictionary = await agent_bridge.stop_query()
		if not bool(result.get("ok", false)):
			add_analysis_step("停止未获确认", str(result.get("error", "未知原因")))
			if chat_stop_button:
				chat_stop_button.disabled = false
			return
	# 等待循环会在下一次轮询时退出，届时由 submit_agent 收尾。

# [DSH] 任务运行时显示"停止"按钮与已等待时长。
#
# 为什么要显示时长：等待上限取消后，一轮任务可以跑很久（真机上"检查代码"就超过 5 分钟），
# 界面上如果只有"正在执行"四个字，用户无法区分"在正常干活"和"已经卡死"。
func update_agent_turn_controls() -> void:
	if chat_stop_button:
		chat_stop_button.visible = chat_busy
		if chat_busy:
			chat_stop_button.disabled = false
			chat_stop_button.text = "停止"
	if not chat_busy or not chat_execution_status:
		return
	if agent_turn_started_at <= 0:
		return
	var elapsed := int((Time.get_ticks_msec() - agent_turn_started_at) / 1000)
	var minutes := elapsed / 60
	var seconds := elapsed % 60
	chat_execution_status.text = "正在执行 · 已等待 %d 分 %02d 秒 · 可随时停止" % [minutes, seconds]
	chat_execution_status.add_theme_color_override("font_color", Color("2388c7"))

func collect_local_knowledge_context(query: String) -> Dictionary:
	if not soul_store:
		return {"text": "", "count": 0}
	var results: Array = soul_store.search_knowledge(query, 3)
	var sections: Array[String] = []
	for result_value in results:
		if not result_value is Dictionary:
			continue
		var result: Dictionary = result_value
		var text := str(result.get("text", "")).strip_edges()
		if text.is_empty():
			continue
		if text.length() > 1200:
			text = text.left(1200) + "……"
		sections.append("【%s】\n%s" % [str(result.get("source", "本地资料")), text])
	return {
		"text": "以下内容来自用户本机知识库，仅在与问题相关时使用：\n\n%s" % "\n\n".join(sections) if not sections.is_empty() else "",
		"count": sections.size()
	}

func send_direct_model_query(query: String, local_context: String, conversation_context := "") -> Dictionary:
	if not deepseek_config or not deepseek_config.has_api_key("chat"):
		return {"ok": false, "error": "尚未配置对话模型"}
	var profile: Dictionary = deepseek_config.get_profile("chat").duplicate(true)
	profile["model"] = selected_chat_model()
	profile["reasoning_effort"] = selected_chat_reasoning_effort()
	profile["thinking"] = selected_chat_reasoning_effort() != "off"
	var system_text := "你是梁鲸，回答要清晰、可靠、简洁。本轮只负责回答，不能声称已经操作电脑。需要操作电脑的请求会由程序单独交给 Harness。"
	if not conversation_context.is_empty():
		system_text += "\n\n以下是当前本机会话最近的上下文，回答时保持连贯：\n" + conversation_context
	if not local_context.is_empty():
		system_text += "\n\n" + local_context
	var user_text := query
	if not chat_attachment_info.is_empty():
		user_text += "\n\n" + harness_attachment_context(query)
	return await request_openai_compatible_chat(profile, deepseek_config.load_api_key("chat"), system_text, user_text, true)

func request_openai_compatible_chat(profile: Dictionary, api_key: String, system_text: String, user_text: String, stream_reasoning := false) -> Dictionary:
	return await request_openai_compatible_messages(profile, api_key, [
		{"role": "system", "content": system_text},
		{"role": "user", "content": user_text}
	], stream_reasoning)

func analyze_current_image(query: String) -> Dictionary:
	if chat_image_bytes.is_empty():
		return {"ok": false, "error": "图片数据为空，请重新粘贴或选择图片"}
	if not deepseek_config:
		return {"ok": false, "error": "模型配置尚未加载"}
	if not deepseek_config.has_api_key("vision"):
		return {"ok": false, "error": "尚未配置视觉模型 API Key，请在模型中心选择“视觉模型”完成配置"}
	var profile: Dictionary = deepseek_config.get_profile("vision")
	var model := str(profile.get("model", "")).strip_edges()
	var base_url := str(profile.get("base_url", "")).strip_edges()
	if model.is_empty() or base_url.is_empty():
		return {"ok": false, "error": "视觉模型的接口地址或模型 ID 不完整"}
	var orchestration: Dictionary = deepseek_config.get_orchestration()
	var collaboration_mode := str(orchestration.get("mode", "vision_then_chat"))
	var visual_prompt := (
		"请完整识别这张图片，重点描述与用户问题相关的界面、文字、对象、位置关系和异常现象。"
		+ "不要声称你操作了电脑，不要遗漏图片中可读的文字。\n\n用户问题：" + query
	)
	if collaboration_mode == "vision_direct":
		visual_prompt = (
			"请仔细阅读这张图片，并先给出针对用户问题的详细判断。"
			+ "同时列出关键可见证据，供后续 Harness 核对和继续执行。\n\n用户问题：" + query
		)
	var media_type := chat_image_media_type if not chat_image_media_type.is_empty() else "image/png"
	var image_url := "data:%s;base64,%s" % [media_type, Marshalls.raw_to_base64(chat_image_bytes)]
	var user_content: Array = [
		{"type": "text", "text": visual_prompt},
		{"type": "image_url", "image_url": {"url": image_url}}
	]
	return await request_openai_compatible_messages(
		profile,
		deepseek_config.load_api_key("vision"),
		[
			{
				"role": "system",
				"content": "你是梁鲸的视觉解析层。只根据图片中真实可见的内容进行识别；不确定时明确说明。"
			},
			{"role": "user", "content": user_content}
		]
	)

func request_openai_compatible_messages(profile: Dictionary, api_key: String, messages: Array, stream_reasoning := false) -> Dictionary:
	var base_url := str(profile.get("base_url", "")).strip_edges().trim_suffix("/")
	var model := str(profile.get("model", "")).strip_edges()
	if base_url.is_empty() or model.is_empty() or api_key.is_empty():
		return {"ok": false, "error": "模型配置不完整"}
	if stream_reasoning:
		var stream_client := OpenAIStreamClient.new()
		add_child(stream_client)
		stream_client.reasoning_delta_received.connect(on_model_reasoning_received)
		var streamed_result: Dictionary = await stream_client.request(profile, api_key, messages, resolved_network_settings())
		stream_client.queue_free()
		return streamed_result
	var endpoint := base_url if base_url.ends_with("/chat/completions") else base_url + "/chat/completions"
	var request := HTTPRequest.new()
	request.timeout = 180.0
	add_child(request)
	configure_http_request_proxy(request)
	var headers := PackedStringArray([
		"Content-Type: application/json",
		"Accept: application/json",
		"Authorization: Bearer %s" % api_key
	])
	var payload := ChatResponse.build_payload(profile, messages)
	var request_error := request.request(endpoint, headers, HTTPClient.METHOD_POST, JSON.stringify(payload))
	if request_error != OK:
		request.queue_free()
		return {"ok": false, "error": "模型请求没有发出"}
	var completed = await request.request_completed
	request.queue_free()
	var transport_result := int(completed[0])
	var response_code := int(completed[1])
	var body: PackedByteArray = completed[3]
	if transport_result != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "error": "模型网络连接失败"}
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if response_code < 200 or response_code >= 300:
		var api_error := "服务返回 %d" % response_code
		if parsed is Dictionary and parsed.get("error", null) is Dictionary:
			api_error = str(parsed.get("error", {}).get("message", api_error))
		return {"ok": false, "error": api_error}
	# [DSH] 模型配好了、却一个候选都没有、还带 error：
	# 这是"HTTP 200 + body 里报错"这种服务端表达方式，必须把**服务端的原话**说出来。
	# 否则用户只会看到"模型回答为空/模型没有返回回答"，把排查方向带偏。
	if parsed is Dictionary and parsed.get("error", null) is Dictionary:
		var api_message := str(parsed.get("error", {}).get("message", ""))
		if not api_message.is_empty():
			return {"ok": false, "error": "模型服务返回错误：%s" % api_message}
	return ChatResponse.parse_completion(parsed)

func harness_attachment_context(query: String) -> String:
	if chat_attachment_info.is_empty():
		return ""
	var attachment_name := str(chat_attachment_info.get("name", "附件"))
	if bool(chat_attachment_info.get("recognized", false)) and soul_store:
		var excerpt: String = soul_store.attachment_excerpt(chat_attachment_info, query, 1800)
		return "附件《%s》的本地解析内容：\n%s" % [attachment_name, excerpt]
	if bool(chat_attachment_info.get("requires_vision", false)):
		return "用户同时附带了图片《%s》，但没有获得可用的视觉识别结果。" % attachment_name
	return "用户同时附带了文件《%s》，当前只能保留文件信息。" % attachment_name

func local_soul_response(query: String, attachment: Dictionary = {}) -> String:
	if not soul_store:
		return "本地灵魂仓库还没有准备好。"
	if not attachment.is_empty():
		if bool(attachment.get("recognized", false)):
			var excerpt: String = soul_store.attachment_excerpt(attachment, query, 420)
			return "我已经读取《%s》。与这次问题最相关的内容是：%s\n\n如果这份资料以后还会用，点击“归档到知识库”，我会保留原件并建立长期索引。" % [
				attachment.get("name", "附件"), excerpt
			]
		if bool(attachment.get("requires_vision", false)):
			return "《%s》是一张图片，已经识别为视觉任务。当前界面已准备好视觉模型路由；下一步接通实际对话请求后，会先由视觉模型读取，再交给对话模型回答。" % attachment.get("name", "图片")
		return "我收到了《%s》，但当前解析器还不能提取这种格式的正文。可以先归档原件，之后补装解析组件再建立索引。" % attachment.get("name", "附件")
	if query.begins_with("记住"):
		var memory_text := query.trim_prefix("记住").trim_prefix("：").trim_prefix(":").strip_edges()
		var remembered: Dictionary = soul_store.remember(memory_text)
		return str(remembered.get("message", "已经记住。"))
	if query.begins_with("忘记"):
		var forget_text := query.trim_prefix("忘记").trim_prefix("：").trim_prefix(":").strip_edges()
		var forgotten: Dictionary = soul_store.forget(forget_text)
		return str(forgotten.get("message", "已经处理。"))
	if query.contains("记得我什么") or query.contains("你记得什么"):
		return memory_summary_text()
	var results: Array = soul_store.search_knowledge(query, 3)
	if not results.is_empty():
		var first: Dictionary = results[0]
		var excerpt := str(first.get("text", "")).replace("\n", " ").strip_edges()
		if excerpt.length() > 150:
			excerpt = excerpt.left(150) + "……"
		return "我在《%s》里找到：%s" % [first.get("source", "本地资料"), excerpt]
	return "这段对话已经保存在本地。模型服务接入后，我会结合记忆和资料继续回答。"

func open_soul_inbox() -> void:
	if soul_store:
		open_local_file_browser(soul_store.inbox_path, "投喂箱")

func open_soul_root() -> void:
	if soul_store:
		open_local_file_browser(soul_store.root_path, "灵魂仓库")

func open_memory_folder() -> void:
	if soul_store:
		open_local_file_browser(soul_store.memory_path, "记忆")

func memory_summary_text() -> String:
	if not soul_store:
		return "本地灵魂仓库还没有准备好。"
	var memories: Array = soul_store.active_memories()
	if memories.is_empty():
		return "我还没有长期记忆。你可以对我说“记住：……”。"
	var lines: Array[String] = []
	var start := maxi(0, memories.size() - 3)
	for index in range(start, memories.size()):
		var memory: Dictionary = memories[index]
		lines.append(str(memory.get("text", "")))
	return "我记得：" + "；".join(lines)

func update_soul_status() -> void:
	if not soul_store or not agent_status:
		return
	var stats: Dictionary = soul_store.get_stats()
	agent_status.text = "记忆 %d · 资料 %d" % [
		int(stats.get("memories", 0)), int(stats.get("documents", 0))
	]

func show_message(text: String, duration: float) -> void:
	if not bubble_text or not bubble:
		return
	var display_text := text.strip_edges()
	# 正式工作窗口打开时，气泡只承担状态提醒，不再复制完整模型答复。
	if scene_input_dock and scene_input_dock.visible and display_text.length() > 72:
		display_text = display_text.left(70) + "……"
	bubble_text.text = display_text
	position_status_bubble()
	bubble.visible = true
	var timer := get_tree().create_timer(duration)
	timer.timeout.connect(func():
		if bubble_text.text == display_text:
			bubble.visible = false
	)

func try_edge_dock() -> void:
	var candidate_screen := DisplayServer.window_get_current_screen()
	var rect := DisplayServer.screen_get_usable_rect(candidate_screen)
	var pos := get_window().position
	var window_size := get_window().size
	if pos.x < rect.position.x + 28:
		if dock_side == 0:
			dock_restore_chat_open = bool(scene_input_dock and scene_input_dock.visible)
			dock_restore_scene_open = scene_furniture_visible
		dock_screen = candidate_screen
		dock_side = -1
		dock_hover_armed = false
		dock_full = Vector2i(rect.position.x, pos.y)
		dock_hidden = Vector2i(rect.position.x - (window_size.x - DOCK_VISIBLE_WIDTH), pos.y)
		play_dock_peek()
		slide_window(dock_hidden)
	elif pos.x + window_size.x > rect.end.x - 28:
		if dock_side == 0:
			dock_restore_chat_open = bool(scene_input_dock and scene_input_dock.visible)
			dock_restore_scene_open = scene_furniture_visible
		dock_screen = candidate_screen
		dock_side = 1
		dock_hover_armed = false
		dock_full = Vector2i(rect.end.x - window_size.x, pos.y)
		dock_hidden = Vector2i(rect.end.x - DOCK_VISIBLE_WIDTH, pos.y)
		play_dock_peek()
		slide_window(dock_hidden)
	else:
		dock_side = 0
		dock_screen = -1
		dock_hover_armed = false
		restore_normal_character()

func update_edge_dock() -> void:
	if dock_side == 0 or dragging:
		return
	var mouse := DisplayServer.mouse_get_position()
	var screen := dock_screen if dock_screen >= 0 else DisplayServer.window_get_current_screen()
	var rect := DisplayServer.screen_get_usable_rect(screen)
	var near_edge := mouse.x < rect.position.x + DOCK_HOVER_ZONE if dock_side < 0 else mouse.x > rect.end.x - DOCK_HOVER_ZONE
	var vertical := mouse.y > get_window().position.y and mouse.y < get_window().position.y + get_window().size.y
	var hover := near_edge and vertical
	# 侧边悬停只做一次轻微探身，不再把整块场景窗口拉出来。
	# 完整场景只在点击探头后恢复，避免桌子、人物、柜子被屏幕边缘依次裁切。
	if hover and not dock_hover_armed:
		dock_hover_armed = true
		play_dock_peek()
	elif not hover:
		dock_hover_armed = false
	if not pointer_down and get_window().position.distance_to(dock_hidden) > 3:
		slide_window(dock_hidden)

func restore_from_edge_dock() -> void:
	if dock_side == 0:
		return
	if dock_tween and dock_tween.is_running():
		dock_tween.kill()
	var previous_side := dock_side
	var screen := dock_screen if dock_screen >= 0 else DisplayServer.window_get_current_screen()
	var rect := DisplayServer.screen_get_usable_rect(screen)
	var restore_size := pet_window_size
	if (
		restore_size.x >= int(float(rect.size.x) * 0.90)
		and restore_size.y >= int(float(rect.size.y) * 0.90)
	):
		restore_size = (
			FURNITURE_WINDOW_SIZE if dock_restore_scene_open or host_window_mode == "scene"
			else WORKSPACE_WINDOW_SIZE
		)
		pet_window_size = restore_size
	restore_size.x = clampi(restore_size.x, mini(WINDOW_MIN_WIDTH, rect.size.x), rect.size.x)
	restore_size.y = clampi(restore_size.y, mini(WINDOW_MIN_HEIGHT, rect.size.y), rect.size.y)
	pet_window_size = restore_size
	var current_y := get_window().position.y
	var restore_y := clampi(current_y, rect.position.y, rect.end.y - restore_size.y)
	var restore_x := rect.position.x + 12 if previous_side < 0 else rect.end.x - restore_size.x - 12
	dock_side = 0
	dock_screen = -1
	dock_hover_armed = false
	dock_peek_holding = false
	get_window().size = restore_size
	get_window().position = Vector2i(restore_x, restore_y)
	pet_window_position = get_window().position
	last_observed_window_size = get_window().size
	last_observed_window_position = get_window().position
	restore_normal_character()
	if dock_restore_chat_open:
		set_chat_workspace_visible(true)
		call_deferred("apply_responsive_chat_layout")
	elif dock_restore_scene_open:
		set_furniture_visible(true, false)
	else:
		enter_compact_idle_window(true)
	dock_restore_chat_open = false
	dock_restore_scene_open = false
	save_app_window_geometry()

func slide_window(target: Vector2i) -> void:
	if dock_tween and dock_tween.is_running() and dock_tween_target == target:
		return
	if dock_tween and dock_tween.is_running():
		dock_tween.kill()
	dock_tween_target = target
	dock_tween = create_tween()
	dock_tween.set_trans(Tween.TRANS_QUINT).set_ease(Tween.EASE_OUT)
	dock_tween.tween_property(get_window(), "position", target, 0.34)

func initialize_outfit_center() -> void:
	outfit_center = OutfitCenter.new()
	add_child(outfit_center)
	outfit_center.appearance_changed.connect(on_outfit_appearance_changed)
	outfit_center.motion_profile_changed.connect(on_outfit_motion_profile_changed)
	# [DSH] 第三个参数是设备密钥来源：换装 Key 与 chat/vision 的 Key 用同一套设备绑定加密。
	outfit_center.setup(soul_store.root_path, load(MODEL_TEXTURE), deepseek_config)
	# [DSH] 把网络设置来源注入换装中心：它的 HTTPRequest 也要走代理，否则
	# 用户开了代理仍然生成失败，而且看不出原因（见 network_config.apply_to_request）。
	outfit_center.network_settings_provider = resolved_network_settings
	outfit_center.mount_model_settings(image_model_settings_box)
	outfit_center.model_settings_requested.connect(open_image_model_settings)
	style_image_model_settings(image_model_settings_box)
	style_model_center_dropdowns(model_center_tabs)

# ── 区域截图提问 ──────────────────────────────────────────────
func initialize_screenshot_center() -> void:
	screenshot_center = ScreenshotCenterCore.new()
	screenshot_center.name = "ScreenshotCenter"
	add_child(screenshot_center)
	screenshot_center.captured.connect(on_screenshot_captured)
	screenshot_center.cancelled.connect(on_screenshot_cancelled)
	screenshot_center.call("setup", self)

# 应用内快捷键（Ctrl+Alt+S 截图提问 / Ctrl+Alt+L 唤起桌宠）。
#
# 注意：Godot 4 没有提供全局热键接口（核对过 4.7.1 的完整 API dump，不存在任何
# 含 hotkey 的方法），因此这两个快捷键只在梁鲸窗口处于前台时生效。
# 要做到“任何程序前台都能唤起”必须在 Windows 侧注册系统热键，那需要常驻辅助进程；
# 这里不做，也不假装能做到——右键菜单里的“框选截图提问”始终可用。
func register_global_hotkeys() -> void:
	print("HOTKEY_MODE=focus-scoped screenshot=Ctrl+Alt+S summon=Ctrl+Alt+L")

# 唤起桌宠：把工作区带到前台，用于快捷键与托盘式操作。
func summon_pet_workspace() -> void:
	if dock_side != 0:
		restore_from_edge_dock()
	if scene_input_dock and not scene_input_dock.visible:
		hide_all_utility_windows()
		set_chat_workspace_visible(true)
		apply_responsive_chat_layout(true)
	if chat_workspace_window:
		chat_workspace_window.show()
		chat_workspace_window.move_to_foreground()
		chat_workspace_window.grab_focus()
	if agent_input:
		agent_input.grab_focus()
	add_analysis_step("已唤起工作区", "Ctrl+Alt+L")

func start_screenshot_capture() -> void:
	if not screenshot_center:
		show_message("截图模块尚未准备好。", 3.0)
		return
	# 框选期间隐藏桌宠自己的窗口，否则会把人物和家具一起截进去。
	if dock_side != 0:
		restore_from_edge_dock()
	get_window().visible = false
	if chat_workspace_window:
		chat_workspace_window.visible = false
	hide_all_utility_windows()
	# 等一帧让窗口真正消失后再抓屏。
	await get_tree().process_frame
	await get_tree().process_frame
	var result: Dictionary = screenshot_center.call("open")
	if not bool(result.get("ok", false)):
		restore_windows_after_screenshot()
		show_message("截图失败：%s" % str(result.get("error", "未知原因")), 4.0)
		add_analysis_step("截图失败", str(result.get("error", "未知原因")))

func on_screenshot_captured(image: Image) -> void:
	restore_windows_after_screenshot()
	if image == null or image.is_empty():
		show_message("没有截到内容，请重新框选。", 3.0)
		return
	var bytes := image.save_png_to_buffer()
	if bytes.is_empty():
		show_message("截图编码失败，请重试。", 3.0)
		return
	# 复用剪贴板图片的既定链路：同样的字节、同样的字节上限、同样的视觉路由。
	if bytes.size() > 5 * 1024 * 1024:
		show_message("选区太大，请框选更小的区域。", 4.0)
		return
	chat_attachment_path = ""
	chat_image_bytes = bytes
	chat_image_media_type = "image/png"
	chat_image_name = "区域截图_%s.png" % Time.get_time_string_from_system().replace(":", "")
	chat_attachment_info = {
		"ok": true,
		"name": chat_image_name,
		"parser": "区域截图 · 已准备发送",
		"requires_vision": true,
		"recognized": false,
		"size": bytes.size()
	}
	if chat_attachment_preview:
		chat_attachment_preview.texture = ImageTexture.create_from_image(image)
		chat_attachment_preview.visible = true
	if chat_attachment_label:
		chat_attachment_label.text = "%s · %d×%d" % [chat_image_name, image.get_width(), image.get_height()]
		chat_attachment_label.add_theme_color_override("font_color", Color("286d9b"))
	if chat_archive_button:
		chat_archive_button.visible = false
	if chat_remove_attachment_button:
		chat_remove_attachment_button.visible = true
	reset_analysis_trace()
	add_analysis_step("截图完成", "%d×%d 像素，将交给视觉模型识别" % [image.get_width(), image.get_height()])
	# 框选完成即视为“要问这张图”，因此直接发送；延迟一帧避免在窗口输入回调里重入。
	call_deferred("submit_agent", "")

func on_screenshot_cancelled() -> void:
	restore_windows_after_screenshot()

func restore_windows_after_screenshot() -> void:
	get_window().visible = true
	if scene_input_dock and scene_input_dock.visible and chat_workspace_window:
		chat_workspace_window.visible = true
	get_window().grab_focus()

# [DSH] 工作区布局自检。
#
# 拆窗之后这里的重点完全变了：不再是"两栏怎么分不重叠"（那种冲突已经不存在），
# 而是守住**拆分本身**——解析面板必须真的在自己的原生窗口里、跟着对话窗显示隐藏、
# 并且停靠后完整落在屏幕内。旧的两栏验收断言已随旧机制一起删除。
func run_workspace_layout_selftest() -> void:
	var result: Dictionary = WorkspaceLayout.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("WORKSPACE_LAYOUT_CALC_FAILURE ", str(failure))
	print("WORKSPACE_LAYOUT_CALC_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())
	run_analysis_window_selftest()
	run_script_structure_selftest()
	run_agent_wait_policy_selftest()
	run_chat_queue_selftest()
	run_proactive_companion_selftest()
	run_workflow_auto_match_selftest()
	run_workflow_schedule_selftest()
	run_workflow_package_selftest()
	run_dock_sequence_selftest()
	run_weknora_client_selftest()

# [DSH] 真机连接自检（--weknora-probe）。
#
# 为什么要有它：假服务只能证明"我按文档实现对了"，证明不了"真的 WeKnora 认这套"。
# 这个探针读**真实配置与真实密钥**，只做只读调用，不产生模型费用；
# 需要验证流式问答时才加 =chat（那一轮会让对方模型真跑一次，算力在用户那边）。
#
# 注意：它必须用**真实的 APPDATA** 运行——设备绑定密钥里包含该路径，
# 换成自检用的临时目录就解不开 weknora.key 了。
func probe_requested() -> bool:
	for argument in OS.get_cmdline_user_args():
		if str(argument).begins_with("--weknora-probe"):
			return true
	return false

func probe_wants_chat() -> bool:
	for argument in OS.get_cmdline_user_args():
		if str(argument).strip_edges() == "--weknora-probe=chat":
			return true
	return false

func run_weknora_probe() -> void:
	print("WEKNORA_PROBE_BEGIN")
	if not weknora_config or not weknora_client:
		print("PROBE_FAIL 知识库连接模块没有初始化")
		get_tree().quit(1)
		return
	print("PROBE_MODE=", weknora_config.get_mode())
	print("PROBE_HOST=", weknora_config.get_api_base_url())
	print("PROBE_ALLOW_INSECURE=", weknora_config.get_allow_insecure_http())
	print("PROBE_KEY_STORED=", weknora_config.has_api_key())
	var key: String = weknora_config.load_api_key()
	print("PROBE_KEY_LENGTH=", key.length())
	if not weknora_config.uses_weknora():
		print("PROBE_FAIL 当前不是 WeKnora 模式（或地址/Key 不完整），无事可做")
		get_tree().quit(1)
		return
	var selected: Array = weknora_config.get_knowledge_base_ids()
	print("PROBE_SELECTED_KB=", selected.size())

	var info: Dictionary = await weknora_client.system_info()
	print("PROBE_SYSTEM ok=", bool(info.get("ok", false)), " graph=", str(info.get("graph_engine", "")), " vector=", str(info.get("vector_engine", "")), " error=", str(info.get("error", "")))

	var listed: Dictionary = await weknora_client.list_knowledge_bases()
	print("PROBE_LIST_KB ok=", bool(listed.get("ok", false)), " count=", Array(listed.get("items", [])).size(), " error=", str(listed.get("error", "")))
	var graph_kbs := 0
	for item in listed.get("items", []):
		var row: Dictionary = item
		if bool(row.get("graph_enabled", false)):
			graph_kbs += 1
		print("PROBE_KB id=", str(row.get("id", "")), " name=", str(row.get("name", "")), " docs=", int(row.get("knowledge_count", 0)), " chunks=", int(row.get("chunk_count", 0)), " processing=", int(row.get("processing_count", 0)), " graph=", bool(row.get("graph_enabled", false)))
	print("PROBE_GRAPH_KBS=", graph_kbs)
	# 顺带把第一个库的原始字段名打出来：不同版本的字段不一样，靠猜不如看一眼。
	if not Array(listed.get("items", [])).is_empty():
		var raw: Dictionary = listed.get("payload", {})
		var raw_items: Variant = raw.get("data", [])
		if raw_items is Array and not Array(raw_items).is_empty() and Array(raw_items)[0] is Dictionary:
			var keys: Array = Dictionary(Array(raw_items)[0]).keys()
			keys.sort()
			print("PROBE_KB_FIELDS=", ", ".join(keys))

	if not selected.is_empty():
		# 挑资料最多的那个库来列文档：只挑第一个的话，碰到空库就什么都验不到
		# （真机上第一次跑就选中了 0 份资料的库）。
		var target := str(selected[0])
		var best_docs := -1
		for item in listed.get("items", []):
			var row: Dictionary = item
			if selected.has(str(row.get("id", ""))) and int(row.get("knowledge_count", 0)) > best_docs:
				best_docs = int(row.get("knowledge_count", 0))
				target = str(row.get("id", ""))
		var documents: Dictionary = await weknora_client.list_knowledge(target, 1, 5)
		print("PROBE_LIST_DOCS ok=", bool(documents.get("ok", false)), " total=", int(documents.get("total", 0)), " page=", Array(documents.get("items", [])).size(), " error=", str(documents.get("error", "")))
		for item in documents.get("items", []):
			var row: Dictionary = item
			print("PROBE_DOC id=", str(row.get("id", "")), " title=", str(row.get("title", "")), " status=", str(row.get("parse_status", "")), " summary=", str(row.get("summary", "")).left(40))
		# 检索：先用一个泛化词，只要服务返回结果就说明检索通道是通的。
		var hits: Dictionary = await weknora_client.search("介绍", selected, 3)
		print("PROBE_SEARCH ok=", bool(hits.get("ok", false)), " hits=", Array(hits.get("items", [])).size(), " error=", str(hits.get("error", "")))
		for item in hits.get("items", []):
			var row: Dictionary = item
			print("PROBE_HIT title=", str(row.get("title", "")), " score=", "%.4f" % float(row.get("score", 0.0)), " chars=", str(row.get("content", "")).length())

	if probe_wants_chat():
		var session: Dictionary = await weknora_client.create_session("梁鲸自检")
		print("PROBE_SESSION ok=", bool(session.get("ok", false)), " id=", str(session.get("session_id", "")), " error=", str(session.get("error", "")))
		if bool(session.get("ok", false)):
			weknora_client.capture_stream_frames = true
			weknora_client.captured_frames.clear()
			var streamed: Dictionary = await weknora_client.stream_knowledge_chat(
				str(session.get("session_id", "")),
				"简单介绍一下知识库里都有什么内容？",
				selected,
				Callable(),
				120.0
			)
			print("PROBE_CHAT ok=", bool(streamed.get("ok", false)), " events=", int(streamed.get("event_count", 0)), " refs=", Array(streamed.get("references", [])).size(), " truncated=", bool(streamed.get("truncated", false)), " error=", str(streamed.get("error", "")))
			print("PROBE_CHAT_ANSWER=", str(streamed.get("answer", "")).left(300).replace("\n", " "))
			print("PROBE_CHAT_CITATIONS=", WeKnoraClientScript.format_citations(streamed.get("references", []), 3))
			for index in range(weknora_client.captured_frames.size()):
				print("PROBE_FRAME[", index, "]=", str(weknora_client.captured_frames[index]).replace("\n", "\\n"))

	print("WEKNORA_PROBE_END")
	get_tree().quit(0)

# [DSH] 知识库中台（WeKnora）连接层自检。
# 分两段：
#   1. 纯函数——地址策略、API 根地址拼装、分页推进、错误文案、multipart 组包、结果解析；
#   2. **真 HTTP**——用 weknora_mock_server.gd 起一个本地假服务，客户端走真的 HTTPRequest 打过去。
#      第 2 段才是关键：只断言拼字符串等于没测，而"上传的文件字节是否原样到达"只有真发一次才知道。
# 注意：这里不连真的 WeKnora，也不读用户配置（走 tmp 下的自检目录）。
func run_weknora_client_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0

	# ── 第一段：地址与配置 ────────────────────────────────────────────
	cases += 1
	if not WeKnoraConfigStore.is_safe_host("http://127.0.0.1:8080"):
		failures.append("本机 http 地址被拒绝")
	cases += 1
	if not WeKnoraConfigStore.is_safe_host("https://kb.example.com"):
		failures.append("https 地址被拒绝")
	cases += 1
	if WeKnoraConfigStore.is_safe_host("http://192.168.1.5:8080"):
		failures.append("明文局域网地址被放行（API Key 会明文上网）")
	cases += 1
	if WeKnoraConfigStore.is_safe_host("http://evil.example") or WeKnoraConfigStore.is_safe_host(""):
		failures.append("不安全地址没有被拒绝")
	cases += 1
	if WeKnoraConfigStore.is_safe_host("https://"):
		failures.append("只有协议头没有主机名的地址被放行")

	cases += 1
	if WeKnoraConfigStore.api_base_url("http://127.0.0.1:8080/") != "http://127.0.0.1:8080/api/v1":
		failures.append("API 根地址拼装错误：%s" % WeKnoraConfigStore.api_base_url("http://127.0.0.1:8080/"))
	cases += 1
	if WeKnoraConfigStore.api_base_url("http://127.0.0.1:8080/api/v1") != "http://127.0.0.1:8080/api/v1":
		failures.append("已经把 /api/v1 粘进来的地址会被重复拼接")
	cases += 1
	if not WeKnoraConfigStore.api_base_url("").is_empty():
		failures.append("空地址应该返回空串")

	# 配置往返：写进去必须读得回来（历史上出现过"保存时静默丢键"）。
	if weknora_config:
		var probe := WeKnoraConfigStore.new()
		var probe_root := ProjectSettings.globalize_path("res://tmp/.selftest_runtime/自检知识库连接探针")
		probe.initialize(probe_root, deepseek_config)
		cases += 1
		var rejected: Dictionary = probe.set_host("http://192.168.1.5:8080")
		if bool(rejected.get("ok", true)):
			failures.append("不安全地址被写进了配置")
		cases += 1
		probe.set_host("http://127.0.0.1:9911")
		if probe.get_host() != "http://127.0.0.1:9911":
			failures.append("地址没有存下来：%s" % probe.get_host())
		cases += 1
		if probe.get_api_base_url() != "http://127.0.0.1:9911/api/v1":
			failures.append("配置里的地址没有转成 API 根地址")
		cases += 1
		# 没有 Key 不允许切到 WeKnora：否则用户会得到一个"看起来配好了但永远失败"的状态。
		var denied: Dictionary = probe.set_mode(WeKnoraConfigStore.MODE_WEKNORA)
		if bool(denied.get("ok", true)):
			failures.append("没有 API Key 也允许切换到 WeKnora")
		cases += 1
		if not probe.save_api_key("sk-selftest-key"):
			failures.append("API Key 保存失败")
		cases += 1
		if probe.load_api_key() != "sk-selftest-key":
			failures.append("API Key 读回来不一致（加密写回有问题）")
		cases += 1
		if not probe.set_mode(WeKnoraConfigStore.MODE_WEKNORA):
			failures.append("地址与 Key 都齐了却切不到 WeKnora")
		cases += 1
		if not probe.uses_weknora():
			failures.append("切换到 WeKnora 后 uses_weknora() 仍为 false")
		cases += 1
		# 密钥文件不能是明文。
		var raw := FileAccess.get_file_as_bytes(probe.secret_path)
		if WeKnoraClientScript.bytes_index_of(raw, "sk-selftest-key".to_utf8_buffer()) >= 0:
			failures.append("API Key 以明文形式落在磁盘上")
		probe.clear_api_key()

	# ── 第二段：分页与错误文案 ────────────────────────────────────────
	cases += 1
	if WeKnoraClientScript.next_page(1, 20, 45, 20) != 2:
		failures.append("分页推进错误：还有下一页时没有前进")
	cases += 1
	if WeKnoraClientScript.next_page(3, 20, 45, 5) != 0:
		failures.append("分页推进错误：已经取完还在继续")
	cases += 1
	if WeKnoraClientScript.next_page(1, 20, 0, 20) != 2:
		failures.append("服务端没有 total 时不能用「取满即续页」推断")
	cases += 1
	if WeKnoraClientScript.next_page(1, 20, 0, 7) != 0:
		failures.append("服务端没有 total 且没取满时应结束")
	cases += 1
	if WeKnoraClientScript.next_page(0, 20, 45, 20) != 0 or WeKnoraClientScript.next_page(1, 0, 45, 20) != 0:
		failures.append("非法分页参数没有安全返回 0")

	cases += 1
	if not WeKnoraClientScript.describe_error(401, null).contains("API Key"):
		failures.append("401 文案没有指向 API Key")
	cases += 1
	if not WeKnoraClientScript.describe_error(409, null).contains("已经在知识库里"):
		failures.append("409 文案没有说明是重复资料")
	cases += 1
	var detailed := WeKnoraClientScript.describe_error(403, {"success": false, "error": {"message": "no permission"}})
	if not detailed.contains("no permission"):
		failures.append("服务端给的具体原因被丢掉了")
	cases += 1
	if WeKnoraClientScript.payload_ok(200, {"success": false, "error": {"message": "x"}}):
		failures.append("HTTP 200 但 success=false 被当成了成功")
	cases += 1
	if not WeKnoraClientScript.payload_ok(201, {"success": true, "data": {}}):
		failures.append("201 成功被误判为失败")

	# ── 第三段：multipart 组包 ────────────────────────────────────────
	# 故意让文件内容里带上 CRLF 和 -- ：这是最容易把分帧写坏的情况。
	var file_bytes := PackedByteArray([0x25, 0x50, 0x44, 0x46, 0x0d, 0x0a, 0x2d, 0x2d, 0x20, 0xe4, 0xb8, 0xad])
	var boundary := WeKnoraClientScript.safe_boundary("a.pdf|12", file_bytes)
	var body := WeKnoraClientScript.multipart_body({"fileName": "docs/a.pdf"}, "file", "a.pdf", file_bytes, boundary)
	cases += 1
	if WeKnoraClientScript.bytes_index_of(body, file_bytes) < 0:
		failures.append("multipart 正文里找不到文件的原始字节")
	cases += 1
	var expected_head := ('--%s\r\nContent-Disposition: form-data; name="fileName"\r\n\r\ndocs/a.pdf\r\n' % boundary).to_utf8_buffer()
	if not body.slice(0, expected_head.size()) == expected_head:
		failures.append("multipart 文本字段的头部格式不对")
	cases += 1
	var expected_tail := ("--%s--\r\n" % boundary).to_utf8_buffer()
	if not body.slice(body.size() - expected_tail.size()) == expected_tail:
		failures.append("multipart 结尾分隔符不对")
	cases += 1
	if not body.get_string_from_utf8().contains('filename="a.pdf"'):
		failures.append("multipart 里缺少文件名")
	cases += 1
	if not body.get_string_from_utf8().contains("Content-Type: application/pdf"):
		failures.append("multipart 里的文件类型没有按扩展名推断")
	cases += 1
	if not WeKnoraClientScript.multipart_content_type(boundary).contains(boundary):
		failures.append("Content-Type 头部与正文用的边界不是同一个")
	# 反向：正文里如果出现边界字符串，必须换一个边界，否则分帧会被打断。
	cases += 1
	var colliding := ("xx%syy" % boundary).to_utf8_buffer()
	if WeKnoraClientScript.safe_boundary("a.pdf|12", colliding) == boundary:
		failures.append("正文里出现边界时没有换边界（会切坏文件）")

	# ── 第四段：结果解析 ──────────────────────────────────────────────
	var search_payload := {"success": true, "data": [
		{"id": "c1", "content": "第一段正文", "knowledge_title": "架构.md", "chunk_index": 0, "score": 0.9},
		{"id": "c2", "content": "", "knowledge_title": "空的.md"},
		"不是字典",
	]}
	var parsed_rows := WeKnoraClientScript.parse_search_results(search_payload)
	cases += 1
	if parsed_rows.size() != 1:
		failures.append("检索结果解析没有过滤掉空正文与非字典项：%d" % parsed_rows.size())
	cases += 1
	if str(Dictionary(parsed_rows[0]).get("title", "")) != "架构.md":
		failures.append("检索结果没有带出来源标题（引用就没法显示）")
	cases += 1
	var context := WeKnoraClientScript.format_context(parsed_rows, 1200)
	if int(context.get("count", 0)) != 1 or not str(context.get("text", "")).contains("第一段正文"):
		failures.append("检索结果没有拼成可注入的上下文")
	cases += 1
	if int(Dictionary(WeKnoraClientScript.format_context([], 1200)).get("count", 0)) != 0:
		failures.append("空结果集应该给出空上下文")
	cases += 1
	if not WeKnoraClientScript.is_parse_pending("processing") or WeKnoraClientScript.is_parse_pending("completed"):
		failures.append("解析状态判定错误（轮询会停不下来或提前结束）")
	cases += 1
	if WeKnoraClientScript.parse_status_text("finalizing") != "正在生成摘要与索引":
		failures.append("解析状态文案缺失")
	# 图谱开关是**按库**判断的（用户部署上没有全局 /system），两种字段拼法都要认。
	cases += 1
	if not WeKnoraClientScript.is_graph_enabled({"indexing_strategy": {"graph_enabled": true}}):
		failures.append("新字段 indexing_strategy.graph_enabled 没被识别")
	cases += 1
	if not WeKnoraClientScript.is_graph_enabled({"extract_config": {"enabled": true}}):
		failures.append("旧字段 extract_config.enabled 没被识别（老版本会显示成未启用）")
	cases += 1
	if WeKnoraClientScript.is_graph_enabled({}) or WeKnoraClientScript.is_graph_enabled({"indexing_strategy": {"graph_enabled": false}}):
		failures.append("没有开图谱的库被误判成已启用")

	# ── 第五段：真 HTTP（本地假服务）──────────────────────────────────
	var mock = WeKnoraMockServer.new()
	mock.name = "WeKnoraMock"
	add_child(mock)
	if not mock.start():
		failures.append("假服务无法监听本机端口，端到端段落跳过")
	else:
		var client = WeKnoraClientScript.new()
		client.name = "WeKnoraClientProbe"
		add_child(client)
		client.initialize(mock.base_url(), "test-key")

		var listed: Dictionary = await client.list_knowledge_bases()
		var listed_items: Array = listed.get("items", [])
		cases += 1
		if not bool(listed.get("ok", false)) or listed_items.size() != 2:
			failures.append("列知识库失败：%s" % str(listed.get("error", "数量不对")))
		cases += 1
		if listed_items.size() != 2 or str(Dictionary(listed_items[0]).get("name", "")) != "技术文档":
			failures.append("知识库名称解析错误")

		# 分页：第一页 2 条（total=3）→ 该续页；第二页 1 条 → 该结束。
		var page_one: Dictionary = await client.list_knowledge("kb-1", 1, 2)
		var page_two: Dictionary = await client.list_knowledge("kb-1", 2, 2)
		cases += 1
		if Array(page_one.get("items", [])).size() != 2 or int(page_one.get("total", 0)) != 3:
			failures.append("知识列表分页解析错误")
		cases += 1
		if WeKnoraClientScript.next_page(1, 2, int(page_one.get("total", 0)), Array(page_one.get("items", [])).size()) != 2:
			failures.append("第一页之后没有续页")
		cases += 1
		if WeKnoraClientScript.next_page(2, 2, int(page_two.get("total", 0)), Array(page_two.get("items", [])).size()) != 0:
			failures.append("最后一页之后还在续页（会无限循环）")
		cases += 1
		var page_two_items: Array = page_two.get("items", [])
		if page_two_items.size() != 1 or str(Dictionary(page_two_items[0]).get("parse_status", "")) != "failed":
			failures.append("解析失败状态没有被解析出来")

		var chunks: Dictionary = await client.list_chunks("k-1", 1, 100)
		cases += 1
		if Array(chunks.get("items", [])).size() != 2:
			failures.append("分块列表解析错误")

		var single: Dictionary = await client.search("怎么部署", ["kb-1"], 6)
		cases += 1
		if not bool(single.get("ok", false)) or Array(single.get("items", [])).size() != 1:
			failures.append("单库混合检索失败：%s" % str(single.get("error", "")))
		var multi: Dictionary = await client.search("怎么部署", ["kb-1", "kb-2"], 6)
		var multi_items: Array = multi.get("items", [])
		cases += 1
		if not bool(multi.get("ok", false)) or multi_items.size() != 1:
			failures.append("多库检索失败：%s" % str(multi.get("error", "")))
		cases += 1
		if multi_items.size() != 1 or not str(Dictionary(multi_items[0]).get("content", "")).contains("跨库"):
			failures.append("多库检索没有走 knowledge-search")
		cases += 1
		var empty_query: Dictionary = await client.search("   ", ["kb-1"], 6)
		if bool(empty_query.get("ok", true)):
			failures.append("空问题也发了检索请求")
		cases += 1
		var no_kb: Dictionary = await client.search("问题", [], 6)
		if bool(no_kb.get("ok", true)):
			failures.append("没有选知识库也发了检索请求")

		# 上传：文件字节必须原样到达服务端（这一步验证 multipart 真的说得对）。
		var upload_bytes := PackedByteArray()
		for index in range(256):
			upload_bytes.append(index)
		var uploaded: Dictionary = await client.upload_file("kb-1", "自检资料.bin", upload_bytes, {"fileName": "自检资料.bin"})
		cases += 1
		if not bool(uploaded.get("ok", false)):
			failures.append("上传失败：%s" % str(uploaded.get("error", "")))
		cases += 1
		if not mock.uploaded_files.has("自检资料.bin"):
			failures.append("服务端没有收到文件")
		elif PackedByteArray(mock.uploaded_files["自检资料.bin"]) != upload_bytes:
			failures.append("到达服务端的字节与上传的不一致（multipart 组包有问题）")
		cases += 1
		if str(uploaded.get("knowledge_id", "")) != "k-new":
			failures.append("上传后没有取回知识 ID（后续没法轮询解析进度）")

		# 重复上传：409 必须被翻译成"已经在库里"，而不是一句"HTTP 409"。
		var duplicate: Dictionary = await client.upload_file("kb-1", "重复资料.md", "x".to_utf8_buffer(), {"duplicate_of": "3"})
		cases += 1
		if int(duplicate.get("status", 0)) != 409:
			failures.append("重复上传没有识别出 409")
		cases += 1
		if not str(duplicate.get("error", "")).contains("已经在知识库里"):
			failures.append("409 没有给出可读提示：%s" % str(duplicate.get("error", "")))

		# 解析轮询：假服务第一次回 processing、之后回 completed，必须真的等到完成。
		mock.parse_poll_count = 0
		var waited: Dictionary = await client.wait_for_parse("k-3", 10.0, 0.05)
		cases += 1
		if str(waited.get("status", "")) != "completed":
			failures.append("等待解析没有等到完成态：%s" % str(waited.get("status", "")))
		cases += 1
		if mock.parse_poll_count < 2:
			failures.append("处于 processing 时没有继续轮询（只查了一次）")
		cases += 1
		if bool(waited.get("timed_out", true)):
			failures.append("解析完成后仍然报告超时")

		# 鉴权与 404：错误必须给出可操作的文案。
		client.initialize(mock.base_url(), "bad-key")
		var unauthorized: Dictionary = await client.list_knowledge_bases()
		cases += 1
		if int(unauthorized.get("status", 0)) != 401 or not str(unauthorized.get("error", "")).contains("API Key"):
			failures.append("Key 失效时没有给出可读提示")
		client.initialize(mock.base_url(), "test-key")
		var missing: Dictionary = await client.knowledge_detail("不存在")
		cases += 1
		if int(missing.get("status", 0)) != 404 or not str(missing.get("error", "")).contains("找不到"):
			failures.append("404 没有给出可读提示")
		cases += 1
		if not mock.requests.size() >= 10:
			failures.append("假服务收到的请求数异常：%d" % mock.requests.size())
		cases += 1
		# 请求头必须真的带上鉴权与来源标识（这是最容易"看起来对"却漏掉的地方）。
		var headers_ok := false
		for record in mock.requests:
			if str(Dictionary(record).get("api_key", "")) == "test-key":
				headers_ok = true
		if not headers_ok:
			failures.append("请求里没有带上 X-API-Key")

		# ── 第六段：SSE 流式问答（知识图谱只在这条管道里生效）────────────
		# 纯函数先钉住分帧规则，再用假服务的分片流真跑一次。
		cases += 1
		var frame_one := WeKnoraClientScript.take_sse_frame("data: {\"a\":1}\n\ndata: {\"b\"".to_utf8_buffer())
		if str(frame_one.get("frame", "")) != "data: {\"a\":1}":
			failures.append("SSE 分帧没有在空行处切开")
		cases += 1
		if PackedByteArray(frame_one.get("rest", PackedByteArray())).get_string_from_utf8() != "data: {\"b\"":
			failures.append("SSE 分帧后残留的尾巴不对（会丢事件）")
		cases += 1
		if not str(WeKnoraClientScript.take_sse_frame("data: 不完整".to_utf8_buffer()).get("frame", "")).is_empty():
			failures.append("不完整的一帧被当成完整帧切走了")
		cases += 1
		var crlf_frame := WeKnoraClientScript.take_sse_frame("data: {\"a\":1}\r\n\r\n".to_utf8_buffer())
		if str(crlf_frame.get("frame", "")) != "data: {\"a\":1}":
			failures.append("CRLF 分隔的事件没有被识别")
		cases += 1
		var parsed_frame := WeKnoraClientScript.parse_sse_frame("event: message\ndata: {\"response_type\":\"answer\",\"content\":\"你好\"}")
		if str(parsed_frame.get("event", "")) != "message" or not str(parsed_frame.get("data", "")).contains("你好"):
			failures.append("事件帧解析错误")
		cases += 1
		if not WeKnoraClientScript.parse_sse_frame(": 这是一条注释").is_empty():
			failures.append("SSE 注释行被当成了事件")

		# 中文跨包截断：这是本轮最容易骗过测试的一条。
		# 端到端（真发一次流）**抓不住**它——分片到达时机不确定，客户端可能一次就读到两片，
		# 于是"朴素写法"照样跑通。所以这里直接钉住那条性质：
		# **还没成帧的字节必须原样留着，不能在解码后重新编码。**
		var frame_bytes := "data: {\"content\":\"尘埃尾\"}\n\n".to_utf8_buffer()
		var cut := WeKnoraClientScript.bytes_index_of(frame_bytes, "尘".to_utf8_buffer()) + 1
		cases += 1
		if cut <= 1 or cut >= frame_bytes.size():
			failures.append("测试自身没把中文字符切开（cut=%d），这条断言会变成摆设" % cut)
		var head_part := frame_bytes.slice(0, cut)
		var tail_part := frame_bytes.slice(cut)
		var half := WeKnoraClientScript.take_sse_frame(head_part)
		cases += 1
		if not str(half.get("frame", "")).is_empty():
			failures.append("半帧被误判成完整帧")
		cases += 1
		# 关键：残留必须逐字节等于喂进去的字节。解码再编码会把半个汉字变成 U+FFFD。
		if PackedByteArray(half.get("rest", PackedByteArray())) != head_part:
			failures.append("未成帧的字节在缓冲区里被改写（中文会被切成乱码）")
		var rejoined: PackedByteArray = half.get("rest", PackedByteArray())
		rejoined.append_array(tail_part)
		var completed := WeKnoraClientScript.take_sse_frame(rejoined)
		cases += 1
		if not str(completed.get("frame", "")).contains("尘埃尾"):
			failures.append("跨包拼回来之后中文不完整：%s" % str(completed.get("frame", "")))

		cases += 1
		var interpreted := WeKnoraClientScript.interpret_chat_frame(
			"event: message\ndata: {\"response_type\":\"references\",\"knowledge_references\":[{\"id\":\"c1\",\"content\":\"正文\",\"knowledge_title\":\"彗星.txt\",\"score\":4.04}]}"
		)
		cases += 1
		if str(interpreted.get("type", "")) != "references" or Array(interpreted.get("references", [])).size() != 1:
			failures.append("引用事件没有被解析出来（界面就没法显示出处）")
		cases += 1
		if not WeKnoraClientScript.format_citations(interpreted.get("references", [])).contains("彗星.txt"):
			failures.append("引用没有转成可读文案")
		cases += 1
		var failed_frame := WeKnoraClientScript.interpret_chat_frame("event: message\ndata: {\"response_type\":\"error\",\"error\":\"模型不可用\"}")
		if str(failed_frame.get("error", "")) != "模型不可用":
			failures.append("错误事件没有被识别（会把失败当成功）")

		var created: Dictionary = await client.create_session()
		cases += 1
		if not bool(created.get("ok", false)) or str(created.get("session_id", "")) != "session-1":
			failures.append("创建会话失败：%s" % str(created.get("error", "")))
		var streamed_events: Array = []
		var streamed: Dictionary = await client.stream_knowledge_chat(
			str(created.get("session_id", "session-1")),
			"彗尾的形状",
			["kb-1"],
			func(event: Dictionary) -> void: streamed_events.append(str(event.get("type", ""))),
			15.0
		)
		cases += 1
		if not bool(streamed.get("ok", false)):
			failures.append("流式问答失败：%s" % str(streamed.get("error", "")))
		cases += 1
		# 中文必须逐字完整：假服务故意把一个汉字切成两半发过来。
		if str(streamed.get("answer", "")) != "彗尾的形状主要分两种：尘埃尾和离子尾。":
			failures.append("流式答案内容不对（中文被切断时会产生乱码）：%s" % str(streamed.get("answer", "")))
		cases += 1
		if Array(streamed.get("references", [])).size() != 1:
			failures.append("流式回答没有带回引用")
		cases += 1
		if str(streamed.get("message_id", "")) != "3475c004":
			failures.append("流式回答没有记住消息 ID（后续停止生成要用）")
		cases += 1
		if bool(streamed.get("truncated", true)):
			failures.append("收到 done 事件后仍被标记为截断")
		cases += 1
		# 回调必须真的被逐个事件调用：界面靠它边收边显示。
		if streamed_events.size() < 4 or not streamed_events.has("references"):
			failures.append("流式事件回调不完整：%s" % str(streamed_events))
		cases += 1
		# 真机教训：首帧 agent_query 也带 done=true，早期版本因此读了第一帧就退出。
		# 假服务现在照着真服务发这一帧，所以这条断言守的是"别再退化成只看 done"。
		if not streamed_events.has("agent_query"):
			failures.append("假服务没有发首帧 agent_query，这条回归断言失去意义")
		cases += 1
		if int(streamed.get("event_count", 0)) < 5:
			failures.append("首帧 done=true 时提前结束了流：只收到 %d 个事件" % int(streamed.get("event_count", 0)))
		var system_info: Dictionary = await client.system_info()
		cases += 1
		if str(system_info.get("graph_engine", "")) != "Neo4j":
			failures.append("没有读到图谱引擎状态（连接自检要用它判断图谱能不能用）")

		client.queue_free()

	# ── 第七段：连接面板（用户填地址与 Key 的唯一入口）──────────────────
	# 这一段守的是"没有界面就等于没法配"：API Key 走设备绑定加密，
	# 手工编辑 json 写不进去，所以面板必须存在、必须能存、必须把不安全的地址挡下来。
	cases += 1
	if not knowledge_connection_window or not knowledge_connection_panel:
		failures.append("知识库连接面板没有创建（用户无处填写地址与 Key）")
	else:
		cases += 1
		if knowledge_source_option.item_count != 2:
			failures.append("来源选项不是两项（本机 / WeKnora）")
		cases += 1
		if not knowledge_key_edit.secret:
			failures.append("API Key 输入框不是密码框（会明文显示在屏幕上）")
		cases += 1
		if knowledge_host_edit.placeholder_text.strip_edges().is_empty():
			failures.append("地址输入框没有提示文字")
		# 完整走一遍填写流程。**刻意用假服务而不是"连不上的端口"**：
		# 连不上的端口会让 HTTPRequest 等满自己的超时（20 秒），两次就把自检顶过
		# 35 秒的退出计时，结果是"什么都没打印、退出码却是 0"——最危险的那种假通过。
		# 失败用例改用假服务返回 401：瞬时、确定，而且更贴近真实（Key 不对）。
		var mock_url: String = mock.base_url()
		var saved_host: String = weknora_config.get_host() if weknora_config else ""
		var saved_mode: String = weknora_config.get_mode() if weknora_config else ""
		knowledge_source_option.select(1)
		knowledge_insecure_check.button_pressed = false
		knowledge_host_edit.text = mock_url
		knowledge_key_edit.text = "bad-key"
		await save_and_test_knowledge_connection()
		cases += 1
		if weknora_config.get_mode() != WeKnoraConfigStore.MODE_LOCAL:
			failures.append("连接失败后仍然切到了 WeKnora（会留下一个每次提问都失败的来源）")
		cases += 1
		if not knowledge_connection_status.text.contains("连接失败"):
			failures.append("连接失败时没有告诉用户：%s" % knowledge_connection_status.text)
		cases += 1
		if not knowledge_connection_status.text.contains("API Key"):
			failures.append("Key 失效时没有说清原因：%s" % knowledge_connection_status.text)
		cases += 1
		if not weknora_config.has_api_key():
			failures.append("面板填写的 API Key 没有被加密保存")
		# 不安全地址必须在发请求之前就被挡下来。
		knowledge_host_edit.text = "http://192.168.1.9:8080"
		await save_and_test_knowledge_connection()
		cases += 1
		if not knowledge_connection_status.text.contains("地址不安全"):
			failures.append("明文内网地址没有被拦下：%s" % knowledge_connection_status.text)
		cases += 1
		if weknora_config.get_host() == "http://192.168.1.9:8080":
			failures.append("不安全的地址被写进了配置")
		# 明文放行开关：默认必须是关的；勾上之后同一个地址必须能过策略，
		# 但仍然要真的去连（连不上照样回到"连接失败"），而不是假装成功。
		cases += 1
		if weknora_config.get_allow_insecure_http():
			failures.append("明文放行开关默认是开的（默认就不该允许明文公网）")
		cases += 1
		if bool(weknora_config.check_host("http://134.175.41.15").get("ok", true)):
			failures.append("没勾选就放行了明文公网地址")
		weknora_config.set_allow_insecure_http(true)
		cases += 1
		var allowed: Dictionary = weknora_config.check_host("http://134.175.41.15")
		if not bool(allowed.get("ok", false)) or not bool(allowed.get("insecure", false)):
			failures.append("勾选明文放行后仍然连不上该地址")
		cases += 1
		if bool(weknora_config.check_host("ftp://134.175.41.15").get("ok", true)):
			failures.append("明文放行把别的协议也放进来了（只该放宽 http）")
		cases += 1
		if bool(weknora_config.check_host("https://kb.example.com").get("insecure", true)):
			failures.append("https 地址被误标成明文")
		# 放行之后同一地址必须能过策略（这里只验策略本身，不再发请求去等超时）。
		knowledge_insecure_check.button_pressed = true
		knowledge_host_edit.text = "http://134.175.41.15"
		cases += 1
		if not bool(weknora_config.check_host("http://134.175.41.15").get("ok", false)):
			failures.append("勾选明文放行后地址仍被策略拦下")
		weknora_config.set_allow_insecure_http(false)
		knowledge_insecure_check.button_pressed = false
		# 成功路径：用假服务真跑一次，必须切到 WeKnora、把知识库列出来、并报出图谱状态。
		knowledge_host_edit.text = mock_url
		knowledge_key_edit.text = "test-key"
		await save_and_test_knowledge_connection()
		cases += 1
		if weknora_config.get_mode() != WeKnoraConfigStore.MODE_WEKNORA:
			failures.append("测试通过却没有切到 WeKnora：%s" % knowledge_connection_status.text)
		cases += 1
		if not knowledge_connection_status.text.contains("读到 2 个知识库"):
			failures.append("连接成功后的汇总不对：%s" % knowledge_connection_status.text)
		cases += 1
		if not knowledge_connection_status.text.contains("知识图谱：已启用（2 个知识库）"):
			failures.append("没有把图谱状态告诉用户：%s" % knowledge_connection_status.text)
		cases += 1
		if collect_selected_knowledge_base_ids().size() != 2:
			failures.append("知识库列表没有渲染出来（用户勾不到任何库）")
		cases += 1
		if not weknora_config.get_knowledge_base_ids().size() == 2:
			failures.append("首次连接的默认全选没有存下来")
		# 叠窗：真机上出现过连接面板压着别的设置窗，右边露出一截别人的内容。
		# 打开连接面板必须先关掉其它工具窗——这条用行为断言钉住。
		open_utility_panel(knowledge_settings_panel, KNOWLEDGE_SETTINGS_WINDOW_SIZE, Vector2(390, 420))
		toggle_knowledge_connection_panel()
		cases += 1
		if knowledge_settings_panel.visible:
			failures.append("打开连接面板时没有关掉其它工具窗（两个窗会叠在一起）")
		cases += 1
		if not knowledge_connection_panel.visible:
			failures.append("连接面板没有打开")
		close_knowledge_connection_panel()
		# 收尾：把面板与配置还原成自检开始前的样子，别污染后续断言。
		knowledge_source_option.select(1 if saved_mode == WeKnoraConfigStore.MODE_WEKNORA else 0)
		knowledge_host_edit.text = saved_host
		knowledge_key_edit.text = ""
		if weknora_config:
			weknora_config.set_host(saved_host)
			weknora_config.clear_api_key()
			weknora_config.set_mode(WeKnoraConfigStore.MODE_LOCAL)
		if weknora_client:
			weknora_client.initialize("", "")

	# 收尾：把自检目录留给下一次运行前统一清理，这里只停掉监听。
	mock.stop()
	mock.queue_free()

	for failure in failures:
		print("WEKNORA_CLIENT_FAILURE ", str(failure))
	print("WEKNORA_CLIENT_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 解析窗拆分自检：直接断言"拆开了"，而不是断言分栏数学。
# 这些断言守的正是真机缺陷的根因——只要解析面板还挂在对话区内，
# "两栏最小尺寸之和超过窗口"就必然导致重叠。
# （2026-09-16 曾按用户要求合并成同窗分栏，同日用户要求改回独立窗口，断言随之还原。）
func run_analysis_window_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0
	cases += 1
	if not analysis_window:
		failures.append("解析窗原生窗口没有创建")
	cases += 1
	if not analysis_panel:
		failures.append("解析面板不存在")
	if analysis_window and analysis_panel:
		cases += 1
		if analysis_panel.get_window() != analysis_window:
			failures.append("解析面板没有挂在解析窗里（父节点是 %s）——它仍会和对话区争抢同一个画布" % analysis_panel.get_parent())
		cases += 1
		if chat_workspace_root and chat_workspace_root.is_ancestor_of(analysis_panel):
			failures.append("解析面板仍是对话工作区画布的后代，两栏冲突会复现")
		# 面板必须有滚动宿主，否则窗口变小时内容会被裁掉。
		sync_analysis_window_minimum()
		cases += 1
		if not analysis_panel.get_parent() is ScrollContainer:
			failures.append("解析面板没有滚动宿主（窗口变小时内容会被裁切）")
		layout_analysis_panel_in_window()
		cases += 1
		if not analysis_panel.get_parent() is ScrollContainer or analysis_panel.get_parent().get_parent() != analysis_window:
			failures.append("解析面板没有铺满解析窗：面板 %s 窗口 %s" % [analysis_panel.size, analysis_window.size])
	# 停靠与可见性同步需要真实屏幕：headless 下 DisplayServer 报可用区 (0,0)，
	# 任何"必须落在屏幕内"的断言都无意义。这里按环境分开，并把跳过原因打出来，
	# 而不是让断言因为环境而误报失败、也不是让它静默通过。
	var saved_chat_position := chat_workspace_window.position if chat_workspace_window else Vector2i.ZERO
	var saved_chat_size := chat_workspace_window.size if chat_workspace_window else Vector2i.ZERO
	var saved_window_position := analysis_window.position if analysis_window else Vector2i.ZERO
	var saved_window_size := analysis_window.size if analysis_window else Vector2i.ZERO
	var saved_window_visible := analysis_window.visible if analysis_window else false
	# [DSH] 气泡定位自检放在"真实屏幕"分支里。
	# 原因：它断言的是"气泡落在它所在的窗口内、并跟着场景换窗口"，而 headless 下
	# 主窗口尺寸是 0×0（get_window().size 返回零），这类断言在零宽窗口上没有意义——
	# 写在外面会**误报失败**，正是项目约定里要避免的那种假失败。
	var saved_bubble_visible := bubble.visible if bubble else false
	var saved_bubble_position := bubble.position if bubble else Vector2.ZERO
	var saved_bubble_size := bubble.size if bubble else Vector2.ZERO
	var usable := DisplayServer.screen_get_usable_rect(DisplayServer.window_get_current_screen())
	if usable.size.x >= 200 and usable.size.y >= 200 and bubble and chat_workspace_window:
		# [DSH] 气泡坐标是逻辑像素，窗口尺寸是物理像素：这里要换算后再比。
		var main_canvas := Vector2(logical_size(get_window().size))
		# 场景一：对话面板开着 —— 气泡必须**换到聊天窗口**里，与对话面板中线对齐。
		scene_input_dock.visible = true
		chat_workspace_window.visible = true
		var chat_canvas := Vector2(chat_workspace_window.size)
		position_status_bubble()
		cases += 1
		if bubble.get_parent() != chat_workspace_root:
			failures.append("对话面板开着时气泡没有换到聊天窗口（父节点 %s）——会落在另一个窗口里，看起来就是没对齐" % bubble.get_parent())
		cases += 1
		if bubble.position.x < -0.5 or bubble.position.x + bubble.size.x > chat_canvas.x + 0.5:
			failures.append("气泡越出聊天窗口：%s（窗口宽 %.1f）" % [Rect2(bubble.position, bubble.size), chat_canvas.x])
		var panel_center := scene_input_dock.position.x + scene_input_dock.size.x * 0.5
		var bubble_center := bubble.position.x + bubble.size.x * 0.5
		cases += 1
		# 面板很宽时气泡会被"面板内边距"限位，因此对齐只要求不超出面板范围。
		if bubble.position.x < scene_input_dock.position.x - 0.5 or bubble.position.x + bubble.size.x > scene_input_dock.position.x + scene_input_dock.size.x + 0.5:
			failures.append("气泡超出对话面板横向范围：气泡 %s 面板 %s" % [Rect2(bubble.position, bubble.size), Rect2(scene_input_dock.position, scene_input_dock.size)])
		elif absf(bubble_center - panel_center) > 1.0 and bubble.size.x < scene_input_dock.size.x - 24.0:
			failures.append("气泡没有与对话面板中线对齐：气泡中线 %.1f 面板中线 %.1f" % [bubble_center, panel_center])
		# 场景二：待机（对话面板关闭）—— 必须移回主窗口，在窗口内居中且不被裁掉。
		scene_input_dock.visible = false
		position_status_bubble()
		cases += 1
		if bubble.get_parent() != self:
			failures.append("待机时气泡没有回到主窗口（父节点 %s）" % bubble.get_parent())
		cases += 1
		if bubble.size.x > main_canvas.x + 0.5 or bubble.position.x < -0.5 or bubble.position.x + bubble.size.x > main_canvas.x + 0.5:
			failures.append("待机时气泡超出主窗口：气泡宽 %.1f 主窗口宽 %.1f" % [bubble.size.x, main_canvas.x])
		cases += 1
		if absf(bubble.position.x + bubble.size.x * 0.5 - main_canvas.x * 0.5) > 1.0:
			failures.append("待机时气泡没有在窗口内居中：中线 %.1f 期望 %.1f" % [bubble.position.x + bubble.size.x * 0.5, main_canvas.x * 0.5])
		scene_input_dock.visible = true
		# 收尾：把气泡挪回主窗口再恢复可见性——否则后续渲染会把它留在聊天窗口里，
		# 而自检期间聊天窗口可能被隐藏，气泡就再也看不见了。
		if bubble:
			var previous_visible := bubble.visible
			bubble.visible = false
			if bubble.get_parent() != self:
				bubble.reparent(self, false)
			bubble.position = saved_bubble_position
			bubble.size = saved_bubble_size
			bubble.visible = previous_visible and saved_bubble_visible
	if usable.size.x < 200 or usable.size.y < 200:
		print("ANALYSIS_WINDOW_DISPLAY_SKIP 无真实屏幕，跳过停靠与可见性同步断言（结构断言已通过）")
	elif chat_workspace_window and analysis_window:
		analysis_window.size = scaled_size(DEFAULT_ANALYSIS_WINDOW_SIZE)
		layout_analysis_panel_in_window()
		# 场景一：对话窗居中、右侧够放 → 应贴在右侧。
		# [DSH] 这里的几何断言全部走物理像素，所以对话窗尺寸也要先换算成物理尺寸，
		# 安全间隙同样按 ui_scale 折算，否则缩放后会出现"实际间隙 10 / 期望 12"的假失败。
		var chat_size := scaled_size(Vector2i(
			mini(WORKSPACE_WINDOW_SIZE.x, usable.size.x),
			mini(WORKSPACE_WINDOW_SIZE.y, usable.size.y)
		))
		chat_workspace_window.size = chat_size
		chat_workspace_window.position = Vector2i(usable.position.x + 20, usable.position.y + 20)
		position_analysis_window()
		var docked := Rect2i(analysis_window.position, analysis_window.size)
		var chat_rect := Rect2i(chat_workspace_window.position, chat_workspace_window.size)
		cases += 1
		if not usable.encloses(docked):
			failures.append("解析窗停靠后越出屏幕：%s（屏幕 %s）" % [docked, usable])
		cases += 1
		if docked.intersects(chat_rect):
			failures.append("解析窗与对话窗重叠：%s vs %s" % [docked, chat_rect])
		var gap := docked.position.x - chat_rect.end.x
		# [DSH] 安全间隙由布局模块按**物理**宽度算（解析窗定位也走物理像素），
		# 所以这里仍然用物理宽度，不要再折算 ui_scale，否则期望值会差 1px。
		var required := int(WorkspaceLayout.safe_gap_for_width(float(chat_rect.size.x)))
		cases += 1
		if gap != required and gap != -(required + docked.size.x):
			# 允许"右侧放不下翻到左侧"，但两者都必须满足安全间隙。
			failures.append("解析窗与对话窗的间隙不等于安全间隙：实际 %d 期望 %d（左侧停靠时为 -%d）" % [gap, required, required + docked.size.x])
		# 场景二：对话窗贴到屏幕右缘 → 右侧放不下，必须翻到左侧且仍在屏幕内。
		chat_workspace_window.position = Vector2i(usable.end.x - chat_size.x - 4, usable.position.y + 20)
		position_analysis_window()
		var flipped := Rect2i(analysis_window.position, analysis_window.size)
		cases += 1
		if not usable.encloses(flipped):
			failures.append("对话窗贴右缘时解析窗越界：%s（屏幕 %s）" % [flipped, usable])
		cases += 1
		if flipped.position.x >= chat_workspace_window.position.x:
			failures.append("对话窗贴右缘时解析窗没有翻到左侧：解析窗 x=%d 对话窗 x=%d" % [flipped.position.x, chat_workspace_window.position.x])
		# 场景三：可见性同步——对话窗隐藏时解析窗也必须隐藏。
		analysis_panel.visible = true
		analysis_window.hide()
		chat_workspace_window.hide()
		sync_analysis_window_visibility()
		cases += 1
		if analysis_window.visible:
			failures.append("对话窗已隐藏，解析窗仍然显示")
		chat_workspace_window.show()
		sync_analysis_window_visibility()
		cases += 1
		if not analysis_window.visible:
			failures.append("对话窗已显示，解析窗没有跟着显示")
		analysis_window.hide()
	# 收尾：恢复自检前的状态。
	if chat_workspace_window:
		chat_workspace_window.position = saved_chat_position
		chat_workspace_window.size = saved_chat_size
	if analysis_window:
		analysis_window.size = saved_window_size
		analysis_window.position = saved_window_position
		analysis_window.visible = saved_window_visible
	for failure in failures:
		print("ANALYSIS_WINDOW_FAILURE ", failure)
	print("ANALYSIS_WINDOW_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 守住一次真实事故：清理脚本删掉 `func schedule_selftest_exit()` 的声明后，
# 它的函数体（await 35 秒 + get_tree().quit()）落进了 `_ready()`，于是正式应用启动
# 35 秒后自己退出。当时所有自检照样 PASS——因为自检本来就是"跑完就退出"，
# 这种破坏对自检完全不可见。
#
# 所以这里直接对**源码结构**断言，而不是断言运行行为：
#   1) `schedule_selftest_exit` 必须是真正的顶层函数（函数体不能落进别的函数）；
#   2) 等待自检退出的那段代码必须只存在于它自己的函数体里。
func run_script_structure_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0
	var source := FileAccess.get_file_as_string("res://main.gd")
	cases += 1
	if source.is_empty():
		failures.append("读不到 main.gd 源码，无法检查脚本结构")
	else:
		var lines := source.split("\n")
		var exit_function := top_level_declaration_index(lines, "func schedule_selftest_exit")
		cases += 1
		if exit_function < 0:
			failures.append("schedule_selftest_exit 不是顶层函数：它的函数体会落进上一个函数（正式启动后会自行退出）")
		else:
			var next_function := top_level_declaration_index(lines, "func ", exit_function + 1)
			var body_end := next_function if next_function > exit_function else lines.size()
			var body := "\n".join(lines.slice(exit_function + 1, body_end))
			cases += 1
			if not body.contains("SELFTEST_EXIT"):
				failures.append("schedule_selftest_exit 的函数体不完整（找不到退出逻辑）")
			cases += 1
			if not body.contains("--selftest-exit="):
				failures.append("schedule_selftest_exit 没有解析 --selftest-exit 参数")
		var stray := -1
		for index in lines.size():
			if not lines[index].contains("await get_tree().create_timer(seconds).timeout"):
				continue
			if exit_function < 0 or index <= exit_function:
				stray = index
				break
		cases += 1
		if stray >= 0:
			failures.append("自检退出等待出现在 schedule_selftest_exit 之外（第 %d 行）" % (stray + 1))
	for failure in failures:
		print("SCRIPT_STRUCTURE_FAILURE ", failure)
	print("SCRIPT_STRUCTURE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# 返回从 from_line 起、行首满足 prefix 的**顶层**声明的行号。
#
# 难点：不能只看行首有没有关键字——GDScript 里函数中间可以出现行首写 `const` / `var`
# 的多行表达式（实测 main.gd 里有三处），把它们当边界会把函数切开。
# 因此这里跟踪括号深度，只在深度为 0 时才认边界；字符串与注释会被跳过。
# main.gd 的括号是配平的（已用独立扫描确认），所以这个判据成立。
func top_level_declaration_index(lines: PackedStringArray, prefix: String, from_line := 0) -> int:
	var depth := 0
	var quote := ""
	for index in range(maxi(0, from_line), lines.size()):
		var text := lines[index]
		var position := 0
		while position < text.length():
			var character := text[position]
			if not quote.is_empty():
				if character == "\\":
					position += 2
					continue
				if character == quote:
					quote = ""
				position += 1
				continue
			if character == "\"" or character == "'":
				quote = character
				position += 1
				continue
			if character == "#":
				break
			if character == "(" or character == "[" or character == "{":
				depth += 1
			elif character == ")" or character == "]" or character == "}":
				depth -= 1
			position += 1
		quote = ""
		if depth == 0 and text.begins_with(prefix):
			return index
	return -1

# [DSH] 守住"不设等待上限 + 用户可中止"这条约定。
#
# 为什么用源码断言：这条约定失效时**运行行为完全正常**——只是任务跑到 5 分钟就被误报成
# "没有完成"，而 Harness 那边其实还在正常执行并最终给出完整回答（真机上已踩过，
# 用户看到的就是"Harness 里答得好好的、程序里说没完成"）。
# 这种回归没法用离线行为断言覆盖，只能在结构上守住。
func run_agent_wait_policy_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0
	var bridge_source := FileAccess.get_file_as_string("res://agent_bridge.gd")
	var adapter_source := FileAccess.get_file_as_string("res://runtime/harness/app/blue-whale-connection.mjs")
	cases += 1
	if bridge_source.is_empty() or adapter_source.is_empty():
		failures.append("读不到 agent_bridge.gd 或 Harness 适配器源码，无法检查等待策略")
	else:
		cases += 1
		if bridge_source.contains("QUERY_TIMEOUT_SECONDS"):
			failures.append("等待上限又回来了：QUERY_TIMEOUT_SECONDS 仍在 agent_bridge.gd 里（会把长任务误报成未完成）")
		cases += 1
		if not bridge_source.contains("while true:"):
			failures.append("send_query 里没有无限等待循环（while true），任务会被某个上限中断")
		cases += 1
		if not bridge_source.contains("func stop_query("):
			failures.append("缺少用户中止入口 stop_query()")
		cases += 1
		if not adapter_source.contains('case "session.stop"'):
			failures.append("Harness 适配器没有 session.stop，桌面端的停止按钮无法真正中止上游轮次")
		cases += 1
		if not bridge_source.contains("query_cancelled"):
			failures.append("等待循环没有 query_cancelled 退出条件，停止后界面会永远停在执行中")
	for failure in failures:
		print("AGENT_WAIT_POLICY_FAILURE ", failure)
	print("AGENT_WAIT_POLICY_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 待发送队列自检。
#
# 守的核心性质是**附件快照**：排队项必须把当时的附件/图片一并带走。
# 若退化成"发送时才读全局状态"，第二条排队的消息就会顶着第一条的附件发出去，
# 而这种错发用户很难第一时间察觉（模型会认真分析错的文件）。
func run_chat_queue_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0
	var saved_text := agent_input.text if agent_input else ""
	var saved_path := chat_attachment_path
	var saved_bytes := chat_image_bytes
	var saved_name := chat_image_name
	var saved_info := chat_attachment_info.duplicate(true)
	var saved_busy := chat_busy
	chat_pending_queue.clear()

	# 1. 空输入（无文字、无附件）不该入队。
	chat_attachment_path = ""
	chat_image_bytes = PackedByteArray()
	chat_attachment_info = {}
	enqueue_chat_message("   ")
	cases += 1
	if not chat_pending_queue.is_empty():
		failures.append("空输入被放进了待发送队列")

	# 2. 只有附件、没有文字时必须能入队（与直接发送的兜底一致）。
	chat_attachment_path = "C:/tmp/示例.md"
	enqueue_chat_message("")
	cases += 1
	if chat_pending_queue.size() != 1:
		failures.append("只有附件没有文字时没有被放进队列")
	cases += 1
	if str(chat_pending_queue[0].get("attachment_path", "")) != "C:/tmp/示例.md":
		failures.append("排队项没有带上附件路径")
	cases += 1
	if not chat_pending_queue[0].get("text", "").contains("请分析这份文件"):
		failures.append("无文字时没有套用默认提问文案")

	# 3. 关键：入队后附件必须从"当前状态"清掉，否则下一条会重复带上它。
	cases += 1
	if not chat_attachment_path.is_empty() or not chat_attachment_info.is_empty():
		failures.append("入队后没有清空当前附件状态——下一条消息会重复带上同一附件")

	# 4. 两条消息各自带自己的附件：快照不能互相污染。
	chat_attachment_path = "C:/tmp/第一条.md"
	enqueue_chat_message("第一条")
	chat_attachment_path = "C:/tmp/第二条.md"
	chat_image_bytes = "fake-image".to_utf8_buffer()
	chat_image_name = "第二条.png"
	enqueue_chat_message("第二条")
	cases += 1
	if chat_pending_queue.size() != 3:
		failures.append("队列条数不对：期望 3，实际 %d" % chat_pending_queue.size())
	elif str(chat_pending_queue[1].get("attachment_path", "")) != "C:/tmp/第一条.md" or str(chat_pending_queue[2].get("attachment_path", "")) != "C:/tmp/第二条.md":
		failures.append("排队项的附件快照互相污染（第二条拿到了别的附件）")
	cases += 1
	if chat_pending_queue[2].get("image_bytes", PackedByteArray()).is_empty():
		failures.append("排队项没有带上图片字节")

	# 5. 撤销排队只弹出最后一条，且不动前面的。
	var before_undo := chat_pending_queue.size()
	undo_last_queued_message()
	cases += 1
	if chat_pending_queue.size() != before_undo - 1:
		failures.append("撤销排队没有只弹出最后一条")
	cases += 1
	if str(chat_pending_queue[0].get("attachment_path", "")) != "C:/tmp/示例.md":
		failures.append("撤销排队把前面的条目也动了")

	# 6. 忙碌时 dispatch 不派发（否则会和当前轮抢状态）。
	chat_busy = true
	dispatch_next_queued_message()
	cases += 1
	if chat_pending_queue.size() != before_undo - 1:
		failures.append("任务执行中仍然派发了队列（会和当前轮抢状态）")

	# 7. 即使 chat_busy 被其他分支错误清掉，只要工作流仍活动就不得派发。
	cases += 1
	if can_dispatch_queued_message(true, false, false, true):
		failures.append("工作流活动时队列仍被允许派发")
	cases += 1
	if not can_dispatch_queued_message(true, false, false, false):
		failures.append("全部锁释放后队列仍不能派发")

	# 收尾：恢复现场，别让自检改变真实状态。
	chat_pending_queue.clear()
	chat_busy = saved_busy
	chat_attachment_path = saved_path
	chat_image_bytes = saved_bytes
	chat_image_name = saved_name
	chat_attachment_info = saved_info
	if agent_input:
		agent_input.text = saved_text
	update_pending_queue_bar()
	for failure in failures:
		print("CHAT_QUEUE_FAILURE ", failure)
	print("CHAT_QUEUE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 主动开口自检：决策纯函数本身的自检（见 proactive_companion.gd），
# 外加一条"真实数据接线"断言——没有会话记录时不允许开口，
# 否则她会说出编造的内容（这是陪伴类功能最容易翻车的地方）。
func run_proactive_companion_selftest() -> void:
	var result: Dictionary = ProactiveCompanion.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("PROACTIVE_FAILURE ", str(failure))
	var cases := int(result.get("cases", 0))
	# [DSH] 时间戳解析必须在**任何环境**下都成立。
	# 这是主动开口最危险的失败模式：解析失败时 last_conversation_span() 静默返回 -1，
	# 于是她永远不说话，而界面上看不出任何异常（不会报错、不会提示）。
	# 因此这里直接断言解析与换算，不依赖是否存在会话记录。
	var probe_seconds := Time.get_unix_time_from_datetime_string("2026-09-14 17:03:57")
	cases += 1
	if probe_seconds <= 0:
		failures.append("会话时间戳（YYYY-MM-DD HH:MM:SS）解析失败——主动开口会永远拿不到'距上次对话多久'")
	else:
		cases += 1
		var round_trip := Time.get_datetime_string_from_unix_time(int(probe_seconds), false)
		if not round_trip.begins_with("2026-09-14"):
			failures.append("时间戳解析后换算不一致：%s" % round_trip)
	# 接线检查：真实数据目录下必须能读出秒数与标题；自检的临时目录里没有会话，
	# 这一项按实际情况报告（不伪装通过）。
	var span := last_conversation_span()
	print("PROACTIVE_DATA last_conversation_seconds=", span.get("seconds", -1.0), " title=", JSON.stringify(str(span.get("title", ""))))
	var conversations: Array = soul_store.list_conversations(1) if soul_store else []
	if conversations.is_empty():
		print("PROACTIVE_DATA_SKIP 当前数据目录没有会话记录，跳过'真实数据接线'断言（纯函数断言已通过）")
	else:
		cases += 1
		if float(span.get("seconds", -1.0)) < 0.0:
			failures.append("存在会话记录却读不到'距上次对话多久'——主动开口会因为拿不到事实而永远不说话")
		cases += 1
		if not str(span.get("title", "")).strip_edges().is_empty():
			failures.append("主动开口的数据接线仍暴露会话标题")
	# [DSH] 开关必须真的能存下来。
	# 这不是形式检查：soul_store.save_ui_settings() 是从 default_ui_settings() 重建字典，
	# **未显式搬运的键会被静默丢弃**——我加这个开关时就先踩了一次
	# （存了进去、读出来却没有），表现为"关掉之后重启又被打开"。
	if soul_store and not soul_store.root_path.is_empty():
		var before_settings: Dictionary = soul_store.get_ui_settings()
		var settings_to_save: Dictionary = before_settings.duplicate(true)
		settings_to_save["proactive_enabled"] = false
		settings_to_save["proactive_opt_in"] = true
		soul_store.save_ui_settings(settings_to_save)
		var reloaded: Dictionary = soul_store.get_ui_settings()
		cases += 1
		if bool(reloaded.get("proactive_enabled", true)):
			failures.append("'空闲时主动开口'开关没有真正保存（关掉后重读仍是开启）")
		cases += 1
		if not bool(reloaded.get("proactive_opt_in", false)):
			failures.append("主动开口的显式授权标记没有保存")
		# 收尾：完整写回测试前设置，别让自检改变现场。
		soul_store.save_ui_settings(before_settings)
	for failure in failures:
		print("PROACTIVE_FAILURE ", str(failure))
	print("PROACTIVE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 工作流「对话自动匹配」自检。
#
# 分两部分：
#   1) 决策纯函数的边界（见 workflow_auto_match.gd）；
#   2) **接线断言**——光有决策函数不算数，它必须真的被 submit_agent 调用。
#      这与"配置存了但从不触发"是同一个陷阱：代码齐全、行为为零，且没有任何报错。
func run_workflow_auto_match_selftest() -> void:
	var result: Dictionary = WorkflowAutoMatch.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("WORKFLOW_AUTO_FAILURE ", str(failure))
	var cases := int(result.get("cases", 0))
	var source := FileAccess.get_file_as_string("res://main.gd")
	cases += 1
	if source.is_empty():
		failures.append("读不到 main.gd，无法检查自动匹配接线")
	else:
		cases += 1
		if not source.contains("maybe_start_auto_workflow(query)"):
			failures.append("submit_agent 没有调用 maybe_start_auto_workflow——触发方式仍然只是保存配置，不会真的执行")
		cases += 1
		if not source.contains("func maybe_start_auto_workflow("):
			failures.append("缺少 maybe_start_auto_workflow 的实现")
		# 命中后必须保留工作流忙碌状态，且有附件时不得走自动工作流。
		cases += 1
		var call_index := source.find("if not has_attachment and maybe_start_auto_workflow(query):")
		if call_index < 0:
			failures.append("自动匹配没有阻止附件消息，附件可能被工作流忽略")
		else:
			var branch := source.substr(call_index, 520)
			if branch.contains("chat_busy = false") or not branch.contains("workflow_runner.is_active()"):
				failures.append("自动工作流启动后没有保持忙碌状态")
			if not branch.contains("append_chat_message(\"user\", display_query)"):
				failures.append("自动执行的用户指令没有写入对话记录")
		# 必须早于对话通道判定：否则同一个请求会被工作流和模型各做一遍。
		cases += 1
		var route_index := source.find("var route := decide_message_route(query)")
		if call_index < 0 or route_index < 0 or call_index > route_index:
			failures.append("自动匹配的判定晚于对话通道路由——同一个请求会被执行两遍")
	for failure in failures:
		print("WORKFLOW_AUTO_FAILURE ", str(failure))
	print("WORKFLOW_AUTO_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

func run_workflow_package_selftest() -> void:
	var result: Dictionary = WorkflowPackage.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("WORKFLOW_PACKAGE_FAILURE ", str(failure))
	print("WORKFLOW_PACKAGE_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())


# 工作流「定时」决策层仍保留兼容测试，但产品接线必须保持关闭。
# 等可视化时间配置、计划预览和显式授权全部完成后，才能重新开放后台调度。
func run_workflow_schedule_selftest() -> void:
	var result: Dictionary = WorkflowSchedule.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("WORKFLOW_SCHEDULE_FAILURE ", str(failure))
	var cases := int(result.get("cases", 0))
	var source := FileAccess.get_file_as_string("res://main.gd")
	cases += 1
	if source.is_empty():
		failures.append("读不到 main.gd，无法检查定时安全开关")
	else:
		cases += 1
		if WORKFLOW_SCHEDULER_ENABLED:
			failures.append("时间配置与授权界面尚未完成，后台调度不得启用")
		cases += 1
		var update_index := source.find("func update_workflow_schedules(")
		if update_index < 0 or not source.substr(update_index, 260).contains("if not WORKFLOW_SCHEDULER_ENABLED"):
			failures.append("后台调度函数缺少关闭状态的第一道保护")
	# 真实接线检查：调度文件路径必须落在灵魂仓库的配置目录下（不是临时目录、不是空）。
	cases += 1
	var path := workflow_schedule_path()
	if soul_store and not soul_store.root_path.is_empty():
		if path.is_empty() or path.get_file() != WORKFLOW_SCHEDULE_FILE:
			failures.append("定时计划文件路径不正确：%s" % path)
	for failure in failures:
		print("WORKFLOW_SCHEDULE_FAILURE ", str(failure))
	print("WORKFLOW_SCHEDULE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# [DSH] 探头动作去重自检：守住"60 个槽位、2 张图片"这件事。
# 这条自检存在的理由是一次真实的内存事故：动作目录里 60 个文件其实只有两张不同的图
# （第 29/30/31 帧是闭眼那一拍），旧实现按文件逐个加载，60 张 1024×1536 纹理
# 各自占一份显存（约 377 MB），而屏幕上真正变化的只有两张。
# 断言分成三层：清单解析（纯函数）、展开后的槽位共用关系、图片内容哈希。
func run_dock_sequence_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0

	# ── 第一层：清单解析（纯函数，不依赖磁盘）──────────────────────────
	cases += 1
	var good := parse_action_manifest({
		"fps": 60,
		"images": {"a": "00.png", "b": "29.png"},
		"frames": ["a", "a", "b"],
	})
	if Array(good.get("frames", [])) != ["00.png", "00.png", "29.png"]:
		failures.append("合法清单没有按帧展开：%s" % str(good.get("frames", [])))
	cases += 1
	if float(good.get("fps", 0.0)) != 60.0:
		failures.append("清单 fps 没有被读取")
	# 反向：清单少一个键时必须整体退回编号扫描，而不是给出半张空白序列。
	cases += 1
	var broken := parse_action_manifest({"images": {"a": "00.png"}, "frames": ["a", "missing"]})
	if not Array(broken.get("frames", [])).is_empty():
		failures.append("清单缺键时没有退回编号帧扫描")
	cases += 1
	if not Array(parse_action_manifest("不是字典").get("frames", [])).is_empty():
		failures.append("非字典清单没有退回编号帧扫描")
	cases += 1
	var clamped := parse_action_manifest({"fps": 999, "images": {"a": "00.png"}, "frames": ["a"]})
	if float(clamped.get("fps", 0.0)) != 60.0:
		failures.append("清单 fps 没有被限制在 1..60")

	# ── 第二层：真实动作库的槽位与共用关系 ────────────────────────────
	cases += 1
	if not action_library.has(DOCK_ACTION):
		failures.append("探头动作没有加载")
	else:
		var frames: Array = action_library[DOCK_ACTION].get("frames", [])
		cases += 1
		if frames.size() != 60:
			failures.append("探头帧数应为 60，实际 %d（帧数变了，动作节奏就变了）" % frames.size())
		var unique := {}
		for texture in frames:
			unique[texture.get_instance_id()] = true
		cases += 1
		if unique.size() != PEEK_UNIQUE_IMAGE_BUDGET:
			failures.append(
				"探头只应有 %d 张不同图片，实际 %d（重复帧又各自占了一份显存）"
				% [PEEK_UNIQUE_IMAGE_BUDGET, unique.size()]
			)
		# 闭眼那一拍必须落在第 29/30/31 帧，且与睁眼帧不是同一张图——
		# 槽位共用关系错了，画面上就会变成"一直眨眼"或"从来不眨"。
		if frames.size() == 60 and unique.size() == PEEK_UNIQUE_IMAGE_BUDGET:
			cases += 1
			var open_id: int = frames[0].get_instance_id()
			var closed_id: int = frames[29].get_instance_id()
			if open_id == closed_id:
				failures.append("第 29 帧与第 0 帧是同一张图，闭眼那一拍丢了")
			cases += 1
			if frames[30].get_instance_id() != closed_id or frames[31].get_instance_id() != closed_id:
				failures.append("闭眼帧没有连续覆盖第 29/30/31 帧")
			cases += 1
			if frames[28].get_instance_id() != open_id or frames[32].get_instance_id() != open_id:
				failures.append("闭眼帧的范围超出了第 29/30/31 帧")
			cases += 1
			if frames[min(PEEK_HOLD_FRAME, frames.size() - 1)].get_instance_id() != open_id:
				failures.append("停靠保持帧取到了闭眼图，探头会定格在闭眼上")

	# ── 第三层：图片内容哈希（美术被换掉时立刻发现）────────────────────
	# 这两个值就是去重前的 00.png 与 29.png，去重不允许改变任何一张图的内容。
	var expected_hashes := {
		"00.png": "3A4E2B00742B47398335FD873F1E5EE24F151FC91C838A21EC28B3823AEAA528",
		"29.png": "1F6F530636166BE3B7F4115E23A8D4B6216524A2E261BCE38008054F9B0A97D2",
	}
	for file_name in expected_hashes:
		cases += 1
		var path := "res://assets/actions/%s/%s" % [DOCK_ACTION, file_name]
		if not FileAccess.file_exists(path):
			failures.append("探头图片缺失：%s" % file_name)
			continue
		var digest := FileAccess.get_sha256(path)
		if digest.to_upper() != expected_hashes[file_name]:
			failures.append("探头图片内容变了：%s（%s）" % [file_name, digest])

	# ── 第四层：停靠保持时的呼吸（纯函数）────────────────────────────
	# 帧序列播完后画面是静止贴图，这里补一点呼吸位移。四个必须成立的性质：
	# 幅度封顶、零相位回到原点、周期连续、非法参数不产生位移。
	cases += 1
	if dock_hold_offset(0.0) != Vector2.ZERO:
		failures.append("呼吸位移在 t=0 不为零，停靠接手瞬间会跳一下")
	cases += 1
	var peak := 0.0
	for step in range(0, 341):
		var offset := dock_hold_offset(float(step) / 100.0)
		peak = maxf(peak, absf(offset.y))
	if peak > PEEK_HOLD_BREATHE_PIXELS + 0.0001:
		failures.append("呼吸幅度超过上限：%.3f > %.3f" % [peak, PEEK_HOLD_BREATHE_PIXELS])
	cases += 1
	if peak < PEEK_HOLD_BREATHE_PIXELS * 0.5:
		failures.append("呼吸幅度几乎为零（%.3f），这个功能等于没接上" % peak)
	cases += 1
	var wrapped := dock_hold_offset(PEEK_HOLD_BREATHE_SECONDS)
	if absf(wrapped.y - dock_hold_offset(0.0).y) > 0.0001:
		failures.append("呼吸在一个周期后没有回到起点，长时间停靠会累积偏移")
	cases += 1
	if dock_hold_offset(1.0, 0.0, 0.0) != Vector2.ZERO or dock_hold_offset(1.0, -1.0, 3.0) != Vector2.ZERO:
		failures.append("非法呼吸参数没有安全回退为零位移")

	# ── 第五层：真跑一次保持状态（不是只测纯函数）──────────────────────
	# 直接驱动 update_dock_hold_breathe，断言"人物位置真的在动、且只上下动"，
	# 结束后把停靠状态与坐标原样还回去——这段自检跑在真实主场景里。
	cases += 1
	var saved_side := dock_side
	var saved_holding := dock_peek_holding
	var saved_clock := dock_hold_clock
	var saved_position := character.position
	dock_side = 1
	dock_peek_holding = true
	dock_hold_clock = 0.0
	update_dock_hold_breathe(0.0)
	var breathe_base := character.position
	update_dock_hold_breathe(PEEK_HOLD_BREATHE_SECONDS * 0.25)
	var breathe_peak := character.position
	update_dock_hold_breathe(PEEK_HOLD_BREATHE_SECONDS * 0.75)
	var breathe_back := character.position
	if breathe_base != dock_character_position():
		failures.append("进入保持状态时人物不在停靠基准点上")
	cases += 1
	if absf((breathe_peak - breathe_base).y) < PEEK_HOLD_BREATHE_PIXELS * 0.95:
		failures.append("保持状态里人物没有真的动：位移 %.3f" % (breathe_peak - breathe_base).y)
	cases += 1
	if absf((breathe_peak - breathe_base).x) > 0.0001:
		failures.append("呼吸带动了横向位移，人物会在屏幕边上左右蹭")
	cases += 1
	if (breathe_back - breathe_base).length() > 0.0001:
		failures.append("一个周期后人物没有回到基准点")
	dock_side = saved_side
	dock_peek_holding = saved_holding
	dock_hold_clock = saved_clock
	character.position = saved_position

	for failure in failures:
		print("DOCK_SEQUENCE_FAILURE ", str(failure))
	var loaded_frames := 0
	var loaded_unique := 0
	if action_library.has(DOCK_ACTION):
		loaded_frames = Array(action_library[DOCK_ACTION].get("frames", [])).size()
		var ids := {}
		for texture in action_library[DOCK_ACTION].get("frames", []):
			ids[texture.get_instance_id()] = true
		loaded_unique = ids.size()
	print(
		"DOCK_SEQUENCE_SELFTEST=", "PASS" if failures.is_empty() else "FAIL",
		" cases=", cases, " failures=", failures.size(),
		" frames=", loaded_frames, " unique=", loaded_unique,
		" load_ms=", "%.1f" % action_library_load_ms
	)

func run_openai_stream_selftest() -> void:
	var result: Dictionary = OpenAIStreamClient.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("OPENAI_STREAM_FAILURE ", str(failure))
	print("OPENAI_STREAM_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())

func run_harness_live_stream_selftest() -> void:
	var result: Dictionary = AgentBridgeCore.assistant_stream_selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("HARNESS_LIVE_STREAM_FAILURE ", str(failure))
	print("HARNESS_LIVE_STREAM_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())

# 工作流运行记录保留策略自检。
func run_workflow_retention_selftest() -> void:
	if not soul_store or soul_store.root_path.is_empty():
		print("WORKFLOW_RETENTION_SELFTEST=SKIP 灵魂仓库未就绪")
		return
	var probe: String = soul_store.root_path.path_join("自检临时/工作流保留")
	var result: Dictionary = WorkflowRunner.selftest(probe)
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("WORKFLOW_RETENTION_FAILURE ", str(failure))
	print("WORKFLOW_RETENTION_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())

func run_screenshot_center_selftest() -> void:
	var result: Dictionary = ScreenshotCenterCore.selftest()
	var failures: Array = result.get("failures", [])
	for failure in failures:
		print("SCREENSHOT_CENTER_FAILURE ", str(failure))
	print("SCREENSHOT_CENTER_SELFTEST=", "PASS" if bool(result.get("ok", false)) else "FAIL", " cases=", int(result.get("cases", 0)), " failures=", failures.size())

# 对话窗口最大化/还原自检。
# 需要真实窗口尺寸，因此 headless（窗口为 0×0）下只报告跳过，不伪装成通过。
func run_chat_maximize_selftest() -> void:
	if DisplayServer.get_name() == "headless":
		print("CHAT_MAXIMIZE_SELFTEST=SKIP 无真实屏幕，原生还原另有独立窗口实测")
		return
	# Do not resize the shared chat while other asynchronous selftests use it.
	var probe := Window.new()
	NativeWindows.configure(probe)
	probe.title = "梁鲸 · 原生还原自检"
	probe.size = Vector2i(640, 480)
	add_child(probe)
	NativeWindows.fit(probe)
	probe.show()
	for index in 8:
		await get_tree().process_frame
	var before := Rect2i(probe.position, probe.size)
	probe.mode = Window.MODE_MAXIMIZED
	for index in 8:
		await get_tree().process_frame
	var maximized := probe.mode == Window.MODE_MAXIMIZED
	probe.mode = Window.MODE_WINDOWED
	for index in 8:
		await get_tree().process_frame
	var restored := Rect2i(probe.position, probe.size) == before
	print("CHAT_MAXIMIZE_SELFTEST=", "PASS" if maximized and restored else "FAIL", " native_maximized=", maximized, " restored=", restored)
	probe.queue_free()


func run_layered_character_selftest() -> void:
	var failures: Array[String] = []
	if not layered_character or not layered_character.ready_for_use:
		print("LAYERED_CHARACTER_SELFTEST=SKIP 分层装置未就绪")
		return
	var original: Texture2D = load(MODEL_TEXTURE)
	if not layered_character.set_appearance(original):
		failures.append("无法把原装纹理交给分层装置")
	elif not layered_character.uses_original_art():
		failures.append("原装纹理未被识别为原装（闭眼合成会被错误关闭）")

	# 换上一张合法的生成形象纹理：必须被接受，且不再判定为原装。
	var outfit_image := Image.create(1024, 1536, false, Image.FORMAT_RGBA8)
	outfit_image.fill(Color(0.9, 0.2, 0.2, 1.0))
	var outfit_texture := ImageTexture.create_from_image(outfit_image)
	if not layered_character.set_appearance(outfit_texture):
		failures.append("合法的 1024x1536 生成形象被拒绝——换装后将退回旧显示方式")
	elif layered_character.uses_original_art():
		failures.append("生成形象被误判为原装")
	# 尺寸不符必须拒绝，否则会被拉伸错位。
	var wrong_texture := ImageTexture.create_from_image(Image.create(512, 768, false, Image.FORMAT_RGBA8))
	if layered_character.set_appearance(wrong_texture):
		failures.append("尺寸不符的纹理竟然被接受")

	# 关键：必须在**真实的换装状态**下断言。
	# custom_outfit_active 必须置为 true，否则即使条件里带着 not custom_outfit_active
	# 也照样成立，这条断言就会变成装饰品（实测踩过：回退修复后它仍然 PASS）。
	var previous_outfit_state := custom_outfit_active
	custom_outfit_active = true
	layered_character.set_appearance(outfit_texture)
	sync_layered_character()
	var outfit_uses_layers: bool = layer_trial_enabled and layered_character.visible and not character_sprite.visible
	if layer_trial_enabled and not outfit_uses_layers:
		failures.append("换装状态下分层装置没有接管显示（回落到了旧路径）")
	custom_outfit_active = previous_outfit_state

	# 合成眨眼的实际渲染检查。
	# 着色器分支只有在真正渲染时才会被验证；这里造一张"虹膜 + 肤色"结构的形象，
	# 在多个闭眼程度上离屏渲染，确认闭眼过程连续、且中心确实从虹膜过渡到肤色。
	failures.append_array(await check_synthetic_blink())

	# 情绪表情的实际渲染检查。
	failures.append_array(await check_expression_states())

	# 收尾：恢复到当前真实外观，避免自检本身改变画面。
	sync_layered_appearance()
	for failure in failures:
		print("LAYERED_CHARACTER_FAILURE ", failure)
	print("LAYERED_CHARACTER_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=18 failures=", failures.size())

# [DSH] 三种表情的离屏渲染检查。
#
# 断言必须落在"只有表情变化才会改变"的像素上，否则就是装饰品：
# 造一张带明确结构的面部测试图（深色眉带 / 蓝虹膜 / 红唇），三行特征互不重叠，
# 然后：
#   平静：眉带处是深色、眼下是肤色、嘴唇是红色（前置条件，证明测试形象生效）；
#   专注：原眉带位置露出肤色——证明"压眉"真的把眉眼带往下移了；
#   沮丧：原眉带位置变成肤色、眼下出现虹膜色——证明"下垂"生效；
#         并且头部区域整体发生了非平凡位移——证明"低头"（旋转）也在起作用。
#
# 注意：行距必须大于最大位移，否则相邻特征会串行。
# 踩过的坑：早期眉带半高 0.012、眼下探针只放 +0.026，结果"眼下探针"落在了嘴唇带里，
# 于是所有采样都是嘴唇色——断言看起来在工作，实际测的是同一个东西。
const EXPRESSION_TEST_BROW_Y := 0.148
const EXPRESSION_TEST_EYE_Y := 0.186
# [DSH] 唇带原来放在 0.220，而虹膜椭圆在 y 方向的半轴是 0.025（下缘 0.211）——
# 两者之间只剩 0.003 的缝，于是"眼下探针"怎么放都落在其中一边：
# 原来放在 +0.018（=0.204）其实**画在虹膜里面**，"平静时眼下是肤色"这条断言
# 从一开始就不可能成立（有屏实测：under=(0.149,0.349,0.8471) 就是虹膜色）。
# 把唇带下移，给眼下让出可采样的肤色区。
const EXPRESSION_TEST_LIP_Y := 0.238
const EXPRESSION_TEST_BROW_HALF := 0.007
const EXPRESSION_TEST_LIP_HALF := 0.006

func check_expression_states() -> Array[String]:
	var failures: Array[String] = []
	var canvas := Vector2i(1024, 1536)
	var skin := Color(0.96, 0.82, 0.72, 1.0)
	var brow := Color(0.12, 0.09, 0.08, 1.0)
	var iris := Color(0.15, 0.35, 0.85, 1.0)
	var lip := Color(0.80, 0.22, 0.30, 1.0)
	var face := Image.create(canvas.x, canvas.y, false, Image.FORMAT_RGBA8)
	face.fill(skin)
	for y in range(int((EXPRESSION_TEST_BROW_Y - EXPRESSION_TEST_BROW_HALF) * canvas.y), int((EXPRESSION_TEST_BROW_Y + EXPRESSION_TEST_BROW_HALF) * canvas.y)):
		for x in range(int(0.36 * canvas.x), int(0.63 * canvas.x)):
			face.set_pixel(x, y, brow)
	for eye_x in [0.444, 0.544]:
		var center := Vector2(eye_x * canvas.x, EXPRESSION_TEST_EYE_Y * canvas.y)
		var radius := Vector2(0.043 * canvas.x, 0.025 * canvas.y)
		for y in range(int(center.y - radius.y * 1.4), int(center.y + radius.y * 1.4)):
			for x in range(int(center.x - radius.x * 1.1), int(center.x + radius.x * 1.1)):
				var local := Vector2((x - center.x) / radius.x, (y - center.y) / radius.y)
				if local.length() <= 1.0:
					face.set_pixel(x, y, iris)
	for y in range(int((EXPRESSION_TEST_LIP_Y - EXPRESSION_TEST_LIP_HALF) * canvas.y), int((EXPRESSION_TEST_LIP_Y + EXPRESSION_TEST_LIP_HALF) * canvas.y)):
		for x in range(int(0.40 * canvas.x), int(0.60 * canvas.x)):
			face.set_pixel(x, y, lip)
	if not layered_character.set_appearance(ImageTexture.create_from_image(face)):
		failures.append("表情检查：测试形象被 set_appearance 拒绝")
		return failures
	var previous_profile: Dictionary = layered_character.profile
	var profile: Dictionary = MotionProfile.defaults()
	profile["eyes_calibrated"] = true
	profile["eyes_enabled"] = true
	profile["blink_enabled"] = true
	profile["arm_swing"] = 0.0
	profile["leg_swing"] = 0.0
	profile["hair"] = 0.0
	profile["breath"] = 0.0
	layered_character.set_motion_profile(profile)

	var probe_brow := Vector2i(int(0.444 * canvas.x), int(EXPRESSION_TEST_BROW_Y * canvas.y))
	var probe_eye := Vector2i(int(0.444 * canvas.x), int(EXPRESSION_TEST_EYE_Y * canvas.y))
	# 眼下探针：必须在虹膜椭圆下缘（0.186+0.025=0.211）之下、唇带（0.238-0.006=0.232）之上。
	var probe_below_eye := Vector2i(int(0.444 * canvas.x), int(0.217 * canvas.y))
	# [DSH] 眉带**上方**的探针：用来测"眉带整体下移"。
	# 原来拿眉带内部的探针去测下垂，指望位移把眉带推离该点——
	# 实测推不掉：下垂量只有 0.0075，而低头旋转在该处还把采样点上抬，两者互相抵消，
	# 于是"沮丧表情：眉带没有下移"长期误报。测方向要在运动方向的前方取样。
	var probe_above_brow := Vector2i(int(0.5 * canvas.x), int((EXPRESSION_TEST_BROW_Y - 0.010) * canvas.y))
	var probe_lip := Vector2i(int(0.5 * canvas.x), int(EXPRESSION_TEST_LIP_Y * canvas.y))
	if not await verify_capture_is_live(canvas, profile):
		print("EXPRESSION_RENDER_SKIP 无可用/不可信的渲染帧，跳过像素级表情检查")
		return failures
	var calm := await capture_layered_frame(canvas, 0.0, layered_character.EMOTION_CALM, true)
	var focus := await capture_layered_frame(canvas, 0.0, layered_character.EMOTION_FOCUS, true)
	var down := await capture_layered_frame(canvas, 0.0, layered_character.EMOTION_DOWN, true)
	close_layered_capture()
	layered_character.set_motion_profile(previous_profile)
	if calm == null or focus == null or down == null:
		print("EXPRESSION_RENDER_SKIP 无可用渲染目标（headless），跳过像素级表情检查")
		return failures
	var calm_brow := calm.get_pixelv(probe_brow)
	var calm_eye := calm.get_pixelv(probe_eye)
	var calm_under := calm.get_pixelv(probe_below_eye)
	var calm_lip := calm.get_pixelv(probe_lip)
	var focus_brow := focus.get_pixelv(probe_brow)
	var down_brow := down.get_pixelv(probe_brow)
	var down_under := down.get_pixelv(probe_below_eye)
	var calm_above := calm.get_pixelv(probe_above_brow)
	var down_above := down.get_pixelv(probe_above_brow)
	# [DSH] "眉眼下垂"改成量**虹膜质心**的下移量：固定列扫"虹膜上缘"会被低头旋转的
	# 横向位移污染（实测沮丧时上缘反而报告"升高"8 像素），质心跨两只眼睛平均，
	# 旋转对左右眼的相反影响会互相抵消，剩下的就是下垂。
	var eye_span := Rect2i(int(0.38 * canvas.x), int(0.15 * canvas.y), int(0.24 * canvas.x), int(0.08 * canvas.y))
	var calm_iris_center := iris_centroid_row(calm, eye_span)
	var down_iris_center := iris_centroid_row(down, eye_span)
	var head_rect := Rect2i(int(0.34 * canvas.x), int(0.105 * canvas.y), int(0.32 * canvas.x), int(0.09 * canvas.y))
	var focus_shift := mean_abs_difference(calm, focus, head_rect)
	var down_shift := mean_abs_difference(calm, down, head_rect)
	print("EXPRESSION_SAMPLES calm(brow=", calm_brow, " eye=", calm_eye, " under=", calm_under, " lip=", calm_lip, ") focus_brow=", focus_brow, " down(brow=", down_brow, " under=", down_under, " above=", down_above, " calm_above=", calm_above, ") iris_center(calm=", calm_iris_center, " down=", down_iris_center, ") shift(focus=", focus_shift, " down=", down_shift, ")")
	# 前置条件：测试形象必须生效，否则后面所有结论都无意义。
	if calm_brow.get_luminance() > 0.55:
		failures.append("表情检查：平静时眉带处不是深色，测试形象没有生效")
	if calm_under.get_luminance() < 0.55:
		failures.append("表情检查：平静时眼下不是肤色（测试形象行距过窄或探针位置错误）")
	if calm_eye.b <= calm_eye.r:
		failures.append("表情检查：平静时眼睛中心不是虹膜色，测试形象没有生效")
	if calm_lip.r < 0.5 or calm_lip.r <= calm_lip.b:
		failures.append("表情检查：平静时嘴唇不是红色，测试形象没有生效")
	# 专注 = 压眉：眉带下移，原本的眉带位置露出肤色。
	if focus_brow.get_luminance() <= calm_brow.get_luminance() + 0.08:
		failures.append("专注表情：眉带没有下移（压眉未生效）")
	# 沮丧 = 眉眼下垂 + 低头。
	# 眉带下移：取眉带**上方**的探针——原来用眉带内部的点，位移推不掉它（见上面的注释）。
	if down_above.get_luminance() >= calm_above.get_luminance() - 0.08:
		failures.append("沮丧表情：眉带没有下移（眉带上方的探针没有变深）")
	# 眼睛跟着下垂：量虹膜质心的下移像素数，而不是赌某个像素恰好变色。
	# [DSH] 这条**只记录不断言**：沮丧同时带来 30% 的眼睑闭合（着色器 emotion_lid），
	# 眼睑从上方盖住虹膜，可见虹膜的重心会因此上移——实测 calm=286 → down=278，
	# 方向与"下垂"相反。也就是说这个量把"眼睑闭合"和"整体下垂"混在一起，
	# 在像素层分不开（下垂约 4 像素，闭合造成的形变更大）。留着打印是为了有据可查，
	# 不让它冒充断言。"眼睛是否跟着下垂"目前只能靠人眼确认。
	if calm_iris_center < 0 or down_iris_center < 0:
		failures.append("表情检查：在眼睛区域找不到虹膜（探针范围不对，后续眼睛断言无意义）")
	if down_shift < 0.02:
		failures.append("沮丧表情：头部区域几乎没有变化，低头（旋转）未生效")
	if focus_shift < 0.005:
		failures.append("专注表情：头部区域几乎没有变化，压眉未生效")
	return failures

# [DSH] 虹膜（蓝色）像素在给定区域内的平均行号；没有蓝色像素时返回 -1。
# 相比"某一列的第一个虹膜像素"，质心对横向位移与采样抖动都更稳。
func iris_centroid_row(image: Image, area: Rect2i) -> int:
	var total := 0.0
	var count := 0
	var x := area.position.x
	while x < area.position.x + area.size.x:
		var y := area.position.y
		while y < area.position.y + area.size.y:
			var pixel := image.get_pixel(x, y)
			if pixel.a > 0.5 and pixel.b > pixel.r + 0.15 and pixel.b > pixel.g + 0.10:
				total += float(y)
				count += 1
			y += 2
		x += 2
	if count == 0:
		return -1
	return int(round(total / float(count)))

# 两张同尺寸图像在给定区域内的平均逐像素差（按 8 像素步长采样）。
# 用途：验证"情绪确实改变了渲染结果"，而不依赖具体某个像素恰好落在某条特征带上。
func mean_abs_difference(a: Image, b: Image, area: Rect2i) -> float:
	var total := 0.0
	var samples := 0
	var step := 8
	var x := area.position.x
	while x < area.position.x + area.size.x:
		var y := area.position.y
		while y < area.position.y + area.size.y:
			if x < a.get_width() and y < a.get_height():
				var pa := a.get_pixel(x, y)
				var pb := b.get_pixel(x, y)
				total += absf(pa.r - pb.r) + absf(pa.g - pb.g) + absf(pa.b - pb.b)
				samples += 1
			y += step
		x += step
	return total / maxf(1.0, float(samples) * 3.0)

# [DSH] 表情状态机自检：状态 → 表情的映射、沮丧的自动回落、以及"沮丧不被覆盖"。
# 这套逻辑的失效方式很隐蔽：wire 断了以后一切都"看起来正常"，只是表情永远不动，
# 所以这里每条断言都同时检查 main.gd 的意图值和 layered_character 的实际值。
func run_harness_emotion_selftest() -> void:
	var failures: Array[String] = []
	var cases := 0
	var previous_expression := harness_expression
	var previous_hold := harness_expression_hold
	harness_expression = EXPRESSION_CALM
	harness_expression_hold = 0.0

	# 1. 等待授权 / 等待用户选择 → 专注。
	set_harness_emotion(EXPRESSION_FOCUS)
	cases += 1
	if harness_expression != EXPRESSION_FOCUS:
		failures.append("等待交互时没有进入专注表情")
	if layered_character and layered_character.current_emotion() != EXPRESSION_FOCUS:
		failures.append("专注意图没有下发到分层装置（表情层未接线）")

	# 2. 用户已作答 → 回到平静。
	set_harness_emotion(EXPRESSION_CALM)
	cases += 1
	if harness_expression != EXPRESSION_CALM:
		failures.append("交互结束后没有回到平静表情")
	if layered_character and layered_character.current_emotion() != EXPRESSION_CALM:
		failures.append("平静意图没有下发到分层装置")

	# 3. 任务失败 → 沮丧，并且保持期内不允许被"执行中"覆盖。
	set_harness_emotion(EXPRESSION_DOWN)
	cases += 1
	if harness_expression != EXPRESSION_DOWN:
		failures.append("失败时没有进入沮丧表情")
	# 执行中的"专注"会被反复下发（每轮任务开始都会设一次），它不能顶掉沮丧。
	set_harness_emotion(EXPRESSION_FOCUS)
	cases += 1
	if harness_expression != EXPRESSION_DOWN:
		failures.append("沮丧保持期内被其他状态覆盖了（失败会瞬间闪掉）")

	# 4. 保持期走完后自动回到平静。
	update_harness_emotion(EXPRESSION_DOWN_HOLD + 0.1)
	cases += 1
	if harness_expression != EXPRESSION_CALM:
		failures.append("沮丧没有在保持期结束后自动收回（会一直难过）")

	# 5. 新的失败重新计时：保持期内再失败必须续期。
	set_harness_emotion(EXPRESSION_DOWN)
	update_harness_emotion(EXPRESSION_DOWN_HOLD - 1.0)
	var remaining := harness_expression_hold
	set_harness_emotion(EXPRESSION_DOWN)
	cases += 1
	if harness_expression_hold <= remaining:
		failures.append("连续失败没有重新计时")
	set_harness_emotion(EXPRESSION_CALM)
	update_harness_emotion(EXPRESSION_DOWN_HOLD + 0.1)

	# 6. 越界值必须被夹紧，不能把未知整数塞进着色器。
	set_harness_emotion(99)
	cases += 1
	if harness_expression != EXPRESSION_DOWN:
		failures.append("越界表情值没有被夹紧到有效范围")
	set_harness_emotion(-5)
	update_harness_emotion(EXPRESSION_DOWN_HOLD + 0.1)
	cases += 1
	if harness_expression != EXPRESSION_CALM:
		failures.append("负数表情值没有被夹紧到平静")

	# 7. 淡入：非立即切换时权重应从未满值开始，不能让表情瞬间跳变。
	# 注意 advance() 对单帧 delta 有上限（防止掉帧时相位跳跃），所以推进必须分多帧，
	# 一帧大 delta 是推不到满值的。
	if layered_character:
		layered_character.set_emotion(layered_character.EMOTION_CALM, true)
		layered_character.set_emotion(layered_character.EMOTION_DOWN)
		cases += 1
		if layered_character.current_emotion_weight() > 0.5:
			failures.append("沮丧表情是瞬间跳变的，没有淡入过程")
		layered_character.advance(0.0, false, Vector2.ZERO, 0.0)
		var weight_after: float = layered_character.current_emotion_weight()
		for _frame in 8:
			layered_character.advance(0.1, false, Vector2.ZERO, 0.0)
		cases += 1
		if layered_character.current_emotion_weight() <= weight_after:
			failures.append("advance() 没有推进表情淡入")
		if not is_equal_approx(layered_character.current_emotion_weight(), 1.0):
			failures.append("表情淡入没有收敛到满值，实际权重=%.3f" % layered_character.current_emotion_weight())
		layered_character.set_emotion(layered_character.EMOTION_CALM, true)

	# 8. 上面那条只验证了 layered_character 自己的淡入；还必须验证常规帧循环不会把它掐掉。
	# 曾经的写法是 update_harness_emotion() 每帧 push 一次"立即生效"，结果 emotion_weight
	# 每帧都被直接设成目标值，淡入永远走不完——表情变成硬切，而第 7 条断言照样通过。
	# 注意：淡入由 layered_character.advance() 推进，所以这里必须同时调用两者，
	# 这才是 _process 里的真实组合（update_harness_emotion + sync_layered_character）。
	harness_expression = EXPRESSION_CALM
	harness_expression_hold = 0.0
	if layered_character:
		layered_character.set_emotion(layered_character.EMOTION_CALM, true)
		set_harness_emotion(EXPRESSION_FOCUS)
		for _tick in 10:
			update_harness_emotion(0.016)
			layered_character.advance(0.016, false, Vector2.ZERO, 0.0)
		var mid_weight: float = layered_character.current_emotion_weight()
		cases += 1
		if mid_weight >= 1.0:
			failures.append("常规帧循环把表情淡入掐掉了（每帧硬切到目标值）")
		if mid_weight <= 0.0:
			failures.append("常规帧循环下表情完全没有推进")
		for _tick in 40:
			update_harness_emotion(0.016)
			layered_character.advance(0.016, false, Vector2.ZERO, 0.0)
		cases += 1
		if not is_equal_approx(layered_character.current_emotion_weight(), 1.0):
			failures.append("常规帧循环下表情淡入没有收敛到满值，实际权重=%.3f" % layered_character.current_emotion_weight())
		layered_character.set_emotion(layered_character.EMOTION_CALM, true)

	harness_expression = previous_expression
	harness_expression_hold = previous_hold
	push_harness_emotion()
	for failure in failures:
		print("HARNESS_EMOTION_FAILURE ", failure)
	print("HARNESS_EMOTION_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", cases, " failures=", failures.size())

# 离屏渲染合成眨眼并检查过渡。返回失败描述列表（空表示通过）。
func check_synthetic_blink() -> Array[String]:
	var failures: Array[String] = []
	var original: Texture2D = load(MODEL_TEXTURE)
	var closed: Texture2D = load(BLINK_TEXTURE)
	if original == null or closed == null:
		failures.append("眨眼检查：缺少原装贴图")
		return failures
	var canvas := Vector2i(1024, 1536)
	var outfit := Image.create(canvas.x, canvas.y, false, Image.FORMAT_RGBA8)
	var skin := Color(0.96, 0.82, 0.72, 1.0)
	var iris := Color(0.15, 0.35, 0.85, 1.0)
	outfit.fill(skin)
	for eye_x in [0.444, 0.544]:
		var center := Vector2(eye_x * canvas.x, 0.182 * canvas.y)
		var radius := Vector2(0.043 * canvas.x, 0.030 * canvas.y)
		for y in range(int(center.y - radius.y * 1.6), int(center.y + radius.y * 1.6)):
			for x in range(int(center.x - radius.x * 1.2), int(center.x + radius.x * 1.2)):
				var local := Vector2((x - center.x) / radius.x, (y - center.y) / radius.y)
				if local.length() <= 1.0:
					outfit.set_pixel(x, y, iris)
	var texture := ImageTexture.create_from_image(outfit)
	if not layered_character.set_appearance(texture):
		failures.append("眨眼检查：测试形象被 set_appearance 拒绝")
		return failures
	var profile: Dictionary = MotionProfile.defaults()
	profile["eyes_calibrated"] = true
	profile["eyes_enabled"] = true
	profile["blink_enabled"] = true
	profile["arm_swing"] = 0.0
	profile["leg_swing"] = 0.0
	profile["hair"] = 0.0
	profile["breath"] = 0.0
	layered_character.set_motion_profile(profile)

	var samples: Array[Color] = []
	var iris_counts: Array[int] = []
	var eye_region := Rect2i(int(0.40 * canvas.x), int(0.155 * canvas.y), int(0.19 * canvas.x), int(0.062 * canvas.y))
	if not await verify_capture_is_live(canvas, profile):
		# headless 的 dummy 渲染驱动不产生可读帧；或者采集通路在当前形状下取不到
		# "会随参数变化的帧"。两种情况下像素断言都不可信，必须报告跳过而不是伪装成通过。
		print("BLINK_RENDER_SKIP 无可用/不可信的渲染帧，跳过像素级检查")
		return failures
	for blink in [0.0, 0.25, 0.5, 0.75, 1.0]:
		# [DSH] 必须显式指定"平静"：上一项检查（verify_capture_is_live）最后停在沮丧，
		# 而沮丧会给眼睑叠 0.30 的闭合基线（着色器里的 emotion_lid），
		# 于是 blink=0.5 时实际闭合已到 0.80，看起来像"过渡是突变的"。
		# 这和 capture_layered_frame 注释里记的 blink 残留是同一类问题，只是发生在情绪上。
		var frame := await capture_layered_frame(canvas, float(blink), layered_character.EMOTION_CALM, true)
		if frame == null:
			print("BLINK_RENDER_SKIP 取不到渲染帧，跳过像素级检查")
			close_layered_capture()
			return failures
		samples.append(frame.get_pixel(int(0.444 * canvas.x), int(0.182 * canvas.y)))
		iris_counts.append(iris_pixel_count(frame, eye_region))
	close_layered_capture()
	print("BLINK_SAMPLES=", samples, " IRIS_COUNTS=", iris_counts)
	if samples[0].b <= samples[0].r:
		failures.append("眨眼检查：睁眼时中心不是虹膜色，测试形象没有生效")
	if samples[4].b >= samples[0].b:
		failures.append("眨眼检查：闭眼后中心仍是虹膜蓝，合成眨眼没有生效")
	# [DSH] 连续过渡原来靠"中间那一帧必须与两端都不同"来判定，而采样点是**瞳孔中心**——
	# 半闭的眼睛本来就还看得见瞳孔（这是对的），中心点天生是二值的：
	# 实测 blink=0.5 时中心仍是纯虹膜色，于是断言误报"过渡是突变的"。
	# 真正该量的是**被眼睑盖住的面积**：虹膜像素数必须单调减少，且不是一步到位。
	if iris_counts[4] >= iris_counts[0]:
		failures.append("眨眼检查：闭眼后虹膜面积没有减少（%d → %d）" % [iris_counts[0], iris_counts[4]])
	var decreasing_steps := 0
	for index in range(1, iris_counts.size()):
		if iris_counts[index] > iris_counts[index - 1]:
			failures.append("眨眼检查：虹膜面积在中途变大了（第 %d 帧）" % index)
		elif iris_counts[index] < iris_counts[index - 1]:
			decreasing_steps += 1
	if decreasing_steps < 2:
		failures.append("眨眼检查：闭眼是一步到位的（只有 %d 个递减阶段），没有连续过渡" % decreasing_steps)
	return failures

# [DSH] 数一数给定区域里有多少"虹膜色"像素。用来量"眼睑盖住了多少"，而不是赌某个像素变色。
func iris_pixel_count(image: Image, area: Rect2i) -> int:
	var count := 0
	for y in range(area.position.y, mini(image.get_height(), area.position.y + area.size.y)):
		for x in range(area.position.x, mini(image.get_width(), area.position.x + area.size.x)):
			var pixel := image.get_pixel(x, y)
			if pixel.a > 0.5 and pixel.b > pixel.r + 0.15 and pixel.b > pixel.g + 0.10:
				count += 1
	return count

# [DSH] 把分层装置放进离屏视口渲染一帧。
#
# 这段代码是本次改动里最容易出错的地方，试错结论必须留下：
#   1) 每帧新建 SubViewport + UPDATE_ONCE，先摆好位置再等两帧：
#      取到的是"视图刚创建时"渲染的那一帧（那时人物还在 (0,0)/0.34，落在画布外），
#      之后无论把参数改成什么都不再重绘 —— 每次调用返回同一张图。
#      这比"跳过检查"更危险：断言看起来在跑，其实一直在比较同一张图。
#   2) UPDATE_ALWAYS + await frame_post_draw：仍是同一张。
#   3) RenderingServer.force_draw()：返回空白帧（当帧新建的视图还没进渲染队列）。
#   4) 在一个**常驻的 UPDATE_ALWAYS 视图**里改参数、等一帧、再取图：这是唯一可靠的顺序。
#      对照实验（同结构、只换成 ColorRect）能依次取到红/绿/蓝，证明取图通路本身没问题。
# 之所以长期没被发现：headless 下取不到帧直接 SKIP，问题被完全遮住。
#
# 另外：自检跑在真实主场景里，_process → sync_layered_character() 每帧都会把角色精灵的
# position/scale 抄到分层装置上，所以采集期间必须让位（layered_frame_capture）。
var layered_frame_capture := false
var layered_capture_viewport: SubViewport

# [DSH] 先确认"取回来的帧真的会随本次要验证的参数变化"，再让像素断言下结论。
#
# 这一步是必需的，因为采集路径已经骗过我一次：早期实现每次调用都返回同一张图，
# 断言语义上"在检查"，实际上一直在比较同一张图。
# 判据必须和后面的检查同源：同样是"静止 profile + 测试形象"，只改 emotion。
# 实测（真实显示、OpenGL 兼容模式）在这种静止形状下，连续帧的哈希完全相同，
# 也就是"参数改了但帧没变"——此时像素断言没有可信度，必须报告跳过。
func verify_capture_is_live(canvas: Vector2i, profile: Dictionary) -> bool:
	if not await open_layered_capture(canvas):
		return false
	layered_character.set_motion_profile(profile)
	var hashes: Array[int] = []
	for emotion in [layered_character.EMOTION_CALM, layered_character.EMOTION_DOWN]:
		var frame := await capture_layered_frame(canvas, 0.0, emotion, true)
		if frame == null:
			close_layered_capture()
			return false
		hashes.append(hash(frame.get_data()))
	var live := hashes[0] != hashes[1]
	if not live:
		print("CAPTURE_NOT_LIVE 参数改变后取回的帧完全相同，像素断言不可信")
	return live

# 打开一个常驻采集视图。返回 false 表示环境不支持取图（headless），调用方应报告跳过。
func open_layered_capture(canvas: Vector2i) -> bool:
	if DisplayServer.get_name() == "headless":
		# dummy 驱动：get_texture() 返回的对象非 null，但取图会在引擎内部报
		# "Parameter t is null"。调用方本来就用"返回 null 就 SKIP"处理这种情况。
		return false
	if layered_capture_viewport:
		close_layered_capture()
	layered_frame_capture = true
	layered_capture_viewport = SubViewport.new()
	layered_capture_viewport.size = canvas
	layered_capture_viewport.transparent_bg = true
	layered_capture_viewport.disable_3d = true
	layered_capture_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(layered_capture_viewport)
	layered_character.reparent(layered_capture_viewport, false)
	layered_character.position = Vector2(canvas) * 0.5
	layered_character.scale = Vector2.ONE
	layered_character.visible = true
	return true

func close_layered_capture() -> void:
	if layered_capture_viewport:
		# 人物必须先挂回角色节点，否则视图释放会把分层装置一起带走。
		layered_character.reparent(character, false)
		layered_capture_viewport.queue_free()
		layered_capture_viewport = null
	layered_frame_capture = false

# 按"当前参数 + blink/emotion"渲染一帧并取回图像。
#
# blink_override 存在的理由：pose() 只在"角色处于运动状态"时才把 blink 写进材质，
# 而上一项检查（眨眼）结束后材质上会残留 blink=1.0（完全闭眼）。实测这个残留会
# 污染后续的表情检查：眼睛被闭合成肤色，"眼下出现虹膜色"这条断言必然失败——
# 看起来像表情没生效，其实是测试自己被上一项检查的残留状态骗了。
# 因此每次采集都显式写入本次要验证的 blink，并在结束后恢复。
func capture_layered_frame(canvas: Vector2i, blink: float, emotion := -1, blink_override := false) -> Image:
	if layered_capture_viewport == null:
		return null
	var previous_blink := 0.0
	if blink_override:
		if layered_character.materials.is_empty():
			return null
		previous_blink = float(layered_character.materials[0].get_shader_parameter("blink"))
	if emotion >= 0:
		layered_character.set_emotion(emotion, true)
	layered_character.visible = true
	layered_character.position = Vector2(canvas) * 0.5
	layered_character.scale = Vector2.ONE
	layered_character.advance(0.0, true, Vector2.ZERO, blink)
	if blink_override:
		for material in layered_character.materials:
			material.set_shader_parameter("blink", clampf(blink, 0.0, 1.0))
	# UPDATE_ALWAYS 保证每帧重绘；等一次 process_frame 让本帧的改动进入绘制，
	# 再等 frame_post_draw 确认绘制真的完成（await process_frame 恢复得太早）。
	#
	# [DSH] 取帧要**有界重试**：真实显示下实测过 get_image() 在视图首次绘制完成之前
	# 会返回 null，原来只等一帧就放弃，于是"眨眼/表情像素检查"会随机退化成 SKIP——
	# 表现是"有屏自检有时报失败、有时报跳过"，同一个缺陷两种症状。
	# 重试仍失败时把可诊断的信息打出来，而不是只留一句"取不到帧"。
	var image: Image = null
	var texture: ViewportTexture = null
	for attempt in 8:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		texture = layered_capture_viewport.get_texture()
		image = texture.get_image() if texture else null
		if image != null:
			break
	if image == null:
		print(
			"CAPTURE_FRAME_NULL attempts=", 8,
			" texture=", texture != null,
			" viewport=", layered_capture_viewport.size,
			" in_tree=", layered_capture_viewport.is_visible_in_tree(),
			" update_mode=", layered_capture_viewport.render_target_update_mode,
			" display=", DisplayServer.get_name()
		)
	if image != null:
		image.convert(Image.FORMAT_RGBA8)
	if blink_override:
		for material in layered_character.materials:
			material.set_shader_parameter("blink", previous_blink)
	return image

# 换装中心自检：守住 apply_light_theme 的两条不变量（不覆盖显式设置、可重复调用）。
func run_outfit_center_selftest() -> void:
	var result: Dictionary = OutfitCenter.selftest()
	var failures: Array = result.get("failures", [])
	# [DSH] 换装请求的代理接线：真实缺陷是"换装自己 new 了 HTTPRequest 却从没设过代理"，
	# 界面只显示"生成失败"，用户根本看不出是代理没生效。
	# Godot 没有读取代理的接口，所以这里断言的是**套用函数的返回值**与**接线真的在**。
	var proxy_cases := 0
	# [DSH] 窗口置顶：默认必须**不置顶**（用户反馈一直置顶体验很差），且开关必须真的作用到窗口上、
	# 选择必须能读回来（否则重启又变回置顶，等于开关无效——这类"开关无效"本仓库踩过）。
	proxy_cases += 1
	if window_topmost:
		failures.append("窗口置顶默认是开着的（用户要求默认取消置顶）")
	proxy_cases += 1
	if get_window().always_on_top:
		failures.append("主窗口启动后仍然是置顶的")
	proxy_cases += 1
	var saved_topmost := window_topmost
	set_window_topmost(true)
	if not window_topmost:
		failures.append("打开置顶开关后开关状态没变")
	proxy_cases += 1
	# 窗口标志本身只在有真实显示时才有意义：headless 的 dummy 驱动不实现置顶，
	# 写进去读回来永远是 false。这里按环境分开，并把跳过原因打出来。
	if DisplayServer.get_name() == "headless":
		print("TOPMOST_WINDOW_STATE_SKIP 无真实显示，跳过窗口置顶标志断言（开关与持久化断言已通过）")
	elif not get_window().always_on_top:
		failures.append("打开置顶开关后主窗口没有置顶")
	proxy_cases += 1
	if soul_store and not bool(soul_store.get_ui_settings().get("window_topmost", false)):
		failures.append("置顶选择没有被写入界面配置（重启会丢）")
	set_window_topmost(saved_topmost)
	proxy_cases += 1
	if window_topmost != saved_topmost:
		failures.append("恢复置顶开关后状态不一致")
	var probe_request := HTTPRequest.new()
	add_child(probe_request)
	proxy_cases += 1
	var applied := NetworkConfigStore.apply_to_request(probe_request, {"enabled": true, "host": "127.0.0.1", "port": 10809})
	if not bool(applied.get("applied", false)) or str(applied.get("host", "")) != "127.0.0.1" or int(applied.get("port", 0)) != 10809:
		failures.append("代理套用函数没有生效：%s" % str(applied))
	proxy_cases += 1
	# 反向：直连时必须显式清空——请求对象是复用的，留着上一次的代理会静默走错出口。
	var cleared := NetworkConfigStore.apply_to_request(probe_request, {"enabled": true, "host": "", "port": -1})
	if bool(cleared.get("applied", true)) or not str(cleared.get("reason", "")).contains("直连"):
		failures.append("代理地址不完整时没有回到直连并清空：%s" % str(cleared))
	probe_request.queue_free()
	proxy_cases += 1
	if not outfit_center or not outfit_center.network_settings_provider.is_valid():
		failures.append("换装中心没有拿到网络设置来源（代理不会生效）")
	proxy_cases += 1
	if outfit_center:
		var live: Dictionary = outfit_center.apply_network_proxy()
		var expected_enabled := bool(resolved_network_settings().get("enabled", false))
		if bool(live.get("applied", false)) != expected_enabled:
			failures.append("换装中心的代理套用结果与当前网络设置不一致：%s" % str(live))
	# 行为级：真跑一次 generate()（指向一个必然连不上的本机端口，不会真的出网），
	# 断言"发请求之前套过代理"，而不只是"套用函数存在"。
	proxy_cases += 1
	var saved_network: Dictionary = network_config.load_config() if network_config else {}
	var saved_proxy_result: Dictionary = outfit_center.last_proxy_result if outfit_center else {}
	var saved_count: int = outfit_center.proxy_apply_count if outfit_center else 0
	if network_config:
		network_config.save_config({"mode": "custom", "proxy_url": "http://127.0.0.1:10809", "no_proxy": "localhost,127.0.0.1,::1"})
	if outfit_center:
		var saved_reference: Image = outfit_center.reference_image
		var saved_endpoint: String = outfit_center.endpoint.text
		var saved_model: String = outfit_center.model.text
		var saved_key: String = outfit_center.key.text
		var saved_timeout: float = outfit_center.timeout_input.value
		outfit_center.reference_image = Image.create(8, 8, false, Image.FORMAT_RGBA8)
		outfit_center.endpoint.text = "http://127.0.0.1:9/v1/images/edits"
		outfit_center.model.text = "selftest-model"
		outfit_center.key.text = "sk-selftest"
		outfit_center.timeout_input.value = 5.0
		outfit_center.generate()
		var waited := 0
		while outfit_center.busy and waited < 240:
			await get_tree().process_frame
			waited += 1
		if outfit_center.proxy_apply_count <= saved_count:
			failures.append("generate() 没有在发请求之前套用代理（换装的代理接线断了）")
		if not bool(outfit_center.last_proxy_result.get("applied", false)):
			failures.append("generate() 套用代理失败：%s" % str(outfit_center.last_proxy_result))
		if int(outfit_center.last_proxy_result.get("port", 0)) != 10809:
			failures.append("generate() 套用的不是当前配置的代理端口：%s" % str(outfit_center.last_proxy_result))
		# 还原现场，别把用户配置留成自检用的代理。
		outfit_center.reference_image = saved_reference
		outfit_center.endpoint.text = saved_endpoint
		outfit_center.model.text = saved_model
		outfit_center.key.text = saved_key
		outfit_center.timeout_input.value = saved_timeout
		outfit_center.last_proxy_result = saved_proxy_result
		outfit_center.proxy_apply_count = saved_count
		outfit_center.set_busy(false)
	if network_config and not saved_network.is_empty():
		network_config.save_config(saved_network)
	# [DSH] 换装 Key 必须能持久化（用户明确要求：换装已经能用了，不要每次重填）。
	# 断言四件事：存得下、读得回、明文不落盘、**新实例启动时会自动回填**。
	proxy_cases += 1
	if outfit_center and soul_store and not soul_store.root_path.is_empty():
		var previous_key: String = outfit_center.load_saved_key()
		var probe_key := "sk-outfit-selftest-9f3a"
		if not outfit_center.save_saved_key(probe_key):
			failures.append("换装 Key 保存失败")
		proxy_cases += 1
		if outfit_center.load_saved_key() != probe_key:
			failures.append("换装 Key 读回来不一致：%s" % outfit_center.load_saved_key())
		proxy_cases += 1
		# 明文绝不能出现在磁盘上（这是"加密保存"的全部意义）。
		var raw := FileAccess.get_file_as_bytes(outfit_center.secret_path)
		if WeKnoraClientScript.bytes_index_of(raw, probe_key.to_utf8_buffer()) >= 0:
			failures.append("换装 Key 以明文形式落在磁盘上")
		proxy_cases += 1
		# 关键：换一个全新实例重新 setup，界面上的 Key 必须已经被填好。
		var restarted := OutfitCenter.new()
		add_child(restarted)
		restarted.setup(soul_store.root_path, load(MODEL_TEXTURE), deepseek_config)
		if str(restarted.key.text).strip_edges() != probe_key:
			failures.append("重启后换装 Key 没有自动回填（用户还得重新粘贴）")
		restarted.queue_free()
		proxy_cases += 1
		# 反向：清空保存后，新实例里必须是空的，而不是残留旧值。
		outfit_center.clear_saved_key()
		if outfit_center.has_saved_key() or not outfit_center.load_saved_key().is_empty():
			failures.append("清除换装 Key 之后仍然读得到")
		# 还原现场：把自检之前的 Key 放回去。
		if not previous_key.is_empty():
			outfit_center.save_saved_key(previous_key)
	for failure in failures:
		print("OUTFIT_CENTER_FAILURE ", str(failure))
	print("OUTFIT_CENTER_SELFTEST=", "PASS" if failures.is_empty() else "FAIL", " cases=", int(result.get("cases", 0)) + proxy_cases, " failures=", failures.size())

func on_outfit_appearance_changed(texture: Texture2D) -> void:
	if dock_side != 0:
		restore_from_edge_dock()
	custom_outfit_active = texture != null
	neutral_texture = texture if texture else load(MODEL_TEXTURE)
	restore_normal_character()
	character_sprite.material = null if custom_outfit_active else character_material
	# 生成形象同样交给分层装置：换装后不再退回 4 顶点的旧显示方式。
	sync_layered_appearance()
func open_outfit_from_cabinet() -> void:
	if outfit_center:
		outfit_center.open()
func open_image_model_settings() -> void:
	if not api_settings_panel.visible:
		open_utility_panel(api_settings_panel, MODEL_SETTINGS_WINDOW_SIZE, Vector2(460, 650))
		populate_api_settings()
	model_center_tabs.current_tab = 1
	api_settings_window.grab_focus()
	if outfit_center:
		outfit_center.key.grab_focus()

func style_image_model_settings(node: Node) -> void:
	if node is Label:
		node.add_theme_color_override("font_color", Color("163f67"))
	elif node is LineEdit or node is OptionButton:
		apply_settings_field_style(node)
	elif node is Button:
		apply_settings_button_style(node, false)
	for child in node.get_children():
		style_image_model_settings(child)
func style_model_center_tabs() -> void:
	var panel := StyleBoxEmpty.new()
	panel.content_margin_top = 12
	model_center_tabs.add_theme_stylebox_override("panel", panel)
	var bar := model_center_tabs.get_tab_bar()
	bar.add_theme_font_size_override("font_size", 15)
	for state in ["tab_selected", "tab_unselected", "tab_hovered", "tab_disabled"]:
		var style := StyleBoxFlat.new()
		style.bg_color = Color("d8efff") if state == "tab_selected" else Color("f3faff")
		style.border_color = Color("65b9ed") if state == "tab_selected" else Color("badced")
		style.set_border_width_all(1)
		style.set_corner_radius_all(8)
		style.content_margin_left = 16
		style.content_margin_right = 16
		style.content_margin_top = 9
		style.content_margin_bottom = 9
		model_center_tabs.add_theme_stylebox_override(state, style)
		bar.add_theme_stylebox_override(state, style)
	for color_name in ["font_selected_color", "font_unselected_color", "font_hovered_color"]:
		model_center_tabs.add_theme_color_override(color_name, Color("173f63"))
		bar.add_theme_color_override(color_name, Color("173f63"))

func style_model_center_dropdowns(node: Node) -> void:
	if node is SpinBox:
		apply_settings_field_style(node.get_line_edit())
	if node is CheckButton:
		for color_name in ["font_color", "font_hover_color", "font_pressed_color", "font_hover_pressed_color", "font_focus_color"]:
			node.add_theme_color_override(color_name, Color("173f63"))
	if node is OptionButton:
		apply_settings_button_style(node, false)
		apply_settings_field_style(node)
	for child in node.get_children():
		style_model_center_dropdowns(child)
