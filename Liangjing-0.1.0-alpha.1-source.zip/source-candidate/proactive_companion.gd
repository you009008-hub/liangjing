# 空闲主动开口的纯决策层。该功能由用户显式开启后才会运行。
class_name BlueWhaleProactiveCompanion
extends RefCounted

const IDLE_BEFORE_FIRST := 150.0
const MIN_GAP_BETWEEN := 420.0
const MAX_PER_SESSION := 3
const AWAY_THRESHOLD := 7200.0


static func decide(context: Dictionary) -> Dictionary:
    var idle := float(context.get("idle_seconds", 0.0))
    var spoken := int(context.get("spoken_count", 0))
    var since_spoken := float(context.get("seconds_since_last_spoken", -1.0))
    var since_conversation := float(context.get("last_conversation_seconds", -1.0))
    if bool(context.get("chat_busy", false)):
        return _no("任务执行中")
    if bool(context.get("workspace_open", false)):
        return _no("对话工作区已打开")
    if spoken >= MAX_PER_SESSION:
        return _no("本次已达到主动开口上限")
    if idle < IDLE_BEFORE_FIRST:
        return _no("安静时间不足")
    if since_spoken >= 0.0 and since_spoken < MIN_GAP_BETWEEN:
        return _no("距上次开口时间不足")
    if since_conversation < 0.0:
        return _no("没有可用的非归档会话记录")
    if since_conversation >= AWAY_THRESHOLD:
        var hours := int(since_conversation / 3600.0)
        if hours >= 24:
            return _yes("离开超过一天", "上次的事情搁了 %d 天，要不要接着看？" % int(hours / 24))
        return _yes("离开数小时", "上次的事情搁了 %d 小时，要不要接着看？" % hours)
    return _no("距上次对话时间较短")


# SoulStore 保存的是本地时间文本；Godot 的字符串解析按 UTC 解释，需减去本地 UTC 偏移。
static func elapsed_since_local_datetime(text: String, now_unix: float, utc_offset_minutes: int) -> float:
    var parsed := Time.get_unix_time_from_datetime_string(text.strip_edges())
    if parsed <= 0:
        return -1.0
    var actual_unix := float(parsed) - float(utc_offset_minutes * 60)
    return maxf(0.0, now_unix - actual_unix)


static func advance_since_spoken(current: float, delta: float) -> float:
    if current < 0.0:
        return current
    return current + maxf(0.0, delta)


static func _no(reason: String) -> Dictionary:
    return {"speak": false, "reason": reason, "text": ""}


static func _yes(reason: String, message: String) -> Dictionary:
    return {"speak": true, "reason": reason, "text": message}


static func selftest() -> Dictionary:
    var failures: Array[String] = []
    var cases := 0
    var base := {
        "idle_seconds": 600.0, "chat_busy": false, "workspace_open": false,
        "spoken_count": 0, "seconds_since_last_spoken": -1.0,
        "last_conversation_seconds": 8000.0,
        "last_conversation_title": "不应显示的私人标题"
    }
    var normal := decide(base)
    cases += 1
    if not bool(normal.get("speak", false)):
        failures.append("满足条件时没有开口")
    cases += 1
    if str(normal.get("text", "")).contains("私人标题"):
        failures.append("主动气泡泄露了会话标题")
    for field in ["chat_busy", "workspace_open"]:
        var blocked := base.duplicate(true)
        blocked[field] = true
        cases += 1
        if bool(decide(blocked).get("speak", false)):
            failures.append("%s=true 时仍主动开口" % field)
    var maxed := base.duplicate(true)
    maxed["spoken_count"] = MAX_PER_SESSION
    cases += 1
    if bool(decide(maxed).get("speak", false)):
        failures.append("达到次数上限后仍开口")
    var too_soon := base.duplicate(true)
    too_soon["seconds_since_last_spoken"] = MIN_GAP_BETWEEN - 1.0
    cases += 1
    if bool(decide(too_soon).get("speak", false)):
        failures.append("间隔不足时仍开口")
    var just_enough := base.duplicate(true)
    just_enough["seconds_since_last_spoken"] = MIN_GAP_BETWEEN
    cases += 1
    if not bool(decide(just_enough).get("speak", false)):
        failures.append("达到最小间隔后没有开口")
    var no_history := base.duplicate(true)
    no_history["last_conversation_seconds"] = -1.0
    cases += 1
    if bool(decide(no_history).get("speak", false)):
        failures.append("没有会话记录时仍开口")
    cases += 1
    if advance_since_spoken(0.0, MIN_GAP_BETWEEN) != MIN_GAP_BETWEEN:
        failures.append("上次开口计时没有累加")
    cases += 1
    if advance_since_spoken(-1.0, 20.0) != -1.0:
        failures.append("从未开口状态被错误推进")
    var parsed := Time.get_unix_time_from_datetime_string("2026-09-14 17:00:00")
    cases += 1
    if elapsed_since_local_datetime("2026-09-14 17:00:00", float(parsed), 480) != 28800.0:
        failures.append("UTC+8 本地时间换算错误")
    cases += 1
    if elapsed_since_local_datetime("坏时间", float(parsed), 480) != -1.0:
        failures.append("坏时间戳没有被拒绝")
    return {"ok": failures.is_empty(), "failures": failures, "cases": cases}
