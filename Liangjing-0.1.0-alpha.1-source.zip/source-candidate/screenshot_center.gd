# [DSH] 本文件包含 DeepSeek Harness 的改动（2026-09-11）。
# [DSH] 新增：区域截图提问（全屏框选 + 冻结帧裁剪）。
# [DSH] 本项目代码由 GPT 与本代理双方改动，此标记用于区分归属；未标注部分为 GPT 的改动。
# 区域截图器。
#
# 用途：让用户直接框选屏幕上一块区域，交给梁鲸的视觉链路识别与提问，
# 不必先自己截图、存文件、再拖进来。
#
# 设计要点：
# 1. 覆盖窗口是全屏、无边框、置顶的独立原生窗口，只在框选期间存在，关掉即释放。
# 2. 冻结帧（截图）与遮罩层在同一窗口内：遮罩只是压暗未选中区域，因此用户看到的
#    底图就是被裁剪的同一份像素，不存在“看到的和拿到的不一致”。
# 3. 不依赖任何全局鼠标钩子：用窗口自身的 GUI 输入处理鼠标，Esc 或右键取消。
# 4. 裁剪与归一化是纯函数（static），因此可以脱离屏幕单独自检。
class_name BlueWhaleScreenshotCenter
extends Node

# 截图成功的回调，参数为 Image（PNG 可编码的 RGBA8）。
signal captured(image: Image)
signal cancelled

const MIN_SELECTION := 8.0
const DIM_COLOR := Color(0.02, 0.07, 0.14, 0.42)
const EDGE_COLOR := Color(0.28, 0.78, 1.0, 1.0)
const FILL_COLOR := Color(0.28, 0.78, 1.0, 0.10)

var window: Window
var overlay: Control
var hint_panel: PanelContainer
var hint_label: Label
var frozen: Image
var pressing := false
var dragging := false
var press_point := Vector2.ZERO
var current_point := Vector2.ZERO
var selecting := false

func setup(owner_node: Node) -> void:
	window = Window.new()
	window.name = "ScreenshotOverlay"
	window.title = "梁鲸 · 框选截图"
	window.borderless = true
	window.transparent = true
	window.always_on_top = true
	window.unresizable = true
	window.transient = false
	window.exclusive = false
	window.visible = false
	owner_node.add_child(window)

	overlay = Control.new()
	overlay.name = "SelectionOverlay"
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.draw.connect(draw_overlay)
	overlay.gui_input.connect(on_overlay_input)
	window.add_child(overlay)

	hint_panel = PanelContainer.new()
	hint_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.02, 0.16, 0.30, 0.88)
	style.border_color = Color(0.33, 0.79, 1.0, 0.82)
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 9
	style.content_margin_bottom = 9
	hint_panel.add_theme_stylebox_override("panel", style)
	window.add_child(hint_panel)
	hint_label = Label.new()
	hint_label.text = "拖动框选要提问的区域 · Esc 或右键取消"
	hint_label.add_theme_color_override("font_color", Color(0.88, 0.97, 1.0))
	hint_label.add_theme_font_size_override("font_size", 14)
	hint_panel.add_child(hint_label)

# 打开框选窗口。返回 {"ok": bool, "error": String}。
# 失败必须给出原因：用户按下快捷方式却什么都没出现时，需要知道是权限问题还是多屏问题。
func open() -> Dictionary:
	# 无显示环境（headless、远程会话被裁剪）下不要尝试抓屏，否则拿到的是一张空图，
	# 用户会以为是框选没生效。
	if DisplayServer.get_screen_count() <= 0:
		return {"ok": false, "error": "当前没有可用屏幕，无法截图"}
	var screen_index := DisplayServer.window_get_current_screen()
	var rect := DisplayServer.screen_get_usable_rect(screen_index)
	if rect.size.x < 16 or rect.size.y < 16:
		return {"ok": false, "error": "没有取到可用屏幕区域"}
	frozen = capture_screen_region(rect)
	if frozen == null or frozen.is_empty():
		return {"ok": false, "error": "屏幕捕获失败：没有拿到画面内容"}
	window.current_screen = screen_index
	window.position = rect.position
	window.size = rect.size
	overlay.size = Vector2(rect.size)
	hint_panel.position = Vector2(18, 18)
	hint_panel.size = Vector2.ZERO
	selecting = false
	pressing = false
	dragging = false
	window.show()
	window.move_to_foreground()
	window.grab_focus()
	overlay.queue_redraw()
	return {"ok": true}

func close() -> void:
	window.hide()
	selecting = false
	pressing = false
	dragging = false
	frozen = null

func cancel() -> void:
	close()
	cancelled.emit()

# 抓取屏幕矩形。Godot 的 get_screen_get_image 需要 px 为真才返回可保存的像素数据。
func capture_screen_region(rect: Rect2i) -> Image:
	var image := DisplayServer.screen_get_image(DisplayServer.window_get_current_screen())
	if image == null or image.is_empty():
		return null
	# 多屏或缩放场景下，取到的图像可能比 usable_rect 大或小，这里按实际尺寸收敛。
	var usable := Rect2i(Vector2i.ZERO, image.get_size())
	var target := rect.intersection(usable)
	if target.size.x < 16 or target.size.y < 16:
		return null
	var region := image.get_region(target)
	if region == null or region.is_empty():
		return null
	region.convert(Image.FORMAT_RGBA8)
	return region

func selection_rect() -> Rect2:
	var start := press_point.min(current_point)
	var end := press_point.max(current_point)
	return Rect2(start, end - start)

func on_overlay_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		cancel()
		return
	if not event is InputEventMouseButton:
		if event is InputEventMouseMotion and pressing:
			current_point = event.position
			dragging = true
			overlay.queue_redraw()
		return
	if event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		cancel()
		return
	if event.button_index != MOUSE_BUTTON_LEFT:
		return
	if event.pressed:
		pressing = true
		dragging = false
		press_point = event.position
		current_point = event.position
		overlay.queue_redraw()
		return
	pressing = false
	current_point = event.position
	var picked := selection_rect()
	# 单击而不是拖动时视为取消：避免用一个几像素的误触区域去问模型。
	if not dragging or picked.size.x < MIN_SELECTION or picked.size.y < MIN_SELECTION:
		cancel()
		return
	var cropped := crop_to_selection(frozen, picked)
	close()
	if cropped == null or cropped.is_empty():
		cancelled.emit()
		return
	captured.emit(cropped)

func draw_overlay() -> void:
	if not overlay:
		return
	var full := Rect2(Vector2.ZERO, overlay.size)
	if not frozen or frozen.is_empty():
		overlay.draw_rect(full, Color(0.02, 0.07, 0.14, 0.85), true)
		return
	# 先把可用区域整体压暗，再把选中区域的原图贴回去，用户看到的就是最终会被裁走的内容。
	overlay.draw_rect(full, DIM_COLOR, true)
	if not selecting and not pressing:
		return
	var picked := selection_rect()
	if picked.size.x < 1.0 or picked.size.y < 1.0:
		return
	var source := Rect2(picked.position, picked.size)
	overlay.draw_texture_rect_region(ImageTexture.create_from_image(frozen), picked, source)
	overlay.draw_rect(picked, FILL_COLOR, true)
	overlay.draw_rect(picked, EDGE_COLOR, false, 2.0)

# 框选 → 裁剪。纯几何部分单独成静态函数，便于无语屏幕自检。
static func crop_to_selection(source: Image, selection: Rect2) -> Image:
	if source == null or source.is_empty():
		return null
	var pixels := selection_to_pixels(selection, source.get_size())
	if pixels.size.x < 1 or pixels.size.y < 1:
		return null
	var region := source.get_region(pixels)
	if region == null or region.is_empty():
		return null
	# 统一成 RGBA8：下游 PNG 编码与视觉模型都按这个格式处理。
	region.convert(Image.FORMAT_RGBA8)
	return region

# 把浮点框选换算成整数像素矩形，并夹紧到图像范围内。
# 允许零面积输入但返回空矩形，调用方据此判定为无效选择。
static func selection_to_pixels(selection: Rect2, bounds: Vector2i) -> Rect2i:
	if bounds.x <= 0 or bounds.y <= 0:
		return Rect2i()
	var left := int(floor(selection.position.x))
	var top := int(floor(selection.position.y))
	var right := int(ceil(selection.position.x + selection.size.x))
	var bottom := int(ceil(selection.position.y + selection.size.y))
	left = clampi(left, 0, bounds.x)
	top = clampi(top, 0, bounds.y)
	right = clampi(right, 0, bounds.x)
	bottom = clampi(bottom, 0, bounds.y)
	return Rect2i(Vector2i(left, top), Vector2i(maxi(0, right - left), maxi(0, bottom - top)))

# 自检：覆盖像素换算的取整、夹紧、零面积与越界，以及裁剪结果的尺寸与格式。
static func selftest() -> Dictionary:
	var failures: Array[String] = []
	# [框选, 边界, 期望矩形]
	var cases := [
		[Rect2(10, 20, 30, 40), Vector2i(100, 100), Rect2i(10, 20, 30, 40)],
		[Rect2(10.4, 20.6, 30.2, 40.3), Vector2i(100, 100), Rect2i(10, 20, 31, 41)],
		[Rect2(-20, -20, 50, 50), Vector2i(100, 100), Rect2i(0, 0, 30, 30)],
		[Rect2(80, 80, 50, 50), Vector2i(100, 100), Rect2i(80, 80, 20, 20)],
		[Rect2(10, 10, 0, 0), Vector2i(100, 100), Rect2i(10, 10, 0, 0)],
		[Rect2(10, 10, 5, 5), Vector2i(0, 0), Rect2i()],
	]
	for case_value in cases:
		var case: Array = case_value
		var observed := selection_to_pixels(case[0], case[1])
		if observed != case[2]:
			failures.append("selection_to_pixels(%s, %s) = %s，期望 %s" % [case[0], case[1], observed, case[2]])

	# 裁剪：尺寸、格式与内容都要对得上。
	var source := Image.create(40, 30, false, Image.FORMAT_RGBA8)
	source.fill(Color(0.1, 0.2, 0.3, 1.0))
	var cropped := crop_to_selection(source, Rect2(5, 6, 10, 8))
	if cropped == null:
		failures.append("crop_to_selection 返回空")
	else:
		if cropped.get_size() != Vector2i(10, 8):
			failures.append("裁剪尺寸应为 (10, 8)，实际 %s" % cropped.get_size())
		if cropped.get_format() != Image.FORMAT_RGBA8:
			failures.append("裁剪结果应统一为 RGBA8，实际格式=%d" % cropped.get_format())
	if crop_to_selection(source, Rect2(0, 0, 0, 0)) != null:
		failures.append("零面积框选应当返回空而不是一张空图")
	if crop_to_selection(null, Rect2(0, 0, 4, 4)) != null:
		failures.append("空源图应当返回空")
	# 越界框选必须被夹紧到图像内，不能崩。
	var clamped := crop_to_selection(source, Rect2(35, 25, 50, 50))
	if clamped == null or clamped.get_size() != Vector2i(5, 5):
		failures.append("越界框选应夹紧为 (5, 5)，实际 %s" % (clamped.get_size() if clamped else "null"))
	return {"ok": failures.is_empty(), "failures": failures, "cases": cases.size() + 4}
